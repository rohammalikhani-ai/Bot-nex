# -*- coding: utf-8 -*-
"""
Context کوتاه‌مدت برای لایه‌ی Natural Language.

هدف (بخش 10 و 20 پرامپت): وقتی کاربر می‌گه «این کاربر رو mute کن» و ربات
می‌پرسه «برای چه مدتی؟»، جواب بعدی کاربر («یک ساعت») باید به همون درخواست
قبلی وصل بشه — نه این‌که یک intent جدید و بی‌ربط حساب بشه.

طراحی عمداً خیلی ساده و کاملاً مستقل از telegram نگه داشته شده تا:
  1) به‌راحتی و بدون وابستگی به python-telegram-bot تست بشه.
  2) امن باشه: هر context فقط برای یک (chat_id, user_id) مشخص، فقط برای
     مدت محدود (TTL) و فقط با یک بار مصرف (pop) قابل استفاده‌ست.

این یک state ماشین کامل نیست؛ فقط یک TTL cache در حافظه است. اگر ربات
ری‌استارت بشه، contextهای در حال انتظار پاک می‌شن — که عمداً قابل قبوله
(به‌جای نگه‌داشتن حالت قدیمی/ناهماهنگ).
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

DEFAULT_TTL_SECONDS = 120


@dataclass
class _Entry:
    payload: dict
    expires_at: float


class ContextStore:
    """Store عمومی برای دو نوع داده:

    1) pending follow-up به ازای (chat_id, user_id) — مثلاً «منتظر مدت‌زمان mute».
       با put_pending/pop_pending/peek_pending کار می‌کنه.
    2) token-based payload برای دکمه‌های تایید/لغو (چون callback_data تلگرام
       محدودیت طول داره و نمی‌شه کل جزئیات را داخلش نوشت). با put_token/
       pop_token کار می‌کنه.
    """

    def __init__(self, ttl_seconds: int = DEFAULT_TTL_SECONDS):
        self._ttl = ttl_seconds
        self._pending: dict[tuple[int, int], _Entry] = {}
        self._tokens: dict[str, _Entry] = {}

    # ---------------- pending follow-up (per chat+user) ----------------

    def put_pending(self, chat_id: int, user_id: int, payload: dict, ttl_seconds: Optional[int] = None) -> None:
        self._purge()
        ttl = ttl_seconds if ttl_seconds is not None else self._ttl
        self._pending[(chat_id, user_id)] = _Entry(payload=payload, expires_at=time.time() + ttl)

    def pop_pending(self, chat_id: int, user_id: int) -> Optional[dict]:
        self._purge()
        entry = self._pending.pop((chat_id, user_id), None)
        return entry.payload if entry else None

    def peek_pending(self, chat_id: int, user_id: int) -> Optional[dict]:
        self._purge()
        entry = self._pending.get((chat_id, user_id))
        return entry.payload if entry else None

    def clear_pending(self, chat_id: int, user_id: int) -> None:
        self._pending.pop((chat_id, user_id), None)

    # ---------------- token-based payload (for confirm/cancel buttons) --

    def put_token(self, payload: dict, ttl_seconds: Optional[int] = None) -> str:
        self._purge()
        ttl = ttl_seconds if ttl_seconds is not None else self._ttl
        token = uuid.uuid4().hex[:12]
        self._tokens[token] = _Entry(payload=payload, expires_at=time.time() + ttl)
        return token

    def pop_token(self, token: str) -> Optional[dict]:
        self._purge()
        entry = self._tokens.pop(token, None)
        return entry.payload if entry else None

    def peek_token(self, token: str) -> Optional[dict]:
        self._purge()
        entry = self._tokens.get(token)
        return entry.payload if entry else None

    # ---------------- housekeeping ----------------

    def _purge(self) -> None:
        now = time.time()
        expired_pending = [k for k, v in self._pending.items() if v.expires_at <= now]
        for k in expired_pending:
            del self._pending[k]
        expired_tokens = [k for k, v in self._tokens.items() if v.expires_at <= now]
        for k in expired_tokens:
            del self._tokens[k]


# یک instance مشترک برای کل پروسه — کافیه، چون ربات تک-پروسه اجرا می‌شه
# (همون فرضی که repositories/store.py هم برای sqlite دارد).
context_store = ContextStore()
