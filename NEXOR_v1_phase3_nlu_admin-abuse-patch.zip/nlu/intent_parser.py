# -*- coding: utf-8 -*-
"""
Intent Parser — لایه‌ی اول و دوم Smart Router (بخش 6 پرامپت):

    User Message
        -> Fast Local Understanding (این ماژول)
        -> شناخته‌شد؟ -> اجرای capability موجود
        -> نه -> (خارج از اسکوپ این نسخه: AI Copilot، در صورت وجود)

این ماژول عمداً کاملاً مستقل از telegram/python-telegram-bot نوشته شده تا:
  - بدون نصب کتابخانه‌ی تلگرام قابل import و تست باشد،
  - قابل استفاده‌ی مجدد در هر context دیگری (مثلاً تست خودکار) هم باشد.

معماری واژگان: از همون locales/<lang>.py::TEXT_TRIGGERS به‌عنوان هسته‌ی
واژگان هر زبان استفاده می‌کنیم (طبق دستور صریح پرامپت: «سیستم ترجمه‌ی دوم
نساز؛ همون i18n موجود را گسترش بده»). این فایل هیچ رشته‌ی خروجی/ترجمه‌ای
تولید نمی‌کند و هیچ کلید جدیدی به STRINGS اضافه نمی‌کند — فقط برای فهمیدن
ورودی کاربر، چند مترادف اضافه (فعل/اسم) را که در TEXT_TRIGGERS نیست (چون
آن سیستم فقط برای Alias دقیق طراحی شده، نه NLU) نگه می‌دارد؛ خروجی/پاسخ‌ها
همچنان از همان STRINGS موجود می‌آیند.

محدودیت شناخته‌شده (صادقانه اعلام می‌شود): پوشش واژگان «مدت‌زمان به‌صورت
کلمه» (مثل «یک ساعت») فقط برای fa و en کامل تست شده؛ برای ar/tr/es/ru فقط
فرمت «عدد+واحد» (مثل «2 hours») پشتیبانی می‌شود، نه عدد به‌صورت کلمه.
"""
from __future__ import annotations

import importlib
import re
from dataclasses import dataclass, field
from typing import Optional

from utils import parse_duration  # اکنون بدون وابستگی به telegram قابل import است
from nlu import learned_phrases

SUPPORTED_LANGS = ("fa", "en", "ar", "tr", "es", "ru")
DEFAULT_LANG = "fa"

# لیست کامل intentهایی که natural_language.py می‌تونه اجرا کنه — هم لایه‌ی
# سریع (این فایل) و هم لایه‌ی AI (ai_copilot/prompts.py::interpret_request_prompt)
# دقیقاً همین اسم‌ها رو برمی‌گردونن؛ هر جا AI اسمی خارج از این لیست برگردونه
# (توهم/اشتباه مدل)، باید نادیده گرفته بشه — هیچ‌وقت به AI اعتماد کور نکن.
KNOWN_INTENTS = (
    "mute_user", "unmute_user", "ban_user", "unban_user", "kick_user", "warn_user",
    "delete_message", "configure_link_protection", "show_security_status",
    "update_rules", "show_rules", "list_auto_answers", "create_auto_answer",
    "delete_auto_answer", "group_health_report", "show_moderation_report", "help",
    # ==================== Phase 3 (گسترش NLU آزاد) ====================
    # فقط دستورهای بدون‌پارامتر یا enable/disable ساده اضافه شدن — عمداً از
    # دستورهایی که پارامتر آزاد/عددی/متنی حساس دارن (setflood, setmaxwarns,
    # createprofile, importsettings, schedulerecurring, buyplan و ...)
    # صرف‌نظر شد، چون طبق بخش 9 برای اون‌ها حدس‌زدن entity توسط لایه‌ی
    # سریع یا AI خطرناک/نادرسته — همون‌ها فقط از مسیر Dictionary (عبارت
    # دقیق در handlers/text_commands.py) قابل اجرا می‌مونن.
    "configure_mention_protection", "configure_antispam", "configure_dupcross",
    "show_ads_list", "show_my_ads", "show_ad_admin_queue",
    "show_daily_notify_menu", "show_daily_assets",
    "test_daily_price", "test_daily_news", "show_recurring_posts",
)

# ---------------------------------------------------------------------------
# 1) واژگان: تا جای ممکن از TEXT_TRIGGERS موجود هر زبان استفاده می‌کنیم.
# ---------------------------------------------------------------------------

_TRIGGERS_CACHE: dict[str, dict] = {}


def _text_triggers(lang: str) -> dict:
    if lang not in _TRIGGERS_CACHE:
        try:
            mod = importlib.import_module(f"locales.{lang}")
        except ImportError:
            mod = importlib.import_module(f"locales.{DEFAULT_LANG}")
        _TRIGGERS_CACHE[lang] = getattr(mod, "TEXT_TRIGGERS", {}) or {}
    return _TRIGGERS_CACHE[lang]


def _words_for(lang: str, cmd_id: str) -> list[str]:
    return [w.casefold() for w in _text_triggers(lang).get(cmd_id, [])]


# مترادف‌های اضافه که در TEXT_TRIGGERS نیستند (چون آنجا فقط Alias دقیق
# دستور تعریف می‌شود، نه مفاهیم آزاد زبان طبیعی مثل «جلوی لینک رو بگیر»).
_LINK_NOUNS = {
    "fa": ["لینک", "لینکها", "لینک‌ها", "لینک ها"],
    "en": ["link", "links"],
    "ar": ["رابط", "الرابط", "الروابط", "روابط"],
    "tr": ["bağlantı", "bağlantıları", "link", "linkler"],
    "es": ["enlace", "enlaces", "link", "links"],
    "ru": ["ссылка", "ссылки", "ссылку", "линк"],
}

_BLOCK_VERBS = {
    "fa": ["ببند", "ببندی", "مسدود", "قفل", "جلوشو بگیر", "جلوگیری", "بگیر"],
    "en": ["block", "stop", "close", "disable", "prevent", "lock"],
    "ar": ["امنع", "احظر", "اغلق", "قفل", "امنعي"],
    "tr": ["engelle", "kapat", "kilitle", "durdur"],
    "es": ["bloquea", "bloquear", "cierra", "prohíbe", "prohibir"],
    "ru": ["заблокируй", "закрой", "запрети", "останови"],
}

_ALLOW_VERBS = {
    "fa": ["باز کن", "بازکن", "اجازه بده", "فعال نکن", "برندار"],
    "en": ["allow", "unblock", "open", "unlock", "enable"],
    "ar": ["افتح", "اسمح", "فعل"],
    "tr": ["aç", "izin ver", "kaldır"],
    "es": ["permite", "permitir", "abre", "desbloquea"],
    "ru": ["разреши", "открой", "разблокируй"],
}

_MUTE_VERBS = {
    "fa": ["سکوت", "میوت", "mute", "ساکت کن", "ساکتش کن"],
    "en": ["mute"],
    "ar": ["كتم", "اسكت", "mute"],
    "tr": ["sustur", "mute"],
    "es": ["silenciar", "mutear", "silencia"],
    "ru": ["мут", "замьютить", "заглуши"],
}

_UNMUTE_VERBS = {
    "fa": _words_for("fa", "unmute") + ["سکوتشو بردار"],
    "en": _words_for("en", "unmute"),
    "ar": _words_for("ar", "unmute"),
    "tr": _words_for("tr", "unmute"),
    "es": _words_for("es", "unmute"),
    "ru": _words_for("ru", "unmute"),
}

_BAN_VERBS = {
    "fa": _words_for("fa", "ban") + ["بنش کن"],
    "en": _words_for("en", "ban"),
    "ar": _words_for("ar", "ban"),
    "tr": _words_for("tr", "ban"),
    "es": _words_for("es", "ban"),
    "ru": _words_for("ru", "ban"),
}

_UNBAN_VERBS = {
    "fa": _words_for("fa", "unban"),
    "en": _words_for("en", "unban"),
    "ar": _words_for("ar", "unban"),
    "tr": _words_for("tr", "unban"),
    "es": _words_for("es", "unban"),
    "ru": _words_for("ru", "unban"),
}

_KICK_VERBS = {
    "fa": _words_for("fa", "kick"),
    "en": _words_for("en", "kick"),
    "ar": _words_for("ar", "kick"),
    # نکته‌ی مهم (باگ واقعی که تست پیدا کرد): TEXT_TRIGGERS ترکی برای "kick"
    # فقط "at" است — یک کلمه‌ی ۲ حرفی که substring خیلی از کلمات دیگه‌ست
    # (مثلاً داخل "saat" = ساعت). با قانون کلمه‌ی کوتاه در _contains_any
    # (فقط تطبیق دقیق توکن) این مشکل رفع شده، ولی برای اطمینان بیشتر یک
    # مترادف بلندتر هم اضافه شده.
    "tr": _words_for("tr", "kick") + ["gruptan at"],
    "es": _words_for("es", "kick"),
    "ru": _words_for("ru", "kick"),
}

_WARN_VERBS = {
    "fa": _words_for("fa", "warn"),
    "en": _words_for("en", "warn"),
    "ar": _words_for("ar", "warn"),
    "tr": _words_for("tr", "warn"),
    "es": _words_for("es", "warn"),
    "ru": _words_for("ru", "warn"),
}

_DELETE_VERBS = {
    "fa": _words_for("fa", "del") + ["پاک کن", "پاکش کن"],
    "en": _words_for("en", "del") + ["remove this message"],
    "ar": _words_for("ar", "del"),
    "tr": _words_for("tr", "del"),
    "es": _words_for("es", "del"),
    "ru": _words_for("ru", "del"),
}

_HELP_NOUNS = {
    "fa": _words_for("fa", "help") + ["راهنمایی"],
    "en": _words_for("en", "help"),
    "ar": _words_for("ar", "help"),
    "tr": _words_for("tr", "help"),
    "es": _words_for("es", "help"),
    "ru": _words_for("ru", "help"),
}

# اسم‌های "قوانین"/"rules" مستقیماً از TEXT_TRIGGERS خونده می‌شن (تابع
# _rules_nouns پایین)، چون همون کلمه‌ای که برای Alias استفاده می‌شه دقیقاً
# همون چیزیه که برای تشخیص NLU هم لازمه — نیازی به مترادف اضافه نیست.


def _rules_nouns(lang: str) -> list[str]:
    return _words_for(lang, "rules")


def _locks_nouns(lang: str) -> list[str]:
    # برای «وضعیت امنیتی/قفل‌ها رو نشون بده» — از همون Alias دقیق "locks" استفاده می‌شه.
    return _words_for(lang, "locks")


def _open_reports_nouns(lang: str) -> list[str]:
    # برای «گزارش‌های باز رو نشون بده» — از همون Alias دقیق "reports" استفاده می‌شه.
    return _words_for(lang, "reports")


def _setanswer_phrases(lang: str) -> list[str]:
    return _words_for(lang, "setanswer")


def _delanswer_phrases(lang: str) -> list[str]:
    return _words_for(lang, "delanswer")


def _setrules_phrases(lang: str) -> list[str]:
    # از همون Alias موجود "setrules" استفاده می‌شه (بخش 3/4 پرامپت: سیستم
    # ترجمه‌ی دوم نساز) — همیشه یک عبارت چندکلمه‌ای در هر ۶ زبان.
    return _words_for(lang, "setrules")


def _answerlist_phrases(lang: str) -> list[str]:
    return _words_for(lang, "answerlist")


def _group_health_phrases(lang: str) -> list[str]:
    # فقط همون عبارت Alias موجود «سلامت گروه» رو با تحمل فرم سؤالی تشخیص
    # می‌ده (مثل «وضعیت گروه چطوره؟») — عمداً کلمات عمومی مثل «اسپم» یا
    # «چیکار کنم» رو trigger نمی‌کنه، چون این intent هزینه‌ی واقعی (یک
    # فراخوان AI) داره؛ trigger گسترده یعنی هزینه‌ی بی‌مورد و نویز (بخش 6/19).
    return _words_for(lang, "aihealth")


# --- Phase 3 (گسترش NLU آزاد): اسم‌های ساده‌ی دستورهای بدون‌پارامتر —
# مستقیماً از همون TEXT_TRIGGERS که در Phase 3 برای Dictionary اضافه شد
# استفاده می‌شه (بخش 3/4 پرامپت: سیستم ترجمه‌ی دوم نساز).

def _ads_list_nouns(lang: str) -> list[str]:
    return _words_for(lang, "ads")


def _my_ads_nouns(lang: str) -> list[str]:
    return _words_for(lang, "myads")


def _ad_admin_nouns(lang: str) -> list[str]:
    return _words_for(lang, "adadmin")


def _daily_notify_nouns(lang: str) -> list[str]:
    return _words_for(lang, "dailynotify")


def _daily_assets_nouns(lang: str) -> list[str]:
    return _words_for(lang, "dailyassets")


def _test_daily_price_phrases(lang: str) -> list[str]:
    return _words_for(lang, "testdailyprice")


def _test_daily_news_phrases(lang: str) -> list[str]:
    return _words_for(lang, "testdailynews")


def _recurring_posts_nouns(lang: str) -> list[str]:
    return _words_for(lang, "recurringposts")


# enable/disable toggleها (mention protection / antispam / dupcross): همون
# اسم دقیقاً از TEXT_TRIGGERS دستور خودش می‌آد؛ جهت (فعال/غیرفعال) از همون
# _BLOCK_VERBS/_ALLOW_VERBS مشترکی که configure_link_protection هم استفاده
# می‌کنه تشخیص داده می‌شه — یک واژگان جدید برای فعل‌ها ساخته نمی‌شه.

def _mention_protection_nouns(lang: str) -> list[str]:
    return _words_for(lang, "mentionprotection")


def _antispam_nouns(lang: str) -> list[str]:
    return _words_for(lang, "antispam")


def _dupcross_nouns(lang: str) -> list[str]:
    return _words_for(lang, "dupcross")


# ---------------------------------------------------------------------------
# 2) استخراج مدت‌زمان از متن آزاد (نه فقط توکن فشرده مثل "1h")
# ---------------------------------------------------------------------------

_UNIT_WORDS = {
    "fa": {"ثانیه": "s", "دقیقه": "m", "ساعت": "h", "روز": "d", "هفته": "w"},
    "en": {
        "second": "s", "seconds": "s", "sec": "s",
        "minute": "m", "minutes": "m", "min": "m",
        "hour": "h", "hours": "h",
        "day": "d", "days": "d",
        "week": "w", "weeks": "w",
    },
    "ar": {"ثانية": "s", "دقيقة": "m", "دقائق": "m", "ساعة": "h", "ساعات": "h", "يوم": "d", "أيام": "d"},
    "tr": {"saniye": "s", "dakika": "m", "saat": "h", "gün": "d", "hafta": "w"},
    "es": {
        "segundo": "s", "segundos": "s", "minuto": "m", "minutos": "m",
        "hora": "h", "horas": "h", "día": "d", "días": "d", "dia": "d", "dias": "d",
        "semana": "w", "semanas": "w",
    },
    "ru": {
        "секунда": "s", "секунды": "s", "секунд": "s",
        "минута": "m", "минуты": "m", "минут": "m",
        "час": "h", "часа": "h", "часов": "h",
        "день": "d", "дня": "d", "дней": "d",
        "неделя": "w", "недели": "w", "недель": "w",
    },
}

# اعداد به‌صورت کلمه — طبق محدودیت اعلام‌شده در docstring، فقط fa/en کامل.
_WORD_NUMBERS = {
    "fa": {
        "یک": 1, "دو": 2, "سه": 3, "چهار": 4, "پنج": 5,
        "شش": 6, "هفت": 7, "هشت": 8, "نه": 9, "ده": 10,
    },
    "en": {
        "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
        "a": 1, "an": 1,
    },
}


def extract_duration_seconds(text: str, lang: str) -> Optional[int]:
    """مدت‌زمان را از یک متن آزاد (نه فقط توکن فشرده) استخراج می‌کند.

    پشتیبانی می‌کند از:
      - توکن فشرده‌ی موجود پروژه: "10m" / "2h" / "1d" (از utils.parse_duration)
      - عدد رقمی + کلمه‌ی واحد: "2 hour" / "2 ساعت" / "2 hours"
      - عدد به‌صورت کلمه + واحد (فقط fa/en): "یک ساعت" / "one hour"
    """
    if not text:
        return None

    tokens = re.findall(r"[\w\u0600-\u06FF]+", text, flags=re.UNICODE)
    units = _UNIT_WORDS.get(lang, {})
    word_numbers = _WORD_NUMBERS.get(lang, {})

    for i, tok in enumerate(tokens):
        folded = tok.casefold()

        # فرمت فشرده‌ی موجود پروژه (مثلاً "1h") در هر جای متن
        compact = parse_duration(folded)
        if compact is not None:
            return compact

        if folded in units:
            unit_letter = units[folded]
            # عدد رقمی بلافاصله قبل از واحد
            if i > 0 and tokens[i - 1].isdigit():
                return parse_duration(f"{tokens[i - 1]}{unit_letter}")
            # عدد به‌صورت کلمه بلافاصله قبل از واحد
            if i > 0 and tokens[i - 1].casefold() in word_numbers:
                value = word_numbers[tokens[i - 1].casefold()]
                return parse_duration(f"{value}{unit_letter}")
    return None


# ---------------------------------------------------------------------------
# 3) نتیجه‌ی parse
# ---------------------------------------------------------------------------

@dataclass
class ParsedIntent:
    intent: Optional[str]
    entities: dict = field(default_factory=dict)
    ambiguous: bool = False
    candidates: list = field(default_factory=list)  # لیست intentهای محتمل، برای fallback

    @property
    def recognized(self) -> bool:
        return self.intent is not None and not self.ambiguous


def _contains_any(words: list[str], raw_text_folded: str, tokens_folded: list[str]) -> bool:
    """آیا یکی از کلمات/عبارت‌های `words` در متن هست؟

    دو حالت:
      - عبارت چندکلمه‌ای یا کلمه‌ی طول ≥۳ حرف: substring-match روی کل متن،
        چون زبان‌های fa/ar/ru/tr صرف فعل و ریشه‌ی کوتاه دارن (مثلاً عربی
        «احذف» باید با ریشه‌ی سه‌حرفی «حذف» تطبیق بخوره، «linkleri» با
        «linkler»، «بگیرم» با «بگیر»).
      - کلمه‌ی خیلی کوتاه (۱-۲ حرف، مثل ترکی "at" = kick): فقط تطبیق دقیق
        روی یک توکن کامل، وگرنه هر substring کوتاه داخل کلمه‌های نامرتبط
        دیگه هم قبول می‌شد (مثلاً "at" داخل "saat" = ساعت -> اشتباهاً kick
        تشخیص داده می‌شد). این یک باگ واقعی بود که همین تست پیدا و رفعش کرد.
    """
    for w in words:
        if " " in w or len(w) >= 3:
            if w in raw_text_folded:
                return True
        elif w in tokens_folded:
            return True
    return False


def parse(text: str, lang: str) -> ParsedIntent:
    """متن آزاد را به یک intent قابل پردازش تبدیل می‌کند.

    اصل بخش 9 (اکشن خطرناک): این تابع صرفاً intent را استخراج می‌کند و
    هیچ اکشنی اجرا نمی‌کند؛ اجرای واقعی و confirmation در لایه‌ی بالاتر
    (handlers/natural_language.py) با دسترسی به Update/context تلگرام
    انجام می‌شود.
    """
    if lang not in SUPPORTED_LANGS:
        lang = DEFAULT_LANG

    raw = (text or "").strip()
    if not raw:
        return ParsedIntent(intent=None)

    folded_text = raw.casefold()
    tokens_folded = [t.casefold() for t in re.findall(r"[\w\u0600-\u06FF]+", raw, flags=re.UNICODE)]

    def has(vocab: dict) -> bool:
        return _contains_any(vocab.get(lang, []), folded_text, tokens_folded)

    has_link_noun = has(_LINK_NOUNS)
    has_block_verb = has(_BLOCK_VERBS)
    has_allow_verb = has(_ALLOW_VERBS)
    has_help_noun = has(_HELP_NOUNS)
    has_rules_noun = _contains_any(_rules_nouns(lang), folded_text, tokens_folded)
    has_locks_noun = _contains_any(_locks_nouns(lang), folded_text, tokens_folded)
    has_open_reports_noun = _contains_any(_open_reports_nouns(lang), folded_text, tokens_folded)
    has_answerlist_phrase = _contains_any(_answerlist_phrases(lang), folded_text, tokens_folded)
    has_group_health_phrase = _contains_any(_group_health_phrases(lang), folded_text, tokens_folded)

    # نکته‌ی مهم (باگ واقعی رفع‌شده): "unmute"/"unban" و مشابهشون در چند
    # زبان شامل خودِ "mute"/"ban" هستن به‌عنوان substring (مثلاً انگلیسی
    # "unmute" شامل "mute" است، روسی "разбан" شامل "бан" است). بنابراین
    # همیشه اول un-نسخه رو چک می‌کنیم و اگر بود، نسخه‌ی مثبت رو کنسل می‌کنیم.
    has_unmute_verb = has(_UNMUTE_VERBS)
    has_mute_verb = has(_MUTE_VERBS) and not has_unmute_verb
    has_unban_verb = has(_UNBAN_VERBS)
    has_ban_verb = has(_BAN_VERBS) and not has_unban_verb
    has_kick_verb = has(_KICK_VERBS)
    has_warn_verb = has(_WARN_VERBS)
    has_delete_verb = has(_DELETE_VERBS)

    # --- moderation (اولویت بالا، چون خطرناک/حساسن) ---
    if has_mute_verb:
        duration = extract_duration_seconds(raw, lang)
        return ParsedIntent(intent="mute_user", entities={"duration_seconds": duration})
    if has_unmute_verb:
        return ParsedIntent(intent="unmute_user")
    if has_ban_verb:
        duration = extract_duration_seconds(raw, lang)
        return ParsedIntent(intent="ban_user", entities={"duration_seconds": duration})
    if has_unban_verb:
        return ParsedIntent(intent="unban_user")
    if has_kick_verb:
        return ParsedIntent(intent="kick_user")
    if has_warn_verb:
        return ParsedIntent(intent="warn_user")
    if has_delete_verb:
        return ParsedIntent(intent="delete_message")

    # --- rules: update (باید قبل از show_rules چک بشه چون عبارت setrules
    # خودش شامل کلمه‌ی "rules" هم هست — مثلاً «تنظیم قوانین» شامل «قوانین») ---
    setrules_phrase = next((p for p in _setrules_phrases(lang) if p in folded_text), None)
    if setrules_phrase:
        # همه‌ی این عبارت‌ها چندکلمه‌ای‌اند، پس idx بر اساس متن folded پیدا
        # می‌شه ولی از raw (نسخه‌ی اصلی، نه folded) برای استخراج متن دقیق
        # قوانین استفاده می‌کنیم تا بزرگ/کوچیکی حروف و فاصله‌ها خراب نشه.
        idx = folded_text.find(setrules_phrase)
        after = raw[idx + len(setrules_phrase):]
        if ":" in after:
            rules_text = after.split(":", 1)[1].strip()
            if rules_text:
                return ParsedIntent(intent="update_rules", entities={"rules_text": rules_text})
        # عبارت «تنظیم قوانین» هست ولی فرمت روشن نیست (بدون ":") — طبق بخش 11،
        # برای یک اکشن حساس (تغییر قوانین گروه) حدس نمی‌زنیم، فرمت دقیق می‌خوایم.
        return ParsedIntent(intent=None, ambiguous=True, candidates=["update_rules"])

    if has_answerlist_phrase:
        return ParsedIntent(intent="list_auto_answers")

    setanswer_phrase = next((p for p in _setanswer_phrases(lang) if p in folded_text), None)
    if setanswer_phrase:
        # setanswer_cmd خودش هیچ آرگومانی نمی‌خواد (فقط یک دکمه‌ی ورود به
        # ویزارد پیوی می‌ده) — پس نیازی به استخراج entity نیست، فقط اجرا.
        return ParsedIntent(intent="create_auto_answer")

    delanswer_phrase = next((p for p in _delanswer_phrases(lang) if p in folded_text), None)
    if delanswer_phrase:
        idx = folded_text.find(delanswer_phrase)
        after = raw[idx + len(delanswer_phrase):]
        if ":" in after:
            keyword = after.split(":", 1)[1].strip()
            if keyword:
                return ParsedIntent(intent="delete_auto_answer", entities={"keyword": keyword})
        # طبق بخش 9/11: بدون فرمت روشن، حدس نمی‌زنیم کدوم auto-answer حذف بشه.
        return ParsedIntent(intent=None, ambiguous=True, candidates=["delete_auto_answer"])

    if has_group_health_phrase:
        return ParsedIntent(intent="group_health_report")

    # --- security: link protection ---
    if has_link_noun and (has_block_verb or has_allow_verb):
        return ParsedIntent(
            intent="configure_link_protection",
            entities={"enabled": has_block_verb and not has_allow_verb},
        )
    if has_link_noun and not (has_block_verb or has_allow_verb):
        # کاربر از "لینک" حرف زده ولی معلوم نیست می‌خواد ببنده یا وضعیتش رو ببینه.
        return ParsedIntent(intent=None, ambiguous=True,
                             candidates=["configure_link_protection", "show_security_status"])

    if has_locks_noun:
        return ParsedIntent(intent="show_security_status")

    if has_open_reports_noun:
        return ParsedIntent(intent="show_moderation_report")

    if has_rules_noun:
        return ParsedIntent(intent="show_rules")

    if has_help_noun:
        return ParsedIntent(intent="help")

    # ==================== Phase 3 (گسترش NLU آزاد) ====================
    # همه‌ی این‌ها بدون‌پارامتر یا enable/disable ساده‌اند — دقیقاً مثل
    # configure_link_protection/show_security_status بالا، بدون نیاز به
    # confirmation (طبق بخش 9، فقط اکشن‌های خطرناک confirm می‌خوان).
    if _contains_any(_mention_protection_nouns(lang), folded_text, tokens_folded):
        if has_block_verb or has_allow_verb:
            return ParsedIntent(
                intent="configure_mention_protection",
                entities={"enabled": has_block_verb and not has_allow_verb},
            )
        return ParsedIntent(intent=None, ambiguous=True, candidates=["configure_mention_protection"])

    if _contains_any(_antispam_nouns(lang), folded_text, tokens_folded):
        if has_block_verb or has_allow_verb:
            return ParsedIntent(
                intent="configure_antispam",
                entities={"enabled": has_block_verb and not has_allow_verb},
            )
        return ParsedIntent(intent=None, ambiguous=True, candidates=["configure_antispam"])

    if _contains_any(_dupcross_nouns(lang), folded_text, tokens_folded):
        if has_block_verb or has_allow_verb:
            return ParsedIntent(
                intent="configure_dupcross",
                entities={"enabled": has_block_verb and not has_allow_verb},
            )
        return ParsedIntent(intent=None, ambiguous=True, candidates=["configure_dupcross"])

    if _contains_any(_ad_admin_nouns(lang), folded_text, tokens_folded):
        return ParsedIntent(intent="show_ad_admin_queue")

    if _contains_any(_my_ads_nouns(lang), folded_text, tokens_folded):
        return ParsedIntent(intent="show_my_ads")

    if _contains_any(_ads_list_nouns(lang), folded_text, tokens_folded):
        return ParsedIntent(intent="show_ads_list")

    if _contains_any(_daily_assets_nouns(lang), folded_text, tokens_folded):
        return ParsedIntent(intent="show_daily_assets")

    if _contains_any(_test_daily_price_phrases(lang), folded_text, tokens_folded):
        return ParsedIntent(intent="test_daily_price")

    if _contains_any(_test_daily_news_phrases(lang), folded_text, tokens_folded):
        return ParsedIntent(intent="test_daily_news")

    if _contains_any(_daily_notify_nouns(lang), folded_text, tokens_folded):
        return ParsedIntent(intent="show_daily_notify_menu")

    if _contains_any(_recurring_posts_nouns(lang), folded_text, tokens_folded):
        return ParsedIntent(intent="show_recurring_posts")

    # --- JSON Learning System (بخش 3): لایه‌ی سریع/قطعی بالا چیزی نشناخت؛
    # قبل از escalate کردن به AI، چک می‌کنیم آیا این عبارت (یا نسخه‌ی
    # نرمال‌شده‌اش) قبلاً با Confidence کافی توسط AI شناخته و یاد گرفته شده.
    # اگر آره، بدون هزینه/تأخیر AI مستقیم dispatch می‌شه — دقیقاً طبق قرارداد
    # این تابع (فقط intent، بدون entity؛ entity هنوز از منطق قطعی می‌آد،
    # همون‌طور که handlers/natural_language.py برای duration انجام می‌ده).
    learned = learned_phrases.get_learned_intent(raw, lang)
    if learned in KNOWN_INTENTS:
        return ParsedIntent(intent=learned)

    return ParsedIntent(intent=None)
