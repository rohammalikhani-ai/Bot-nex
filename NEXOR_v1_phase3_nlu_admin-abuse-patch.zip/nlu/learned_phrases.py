# -*- coding: utf-8 -*-
"""
JSON Learning System (بخش 3 پرامپت — گپ واقعی که در Audit پیدا شد):

قبلاً `nlu/ai_escalation_log.py` فقط هر escalation به AI را برای بررسی
دستیِ بعدی لاگ می‌کرد؛ هیچ مسیری برای "یادگیری خودکار" وجود نداشت — یعنی
یک عبارت جدید هر بار دوباره AI را صدا می‌زد، حتی اگر قبلاً با Confidence
بالا شناخته شده بود.

این ماژول همان حلقه‌ی گمشده را اضافه می‌کند، بدون اینکه ai_escalation_log.py
(که برای بررسی/آنالیز انسانی می‌ماند) را حذف یا جایگزین کند:

    Known Command/Phrase
            |
    Dictionary (TEXT_TRIGGERS)  -----------\
            | not found                     |
    Learned Phrases (این فایل)  <-----------/  (AI با Confidence بالا یاد می‌ده)
            | not found
            v
           AI

جایگاه در پایپ‌لاین:
  - `nlu/intent_parser.py::parse()` قبل از برگرداندن intent=None، این
    فایل را (به ازای زبان پیام) چک می‌کند.
  - `handlers/natural_language.py::_escalate_to_ai` بعد از یک تفسیر موفق
    AI با Confidence بالای آستانه، عبارت را اینجا ذخیره می‌کند.

طراحی مطابق همان قرارداد `ai_escalation_log.py`: کاملاً مستقل از تلگرام
(قابل تست بدون python-telegram-bot)، best-effort/fail-silent (یک خطای
فایل هرگز نباید جلوی پاسخ به کاربر را بگیرد)، و فقط intent را برمی‌گرداند
— نه entity؛ استخراج entity همچنان از همان منطق قطعی (extract_duration_seconds
و مشابه) در لایه‌ی بالاتر انجام می‌شود، دقیقاً مثل مسیر AI (بخش 23: عدم
اعتماد کور به AI/یادگیری برای جزئیات حساس).

آستانه‌ی پیش‌فرض یادگیری (LEARN_CONFIDENCE_THRESHOLD) عمداً محافظه‌کارانه
بالاست — چون یک ورودی اشتباه اینجا یعنی از این پس همیشه بدون AI (و بدون
دوباره‌سنجی confidence) اجرا می‌شود.
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Optional

DEFAULT_STORE_DIR = Path("data/learned_phrases")
LEARN_CONFIDENCE_THRESHOLD = 80

_MEMORY_CACHE: dict[str, dict] = {}


def _normalize(text: str) -> str:
    """نرمال‌سازی سبک: trim + فشرده‌کردن فاصله‌ها + casefold — تا تفاوت
    فاصله/بزرگ‌کوچیکی حروف باعث miss نشه، بدون اینکه معنی عبارت تغییر کنه."""
    return re.sub(r"\s+", " ", (text or "").strip()).casefold()


def _store_path(lang: str, base_dir: Path | str = DEFAULT_STORE_DIR) -> Path:
    return Path(base_dir) / f"{lang}.json"


def _load(lang: str, base_dir: Path | str = DEFAULT_STORE_DIR) -> dict:
    cache_key = f"{base_dir}:{lang}"
    if cache_key in _MEMORY_CACHE:
        return _MEMORY_CACHE[cache_key]
    path = _store_path(lang, base_dir)
    data: dict = {}
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError):
            data = {}
    _MEMORY_CACHE[cache_key] = data
    return data


def get_learned_intent(text: str, lang: str, base_dir: Path | str = DEFAULT_STORE_DIR) -> Optional[str]:
    """اگر این عبارت (نرمال‌شده) قبلاً با Confidence کافی یاد گرفته شده،
    اسم intent را برمی‌گرداند؛ وگرنه None — دقیقاً مثل «چیز نامشخص = سکوت»
    که بقیه‌ی nlu/intent_parser.py رعایت می‌کند."""
    normalized = _normalize(text)
    if not normalized:
        return None
    data = _load(lang, base_dir)
    entry = data.get(normalized)
    if not entry:
        return None
    return entry.get("intent")


def record_learned_phrase(
    text: str,
    lang: str,
    intent: str,
    confidence: Optional[int],
    *,
    threshold: int = LEARN_CONFIDENCE_THRESHOLD,
    base_dir: Path | str = DEFAULT_STORE_DIR,
) -> bool:
    """اگر confidence >= threshold باشه، عبارت را در JSON این زبان ذخیره
    می‌کند تا دفعه‌ی بعد بدون AI مستقیم dispatch بشه. برمی‌گرداند True اگر
    واقعاً ذخیره شد.

    best-effort: هیچ‌وقت استثنا پرتاب نمی‌کند — یک خطای نوشتن فایل نباید
    جلوی پاسخ به کاربر را بگیرد (دقیقاً هم‌قرارداد با ai_escalation_log.py).
    """
    if confidence is None or confidence < threshold:
        return False
    normalized = _normalize(text)
    if not normalized:
        return False

    try:
        data = _load(lang, base_dir)
        existing = data.get(normalized)
        hits = (existing.get("hits", 0) + 1) if existing else 1
        data[normalized] = {
            "intent": intent,
            "confidence": confidence,
            "hits": hits,
            "first_seen": existing.get("first_seen", time.time()) if existing else time.time(),
            "last_seen": time.time(),
        }
        path = _store_path(lang, base_dir)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = path.with_suffix(".json.tmp")
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
        tmp_path.replace(path)  # atomic روی همون فایل‌سیستم — از فایل نیمه‌نوشته جلوگیری می‌کنه
        _MEMORY_CACHE[f"{base_dir}:{lang}"] = data
        return True
    except OSError:
        return False


def forget_phrase(text: str, lang: str, base_dir: Path | str = DEFAULT_STORE_DIR) -> bool:
    """حذف یک عبارت یادگرفته‌شده (مثلاً اگر یک ادمین گزارش داد که اشتباه
    یاد گرفته شده) — برای ابزار مدیریتی/تست، نه برای استفاده‌ی خودکار."""
    normalized = _normalize(text)
    data = _load(lang, base_dir)
    if normalized not in data:
        return False
    try:
        del data[normalized]
        path = _store_path(lang, base_dir)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
        _MEMORY_CACHE[f"{base_dir}:{lang}"] = data
        return True
    except OSError:
        return False


def reset_cache() -> None:
    """فقط برای تست: کش حافظه رو خالی می‌کنه تا تست بعدی از فایل واقعی بخونه."""
    _MEMORY_CACHE.clear()
