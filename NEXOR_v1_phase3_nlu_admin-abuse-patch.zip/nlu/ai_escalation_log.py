# -*- coding: utf-8 -*-
"""
لاگ escalation به AI (درخواست خود کاربر در این مکالمه): هر بار که لایه‌ی
سریع/قطعی (nlu/intent_parser.py) یک پیام رو نشناخت و به AI (لایه‌ی سوم
Smart Router، بخش 6/7) ارجاع داده شد، این ماژول همون پیام + نتیجه‌ی
تفسیر AI رو (چه موفق چه ناموفق) توی یک فایل JSONL (هر خط یک JSON کامل)
ذخیره می‌کنه.

هدف (طبق درخواست صریح کاربر): این فایل بعداً قابل بررسیه تا معلوم بشه
کاربرهای واقعی دقیقاً با چه جمله‌هایی درخواست می‌دن — و از روی همون
جمله‌های واقعی، واژگان لایه‌ی سریع/قطعی (nlu/intent_parser.py) گسترش داده
بشه (یعنی با گذشت زمان، وابستگی به AI کمتر و لایه‌ی رایگان/سریع دقیق‌تر
می‌شه — دقیقاً همون اصل بخش 6: «تا جایی که می‌شه بدون AI تشخیص بده»).

کاملاً مستقل از telegram — تا بدون نصب python-telegram-bot قابل تست باشه.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Optional

DEFAULT_LOG_PATH = Path("data/ai_nlu_escalations.jsonl")


def log_ai_interpretation(
    *,
    chat_id: int,
    lang: str,
    text: str,
    intent: Optional[str],
    confidence: Optional[int],
    used_ai: bool,
    error_code: Optional[str] = None,
    path: Path | str = DEFAULT_LOG_PATH,
) -> None:
    """یک رکورد به فایل JSONL اضافه می‌کنه (append، نه overwrite).

    هیچ‌وقت استثنا پرتاب نمی‌کنه (best-effort) — یه مشکل نوشتن فایل نباید
    جلوی پاسخ به کاربر رو بگیره؛ فقط silently fail می‌شه (caller می‌تونه
    لاگ کنه اگه لازمه، ولی این خودش تصمیم نمی‌گیره بترکونه).
    """
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        entry = {
            "ts": time.time(),
            "chat_id": chat_id,
            "lang": lang,
            "text": text,
            "intent": intent,
            "confidence": confidence,
            "used_ai": used_ai,
            "error_code": error_code,
        }
        with open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except OSError:
        pass


def read_all(path: Path | str = DEFAULT_LOG_PATH) -> list[dict]:
    """همه‌ی رکوردهای ذخیره‌شده رو می‌خونه (برای بررسی/تحلیل بعدی، یا برای
    تست). اگه فایل هنوز وجود نداره، لیست خالی برمی‌گردونه (نه خطا)."""
    p = Path(path)
    if not p.exists():
        return []
    records = []
    with open(p, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                continue  # یه خط خراب نباید کل فایل رو غیرقابل‌خوندن کنه
    return records
