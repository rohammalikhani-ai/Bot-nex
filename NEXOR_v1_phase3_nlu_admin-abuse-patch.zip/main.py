# -*- coding: utf-8 -*-
"""NEXOR_v1 entry point."""
import logging

from core.bootstrap import build_application

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


def main():
    app = build_application()
    logger.info("NEXOR_v1 در حال اجراست...")
    app.run_polling()


if __name__ == "__main__":
    main()
