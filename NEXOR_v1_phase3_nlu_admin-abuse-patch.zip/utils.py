# -*- coding: utf-8 -*-
"""
ابزار کمکی برای ارسال پیام با رعایت محدودیت نرخ (Rate Limit) تلگرام.
اگه تلگرام خطای "Too Many Requests" بده، به‌جای کرش کردن، خودکار صبر
می‌کنه و دوباره تلاش می‌کنه.
"""

import asyncio
import logging
import re

from config import SEND_RETRY_MAX, SEND_MIN_INTERVAL

# نکته (رفع مشکل تست‌پذیری / کوپلینگ): import کتابخانه‌ی telegram اینجا در
# سطح ماژول انجام نمی‌شه، چون parse_duration/format_duration توابع خالص
# هستن و نباید فقط برای استفاده‌شون کل python-telegram-bot نصب باشه (مثلاً
# در محیط تست یا در ماژول‌های NLU که فقط parse_duration رو لازم دارن). خود
# telegram.error فقط داخل call_with_retry، جایی که واقعاً لازمه، import
# می‌شه؛ رفتار call_with_retry هیچ تغییری نکرده.

logger = logging.getLogger(__name__)

_DURATION_RE = re.compile(r"^(\d+)([smhdw])$", re.IGNORECASE)
_DURATION_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}


def parse_duration(token: str):
    """
    یک رشته مثل 10m / 2h / 1d / 3w را به ثانیه تبدیل می‌کند.
    اگر فرمت نامعتبر بود None برمی‌گرداند (یعنی این توکن مدت‌زمان نیست).
    """
    if not token:
        return None
    m = _DURATION_RE.match(token.strip())
    if not m:
        return None
    value, unit = m.groups()
    return int(value) * _DURATION_UNITS[unit.lower()]


def format_duration(seconds: int) -> str:
    if not seconds or seconds <= 0:
        return "همیشگی"
    units = [("هفته", 604800), ("روز", 86400), ("ساعت", 3600), ("دقیقه", 60), ("ثانیه", 1)]
    for label, size in units:
        if seconds >= size:
            n = seconds // size
            return f"{n} {label}"
    return f"{seconds} ثانیه"


def strip_prefix_words(text: str, n: int) -> str:
    """اولین n «کلمه» (جداشده با whitespace) رو از ابتدای text حذف می‌کنه و
    بقیه‌ی متن رو دقیقاً همون‌طور که هست (با فاصله/newline های داخلی‌اش)
    برمی‌گردونه — بر خلاف text.split(None, n)[-1] که این کار رو *نمی‌کنه*
    اگه یکی از آرگومان‌های اولیه خودش شامل چیزی نباشه؛ اینجا با پیمایش
    دستی کاراکتر به کاراکتر، دقیقاً n کلمه (نه بیشتر، نه کمتر) حذف می‌شه.

    باگ واقعی‌ای که این تابع رفعش می‌کنه (handlers/rules.py::setrules_cmd):
    وقتی یک دستور «چندکلمه‌ای» به‌جای «/command تک‌کلمه‌ای» صدا زده می‌شه
    (مثلاً از طریق Alias دوکلمه‌ای «تنظیم قوانین» به‌جای «/setrules»)،
    کد قبلی فرض می‌کرد پیشوند همیشه دقیقاً یک کلمه است
    (`text.split(None, 1)[1]`)؛ برای پیشوند دوکلمه‌ای، کلمه‌ی دوم پیشوند
    ("قوانین") اشتباهاً به متن قوانینِ ذخیره‌شده می‌چسبید. این تابع با
    گرفتن n واقعی (که از روی context.args محاسبه می‌شه) این مشکل رو حل
    می‌کنه، برای هر مقدار n، نه فقط ۰/۱.
    """
    if n <= 0:
        return text
    idx = 0
    length = len(text)
    words_seen = 0
    while words_seen < n and idx < length:
        while idx < length and text[idx].isspace():
            idx += 1
        if idx >= length:
            break
        while idx < length and not text[idx].isspace():
            idx += 1
        words_seen += 1
    if idx < length and text[idx].isspace():
        idx += 1  # فقط همون یک فاصله‌ای که پیشوند رو از بقیه جدا می‌کنه
    return text[idx:]

_last_send_lock = asyncio.Lock()
_last_send_time = 0.0


async def _throttle():
    """فاصله حداقلی بین ارسال‌های پشت‌سرهم را تضمین می‌کند."""
    global _last_send_time
    async with _last_send_lock:
        now = asyncio.get_event_loop().time()
        wait = SEND_MIN_INTERVAL - (now - _last_send_time)
        if wait > 0:
            await asyncio.sleep(wait)
        _last_send_time = asyncio.get_event_loop().time()


async def call_with_retry(coro_func, *args, **kwargs):
    """
    coro_func را با تلاش مجدد در برابر RetryAfter/TimedOut/NetworkError صدا می‌زند.
    مثال: await call_with_retry(context.bot.send_message, chat_id=1, text="hi")
    """
    from telegram.error import RetryAfter, TimedOut, NetworkError

    attempt = 0
    while True:
        await _throttle()
        try:
            return await coro_func(*args, **kwargs)
        except RetryAfter as e:
            attempt += 1
            if attempt > SEND_RETRY_MAX:
                raise
            wait_time = float(e.retry_after) + 0.5
            logger.warning(f"Rate limited by Telegram. Waiting {wait_time:.1f}s (attempt {attempt}).")
            await asyncio.sleep(wait_time)
        except (TimedOut, NetworkError):
            attempt += 1
            if attempt > SEND_RETRY_MAX:
                raise
            await asyncio.sleep(1.5 * attempt)
