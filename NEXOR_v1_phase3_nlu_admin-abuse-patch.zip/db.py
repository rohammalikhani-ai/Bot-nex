# -*- coding: utf-8 -*-
"""
لایه پایگاه‌داده (SQLite) — تمام داده‌ها این‌جا دائمی ذخیره می‌شن
تا با ری‌استارت ربات از بین نرن.
"""

from __future__ import annotations  # keep X | None / dict[...] hints working on Python < 3.10

import json
import sqlite3
import threading
import time
from contextlib import contextmanager

from config import DB_PATH

_lock = threading.Lock()
_conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=10)
_conn.execute("PRAGMA journal_mode=WAL;")
_conn.execute("PRAGMA busy_timeout=10000;")
_conn.execute("PRAGMA foreign_keys=ON;")


# ---------------- Per-chat config cache (Priority fix: hot-path read amplification) ----------------
# moderate_message و مسیرهای مشابه به ازای هر پیام چندین بار get_setting/get_locks/
# get_filters/get_filter_whitelist/is_domain_listed رو صدا می‌زنن. اینجا یه کش
# in-memory ساده per-chat می‌سازیم که:
#   - روی هر نوشتن (set_setting/add_lock/...) بلافاصله invalidate می‌شه (سازگاری تضمینی)
#   - یه TTL کوتاه هم به‌عنوان شبکه‌ی ایمنی داره (برای هر باگ احتمالی جا افتاده در invalidation)
_CFG_CACHE_TTL_SECONDS = 300
_cfg_cache: dict = {}
_cfg_cache_lock = threading.Lock()


def _load_chat_cache_entry(chat_id: int) -> dict:
    """یک snapshot تازه از تنظیمات/قفل‌ها/فیلترهای یک چت رو از DB می‌خونه."""
    with _lock:
        cur = _conn.cursor()
        try:
            cur.execute("SELECT key, value FROM settings WHERE chat_id=?", (chat_id,))
            settings = dict(cur.fetchall())

            cur.execute("SELECT lock_type FROM locks WHERE chat_id=?", (chat_id,))
            locks = {row[0] for row in cur.fetchall()}

            cur.execute("SELECT word FROM word_filters WHERE chat_id=?", (chat_id,))
            filters_ = {row[0] for row in cur.fetchall()}

            cur.execute("SELECT word FROM filters_whitelist WHERE chat_id=?", (chat_id,))
            whitelist = [row[0] for row in cur.fetchall()]

            cur.execute("SELECT domain FROM domains WHERE chat_id=? AND kind='blacklist'", (chat_id,))
            domains_blacklist = {row[0] for row in cur.fetchall()}

            cur.execute("SELECT domain FROM domains WHERE chat_id=? AND kind='whitelist'", (chat_id,))
            domains_whitelist = {row[0] for row in cur.fetchall()}
        finally:
            cur.close()

    entry = {
        "settings": settings,
        "locks": locks,
        "filters": filters_,
        "whitelist": whitelist,
        "domains": {"blacklist": domains_blacklist, "whitelist": domains_whitelist},
        "expires_at": time.monotonic() + _CFG_CACHE_TTL_SECONDS,
    }
    with _cfg_cache_lock:
        _cfg_cache[chat_id] = entry
    return entry


def _get_chat_cache_entry(chat_id: int) -> dict:
    with _cfg_cache_lock:
        entry = _cfg_cache.get(chat_id)
        if entry is not None and entry["expires_at"] > time.monotonic():
            return entry
    # cache miss یا expired: بیرون از لاک کش، از DB بخون (لاک جدا برای اتصال داریم)
    return _load_chat_cache_entry(chat_id)


def _invalidate_chat_cache(chat_id: int) -> None:
    with _cfg_cache_lock:
        _cfg_cache.pop(chat_id, None)


def reset_config_cache() -> None:
    """کل کش تنظیمات/قفل‌ها/فیلترهای همه‌ی چت‌ها را خالی می‌کند. فقط برای
    تست‌ها؛ هم‌روال با reset_rank_cache در handlers.common و
    providers.reset_provider_cache در ai_copilot."""
    with _cfg_cache_lock:
        _cfg_cache.clear()


@contextmanager
def cursor():
    """Run one DB unit of work atomically.

    A failed statement must never leave earlier statements from the same
    operation committed. The previous implementation committed even when the
    body raised, which could leave partially-applied configuration.
    """
    with _lock:
        cur = _conn.cursor()
        try:
            yield cur
        except Exception:
            _conn.rollback()
            raise
        else:
            _conn.commit()
        finally:
            cur.close()


def _column_exists(cur, table: str, column: str) -> bool:
    cur.execute(f"PRAGMA table_info({table})")
    return any(row[1] == column for row in cur.fetchall())


def _ensure_schema_meta(cur):
    cur.execute("""
        CREATE TABLE IF NOT EXISTS schema_meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    """)
    cur.execute(
        "INSERT OR IGNORE INTO schema_meta(key, value) VALUES('schema_version', '1')"
    )


def init_db():
    with cursor() as cur:
        _ensure_schema_meta(cur)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS warns (
                chat_id INTEGER, user_id INTEGER, count INTEGER,
                PRIMARY KEY (chat_id, user_id)
            )
        """)
        # --- Migration: warns با آخرین دلیل/زمان ---
        if not _column_exists(cur, "warns", "last_reason"):
            cur.execute("ALTER TABLE warns ADD COLUMN last_reason TEXT")
        if not _column_exists(cur, "warns", "updated_at"):
            cur.execute("ALTER TABLE warns ADD COLUMN updated_at REAL")

        cur.execute("""
            CREATE TABLE IF NOT EXISTS warns_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER, user_id INTEGER, actor_id INTEGER,
                reason TEXT, ts REAL
            )
        """)

        # --- کش کاربران (برای resolve با @username یا user_id بدون ریپلای) ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users_cache (
                user_id INTEGER PRIMARY KEY,
                username TEXT, first_name TEXT, updated_at REAL
            )
        """)

        # --- نقش‌های داخلی ربات (Moderator) — مستقل از ادمین واقعی تلگرام ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS roles (
                chat_id INTEGER, user_id INTEGER, role TEXT,
                PRIMARY KEY (chat_id, user_id)
            )
        """)

        # --- لاگ کامل اقدامات (Admin Logs / Moderator Audit) ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER, actor_id INTEGER, actor_name TEXT,
                action TEXT, target_id INTEGER, target_name TEXT,
                reason TEXT, ts REAL
            )
        """)

        # --- Link Protection: Domain Whitelist/Blacklist ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS domains (
                chat_id INTEGER, domain TEXT, kind TEXT,
                PRIMARY KEY (chat_id, domain, kind)
            )
        """)

        # --- Forbidden Words: استثناها (Whitelist) ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS filters_whitelist (
                chat_id INTEGER, word TEXT,
                PRIMARY KEY (chat_id, word)
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS locks (
                chat_id INTEGER, lock_type TEXT,
                PRIMARY KEY (chat_id, lock_type)
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS word_filters (
                chat_id INTEGER, word TEXT,
                PRIMARY KEY (chat_id, word)
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS notes (
                chat_id INTEGER, name TEXT, content TEXT,
                PRIMARY KEY (chat_id, name)
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                chat_id INTEGER, key TEXT, value TEXT,
                PRIMARY KEY (chat_id, key)
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS pending_captcha (
                chat_id INTEGER, user_id INTEGER, join_time REAL,
                PRIMARY KEY (chat_id, user_id)
            )
        """)
        # --- Forward Protection: قوانین انتخابی Allow/Block روی Source خاص ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS forward_rules (
                chat_id INTEGER, source_key TEXT, source_label TEXT, mode TEXT,
                PRIMARY KEY (chat_id, source_key)
            )
        """)

        # --- Mention Protection ---
        # (تنظیمات در جدول settings ذخیره می‌شود؛ جدول جدا لازم نیست)

        # --- Priority 4: Rules System (چندزبانه — هر گروه می‌تواند برای هر زبان متن جدا داشته باشد) ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS chat_rules (
                chat_id INTEGER, lang TEXT, text TEXT,
                PRIMARY KEY (chat_id, lang)
            )
        """)

        # --- Priority 4: Filters (Keyword Trigger -> Automatic Response) — مجزا از Forbidden Words ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS keyword_triggers (
                chat_id INTEGER, keyword TEXT, response TEXT,
                PRIMARY KEY (chat_id, keyword)
            )
        """)

        # --- Auto-Answer (پاسخ خودکار): کلیدواژه -> یک یا چند پاسخ رندوم
        # (متن/رسانه)، با هدف‌گذاری مخاطب (همه/مقام‌داران/مالکین). کاملاً
        # مستقل از keyword_triggers بالا (اون سیستم قدیمی‌تر، فقط متن ساده و
        # بدون هدف‌گذاری مخاطب/رسانه/کول‌داون است) تا رفتار هرکدوم قابل
        # پیش‌بینی و مجزا بمونه.
        cur.execute("""
            CREATE TABLE IF NOT EXISTS auto_answers (
                chat_id INTEGER, keyword TEXT, audience TEXT,
                responses_json TEXT, created_by INTEGER, created_at REAL,
                PRIMARY KEY (chat_id, keyword)
            )
        """)

        # --- Priority 4: Custom Commands ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS custom_commands (
                chat_id INTEGER, name TEXT, response TEXT,
                PRIMARY KEY (chat_id, name)
            )
        """)

        # --- Priority 4: Scheduled Messages — Recurring (Daily/Weekly/Monthly) ---
        # مکمل schedulepost یک‌باره‌ی موجود در channel.py؛ این جدول برای پست‌های
        # تکرارشونده است و دائمی ذخیره می‌شود تا با ری‌استارت ربات از بین نره.
        cur.execute("""
            CREATE TABLE IF NOT EXISTS recurring_posts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER, channel TEXT, schedule_type TEXT,
                weekday INTEGER, day_of_month INTEGER, hour INTEGER, minute INTEGER,
                text TEXT, buttons_json TEXT, created_by INTEGER, active INTEGER DEFAULT 1
            )
        """)

        # --- Priority 4: Auto Actions — Rule Engine (Condition -> Action) ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS auto_action_rules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER, condition_type TEXT, condition_value TEXT,
                action_type TEXT, action_value TEXT, enabled INTEGER DEFAULT 1
            )
        """)

        # --- Priority 5, Item 25: Permission Profiles (سفارشی، مستقل از Hierarchy) ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS permission_profiles (
                chat_id INTEGER, name TEXT, capabilities TEXT,
                PRIMARY KEY (chat_id, name)
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS profile_assignments (
                chat_id INTEGER, user_id INTEGER, profile TEXT,
                PRIMARY KEY (chat_id, user_id)
            )
        """)

        # --- Priority 5, Item 26: Reports ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER, reporter_id INTEGER, reporter_name TEXT,
                target_id INTEGER, target_name TEXT, message_id INTEGER,
                reason TEXT, ts REAL, status TEXT DEFAULT 'open'
            )
        """)

        # --- Priority 5, Item 27: Admin Alerts (تاریخچه‌ی دائمی همه‌ی Alertها) ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS admin_alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER, alert_type TEXT, text TEXT, ts REAL
            )
        """)

        # --- NEXOR Copilot (AI Module): مصرف روزانه به ازای (چت، کاربر) برای Rate Limit ---
        cur.execute("""
            CREATE TABLE IF NOT EXISTS ai_usage_daily (
                chat_id INTEGER, user_id INTEGER, day TEXT, count INTEGER DEFAULT 0,
                PRIMARY KEY (chat_id, user_id, day)
            )
        """)

        # --- NEXOR Copilot (AI Module): لاگ کامل هر درخواست AI (برای دیباگ/حسابرسی هزینه) ---
        # توجه: متن خام پیام کاربر اینجا ذخیره نمی‌شود؛ فقط feature/plan/نتیجه، تا
        # داده‌ی غیرضروری گروه به‌صورت دائمی نگه‌داشته نشود.
        cur.execute("""
            CREATE TABLE IF NOT EXISTS ai_request_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER, actor_id INTEGER, feature TEXT, plan TEXT,
                success INTEGER, used_ai INTEGER, error TEXT, ts REAL
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS federations (
                fed_id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT, owner_id INTEGER
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS federation_chats (
                fed_id INTEGER, chat_id INTEGER,
                PRIMARY KEY (fed_id, chat_id)
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS federation_bans (
                fed_id INTEGER, user_id INTEGER, reason TEXT,
                PRIMARY KEY (fed_id, user_id)
            )
        """)

        # --- Payments/Subscriptions: سفارش‌های خرید اشتراک (Stars/TON/کارت‌به‌کارت) ---
        # این جدول عمداً هر سه روش پرداخت رو تو یک ردیف نگه می‌داره (به‌جای سه جدول
        # جدا) تا استعلام «سفارش‌های در انتظار کاربر» و «تاریخچه‌ی پرداخت» ساده بمونه؛
        # ستون‌های مخصوصِ هر روش (memo/tx_hash برای TON، charge_id برای Stars،
        # reference/receipt برای کارت) برای بقیه‌ی روش‌ها NULL می‌مونه.
        # status: pending / confirmed / rejected / expired
        # method: stars / ton / card
        cur.execute("""
            CREATE TABLE IF NOT EXISTS subscription_orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                plan TEXT NOT NULL,
                months INTEGER NOT NULL DEFAULT 1,
                method TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                amount_stars INTEGER,
                amount_ton_nano INTEGER,
                ton_memo TEXT UNIQUE,
                ton_tx_hash TEXT,
                stars_invoice_payload TEXT UNIQUE,
                stars_charge_id TEXT,
                card_reference TEXT UNIQUE,
                card_receipt_note TEXT,
                admin_id INTEGER,
                created_at REAL NOT NULL,
                confirmed_at REAL
            )
        """)
        cur.execute("CREATE INDEX IF NOT EXISTS idx_subscription_orders_status ON subscription_orders(status, method)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_subscription_orders_chat ON subscription_orders(chat_id, status)")

        # ---------------- Ads (سیستم تبلیغات — پورت‌شده از nationbot با معماری ساده‌تر) ----------------
        cur.execute("""
            CREATE TABLE IF NOT EXISTS known_chats (
                chat_id INTEGER PRIMARY KEY,
                title TEXT,
                is_active INTEGER NOT NULL DEFAULT 1,
                added_at REAL NOT NULL,
                last_seen REAL NOT NULL
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS ad_orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                kind TEXT NOT NULL DEFAULT 'free',
                banner_file_id TEXT,
                text TEXT NOT NULL,
                times_per_day INTEGER NOT NULL DEFAULT 1,
                duration_days INTEGER NOT NULL DEFAULT 1,
                method TEXT,
                amount_stars INTEGER,
                amount_ton_nano INTEGER,
                ton_memo TEXT UNIQUE,
                ton_tx_hash TEXT,
                stars_invoice_payload TEXT UNIQUE,
                stars_charge_id TEXT,
                status TEXT NOT NULL DEFAULT 'draft',
                rejection_reason TEXT,
                admin_id INTEGER,
                created_at REAL NOT NULL,
                paid_at REAL,
                approved_at REAL,
                starts_at REAL,
                expires_at REAL
            )
        """)
        cur.execute("CREATE INDEX IF NOT EXISTS idx_ad_orders_status ON ad_orders(status)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_ad_orders_owner ON ad_orders(owner_chat_id, status)")
        cur.execute("""
            CREATE TABLE IF NOT EXISTS ad_delivery_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ad_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                slot INTEGER NOT NULL,
                day TEXT NOT NULL,
                ts REAL NOT NULL,
                UNIQUE(chat_id, slot, day)
            )
        """)
        cur.execute("CREATE INDEX IF NOT EXISTS idx_ad_delivery_ad_day ON ad_delivery_log(ad_id, day)")
        cur.execute("""
            CREATE TABLE IF NOT EXISTS ad_rotation_state (
                bucket TEXT PRIMARY KEY,
                cursor INTEGER NOT NULL DEFAULT 0
            )
        """)


# ---------------- Warns ----------------

def get_warns(chat_id: int, user_id: int) -> int:
    with cursor() as cur:
        cur.execute("SELECT count FROM warns WHERE chat_id=? AND user_id=?", (chat_id, user_id))
        row = cur.fetchone()
        return row[0] if row else 0


def set_warns(chat_id: int, user_id: int, count: int, reason: str = None, ts: float = None):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO warns (chat_id, user_id, count, last_reason, updated_at) VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(chat_id, user_id) DO UPDATE SET count=excluded.count, "
            "last_reason=COALESCE(excluded.last_reason, warns.last_reason), "
            "updated_at=COALESCE(excluded.updated_at, warns.updated_at)",
            (chat_id, user_id, count, reason, ts),
        )


def add_warn_log(chat_id: int, user_id: int, actor_id: int, reason: str, ts: float):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO warns_log (chat_id, user_id, actor_id, reason, ts) VALUES (?, ?, ?, ?, ?)",
            (chat_id, user_id, actor_id, reason, ts),
        )


def get_warn_history(chat_id: int, user_id: int, limit: int = 10) -> list:
    with cursor() as cur:
        cur.execute(
            "SELECT actor_id, reason, ts FROM warns_log WHERE chat_id=? AND user_id=? "
            "ORDER BY ts DESC LIMIT ?",
            (chat_id, user_id, limit),
        )
        return cur.fetchall()


# ---------------- User cache (برای resolve با username/ID) ----------------

def upsert_user(user_id: int, username: str, first_name: str, ts: float):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO users_cache (user_id, username, first_name, updated_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET username=excluded.username, "
            "first_name=excluded.first_name, updated_at=excluded.updated_at",
            (user_id, (username or "").lower() or None, first_name, ts),
        )


def find_user_by_username(username: str):
    username = username.lstrip("@").lower()
    with cursor() as cur:
        cur.execute("SELECT user_id, first_name FROM users_cache WHERE username=?", (username,))
        return cur.fetchone()


def get_cached_name(user_id: int) -> str:
    with cursor() as cur:
        cur.execute("SELECT first_name FROM users_cache WHERE user_id=?", (user_id,))
        row = cur.fetchone()
        return row[0] if row else str(user_id)


# ---------------- Roles داخلی (Moderator) ----------------

def set_role(chat_id: int, user_id: int, role: str):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO roles (chat_id, user_id, role) VALUES (?, ?, ?) "
            "ON CONFLICT(chat_id, user_id) DO UPDATE SET role=excluded.role",
            (chat_id, user_id, role),
        )


def remove_role(chat_id: int, user_id: int):
    with cursor() as cur:
        cur.execute("DELETE FROM roles WHERE chat_id=? AND user_id=?", (chat_id, user_id))


def get_role(chat_id: int, user_id: int):
    with cursor() as cur:
        cur.execute("SELECT role FROM roles WHERE chat_id=? AND user_id=?", (chat_id, user_id))
        row = cur.fetchone()
        return row[0] if row else None


def list_roles(chat_id: int) -> list:
    with cursor() as cur:
        cur.execute("SELECT user_id, role FROM roles WHERE chat_id=?", (chat_id,))
        return cur.fetchall()


# ---------------- Audit log ----------------

def add_audit(chat_id: int, actor_id: int, actor_name: str, action: str,
              target_id: int, target_name: str, reason: str, ts: float):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO audit_log (chat_id, actor_id, actor_name, action, target_id, "
            "target_name, reason, ts) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (chat_id, actor_id, actor_name, action, target_id, target_name, reason, ts),
        )


def get_recent_audit(chat_id: int, limit: int = 15) -> list:
    with cursor() as cur:
        cur.execute(
            "SELECT actor_name, action, target_name, reason, ts FROM audit_log "
            "WHERE chat_id=? ORDER BY ts DESC LIMIT ?",
            (chat_id, limit),
        )
        return cur.fetchall()


def count_audit_actions(chat_id: int, since_ts: float, action_like: str = None) -> int:
    """برای NEXOR Copilot (Group Health): شمارش اقدامات ثبت‌شده در یک بازه‌ی زمانی."""
    with cursor() as cur:
        if action_like:
            cur.execute(
                "SELECT COUNT(*) FROM audit_log WHERE chat_id=? AND ts>=? AND action LIKE ?",
                (chat_id, since_ts, action_like),
            )
        else:
            cur.execute(
                "SELECT COUNT(*) FROM audit_log WHERE chat_id=? AND ts>=?",
                (chat_id, since_ts),
            )
        return cur.fetchone()[0]


def get_audit_for_target(chat_id: int, target_id: int, limit: int = 10) -> list:
    """برای NEXOR Copilot (Explain Action): آخرین اقدامات مدیریتی ثبت‌شده روی یک کاربر خاص."""
    with cursor() as cur:
        cur.execute(
            "SELECT actor_name, action, reason, ts FROM audit_log "
            "WHERE chat_id=? AND target_id=? ORDER BY ts DESC LIMIT ?",
            (chat_id, target_id, limit),
        )
        return cur.fetchall()


def get_actor_audit_count(chat_id: int, actor_id: int, action: str, since_ts: float) -> int:
    """برای Anti-Admin Abuse: چند بار یک actor یک اکشن خاص رو اخیراً انجام داده."""
    with cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) FROM audit_log WHERE chat_id=? AND actor_id=? AND action=? AND ts>=?",
            (chat_id, actor_id, action, since_ts),
        )
        return cur.fetchone()[0]


def count_actor_destructive_actions(chat_id: int, actor_id: int, actions, since_ts: float) -> int:
    """برای Anti-Admin Abuse: مجموع تعداد هر کدوم از یک دسته اکشن مخرب (مثل
    ban/mute/kick/warn با هم) که یک actor مشخص در یک بازه‌ی زمانی اخیر روی این
    گروه زده — برخلاف get_actor_audit_count که فقط یک نوع اکشن رو می‌شمرد."""
    actions = tuple(actions)
    if not actions:
        return 0
    placeholders = ",".join("?" for _ in actions)
    with cursor() as cur:
        cur.execute(
            f"SELECT COUNT(*) FROM audit_log WHERE chat_id=? AND actor_id=? "
            f"AND action IN ({placeholders}) AND ts>=?",
            (chat_id, actor_id, *actions, since_ts),
        )
        return cur.fetchone()[0]


# ---------------- Link Protection: Domain Whitelist/Blacklist ----------------

def add_domain(chat_id: int, domain: str, kind: str):
    with cursor() as cur:
        cur.execute(
            "INSERT OR IGNORE INTO domains (chat_id, domain, kind) VALUES (?, ?, ?)",
            (chat_id, domain.lower().strip(), kind),
        )
    _invalidate_chat_cache(chat_id)


def remove_domain(chat_id: int, domain: str, kind: str):
    with cursor() as cur:
        cur.execute(
            "DELETE FROM domains WHERE chat_id=? AND domain=? AND kind=?",
            (chat_id, domain.lower().strip(), kind),
        )
    _invalidate_chat_cache(chat_id)


def get_domains(chat_id: int, kind: str) -> list:
    with cursor() as cur:
        cur.execute("SELECT domain FROM domains WHERE chat_id=? AND kind=?", (chat_id, kind))
        return [row[0] for row in cur.fetchall()]


def is_domain_listed(chat_id: int, domain: str, kind: str) -> bool:
    """آیا دامنه (یا زیردامنه‌اش) توی لیست kind هست؟ از کش per-chat می‌خونه، نه DB مستقیم."""
    domain = domain.lower().strip()
    entry = _get_chat_cache_entry(chat_id)
    domains = entry["domains"].get(kind, ())
    for listed in domains:
        if domain == listed or domain.endswith("." + listed):
            return True
    return False


# ---------------- Forbidden Words: استثناها ----------------

def add_filter_whitelist(chat_id: int, word: str):
    with cursor() as cur:
        cur.execute(
            "INSERT OR IGNORE INTO filters_whitelist (chat_id, word) VALUES (?, ?)",
            (chat_id, word.lower().strip()),
        )
    _invalidate_chat_cache(chat_id)


def remove_filter_whitelist(chat_id: int, word: str):
    with cursor() as cur:
        cur.execute(
            "DELETE FROM filters_whitelist WHERE chat_id=? AND word=?",
            (chat_id, word.lower().strip()),
        )
    _invalidate_chat_cache(chat_id)


def get_filter_whitelist(chat_id: int) -> list:
    return list(_get_chat_cache_entry(chat_id)["whitelist"])


# ---------------- Forward Protection: قوانین انتخابی ----------------

def add_forward_rule(chat_id: int, source_key: str, source_label: str, mode: str):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO forward_rules (chat_id, source_key, source_label, mode) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(chat_id, source_key) DO UPDATE SET source_label=excluded.source_label, mode=excluded.mode",
            (chat_id, source_key, source_label, mode),
        )


def remove_forward_rule(chat_id: int, source_key: str):
    with cursor() as cur:
        cur.execute("DELETE FROM forward_rules WHERE chat_id=? AND source_key=?", (chat_id, source_key))


def get_forward_rule(chat_id: int, source_key: str):
    with cursor() as cur:
        cur.execute(
            "SELECT mode FROM forward_rules WHERE chat_id=? AND source_key=?",
            (chat_id, source_key),
        )
        row = cur.fetchone()
        return row[0] if row else None


def list_forward_rules(chat_id: int, mode: str = None) -> list:
    with cursor() as cur:
        if mode:
            cur.execute(
                "SELECT source_key, source_label, mode FROM forward_rules WHERE chat_id=? AND mode=?",
                (chat_id, mode),
            )
        else:
            cur.execute(
                "SELECT source_key, source_label, mode FROM forward_rules WHERE chat_id=?",
                (chat_id,),
            )
        return cur.fetchall()


# ---------------- Locks ----------------

def get_locks(chat_id: int) -> set:
    return set(_get_chat_cache_entry(chat_id)["locks"])


def add_lock(chat_id: int, lock_type: str):
    with cursor() as cur:
        cur.execute("INSERT OR IGNORE INTO locks (chat_id, lock_type) VALUES (?, ?)", (chat_id, lock_type))
    _invalidate_chat_cache(chat_id)


def remove_lock(chat_id: int, lock_type: str):
    with cursor() as cur:
        cur.execute("DELETE FROM locks WHERE chat_id=? AND lock_type=?", (chat_id, lock_type))
    _invalidate_chat_cache(chat_id)


# ---------------- Word filters ----------------

def get_filters(chat_id: int) -> set:
    return set(_get_chat_cache_entry(chat_id)["filters"])


def add_filter(chat_id: int, word: str):
    with cursor() as cur:
        cur.execute("INSERT OR IGNORE INTO word_filters (chat_id, word) VALUES (?, ?)", (chat_id, word))
    _invalidate_chat_cache(chat_id)


def remove_filter(chat_id: int, word: str):
    with cursor() as cur:
        cur.execute("DELETE FROM word_filters WHERE chat_id=? AND word=?", (chat_id, word))
    _invalidate_chat_cache(chat_id)


# ---------------- Notes ----------------

def get_note(chat_id: int, name: str):
    with cursor() as cur:
        cur.execute("SELECT content FROM notes WHERE chat_id=? AND name=?", (chat_id, name))
        row = cur.fetchone()
        return row[0] if row else None


def list_notes(chat_id: int) -> list:
    with cursor() as cur:
        cur.execute("SELECT name FROM notes WHERE chat_id=?", (chat_id,))
        return [row[0] for row in cur.fetchall()]


def save_note(chat_id: int, name: str, content: str):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO notes (chat_id, name, content) VALUES (?, ?, ?) "
            "ON CONFLICT(chat_id, name) DO UPDATE SET content=excluded.content",
            (chat_id, name, content),
        )


def delete_note(chat_id: int, name: str):
    with cursor() as cur:
        cur.execute("DELETE FROM notes WHERE chat_id=? AND name=?", (chat_id, name))


# ---------------- Settings (key-value per chat) ----------------

def get_setting(chat_id: int, key: str, default=None):
    return _get_chat_cache_entry(chat_id)["settings"].get(key, default)


def set_setting(chat_id: int, key: str, value: str):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO settings (chat_id, key, value) VALUES (?, ?, ?) "
            "ON CONFLICT(chat_id, key) DO UPDATE SET value=excluded.value",
            (chat_id, key, str(value)),
        )
    _invalidate_chat_cache(chat_id)


def all_settings(chat_id: int) -> dict:
    return dict(_get_chat_cache_entry(chat_id)["settings"])


# ---------------- Daily Notify (سیستم اطلاع‌رسانی روزانه) ----------------
# روی همون جدول settings کلید-مقدار عمومی سوار می‌شه (یک کلید JSON به اسم
# "daily_notify_config" به ازای هر چت) تا:
#   ۱) هیچ Migration/جدول جدیدی لازم نباشه،
#   ۲) رایگان و بدون تغییر توی /exportsettings و /importsettings هم شرکت کنه
#      (چون db.all_settings همین‌جوری همه‌ی کلیدها رو می‌گیره).
_DAILY_NOTIFY_KEY = "daily_notify_config"


def get_daily_notify_config(chat_id: int) -> dict:
    raw = get_setting(chat_id, _DAILY_NOTIFY_KEY, None)
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, TypeError):
        return {}


def set_daily_notify_config(chat_id: int, config: dict) -> None:
    set_setting(chat_id, _DAILY_NOTIFY_KEY, json.dumps(config, ensure_ascii=False))


def list_daily_notify_chats() -> list[int]:
    """همه‌ی چت‌هایی که حداقل یک‌بار تنظیمات اطلاع‌رسانی روزانه براشون ذخیره
    شده (برای reschedule موقع استارت ربات)."""
    with cursor() as cur:
        cur.execute("SELECT chat_id FROM settings WHERE key=?", (_DAILY_NOTIFY_KEY,))
        return [row[0] for row in cur.fetchall()]


# ---------------- CAPTCHA pending list ----------------

def add_pending_captcha(chat_id: int, user_id: int, join_time: float):
    with cursor() as cur:
        cur.execute(
            "INSERT OR REPLACE INTO pending_captcha (chat_id, user_id, join_time) VALUES (?, ?, ?)",
            (chat_id, user_id, join_time),
        )


def remove_pending_captcha(chat_id: int, user_id: int):
    with cursor() as cur:
        cur.execute("DELETE FROM pending_captcha WHERE chat_id=? AND user_id=?", (chat_id, user_id))


def is_pending_captcha(chat_id: int, user_id: int) -> bool:
    with cursor() as cur:
        cur.execute("SELECT 1 FROM pending_captcha WHERE chat_id=? AND user_id=?", (chat_id, user_id))
        return cur.fetchone() is not None


# ---------------- Federations ----------------

def create_federation(name: str, owner_id: int) -> int:
    with cursor() as cur:
        cur.execute("INSERT INTO federations (name, owner_id) VALUES (?, ?)", (name, owner_id))
        return cur.lastrowid


def get_federation(fed_id: int):
    with cursor() as cur:
        cur.execute("SELECT fed_id, name, owner_id FROM federations WHERE fed_id=?", (fed_id,))
        return cur.fetchone()


def join_federation(fed_id: int, chat_id: int):
    with cursor() as cur:
        cur.execute("INSERT OR IGNORE INTO federation_chats (fed_id, chat_id) VALUES (?, ?)", (fed_id, chat_id))


def leave_federation(fed_id: int, chat_id: int):
    with cursor() as cur:
        cur.execute("DELETE FROM federation_chats WHERE fed_id=? AND chat_id=?", (fed_id, chat_id))


def get_chat_federation(chat_id: int):
    """فدراسیونی که این چت عضوشه رو برمی‌گردونه (یک چت فقط تو یک فدراسیون)."""
    with cursor() as cur:
        cur.execute("""
            SELECT f.fed_id, f.name, f.owner_id FROM federations f
            JOIN federation_chats fc ON f.fed_id = fc.fed_id
            WHERE fc.chat_id=?
        """, (chat_id,))
        return cur.fetchone()


def get_federation_chats(fed_id: int) -> list:
    with cursor() as cur:
        cur.execute("SELECT chat_id FROM federation_chats WHERE fed_id=?", (fed_id,))
        return [row[0] for row in cur.fetchall()]


def add_federation_ban(fed_id: int, user_id: int, reason: str):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO federation_bans (fed_id, user_id, reason) VALUES (?, ?, ?) "
            "ON CONFLICT(fed_id, user_id) DO UPDATE SET reason=excluded.reason",
            (fed_id, user_id, reason),
        )


def remove_federation_ban(fed_id: int, user_id: int):
    with cursor() as cur:
        cur.execute("DELETE FROM federation_bans WHERE fed_id=? AND user_id=?", (fed_id, user_id))


def is_federation_banned(fed_id: int, user_id: int) -> bool:
    with cursor() as cur:
        cur.execute("SELECT 1 FROM federation_bans WHERE fed_id=? AND user_id=?", (fed_id, user_id))
        return cur.fetchone() is not None


# ---------------- Priority 4: Rules System ----------------

def set_rules(chat_id: int, lang: str, text: str):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO chat_rules (chat_id, lang, text) VALUES (?, ?, ?) "
            "ON CONFLICT(chat_id, lang) DO UPDATE SET text=excluded.text",
            (chat_id, lang, text),
        )


def get_rules(chat_id: int, lang: str):
    with cursor() as cur:
        cur.execute("SELECT text FROM chat_rules WHERE chat_id=? AND lang=?", (chat_id, lang))
        row = cur.fetchone()
        return row[0] if row else None


def get_any_rules(chat_id: int):
    """اگر برای زبان فعلی گروه قانونی ثبت نشده بود، هر زبان دیگری که موجود باشد را برمی‌گرداند."""
    with cursor() as cur:
        cur.execute("SELECT lang, text FROM chat_rules WHERE chat_id=? LIMIT 1", (chat_id,))
        return cur.fetchone()


def clear_rules(chat_id: int, lang: str) -> bool:
    with cursor() as cur:
        cur.execute("DELETE FROM chat_rules WHERE chat_id=? AND lang=?", (chat_id, lang))
        return cur.rowcount > 0


def list_rules_langs(chat_id: int) -> list:
    with cursor() as cur:
        cur.execute("SELECT lang FROM chat_rules WHERE chat_id=?", (chat_id,))
        return [row[0] for row in cur.fetchall()]


# ---------------- Priority 4: Filters (Keyword -> Auto Response) ----------------

def add_keyword_trigger(chat_id: int, keyword: str, response: str) -> bool:
    """True اگر جدید بود، False اگر از قبل بود و فقط آپدیت شد."""
    keyword = keyword.lower().strip()
    existed = get_keyword_trigger(chat_id, keyword) is not None
    with cursor() as cur:
        cur.execute(
            "INSERT INTO keyword_triggers (chat_id, keyword, response) VALUES (?, ?, ?) "
            "ON CONFLICT(chat_id, keyword) DO UPDATE SET response=excluded.response",
            (chat_id, keyword, response),
        )
    return not existed


def remove_keyword_trigger(chat_id: int, keyword: str) -> bool:
    keyword = keyword.lower().strip()
    with cursor() as cur:
        cur.execute("DELETE FROM keyword_triggers WHERE chat_id=? AND keyword=?", (chat_id, keyword))
        return cur.rowcount > 0


def get_keyword_trigger(chat_id: int, keyword: str):
    keyword = keyword.lower().strip()
    with cursor() as cur:
        cur.execute("SELECT response FROM keyword_triggers WHERE chat_id=? AND keyword=?", (chat_id, keyword))
        row = cur.fetchone()
        return row[0] if row else None


def list_keyword_triggers(chat_id: int) -> list:
    with cursor() as cur:
        cur.execute("SELECT keyword, response FROM keyword_triggers WHERE chat_id=?", (chat_id,))
        return cur.fetchall()


# ---------------- Auto-Answer (پاسخ خودکار) ----------------

def add_auto_answer(chat_id: int, keyword: str, audience: str, responses: list, created_by: int) -> bool:
    """ذخیره/آپدیت یک تریگر Auto-Answer. True یعنی جدید بود، False یعنی جایگزین شد."""
    keyword = keyword.lower().strip()
    existed = get_auto_answer(chat_id, keyword) is not None
    with cursor() as cur:
        cur.execute(
            "INSERT INTO auto_answers (chat_id, keyword, audience, responses_json, created_by, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(chat_id, keyword) DO UPDATE SET "
            "audience=excluded.audience, responses_json=excluded.responses_json, "
            "created_by=excluded.created_by, created_at=excluded.created_at",
            (chat_id, keyword, audience, json.dumps(responses, ensure_ascii=False), created_by, time.time()),
        )
    return not existed


def remove_auto_answer(chat_id: int, keyword: str) -> bool:
    keyword = keyword.lower().strip()
    with cursor() as cur:
        cur.execute("DELETE FROM auto_answers WHERE chat_id=? AND keyword=?", (chat_id, keyword))
        return cur.rowcount > 0


def clear_auto_answers(chat_id: int) -> int:
    """حذف همه‌ی Auto-Answerهای این چت؛ تعداد ردیف حذف‌شده را برمی‌گرداند."""
    with cursor() as cur:
        cur.execute("DELETE FROM auto_answers WHERE chat_id=?", (chat_id,))
        return cur.rowcount


def get_auto_answer(chat_id: int, keyword: str):
    """(audience, responses:list) یا None."""
    keyword = keyword.lower().strip()
    with cursor() as cur:
        cur.execute("SELECT audience, responses_json FROM auto_answers WHERE chat_id=? AND keyword=?", (chat_id, keyword))
        row = cur.fetchone()
        if not row:
            return None
        try:
            responses = json.loads(row[1])
        except (TypeError, ValueError):
            responses = []
        return row[0], responses


def list_auto_answers(chat_id: int) -> list:
    """[(keyword, audience, responses:list), ...]"""
    with cursor() as cur:
        cur.execute("SELECT keyword, audience, responses_json FROM auto_answers WHERE chat_id=?", (chat_id,))
        rows = cur.fetchall()
    out = []
    for keyword, audience, responses_json in rows:
        try:
            responses = json.loads(responses_json)
        except (TypeError, ValueError):
            responses = []
        out.append((keyword, audience, responses))
    return out


def find_matching_auto_answer(chat_id: int, text_lower: str):
    """اولین تریگر Auto-Answer که کلیدواژه‌اش زیررشته‌ی متن پیام است را برمی‌گرداند.

    (keyword, audience, responses:list) یا None.
    """
    for keyword, audience, responses in list_auto_answers(chat_id):
        if keyword in text_lower:
            return keyword, audience, responses
    return None


# ---------------- Priority 4: Custom Commands ----------------

def add_custom_command(chat_id: int, name: str, response: str) -> bool:
    name = name.lower().strip().lstrip("/")
    existed = get_custom_command(chat_id, name) is not None
    with cursor() as cur:
        cur.execute(
            "INSERT INTO custom_commands (chat_id, name, response) VALUES (?, ?, ?) "
            "ON CONFLICT(chat_id, name) DO UPDATE SET response=excluded.response",
            (chat_id, name, response),
        )
    return not existed


def remove_custom_command(chat_id: int, name: str) -> bool:
    name = name.lower().strip().lstrip("/")
    with cursor() as cur:
        cur.execute("DELETE FROM custom_commands WHERE chat_id=? AND name=?", (chat_id, name))
        return cur.rowcount > 0


def get_custom_command(chat_id: int, name: str):
    name = name.lower().strip().lstrip("/")
    with cursor() as cur:
        cur.execute("SELECT response FROM custom_commands WHERE chat_id=? AND name=?", (chat_id, name))
        row = cur.fetchone()
        return row[0] if row else None


def list_custom_commands(chat_id: int) -> list:
    with cursor() as cur:
        cur.execute("SELECT name, response FROM custom_commands WHERE chat_id=?", (chat_id,))
        return cur.fetchall()


# ---------------- Priority 4: Recurring Posts (Scheduled Messages) ----------------

def add_recurring_post(chat_id: int, channel: str, schedule_type: str, weekday, day_of_month,
                        hour: int, minute: int, text: str, buttons_json: str, created_by: int) -> int:
    with cursor() as cur:
        cur.execute(
            "INSERT INTO recurring_posts (chat_id, channel, schedule_type, weekday, day_of_month, "
            "hour, minute, text, buttons_json, created_by, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)",
            (chat_id, channel, schedule_type, weekday, day_of_month, hour, minute, text, buttons_json, created_by),
        )
        return cur.lastrowid


def get_recurring_posts(chat_id: int, active_only: bool = True) -> list:
    with cursor() as cur:
        if active_only:
            cur.execute(
                "SELECT id, channel, schedule_type, weekday, day_of_month, hour, minute, text, buttons_json "
                "FROM recurring_posts WHERE chat_id=? AND active=1", (chat_id,),
            )
        else:
            cur.execute(
                "SELECT id, channel, schedule_type, weekday, day_of_month, hour, minute, text, buttons_json "
                "FROM recurring_posts WHERE chat_id=?", (chat_id,),
            )
        return cur.fetchall()


def get_all_active_recurring_posts() -> list:
    """برای بازسازی Jobها هنگام استارت ربات."""
    with cursor() as cur:
        cur.execute(
            "SELECT id, chat_id, channel, schedule_type, weekday, day_of_month, hour, minute, text, buttons_json "
            "FROM recurring_posts WHERE active=1"
        )
        return cur.fetchall()


def deactivate_recurring_post(post_id: int, chat_id: int) -> bool:
    with cursor() as cur:
        cur.execute(
            "UPDATE recurring_posts SET active=0 WHERE id=? AND chat_id=? AND active=1",
            (post_id, chat_id),
        )
        return cur.rowcount > 0


# ---------------- Priority 4: Auto Actions (Rule Engine) ----------------

def add_auto_action_rule(chat_id: int, condition_type: str, condition_value: str,
                          action_type: str, action_value: str) -> int:
    with cursor() as cur:
        cur.execute(
            "INSERT INTO auto_action_rules (chat_id, condition_type, condition_value, "
            "action_type, action_value, enabled) VALUES (?, ?, ?, ?, ?, 1)",
            (chat_id, condition_type, condition_value, action_type, action_value),
        )
        return cur.lastrowid


def get_auto_action_rules(chat_id: int, condition_type: str = None) -> list:
    with cursor() as cur:
        if condition_type:
            cur.execute(
                "SELECT id, condition_type, condition_value, action_type, action_value FROM auto_action_rules "
                "WHERE chat_id=? AND condition_type=? AND enabled=1", (chat_id, condition_type),
            )
        else:
            cur.execute(
                "SELECT id, condition_type, condition_value, action_type, action_value FROM auto_action_rules "
                "WHERE chat_id=? AND enabled=1", (chat_id,),
            )
        return cur.fetchall()


def remove_auto_action_rule(rule_id: int, chat_id: int) -> bool:
    with cursor() as cur:
        cur.execute("DELETE FROM auto_action_rules WHERE id=? AND chat_id=?", (rule_id, chat_id))
        return cur.rowcount > 0


# ---------------- Priority 5, Item 25: Permission Profiles ----------------

def set_permission_profile(chat_id: int, name: str, capabilities: str):
    """capabilities یک رشته‌ی comma-separated از کلیدهای config.CAPABILITIES است."""
    with cursor() as cur:
        cur.execute(
            "INSERT INTO permission_profiles (chat_id, name, capabilities) VALUES (?, ?, ?) "
            "ON CONFLICT(chat_id, name) DO UPDATE SET capabilities=excluded.capabilities",
            (chat_id, name.lower().strip(), capabilities),
        )


def get_permission_profile(chat_id: int, name: str):
    with cursor() as cur:
        cur.execute(
            "SELECT capabilities FROM permission_profiles WHERE chat_id=? AND name=?",
            (chat_id, name.lower().strip()),
        )
        row = cur.fetchone()
        return row[0] if row else None


def delete_permission_profile(chat_id: int, name: str) -> bool:
    name = name.lower().strip()
    with cursor() as cur:
        cur.execute("DELETE FROM permission_profiles WHERE chat_id=? AND name=?", (chat_id, name))
        existed = cur.rowcount > 0
        # پروفایل حذف‌شده از هر کاربری که بهش assign شده هم برداشته می‌شه که Dangling نمونه
        cur.execute("DELETE FROM profile_assignments WHERE chat_id=? AND profile=?", (chat_id, name))
        return existed


def list_permission_profiles(chat_id: int) -> list:
    with cursor() as cur:
        cur.execute("SELECT name, capabilities FROM permission_profiles WHERE chat_id=?", (chat_id,))
        return cur.fetchall()


def assign_profile(chat_id: int, user_id: int, profile: str):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO profile_assignments (chat_id, user_id, profile) VALUES (?, ?, ?) "
            "ON CONFLICT(chat_id, user_id) DO UPDATE SET profile=excluded.profile",
            (chat_id, user_id, profile.lower().strip()),
        )


def unassign_profile(chat_id: int, user_id: int) -> bool:
    with cursor() as cur:
        cur.execute("DELETE FROM profile_assignments WHERE chat_id=? AND user_id=?", (chat_id, user_id))
        return cur.rowcount > 0


def get_profile_assignment(chat_id: int, user_id: int):
    with cursor() as cur:
        cur.execute("SELECT profile FROM profile_assignments WHERE chat_id=? AND user_id=?", (chat_id, user_id))
        row = cur.fetchone()
        return row[0] if row else None


def list_profile_assignments(chat_id: int) -> list:
    with cursor() as cur:
        cur.execute("SELECT user_id, profile FROM profile_assignments WHERE chat_id=?", (chat_id,))
        return cur.fetchall()


# ---------------- Priority 5, Item 26: Reports ----------------

def add_report(chat_id: int, reporter_id: int, reporter_name: str, target_id: int, target_name: str,
               message_id: int, reason: str, ts: float) -> int:
    with cursor() as cur:
        cur.execute(
            "INSERT INTO reports (chat_id, reporter_id, reporter_name, target_id, target_name, "
            "message_id, reason, ts, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open')",
            (chat_id, reporter_id, reporter_name, target_id, target_name, message_id, reason, ts),
        )
        return cur.lastrowid


def get_report(report_id: int):
    with cursor() as cur:
        cur.execute(
            "SELECT id, chat_id, reporter_id, reporter_name, target_id, target_name, message_id, "
            "reason, ts, status FROM reports WHERE id=?",
            (report_id,),
        )
        return cur.fetchone()


def set_report_status(report_id: int, status: str):
    with cursor() as cur:
        cur.execute("UPDATE reports SET status=? WHERE id=?", (status, report_id))


def list_open_reports(chat_id: int, limit: int = 15) -> list:
    with cursor() as cur:
        cur.execute(
            "SELECT id, reporter_name, target_name, reason, ts FROM reports "
            "WHERE chat_id=? AND status='open' ORDER BY ts DESC LIMIT ?",
            (chat_id, limit),
        )
        return cur.fetchall()


def find_recent_report_by_reporter(chat_id: int, reporter_id: int, message_id: int, since_ts: float):
    """برای جلوگیری از Report تکراری روی همون پیام در بازه‌ی Cooldown."""
    with cursor() as cur:
        cur.execute(
            "SELECT id FROM reports WHERE chat_id=? AND reporter_id=? AND message_id=? AND ts>=?",
            (chat_id, reporter_id, message_id, since_ts),
        )
        return cur.fetchone()


def count_recent_reports_on_target(chat_id: int, target_id: int, since_ts: float) -> int:
    """برای Admin Alert «Multiple Reports»: چند Report مجزا اخیراً روی این کاربر ثبت شده."""
    with cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) FROM reports WHERE chat_id=? AND target_id=? AND ts>=?",
            (chat_id, target_id, since_ts),
        )
        return cur.fetchone()[0]


# ---------------- Priority 5, Item 27: Admin Alerts ----------------

def add_alert(chat_id: int, alert_type: str, text: str, ts: float):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO admin_alerts (chat_id, alert_type, text, ts) VALUES (?, ?, ?, ?)",
            (chat_id, alert_type, text, ts),
        )


def list_recent_alerts(chat_id: int, limit: int = 15) -> list:
    with cursor() as cur:
        cur.execute(
            "SELECT alert_type, text, ts FROM admin_alerts WHERE chat_id=? ORDER BY ts DESC LIMIT ?",
            (chat_id, limit),
        )
        return cur.fetchall()


# ---------------- Priority 5, Item 28: Import / Export Settings ----------------

def get_all_chat_rules(chat_id: int) -> list:
    with cursor() as cur:
        cur.execute("SELECT lang, text FROM chat_rules WHERE chat_id=?", (chat_id,))
        return cur.fetchall()


def replace_chat_config(chat_id: int, data: dict):
    """Atomically replace all importable configuration for a chat.

    All deletes/inserts share one SQLite transaction. If any statement fails,
    the cursor context rolls the transaction back instead of leaving a partial import.
    """
    tables = (
        "locks", "word_filters", "filters_whitelist", "domains", "forward_rules",
        "chat_rules", "keyword_triggers", "custom_commands", "auto_action_rules",
        "permission_profiles", "profile_assignments", "settings",
    )
    with _lock:
        cur = _conn.cursor()
        try:
            for table in tables:
                cur.execute(f"DELETE FROM {table} WHERE chat_id=?", (chat_id,))

            cur.executemany(
                "INSERT INTO settings(chat_id,key,value) VALUES(?,?,?)",
                [(chat_id, k, str(v)) for k, v in data.get("settings", {}).items()],
            )
            cur.executemany(
                "INSERT INTO locks(chat_id,lock_type) VALUES(?,?)",
                [(chat_id, x) for x in data.get("locks", [])],
            )
            cur.executemany(
                "INSERT INTO word_filters(chat_id,word) VALUES(?,?)",
                [(chat_id, x) for x in data.get("word_filters", [])],
            )
            cur.executemany(
                "INSERT INTO filters_whitelist(chat_id,word) VALUES(?,?)",
                [(chat_id, x) for x in data.get("filters_whitelist", [])],
            )
            domains = data.get("domains", {})
            cur.executemany(
                "INSERT INTO domains(chat_id,domain,kind) VALUES(?,?,?)",
                [(chat_id, x, "blacklist") for x in domains.get("blacklist", [])]
                + [(chat_id, x, "whitelist") for x in domains.get("whitelist", [])],
            )
            cur.executemany(
                "INSERT INTO forward_rules(chat_id,source_key,source_label,mode) VALUES(?,?,?,?)",
                [(chat_id, r["source_key"], r.get("source_label", r["source_key"]), r["mode"])
                 for r in data.get("forward_rules", [])],
            )
            cur.executemany(
                "INSERT INTO chat_rules(chat_id,lang,text) VALUES(?,?,?)",
                [(chat_id, r["lang"], r["text"]) for r in data.get("chat_rules", [])],
            )
            cur.executemany(
                "INSERT INTO keyword_triggers(chat_id,keyword,response) VALUES(?,?,?)",
                [(chat_id, r["keyword"], r["response"]) for r in data.get("keyword_triggers", [])],
            )
            cur.executemany(
                "INSERT INTO custom_commands(chat_id,name,response) VALUES(?,?,?)",
                [(chat_id, r["name"], r["response"]) for r in data.get("custom_commands", [])],
            )
            cur.executemany(
                "INSERT INTO auto_action_rules(chat_id,condition_type,condition_value,action_type,action_value,enabled) VALUES(?,?,?,?,?,1)",
                [(chat_id, r["condition_type"], r["condition_value"], r["action_type"], r.get("action_value", ""))
                 for r in data.get("auto_action_rules", [])],
            )
            cur.executemany(
                "INSERT INTO permission_profiles(chat_id,name,capabilities) VALUES(?,?,?)",
                [(chat_id, r["name"].lower().strip(), r["capabilities"])
                 for r in data.get("permission_profiles", [])],
            )
            cur.executemany(
                "INSERT INTO profile_assignments(chat_id,user_id,profile) VALUES(?,?,?)",
                [(chat_id, int(r["user_id"]), r["profile"].lower().strip())
                 for r in data.get("profile_assignments", [])],
            )
            _conn.commit()
        except Exception:
            _conn.rollback()
            raise
        finally:
            cur.close()
    _invalidate_chat_cache(chat_id)


def clear_chat_config(chat_id: int):
    """
    پاک‌سازی کامل «تنظیمات قابل Import/Export» یک گروه، قبل از اعمال Import.
    عمداً جدول‌های تاریخچه‌ای/دائمی (warns/warns_log/audit_log/reports/admin_alerts/
    users_cache/pending_captcha) دست‌نخورده می‌مونن چون این‌ها Log هستن نه Setting.
    """
    tables = (
        "locks", "word_filters", "filters_whitelist", "domains", "forward_rules",
        "chat_rules", "keyword_triggers", "custom_commands", "auto_action_rules",
        "permission_profiles", "profile_assignments",
    )
    with cursor() as cur:
        for table in tables:
            cur.execute(f"DELETE FROM {table} WHERE chat_id=?", (chat_id,))
        cur.execute("DELETE FROM settings WHERE chat_id=?", (chat_id,))
    _invalidate_chat_cache(chat_id)

# ---------------- NEXOR Copilot (AI Module) ----------------

def ai_get_usage(chat_id: int, user_id: int, day: str) -> int:
    with cursor() as cur:
        cur.execute(
            "SELECT count FROM ai_usage_daily WHERE chat_id=? AND user_id=? AND day=?",
            (chat_id, user_id, day),
        )
        row = cur.fetchone()
        return row[0] if row else 0


def ai_increment_usage(chat_id: int, user_id: int, day: str) -> int:
    """اتمیک: مصرف امروز را یکی زیاد می‌کند و مقدار جدید را برمی‌گرداند."""
    with cursor() as cur:
        cur.execute(
            "INSERT INTO ai_usage_daily (chat_id, user_id, day, count) VALUES (?, ?, ?, 1) "
            "ON CONFLICT(chat_id, user_id, day) DO UPDATE SET count = count + 1",
            (chat_id, user_id, day),
        )
        cur.execute(
            "SELECT count FROM ai_usage_daily WHERE chat_id=? AND user_id=? AND day=?",
            (chat_id, user_id, day),
        )
        return cur.fetchone()[0]


def ai_log_request(chat_id: int, actor_id: int, feature: str, plan: str,
                    success: bool, used_ai: bool, error: str, ts: float):
    with cursor() as cur:
        cur.execute(
            "INSERT INTO ai_request_log (chat_id, actor_id, feature, plan, success, used_ai, error, ts) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (chat_id, actor_id, feature, plan, 1 if success else 0, 1 if used_ai else 0, error, ts),
        )


def ai_recent_request_stats(chat_id: int, since_ts: float) -> list:
    """برای Group Health: خلاصه‌ی مصرف اخیر AI این گروه، به تفکیک feature."""
    with cursor() as cur:
        cur.execute(
            "SELECT feature, COUNT(*), SUM(success), SUM(used_ai) FROM ai_request_log "
            "WHERE chat_id=? AND ts>=? GROUP BY feature",
            (chat_id, since_ts),
        )
        return cur.fetchall()


def ai_count_autoaction_firings(chat_id: int, rule_id: int, since_ts: float) -> int:
    """برای Rule Optimization: چند بار این قانون اخیراً واقعاً اجرا شده (از audit_log)."""
    with cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) FROM audit_log WHERE chat_id=? AND action LIKE 'autoaction_%' "
            "AND reason LIKE ? AND ts>=?",
            (chat_id, f"%(#{rule_id})%", since_ts),
        )
        return cur.fetchone()[0]


# ---------------- Payments/Subscriptions ----------------
# لایه‌ی داده‌ی خام برای سفارش‌های خرید اشتراک. منطق قیمت‌گذاری/اعمال پلن اینجا
# نیست (در services/payments.py) — این ماژول فقط CRUD خام روی جدول رو انجام
# می‌ده، هم‌سو با بقیه‌ی db.py.

def create_subscription_order(chat_id: int, user_id: int, plan: str, months: int,
                               method: str, ts: float, amount_stars: int = None,
                               amount_ton_nano: int = None, ton_memo: str = None,
                               stars_invoice_payload: str = None,
                               card_reference: str = None) -> int:
    with cursor() as cur:
        cur.execute(
            "INSERT INTO subscription_orders "
            "(chat_id, user_id, plan, months, method, status, amount_stars, "
            "amount_ton_nano, ton_memo, stars_invoice_payload, card_reference, created_at) "
            "VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?)",
            (chat_id, user_id, plan, months, method, amount_stars, amount_ton_nano,
             ton_memo, stars_invoice_payload, card_reference, ts),
        )
        return cur.lastrowid


_SUBSCRIPTION_ORDER_COLUMNS = (
    "id", "chat_id", "user_id", "plan", "months", "method", "status",
    "amount_stars", "amount_ton_nano", "ton_memo", "ton_tx_hash",
    "stars_invoice_payload", "stars_charge_id", "card_reference",
    "card_receipt_note", "admin_id", "created_at", "confirmed_at",
)


def _row_to_order(row) -> dict | None:
    if row is None:
        return None
    return dict(zip(_SUBSCRIPTION_ORDER_COLUMNS, row))


def set_stars_invoice_payload(order_id: int, payload: str) -> None:
    with cursor() as cur:
        cur.execute("UPDATE subscription_orders SET stars_invoice_payload=? WHERE id=?", (payload, order_id))


def get_subscription_order(order_id: int) -> dict | None:
    with cursor() as cur:
        cur.execute(f"SELECT {', '.join(_SUBSCRIPTION_ORDER_COLUMNS)} FROM subscription_orders WHERE id=?", (order_id,))
        return _row_to_order(cur.fetchone())


def get_subscription_order_by_payload(invoice_payload: str) -> dict | None:
    with cursor() as cur:
        cur.execute(
            f"SELECT {', '.join(_SUBSCRIPTION_ORDER_COLUMNS)} FROM subscription_orders WHERE stars_invoice_payload=?",
            (invoice_payload,),
        )
        return _row_to_order(cur.fetchone())


def get_pending_subscription_orders(method: str, max_age_hours: float = None) -> list:
    with cursor() as cur:
        if max_age_hours is None:
            cur.execute(
                f"SELECT {', '.join(_SUBSCRIPTION_ORDER_COLUMNS)} FROM subscription_orders "
                "WHERE method=? AND status='pending'",
                (method,),
            )
        else:
            import time as _time
            cutoff = _time.time() - max_age_hours * 3600
            cur.execute(
                f"SELECT {', '.join(_SUBSCRIPTION_ORDER_COLUMNS)} FROM subscription_orders "
                "WHERE method=? AND status='pending' AND created_at>=?",
                (method, cutoff),
            )
        return [_row_to_order(r) for r in cur.fetchall()]


def expire_stale_subscription_orders(method: str, max_age_hours: float) -> int:
    """سفارش‌های pending قدیمی‌تر از max_age_hours رو expired می‌کنه (برای TON/کارت که
    تاییدشون خودکار از تلگرام نمیاد و ممکنه هیچ‌وقت تکمیل نشن)."""
    import time as _time
    cutoff = _time.time() - max_age_hours * 3600
    with cursor() as cur:
        cur.execute(
            "UPDATE subscription_orders SET status='expired' "
            "WHERE method=? AND status='pending' AND created_at<?",
            (method, cutoff),
        )
        return cur.rowcount


def confirm_ton_subscription_order(ton_memo: str, tx_hash: str, ts: float) -> dict | None:
    """Idempotent: فقط اگه سفارش هنوز pending باشه تایید می‌شه (جلوگیری از دوبار
    واریز پاداش در صورت دیدن دوباره‌ی همون تراکنش توسط حلقه‌ی بررسی)."""
    with cursor() as cur:
        cur.execute(
            "UPDATE subscription_orders SET status='confirmed', ton_tx_hash=?, confirmed_at=? "
            "WHERE ton_memo=? AND status='pending'",
            (tx_hash, ts, ton_memo),
        )
        if cur.rowcount == 0:
            return None
        cur.execute(f"SELECT {', '.join(_SUBSCRIPTION_ORDER_COLUMNS)} FROM subscription_orders WHERE ton_memo=?", (ton_memo,))
        return _row_to_order(cur.fetchone())


def confirm_stars_subscription_order(invoice_payload: str, charge_id: str, ts: float) -> dict | None:
    with cursor() as cur:
        cur.execute(
            "UPDATE subscription_orders SET status='confirmed', stars_charge_id=?, confirmed_at=? "
            "WHERE stars_invoice_payload=? AND status='pending'",
            (charge_id, ts, invoice_payload),
        )
        if cur.rowcount == 0:
            return None
        cur.execute(
            f"SELECT {', '.join(_SUBSCRIPTION_ORDER_COLUMNS)} FROM subscription_orders WHERE stars_invoice_payload=?",
            (invoice_payload,),
        )
        return _row_to_order(cur.fetchone())


def list_pending_card_orders() -> list:
    with cursor() as cur:
        cur.execute(
            f"SELECT {', '.join(_SUBSCRIPTION_ORDER_COLUMNS)} FROM subscription_orders "
            "WHERE method='card' AND status='pending' ORDER BY created_at ASC",
        )
        return [_row_to_order(r) for r in cur.fetchall()]


def set_card_order_receipt_note(order_id: int, note: str) -> None:
    with cursor() as cur:
        cur.execute("UPDATE subscription_orders SET card_receipt_note=? WHERE id=?", (note, order_id))


def confirm_card_subscription_order(order_id: int, admin_id: int, ts: float) -> dict | None:
    with cursor() as cur:
        cur.execute(
            "UPDATE subscription_orders SET status='confirmed', admin_id=?, confirmed_at=? "
            "WHERE id=? AND status='pending' AND method='card'",
            (admin_id, ts, order_id),
        )
        if cur.rowcount == 0:
            return None
        cur.execute(f"SELECT {', '.join(_SUBSCRIPTION_ORDER_COLUMNS)} FROM subscription_orders WHERE id=?", (order_id,))
        return _row_to_order(cur.fetchone())


def reject_subscription_order(order_id: int, admin_id: int) -> bool:
    with cursor() as cur:
        cur.execute(
            "UPDATE subscription_orders SET status='rejected', admin_id=? "
            "WHERE id=? AND status='pending'",
            (admin_id, order_id),
        )
        return cur.rowcount > 0


# ---------------- Ads: known_chats registry ----------------

def touch_known_chat(chat_id: int, title: str | None, ts: float) -> None:
    with cursor() as cur:
        cur.execute(
            "INSERT INTO known_chats (chat_id, title, is_active, added_at, last_seen) "
            "VALUES (?, ?, 1, ?, ?) "
            "ON CONFLICT(chat_id) DO UPDATE SET title=COALESCE(excluded.title, known_chats.title), "
            "is_active=1, last_seen=excluded.last_seen",
            (chat_id, title, ts, ts),
        )


def mark_known_chat_inactive(chat_id: int) -> None:
    with cursor() as cur:
        cur.execute("UPDATE known_chats SET is_active=0 WHERE chat_id=?", (chat_id,))


def list_active_group_chats() -> list[int]:
    """همه‌ی گروه‌هایی که ربات هنوز عضوشونه (chat_id منفی = گروه/سوپرگروه در تلگرام)."""
    with cursor() as cur:
        cur.execute("SELECT chat_id FROM known_chats WHERE is_active=1 AND chat_id < 0")
        return [row[0] for row in cur.fetchall()]


# ---------------- Ads: ad_orders ----------------

_AD_ORDER_COLUMNS = (
    "id", "owner_chat_id", "user_id", "kind", "banner_file_id", "text",
    "times_per_day", "duration_days", "method", "amount_stars", "amount_ton_nano",
    "ton_memo", "ton_tx_hash", "stars_invoice_payload", "stars_charge_id",
    "status", "rejection_reason", "admin_id", "created_at", "paid_at",
    "approved_at", "starts_at", "expires_at",
)


def _row_to_ad(row) -> dict | None:
    if row is None:
        return None
    return dict(zip(_AD_ORDER_COLUMNS, row))


def create_ad_draft(owner_chat_id: int, user_id: int, kind: str, banner_file_id: str | None,
                     text: str, times_per_day: int, duration_days: int, ts: float) -> int:
    with cursor() as cur:
        cur.execute(
            "INSERT INTO ad_orders (owner_chat_id, user_id, kind, banner_file_id, text, "
            "times_per_day, duration_days, status, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, 'draft', ?)",
            (owner_chat_id, user_id, kind, banner_file_id, text, times_per_day, duration_days, ts),
        )
        return cur.lastrowid


def get_ad_order(ad_id: int) -> dict | None:
    with cursor() as cur:
        cur.execute(f"SELECT {', '.join(_AD_ORDER_COLUMNS)} FROM ad_orders WHERE id=?", (ad_id,))
        return _row_to_ad(cur.fetchone())


def set_ad_payment_pending(ad_id: int, method: str, amount_stars: int = None,
                            amount_ton_nano: int = None, ton_memo: str = None,
                            stars_invoice_payload: str = None) -> None:
    with cursor() as cur:
        cur.execute(
            "UPDATE ad_orders SET status='pending_payment', method=?, amount_stars=?, "
            "amount_ton_nano=?, ton_memo=?, stars_invoice_payload=? WHERE id=?",
            (method, amount_stars, amount_ton_nano, ton_memo, stars_invoice_payload, ad_id),
        )


def get_ad_order_by_stars_payload(payload: str) -> dict | None:
    with cursor() as cur:
        cur.execute(f"SELECT {', '.join(_AD_ORDER_COLUMNS)} FROM ad_orders WHERE stars_invoice_payload=?", (payload,))
        return _row_to_ad(cur.fetchone())


def get_pending_ad_orders(method: str, max_age_hours: float = None) -> list:
    with cursor() as cur:
        if max_age_hours is None:
            cur.execute(
                f"SELECT {', '.join(_AD_ORDER_COLUMNS)} FROM ad_orders "
                "WHERE method=? AND status='pending_payment'",
                (method,),
            )
        else:
            cutoff = time.time() - max_age_hours * 3600
            cur.execute(
                f"SELECT {', '.join(_AD_ORDER_COLUMNS)} FROM ad_orders "
                "WHERE method=? AND status='pending_payment' AND created_at>=?",
                (method, cutoff),
            )
        return [_row_to_ad(r) for r in cur.fetchall()]


def expire_stale_ad_orders(method: str, max_age_hours: float) -> int:
    cutoff = time.time() - max_age_hours * 3600
    with cursor() as cur:
        cur.execute(
            "UPDATE ad_orders SET status='expired' "
            "WHERE method=? AND status='pending_payment' AND created_at<?",
            (method, cutoff),
        )
        return cur.rowcount


def confirm_ad_ton_payment(ton_memo: str, tx_hash: str, ts: float) -> dict | None:
    with cursor() as cur:
        cur.execute(
            "UPDATE ad_orders SET status='pending_review', ton_tx_hash=?, paid_at=? "
            "WHERE ton_memo=? AND status='pending_payment'",
            (tx_hash, ts, ton_memo),
        )
        if cur.rowcount == 0:
            return None
        cur.execute(f"SELECT {', '.join(_AD_ORDER_COLUMNS)} FROM ad_orders WHERE ton_memo=?", (ton_memo,))
        return _row_to_ad(cur.fetchone())


def confirm_ad_stars_payment(invoice_payload: str, charge_id: str, ts: float) -> dict | None:
    with cursor() as cur:
        cur.execute(
            "UPDATE ad_orders SET status='pending_review', stars_charge_id=?, paid_at=? "
            "WHERE stars_invoice_payload=? AND status='pending_payment'",
            (charge_id, ts, invoice_payload),
        )
        if cur.rowcount == 0:
            return None
        cur.execute(
            f"SELECT {', '.join(_AD_ORDER_COLUMNS)} FROM ad_orders WHERE stars_invoice_payload=?",
            (invoice_payload,),
        )
        return _row_to_ad(cur.fetchone())


def submit_free_ad_for_review(ad_id: int) -> None:
    with cursor() as cur:
        cur.execute("UPDATE ad_orders SET status='pending_review' WHERE id=? AND status='draft'", (ad_id,))


def list_pending_review_ads() -> list:
    with cursor() as cur:
        cur.execute(
            f"SELECT {', '.join(_AD_ORDER_COLUMNS)} FROM ad_orders WHERE status='pending_review' "
            "ORDER BY created_at ASC",
        )
        return [_row_to_ad(r) for r in cur.fetchall()]


def approve_ad(ad_id: int, admin_id: int, ts: float, duration_days: int) -> dict | None:
    expires_at = ts + duration_days * 86400
    with cursor() as cur:
        cur.execute(
            "UPDATE ad_orders SET status='active', admin_id=?, approved_at=?, starts_at=?, expires_at=? "
            "WHERE id=? AND status='pending_review'",
            (admin_id, ts, ts, expires_at, ad_id),
        )
        if cur.rowcount == 0:
            return None
        cur.execute(f"SELECT {', '.join(_AD_ORDER_COLUMNS)} FROM ad_orders WHERE id=?", (ad_id,))
        return _row_to_ad(cur.fetchone())


def reject_ad(ad_id: int, admin_id: int, reason: str | None) -> bool:
    with cursor() as cur:
        cur.execute(
            "UPDATE ad_orders SET status='rejected', admin_id=?, rejection_reason=? "
            "WHERE id=? AND status='pending_review'",
            (admin_id, reason, ad_id),
        )
        return cur.rowcount > 0


def list_active_ads(now_ts: float, kind: str | None = None) -> list:
    with cursor() as cur:
        if kind:
            cur.execute(
                f"SELECT {', '.join(_AD_ORDER_COLUMNS)} FROM ad_orders "
                "WHERE status='active' AND kind=? AND (expires_at IS NULL OR expires_at > ?)",
                (kind, now_ts),
            )
        else:
            cur.execute(
                f"SELECT {', '.join(_AD_ORDER_COLUMNS)} FROM ad_orders "
                "WHERE status='active' AND (expires_at IS NULL OR expires_at > ?)",
                (now_ts,),
            )
        return [_row_to_ad(r) for r in cur.fetchall()]


def expire_stale_ads(now_ts: float) -> int:
    with cursor() as cur:
        cur.execute(
            "UPDATE ad_orders SET status='expired' WHERE status='active' AND expires_at IS NOT NULL AND expires_at<=?",
            (now_ts,),
        )
        return cur.rowcount


def list_my_ads(owner_chat_id: int) -> list:
    with cursor() as cur:
        cur.execute(
            f"SELECT {', '.join(_AD_ORDER_COLUMNS)} FROM ad_orders WHERE owner_chat_id=? "
            "ORDER BY created_at DESC LIMIT 20",
            (owner_chat_id,),
        )
        return [_row_to_ad(r) for r in cur.fetchall()]


# ---------------- Ads: delivery log + rotation ----------------

def record_ad_delivery(ad_id: int, chat_id: int, slot: int, day: str, ts: float) -> bool:
    """True اگه این ترکیب (chat_id, slot, day) قبلاً ثبت نشده بود (جلوگیری از ارسال تکراری)."""
    with cursor() as cur:
        try:
            cur.execute(
                "INSERT INTO ad_delivery_log (ad_id, chat_id, slot, day, ts) VALUES (?, ?, ?, ?, ?)",
                (ad_id, chat_id, slot, day, ts),
            )
            return True
        except sqlite3.IntegrityError:
            return False


def count_ad_deliveries_today(ad_id: int, day: str) -> int:
    with cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM ad_delivery_log WHERE ad_id=? AND day=?", (ad_id, day))
        return cur.fetchone()[0]


def chat_already_served_slot(chat_id: int, slot: int, day: str) -> bool:
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM ad_delivery_log WHERE chat_id=? AND slot=? AND day=?",
            (chat_id, slot, day),
        )
        return cur.fetchone() is not None


def next_rotation_index(bucket: str, pool_size: int) -> int:
    """Round-robin ساده: ایندکس بعدی رو برای این bucket برمی‌گردونه (mod pool_size)."""
    if pool_size <= 0:
        return 0
    with cursor() as cur:
        cur.execute(
            "INSERT INTO ad_rotation_state (bucket, cursor) VALUES (?, 0) "
            "ON CONFLICT(bucket) DO UPDATE SET cursor = cursor + 1",
            (bucket,),
        )
        cur.execute("SELECT cursor FROM ad_rotation_state WHERE bucket=?", (bucket,))
        value = cur.fetchone()[0]
        return value % pool_size


# ---------------- Ads: آمار برای خریدار ----------------

def get_ad_delivery_stats(ad_id: int, days_back: int = 14) -> dict:
    """آمار نمایش یه آگهی: مجموع ارسال‌ها، تعداد گروه‌های یکتا، و ریز روزانه
    (حداکثر days_back روز اخیر) — از همون ad_delivery_log که هر بار
    services/ads.py:run_delivery_slot یه تبلیغ می‌فرسته پر می‌شه."""
    with cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM ad_delivery_log WHERE ad_id=?", (ad_id,))
        total = cur.fetchone()[0]
        cur.execute("SELECT COUNT(DISTINCT chat_id) FROM ad_delivery_log WHERE ad_id=?", (ad_id,))
        unique_chats = cur.fetchone()[0]
        cur.execute(
            "SELECT day, COUNT(*) FROM ad_delivery_log WHERE ad_id=? "
            "GROUP BY day ORDER BY day DESC LIMIT ?",
            (ad_id, days_back),
        )
        per_day = [{"day": row[0], "count": row[1]} for row in cur.fetchall()]
        return {"total": total, "unique_chats": unique_chats, "per_day": per_day}
