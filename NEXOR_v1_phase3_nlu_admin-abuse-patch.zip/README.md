# NEXOR_v1 — ربات مدیریت گروه و کانال تلگرام

## پیش‌نیاز: نسخه‌ی پایتون

حداقل **Python 3.9** لازم است (خود کتابخانه‌ی `python-telegram-bot==21.4` این
حداقل را می‌خواهد). نسخه‌ی خودت را با `python --version` چک کن. اگر ارور
`TypeError: 'type' object is not subscriptable` یا مشابه آن موقع اجرای
`main.py` دیدی، یعنی نسخه‌ی پایتونت قدیمی‌تر است — پایتون را از
[python.org](https://www.python.org/downloads/) به‌روزرسانی کن (نسخه‌ی ۳.۱۲
پیشنهاد می‌شود، همانی که Dockerfile هم استفاده می‌کند).

## نصب

```bash
pip install -r requirements.txt
export BOT_TOKEN="توکن گرفته‌شده از @BotFather"
python main.py
```

پایگاه‌داده SQLite به‌صورت خودکار (فایل `bot_data.sqlite3`) کنار پروژه ساخته می‌شود؛
نیازی به تنظیم اضافه نیست، اما با متغیر محیطی `BOT_DB_PATH` قابل تغییر است.

## پیش‌نیازهای ربات

- ربات باید در گروه **ادمین** باشد با دسترسی‌های: حذف پیام، بن/محدود کردن کاربر، پین (اختیاری).
- برای بخش مدیریت کانال، ربات باید در کانال هم **ادمین** باشد با دسترسی ارسال/ویرایش/حذف پست.

## دستورات

راهنمای کامل دستورات داخل خود ربات با `/help` قابل مشاهده است.

خلاصه:

| بخش | دستورات |
|---|---|
| اعضا | `/warn` `/unwarn` `/mute` `/unmute` `/ban` `/unban` `/kick` |
| قفل محتوا | `/lock` `/unlock` `/locks` |
| فیلتر کلمات | `/filter` `/stopfilter` `/filters` |
| کپچا | `/captcha on|off` |
| یادداشت | `/save` `/get` `/notes` `/clear` یا `#نام` |
| کانال | `/setchannel` `/post` `/schedulepost` `/editpost` `/delpost` `/channelstats` |
| لاگ | `/setlogchannel` |
| پروفایل دسترسی (Priority 5) | `/createprofile` `/delprofile` `/profiles` `/assignprofile` `/unassignprofile` `/myperms` |
| گزارش‌ها (Priority 5) | `/report` `/reports` |
| هشدار ادمین (Priority 5) | `/setalertchannel` `/alerts` |
| تنظیمات (Priority 5) | `/exportsettings` `/importsettings` |
| عمومی | `/start` `/help` `/settings` |
| 🤖 NEXOR Copilot (AI) | `/copilot` `/aicheck` `/aiexplain` `/aireports` `/aihealth` `/airule` `/aioptimize` `/aiincident` `/aiplan` |

## NEXOR Copilot (ماژول AI)

دستیار هوش مصنوعی **مخصوص ادمین/مدیران گروه** — نه یک چت‌بات عمومی. اعضای
عادی هیچ دسترسی‌ای به آن ندارند. Copilot فقط تحلیل و Recommendation می‌دهد؛
هیچ Ban/Mute/Delete‌ای مستقیماً از داخل آن اجرا نمی‌شود — همیشه از همون
مسیر تأیید صریح ادمین + Permission/Policy Engine موجود عبور می‌کند.

- **پنل Action-based:** `/copilot` → Analyze Message · Explain Action ·
  Group Health · Review Reports · Optimize Rules · Rule Advisor · Incident Analysis
- **سه پلن مستقل (Free/Pro/Premium)،** هرکدام با API/Provider جدا — پیکربندی
  کامل در `.env.example` (بخش `NEXOR_AI_*`). بدون Configuration، همان پلن
  فقط پیام «در دسترس نیست» می‌دهد؛ بقیه‌ی ربات دست‌نخورده کار می‌کند.
- **کنترل هزینه:** پیش از هر فراخوانی API یک پیش‌فیلتر محلی رایگان اجرا
  می‌شود (`ai_copilot/pipeline.py`) و Rate Limit روزانه قابل‌تنظیم دارد.
- جزئیات معماری کامل: `ARCHITECTURE.md`.

## ساختار پروژه

```
NEXOR_v1/
├── main.py                 # نقطه ورود بسیار کوچک
├── core/
│   └── bootstrap.py        # ساخت Application و lifecycle
├── handlers/               # Command / Callback / Message handlers
│   ├── registry.py         # سیم‌کشی Telegram handlers
│   └── ai_copilot.py       # لایه‌ی Telegram برای NEXOR Copilot
├── ai_copilot/              # ماژول مستقل AI (Provider/Plan/RateLimit/Prompt/Service)
├── services/
│   └── authorization.py    # قوانین کسب‌وکار مجوزها
├── security_policy.py      # policy خالص و قابل تست
├── db.py                   # SQLite persistence
├── config.py               # تنظیمات
├── i18n.py + locales/      # چندزبانه
├── tests/                  # تست‌ها
└── deploy/                 # systemd / deployment
```

اصل معماری: `main → core → handlers → services/policy → db` و Telegram-only.
`ai_copilot/` از این قاعده مستثنی نیست: `handlers/ai_copilot.py` فقط با
`ai_copilot/service.py` صحبت می‌کند، نه مستقیم با Providerها.
