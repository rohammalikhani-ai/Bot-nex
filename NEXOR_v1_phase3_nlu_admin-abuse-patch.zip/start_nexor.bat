@echo off
REM ===== تنظیمات: این ۲ خط رو با مسیر واقعی خودتون عوض کنید =====
set VPN_EXE="C:\Path\To\YourVPN.exe"
set BOT_DIR=C:\bot\NEXOR_v1

REM ۱) اجرای فیلترشکن
start "" %VPN_EXE%

REM ۲) صبر برای وصل شدن (ثانیه رو بسته به سرعت وصل شدنش تنظیم کنید)
timeout /t 15 /nobreak

REM ۳) تنظیم پروکسی (اگه فیلترشکنتون روی این پورت پروکسی می‌ده)
set HTTPS_PROXY=http://127.0.0.1:8080
set HTTP_PROXY=http://127.0.0.1:8080

REM ۴) رفتن به پوشه‌ی ربات، فعال کردن venv و اجرا
cd /d %BOT_DIR%
call venv\Scripts\activate.bat
python main.py

pause
