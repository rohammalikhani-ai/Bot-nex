# -*- coding: utf-8 -*-
"""
لایه‌ی چندزبانه (i18n).

معماری: هر زبان یک فایل مستقل در locales/<code>.py دارد که فقط یک دیکشنری
STRINGS تعریف می‌کند. اضافه کردن زبان جدید = ساختن یک فایل جدید + یک خط در
SUPPORTED_LANGUAGES؛ هیچ‌جای دیگر کد نیازی به تغییر ندارد (طبق خواسته‌ی
Multi-Language: "حداقل Architecture باید طوری باشد که اضافه کردن زبان جدید
آسان باشد").

هر گروه زبان خودش را جدا دارد (ذخیره در settings به کلید "language")؛
پیش‌فرض فارسی است چون خود پروژه با فارسی شروع شده، ولی هر گروه می‌تواند با
/setlang آن را عوض کند.
"""
import importlib
from typing import Dict

from repositories import store as db

SUPPORTED_LANGUAGES = {
    "fa": "🇮🇷 فارسی",
    "en": "🇬🇧 English",
    "ar": "🇸🇦 العربية",
    "tr": "🇹🇷 Türkçe",
    "ru": "🇷🇺 Русский",
    "es": "🇪🇸 Español",
}
DEFAULT_LANG = "fa"

_CACHE: Dict[str, dict] = {}


def _load(lang: str) -> dict:
    if lang not in _CACHE:
        try:
            mod = importlib.import_module(f"locales.{lang}")
        except ImportError:
            mod = importlib.import_module(f"locales.{DEFAULT_LANG}")
        _CACHE[lang] = mod.STRINGS
    return _CACHE[lang]


def get_lang(chat_id: int) -> str:
    lang = db.get_setting(chat_id, "language", DEFAULT_LANG)
    return lang if lang in SUPPORTED_LANGUAGES else DEFAULT_LANG


def set_lang(chat_id: int, lang: str) -> bool:
    if lang not in SUPPORTED_LANGUAGES:
        return False
    db.set_setting(chat_id, "language", lang)
    return True


def t(lang: str, key: str, **kwargs) -> str:
    """رشته‌ی ترجمه‌شده را برمی‌گرداند؛ اگه کلید در آن زبان نبود، از فارسی fallback می‌کند."""
    strings = _load(lang)
    template = strings.get(key)
    if template is None:
        template = _load(DEFAULT_LANG).get(key, key)
    try:
        return template.format(**kwargs)
    except Exception:
        return template


def tc(chat_id: int, key: str, **kwargs) -> str:
    """میانبر: مستقیم با chat_id، زبان همان گروه را resolve می‌کند."""
    return t(get_lang(chat_id), key, **kwargs)
