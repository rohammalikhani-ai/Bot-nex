# وضعیت پروژه و نقشه راه

## ۱. بررسی سورس فعلی (قبل از تغییر)
پروژه یک ربات `python-telegram-bot` با معماری ماژولار بود که این‌ها را از قبل داشت:
Ban/Unban/Mute/Unmute/Kick (فقط با ریپلای)، Warn ساده (بدون دلیل/تنظیم)، Lock محتوا،
فیلتر کلمات، آنتی‌فلاد ساده، کپچا، Welcome/Goodbye، Notes، مدیریت کانال (پست/زمان‌بندی)،
لاگ‌چنل ساده، و Federation (بن مشترک بین گروه‌ها).

⚠️ **تصمیم معماری:** پروژه فقط Telegram-based است و Web Dashboard ندارد.
که دقیقاً همان چیزیه که گفتید نمی‌خواهید. طبق قانون «چیزی که هست را خراب نکن»، حذفش نکردم،
اما توسعه‌اش هم ندادم و در معماری جدید هیچ قابلیت مدیریتی به آن وابسته نیست — همه‌چیز از
مسیر Command/Reply/Inline Keyboard داخل تلگرام کار می‌کند. اگر بخواهید کاملاً حذفش می‌کنم.

## ۲. مشکلات معماری که پیدا و رفع شد
- ❌ **Hierarchy واقعی وجود نداشت.** `admin_only` فقط چک می‌کرد ادمین هست یا نه؛ یک ادمین
  می‌توانست ادمین دیگر یا Owner را ban/mute کند. ✅ الان `common.get_rank` رتبه واقعی
  (Owner/Admin/Moderator/User) را از خود Telegram API می‌خواند و `can_act_on` تضمین می‌کند
  actor باید رتبه‌ی *بالاتر* از target داشته باشد.
- ❌ **هدف‌گیری فقط با Reply.** Ban با User ID/Username که در اولویت ۱ خواسته بودید اصلاً
  وجود نداشت. ✅ `resolve_target` حالا از کش داخلی کاربران (`users_cache`) برای
  `@username`/`user_id` هم پشتیبانی می‌کند.
- ❌ **بدون Reason/Duration.** Ban/Mute دلیل و Temporary نداشتند (فقط mute دقیقه داشت، بدون دلیل).
  ✅ همه‌ی `/ban /mute /warn /kick` حالا `[مدت] [دلیل]` می‌گیرند (مثلا `/ban 2h اسپم`) و در
  پیام و لاگ ثبت می‌شود.
- ❌ **Warning System بدون تنظیم.** سقف اخطار hardcode بود و فقط ban می‌کرد. ✅ `/setmaxwarns`
  و `/setwarnaction mute|ban` اضافه شد؛ تاریخچه‌ی هر اخطار با دلیل/زمان/عامل ذخیره می‌شود (`/warns`).
- ❌ **Admin Logs ناقص.** فقط وقتی لاگ‌چنل ست شده بود، یک خط متن ساده می‌رفت — هیچ رکورد
  ساختاریافته‌ای نبود، و بدون لاگ‌چنل هیچ سابقه‌ای نمی‌ماند. ✅ جدول `audit_log` همه‌چیز را
  (actor, action, target, reason, زمان) دائمی ذخیره می‌کند؛ `/logs` آن را مستقیم داخل تلگرام
  نشان می‌دهد (نیازی به کانال جدا نیست) — این پایه‌ی Moderator Audit هم هست.
- ❌ **Callback Query بدون Server-side Validation.** دکمه‌ی کپچا فقط چک می‌کرد کلیک‌کننده
  همان کاربره؛ اکشن مدیریتی روی دکمه وجود نداشت. ✅ دکمه‌های سریع warn (`حذف اخطار/سکوت/بن`)
  اضافه شدند و `modact_callback` رتبه‌ی کلیک‌کننده و target را **دوباره از صفر** چک می‌کند —
  دستکاری callback_data نمی‌تواند اکشن غیرمجاز اجرا کند.
- ❌ **Duplicate نداشتیم** — قابلیت تکراری در کد قبلی پیدا نشد؛ صرفاً ناقص بودند.

## ۳. آنچه در این نسخه اضافه/تقویت شد (Priority 1)
1. Ban/Unban — Reply + Username + ID، Temporary، دلیل، Hierarchy-check
2. Mute/Unmute — همان‌ها + دلیل
3. Kick — دلیل + Hierarchy-check
4. Warning System — دلیل، تاریخچه (`/warns`)، سقف و اکشن قابل تنظیم per-group
5. Delete/Purge — `/del` و `/purge` (با ریپلای یا تعداد)
6. Admin/Permission System — Hierarchy واقعی (Owner→Admin→Moderator→User)، نقش داخلی
   Moderator با `/promote` `/demote` `/roles`
7. Admin Logs — `audit_log` دائمی + `/logs`، پایه‌ی آماده برای Moderator Audit (آیتم ۳۹)

## ۳.۵ چندزبانه‌سازی (Multi-Language) — انجام شد
معماری i18n اضافه شد: هر زبان یک فایل مستقل در `locales/<code>.py` است (فقط یک
دیکشنری `STRINGS`)؛ افزودن زبان جدید فقط یعنی ساختن یک فایل مشابه + یک خط در
`i18n.SUPPORTED_LANGUAGES` — هیچ‌جای دیگر کد نیاز به تغییر ندارد. هر گروه زبان
مستقل خودش را دارد (`/setlang` با دکمه‌های Inline، فقط برای ادمین به بالا، با
Server-side validation کامل روی کلیک).

زبان‌های پیاده‌شده در این نسخه: 🇮🇷 فارسی (پیش‌فرض)، 🇬🇧 English، 🇸🇦 العربية،
🇹🇷 Türkçe، 🇷🇺 Русский، 🇪🇸 Español — هر ۶ زبان کاملاً کامل و یکسان (۱۳۷ کلید هر
کدام؛ تست شد که چیزی جا نیفتاده). تمام متن‌های کاربر-محور در همه‌ی ماژول‌ها
(moderation, roles, basic/help/settings, captcha/welcome, locks/filters, notes,
channel management, log-channel, federation) به این سیستم منتقل شدند. تنها
استثنا `errors.py` است که فقط برای owner ربات (توسعه‌دهنده) است، نه اعضای گروه.

## ۵. فاز ۲ (Priority 2 — امنیت) — انجام شد

**Anti-Spam:** تشخیص پیام‌های تکراری (۳ بار عین هم در ۶۰ ثانیه) و لینک از عضو
تازه‌وارد (کمتر از ۱۰ دقیقه از Join). اکشن قابل تنظیم با `/setspamaction
delete|warn|mute|ban`، روشن/خاموش با `/antispam`.

**Anti-Flood:** حالا per-group قابل تنظیمه (`/setflood تعداد ثانیه`، قبلاً
hardcode بود) با اکشن قابل تنظیم (`/setfloodaction`) به‌جای فقط Mute ثابت.

**Link Protection:** قفل‌های `link`/`invitelink`/`channellink` جدا شدن (قبلاً
یک قفل کلی بود که هم لینک خارجی هم لینک تلگرام رو با هم می‌گرفت). به‌علاوه
Domain Whitelist/Blacklist مستقل از قفل‌ها (`/blockdomain`, `/allowdomain`,
`/domains`) — یک دامنه‌ی بلاک‌شده همیشه حذف می‌شه حتی اگه قفل `link` خاموش باشه.

**Forbidden Words:** اکشن قابل تنظیم (`/setfilteraction`) به‌جای فقط حذف، و
Whitelist استثنا (`/allowword`, `/disallowword`).

**Anti-Raid:** تشخیص Join دسته‌جمعی در بازه‌ی کوتاه (`/setraidthreshold`)،
قفل خودکار کل گروه با پیام هشدار + دکمه‌ی «باز کردن قفل الان»، و باز شدن
خودکار بعد از مدت مشخص. `/lockdown` و `/unlockchat` هم برای قفل/باز کردن
دستی (نقش نزدیک به Panic Button، هرچند دکمه‌ی همیشه-در-دسترس هنوز نیست —
در روادمپ زیر ثبت شده).

**رفع یک باگ معماری مهم:** در نسخه‌ی قبلی، چند Handler برای همون نوع Update
(مثلاً NEW_CHAT_MEMBERS، یا پیام‌های متنی معمولی) همه با group پیش‌فرض ثبت
شده بودن. در python-telegram-bot، در هر group فقط اولین Handlerِ منطبق اجرا
می‌شه، نه همه‌شون — یعنی `moderate_message` (قفل/فیلتر/آنتی‌فلاد) عملاً
هیچ‌وقت روی پیام‌های متنی اجرا نمی‌شد چون `hashtag_note_trigger` قبلش
می‌نشست، و چک بن فدراسیون هنگام Join هم توسط هندلر کپچا سایه می‌خورد. با
اختصاص گروه‌های عددی جدا به هرکدوم (`group=10..21`) این مشکل رفع شد.

## ۶. فاز ۳ (Priority 3 — Content Control) — انجام شد

**Media Locks (آیتم ۱۴):** ۴ نوع قفل جدید اضافه شد: `gif` (Animation)، `video_note`
(ویدیو دایره‌ای)، `document`، `poll` — در کنار ۸ نوع قبلی (`link/invitelink/channellink/
photo/video/sticker/voice/forward`). `VALID_LOCKS` در `config.py` تمرکز واحد است؛
`/lock` `/unlock` `/locks` بدون تغییر کار می‌کنند چون گزینه‌ها را دینامیک از همین Set می‌خوانند.

**Forward Protection (آیتم ۱۵):** قفل کلی `forward` حذف نشد (طبق قانون «چیزی که هست را
خراب نکن»)، بلکه یک لایه‌ی انتخابی روی آن اضافه شد: جدول جدید `forward_rules` با
Allow/Block per-source. `/allowforward` `/blockforward` `/unruleforward` `/forwardrules`
منبع را با `@username`، ID عددی، یا نام (برای فرستنده‌های مخفی) شناسایی می‌کنند. یک منبع
Block‌شده همیشه حذف می‌شود حتی اگر قفل کلی خاموش باشد؛ یک منبع Allow‌شده همیشه رد می‌شود حتی
اگر قفل کلی روشن باشد. با MessageOrigin (Bot API 7+) و فیلدهای قدیمی‌تر (`forward_from` و
مشابه) هر دو سازگار است.

**Mention Protection (آیتم ۱۶):** تشخیص سوءاستفاده از Mention دسته‌جمعی — اگر تعداد
Entityهای نوع `mention`/`text_mention` در یک پیام به سقف تنظیم‌شده برسد (پیش‌فرض ۵)،
اکشن قابل تنظیم اجرا می‌شود. `/mentionprotection on|off` `/setmentionlimit` `/setmentionaction`.

**Duplicate Message Detection بین‌کاربری (آیتم ۱۷):** تشخیص تکراری قبلی (`_recent_texts`)
فقط per-user بود؛ حالا یک ساختار جدید (`_chat_recent_texts`) کل چت را می‌بیند و اگر عین یک
متن از چند کاربر مختلف در یک بازه‌ی زمانی کوتاه ارسال شود (Copy/Paste Raid)، تشخیص داده و
اکشن `spam_action` روی فرستنده‌ی جاری اجرا می‌شود. `/dupcross on|off` `/setdupcross آستانه ثانیه`.

**چندزبانه:** ۲۲ کلید متن جدید (usage/done/error برای هر قابلیت بالا) به هر ۶ فایل
`locales/*.py` اضافه شد و بخش `/help` هر ۶ زبان به‌روزرسانی شد. تست پریتی خودکار (مقایسه‌ی
Set کلیدهای هر زبان با en) نشان می‌دهد هر ۶ زبان دقیقاً ۲۰۲ کلید یکسان دارند — چیزی جا نیفتاده.

**Regression check:** تمام فایل‌های پروژه (`main.py`, `db.py`, `config.py`, تمام
`handlers/*.py`, تمام `locales/*.py`) با `py_compile` بدون خطا کامپایل شدند؛ هیچ Handler یا
جدول موجودی حذف/بازنویسی نشد، فقط اضافه شد.

## ۷. فاز ۴ (Priority 4 — New Members & Automation) — انجام شد

**Welcome Auto-Delete (آیتم ۱۸):** تنظیم `/setwelcomedelete ثانیه|off` — اگر فعال باشد،
پیام خوش‌آمد (چه نسخه‌ی ساده، چه نسخه‌ی کپچا) بعد از مدت تنظیم‌شده با `job_queue.run_once`
خودکار حذف می‌شود. رفتار قبلی (بدون auto-delete) پیش‌فرض باقی می‌ماند.

**Goodbye کاملاً شخصی‌سازی‌شده (آیتم ۱۹):** `/setgoodbye متن` با متغیرهای `{name}` `{username}`
`{mention}` `{chat}` `{count}`، `/resetgoodbye` برای برگشت به پیش‌فرض، `/goodbye on|off`
برای خاموش/روشن کردن کامل. اگر قالب سفارشی ست نشده باشد، متن پیش‌فرض قبلی (`goodbye_msg`)
دست‌نخورده کار می‌کند.

**Rules System (آیتم ۲۰):** `/rules` `/setrules [کد زبان] متن` `/clearrules [کد زبان]` —
جدول جدید `chat_rules(chat_id, lang, text)`. اگر برای زبان فعلی گروه قانونی ثبت نشده باشد،
هر زبان دیگری که برای همان گروه موجود باشد نمایش داده می‌شود (fallback).

**Filters: Keyword → Auto Response (آیتم ۲۱):** عمداً کاملاً مستقل از Forbidden Words
Filter فعلی (`/filter`) پیاده شد تا اشتباهاً با آن ادغام نشود — نام دستورها هم تعمداً
متفاوت است: `/addkeyword کلمه پاسخ` (یا با ریپلای) `/delkeyword کلمه` `/keywords`. یک
MessageHandler مستقل (`group=22`) روی پیام‌های متنی چک می‌کند و فقط پاسخ می‌فرستد — هیچ
کاری به حذف/اکشن پیام ندارد (که وظیفه‌ی سیستم Forbidden Words است).

**Custom Commands (آیتم ۲۲):** `/addcmd نام پاسخ` (یا با ریپلای) `/delcmd نام` `/cmds`.
جدول `custom_commands`. یک لیست `RESERVED_COMMAND_NAMES` در `config.py` از بازنویسی
دستورهای واقعی ربات جلوگیری می‌کند. Dispatcher در `group=30` (بعد از همه‌ی دستورهای
واقعی) ثبت شده و کاری به دستورهای غیر سفارشی ندارد.

**Scheduled Messages — Recurring (آیتم ۲۳):** `/schedulepost` یک‌باره‌ی قبلی دست‌نخورده
باقی ماند؛ در کنارش `/schedulerecurring daily|weekly|monthly ...` `/recurringposts`
`/delrecurring شناسه` اضافه شد. جدول `recurring_posts` پست‌ها را دائمی نگه می‌دارد؛
`reschedule_recurring_posts()` هنگام استارت ربات (در `main.py`) تمام Jobهای فعال را
دوباره با `job_queue.run_daily` ثبت می‌کند تا با ری‌استارت از بین نروند. حالت Monthly
چون در python-telegram-bot به‌صورت native پشتیبانی نمی‌شود، با چک روزانه‌ی «امروز همان
روز ماه هست؟» پیاده شده (با Clamp به آخرین روز ماه برای ماه‌های کوتاه‌تر مثل فوریه).

**Auto Actions — Rule Engine (آیتم ۲۴):** جدول `auto_action_rules` با فرمت ساده‌ی
`condition_type:condition_value → action_type:action_value`. شرط‌های پشتیبانی‌شده:
`message_type` (نوع پیام)، `user_role` (نقش فرستنده)، `warns_gte` (تعداد اخطار فعلی).
اکشن‌ها: `delete` `warn` `mute` `ban` `kick`. دو نقطه‌ی اتصال به بقیه‌ی سیستم:
(۱) یک MessageHandler مستقل (`group=23`) شرط‌های `message_type`/`user_role` را روی هر
پیام چک می‌کند، (۲) `handlers/moderation.py` بعد از هر `_do_warn` تابع
`auto_actions.evaluate_warn_rules` را صدا می‌زند تا شرط‌های `warns_gte` هم چک شوند —
این کاملاً مستقل و مکمل سقف اخطار استاندارد (`/setmaxwarns`) است، نه جایگزین آن. روی
ادمین/مالک واقعی گروه هرگز اکشن خودکار اجرا نمی‌شود (Hierarchy رعایت می‌شود).

**`/settings` به‌روزرسانی شد:** وضعیت Goodbye و Auto Actions هم به خروجی اضافه شد.

**چندزبانه:** ۶۰ کلید متن جدید (usage/done/error/header برای هر ۷ آیتم بالا، به‌علاوه
`settings_goodbye`/`settings_autoaction`) به هر ۶ فایل `locales/*.py` اضافه شد و بخش
`/help` هر ۶ زبان به‌روزرسانی شد. تست پریتی خودکار نشان می‌دهد هر ۶ زبان دقیقاً ۲۶۲ کلید
یکسان دارند و تمام `{placeholder}`های هر رشته با نسخه‌ی انگلیسی مطابقت دارد — چیزی جا
نیفتاده و هیچ Placeholder گمشده‌ای نیست.

**Regression check:** تمام فایل‌های پروژه با `py_compile` و `ast.parse` بدون خطا
کامپایل شدند؛ هیچ Handler، جدول، یا دستور موجودی حذف/بازنویسی نشد — فقط اضافه شد.
(⚠️ نصب واقعی پکیج `python-telegram-bot` روی محیط توسعه به‌خاطر نبود دسترسی شبکه ممکن
نشد، پس فقط تست استاتیک/کامپایل انجام شد، نه اجرای واقعی ربات — پیشنهاد می‌کنم قبل از
Deploy یک تست دستی کوتاه از دستورهای این فاز در یک گروه تست انجام بدید.)

## ۸. فاز ۵ (Priority 5 — Professional Admin Tools) — انجام شد

**Permission Profiles (آیتم ۲۵):** `/createprofile نام قابلیت1,قابلیت2,...` `/delprofile نام`
`/profiles` `/assignprofile [ریپلای|@user|id] نام‌پروفایل` `/unassignprofile [...]`
`/myperms`. دو جدول جدید: `permission_profiles` (تعریف پروفایل‌ها در سطح گروه) و
`profile_assignments` (اختصاص یک پروفایل به یک کاربر). ساخت/حذف پروفایل فقط برای
Owner است (چون خودِ تعریفِ سطح دسترسی‌هاست)؛ Assign کردن یک پروفایل *موجود* برای
Admin به بالا هم آزاد است. **نکته‌ی امنیتی مهم:** این سیستم جایگزین Hierarchy
نمی‌شود — تابع جدید `has_capability()` در `common.py` همیشه یا Rank کافی
(مثلاً Moderator برای mute) یا وجود قابلیت در پروفایل را می‌پذیرد، اما چک
`can_act_on` (actor باید Rank بالاتر از target داشته باشد) همیشه جداگانه و
اجباری باقی می‌ماند؛ یعنی یک کاربر عادی با پروفایل نمی‌تواند روی کاربر هم‌رتبه یا
بالاتر اکشن بزند — این محدودیت آگاهانه است تا Hierarchy هرگز دور زده نشود.

**Reports (آیتم ۲۶):** `/report [دلیل]` (با ریپلای روی پیام) و `/reports` (لیست
گزارش‌های باز). هر گزارش هم در جدول دائمی `reports` ذخیره می‌شود و هم فوری با
دکمه‌های اکشن سریع (سکوت/بن/حذف پیام/رد گزارش) به ادمین‌ها اطلاع داده می‌شود —
دقیقاً با همان الگوی امنیتیِ دکمه‌های سریع `warn` در `moderation.py`: هر کلیک
دوباره از صفر روی سرور (Rank/Profile/Hierarchy) چک می‌شود، نه فقط نمایش دکمه.
کول‌داون ۶۰ ثانیه‌ای جلوی Report تکراری روی همون پیام رو می‌گیره.

**Admin Alerts (آیتم ۲۷):** سیستم Alert که قبلاً فقط مخصوص Raid بود، عمومی شد.
ماژول جدید `handlers/alerts.py` با تابع عمومی `raise_alert(context, chat_id,
alert_type, text)` که هر بخش دیگری از ربات (الان: Reports؛ در آینده: Priority 7)
می‌تونه صداش بزنه — هم در جدول دائمی `admin_alerts` ذخیره می‌شه (برای `/alerts`)
هم فوری اطلاع‌رسانی می‌شه. انواع جدید: `multiple_reports` (وقتی چند Report مجزا
در یک ساعت روی یک کاربر جمع بشه)، `suspicious_activity`، `security_event`،
`abnormal_behavior` (این سه‌تا آخر فعلاً فقط زیرساخت‌شون آماده‌ست، برای اتصال از
Priority 7). `/setalertchannel chat_id` مقصد اختصاصی Alertها رو جدا از لاگ‌چنل
تنظیم می‌کنه (fallback: لاگ‌چنل، بعد خودِ گروه). Raid Alert قبلی دست‌نخورده باقی
موند، فقط یک خط اضافه شد تا در `admin_alerts` هم ثبت بشه.

**Import/Export Settings (آیتم ۲۸):** `/exportsettings` (Admin به بالا) تمام
تنظیمات قابل‌انتقال گروه (settings، locks، word_filters، domains، forward_rules،
chat_rules، keyword_triggers، custom_commands، auto_action_rules،
permission_profiles) رو به یک فایل JSON نسخه‌دار (`version: 1`) تبدیل و ارسال
می‌کنه. `/importsettings` (فقط Owner، با ریپلای روی همون فایل) قبل از هر تغییری
کامل Validate می‌کنه (نسخه، ساختار هر بخش، نام دستورهای Custom Command در برابر
`RESERVED_COMMAND_NAMES`، قابلیت‌های هر Permission Profile در برابر
`CAPABILITIES`) و فقط بعد از یک تأیید صریح با دکمه (که Rank کلیک‌کننده رو دوباره
از صفر چک می‌کنه) اعمال می‌شه. Import یک عملیات Merge نیست — تنظیمات فعلی گروه
رو کامل جایگزین می‌کنه (`clear_chat_config`)، اما جدول‌های تاریخچه‌ای (warns،
audit_log، reports، admin_alerts، ...) هرگز پاک یا Import نمی‌شن. تست شد که
Export یک گروه با موفقیت در یک گروه *دیگر* هم قابل Import هست.

**`/help` هر ۶ زبان به‌روزرسانی شد** با بخش‌های جدید Permission Profiles،
Reports، Admin Alerts، Import/Export. `RESERVED_COMMAND_NAMES` هم برای همه‌ی
دستورهای جدید این فاز به‌روز شد.

**چندزبانه:** ۵۶ کلید متن جدید به هر ۶ فایل `locales/*.py` اضافه شد. تست پریتی
خودکار نشان می‌دهد هر ۶ زبان دقیقاً ۳۱۸ کلید یکسان دارند (چیزی جا نیفتاده).

**Regression check:** تمام فایل‌های پروژه با `py_compile` بدون خطا کامپایل شدند.
این‌بار برخلاف فازهای قبل، با ساخت یک Stub سبک از پکیج `telegram`/`telegram.ext`
(چون نصب واقعی پکیج به‌خاطر نبود دسترسی شبکه ممکن نشد)، `main()` واقعاً *اجرا* شد:
تمام Handlerهای این فاز و فازهای قبل بدون خطا Register شدند و `db.init_db()` روی
یک دیتابیس تازه هم اجرا شد (۲۶ جدول ساخته شد، شامل ۴ جدول جدید این فاز). علاوه بر
این، منطق DB و Import/Export این فاز با یک سناریوی end-to end واقعی (ساخت
پروفایل/گزارش/Alert، Export یک گروه، تلاش Import چند نسخه‌ی خراب‌شده‌ی عمدی برای
تست Validation، و Import موفق در یک گروه دیگر) روی یک دیتابیس واقعی SQLite تست
شد — نه فقط کامپایل استاتیک. هیچ Handler، جدول، یا دستور موجودی حذف/بازنویسی
نشد — فقط اضافه شد.
(⚠️ چیزی که همچنان تست نشد: رفتار واقعی در برابر Telegram API — چون Stub جایگزین
پکیج واقعی شد. پیشنهاد می‌کنم قبل از Deploy یک تست دستی کوتاه از دستورهای این فاز
در یک گروه تست (به‌خصوص دکمه‌های Report و جریان تأیید Import) انجام بدید.)

## ۹. اولویت‌های بعدی (هنوز پیاده نشده‌اند)

**فازهای بعدی:** Priority 6 (Analytics: Group/Activity/Moderation/Security
Statistics) → Priority 7 (Risk Score، Smart Escalation، Emergency Lockdown، Panic
Button دائمی، Anti-Admin Abuse، Appeals، Per-User Rules، Unified Whitelist) →
Priority 8 (Federation پیشرفته، Cross-Group Security، Bot-to-Bot Security) → دستیار
Gemini (در انتها، چون به آمار/گزارش‌های فازهای قبل به‌عنوان ورودی نیاز دارد).

هر فاز را جدا پیاده می‌کنم، دقیقاً مثل این فاز: چیزی که کار می‌کند خراب نمی‌شود، فقط
اضافه می‌شود، و همه‌چیز به سیستم چندزبانه‌ی موجود متصل می‌ماند.



## ۱۰. سیستم اطلاع‌رسانی روزانه (Daily Notify) — 💰 قیمت + 📰 اخبار + 📅 تاریخ/مناسبت

این فاز مستقل از اولویت‌های بالا بود (درخواست جداگانه‌ی کاربر) و همون قانون همیشگی رعایت شد:
چیزی که کار می‌کرد خراب نشد، فقط اضافه شد، و کاملاً به معماری/i18n/Scheduler موجود وصل ماند.

**قبل از شروع، معماری فعلی بررسی شد** (طبق دستور صریح کاربر): `db.py` (الگوی جدول
key-value عمومی `settings` + الگوی جدول‌های شبیه `ad_delivery_log` برای dedupe)،
`handlers/channel.py` (الگوی دقیق «یک Job به‌ازای هر چت با `job_queue.run_daily` +
حذف Job قبلی قبل از ثبت دوباره + `reschedule_recurring_posts` موقع استارت»)، سیستم i18n
(`locales/*.py` + `tc()`/`get_lang()`)، و مرزبندی ماژول‌های مستقل مثل `ai_copilot/`
(الگوی «یک ماژول سرویسِ کاملاً Telegram-agnostic + یک هندلر نازک که بهش وصله»).
قابلیت جدید دقیقاً روی همین سه الگو ساخته شد؛ هیچ Scheduler موازی، هیچ جدول تنظیمات
جدید، و هیچ سیستم ترجمه‌ی جدیدی اضافه نشد.

**معماری مرکزی** (طبق درخواست، دقیقاً همین ساختار):

```
DailyMessageBuilder → DateService + OccasionService + PriceService + NewsService
handlers/daily_notify.py → services/daily_message_builder.py → {date_service, occasion_service, price_service, news_service}
```

جزئیات کامل در `ARCHITECTURE.md` بخش «Daily Notify boundary» مستند شده.

**نکته‌ی مهم درباره‌ی وضعیت اولیه:** بخش زیادی از لایه‌ی سرویس این قابلیت
(`services/date_service.py`، `services/occasion_service.py`، `services/price_providers.py`،
`services/price_service.py`، `services/news_service.py`، `services/daily_message_builder.py`،
و حتی خودِ `handlers/daily_notify.py` با پنل دکمه‌ای کامل) از قبل در پروژه‌ی آپلودشده
وجود داشت — ولی به `handlers/registry.py` و `core/bootstrap.py` وصل نشده بود و هیچ
کلید i18n‌ای برایش در `locales/*.py` تعریف نشده بود (یعنی اگر بدون تغییر اجرا می‌شد،
هر پیام آن دقیقاً کلید خام مثل `daily_price_header` را نشون می‌داد، نه متن ترجمه‌شده).
کاری که در این فاز انجام شد:

1. **Wiring**: ثبت هر ۷ دستور (`dailynotify`, `setpricetime`, `setnewstime`, `setdailytz`,
   `testdailyprice`, `testdailynews`, `dailyassets`) و Callback الگوی `dn:` در
   `handlers/registry.py`، و فراخوانی `daily_notify.reschedule_all(app)` در
   `core/bootstrap.py` (دقیقاً کنار `channel.reschedule_recurring_posts(app)` موجود).
2. **i18n**: نزدیک ۹۵ کلید جدید (نام روزها/ماه‌های میلادی و شمسی، قالب تاریخ، متن پیام
   قیمت/خبر، برچسب دارایی‌ها و واحدها، کل متن پنل دکمه‌ای/راهنما/خطاها، و یک بخش جدید
   در `/help`) به هر ۶ فایل `locales/*.py` اضافه شد. بعد از اضافه‌کردن، **هر ۶ زبان
   دقیقاً ۷۸۲ کلید یکسان دارند** (پریتی کامل، تست‌شده با اسکریپت) و با یک تست جداگانه
   تأیید شد که هیچ کلیدی که کد جدید صدا می‌زند در هیچ‌کدام از ۶ فایل غایب نیست.
3. **رفع باگ واقعی در تبدیل تقویم شمسی**: الگوریتم قبلیِ `gregorian_to_jalali` یک چرخه‌ی
   ساده‌ی کبیسه‌ی هر-۴-سال بود که سال ۱۴۰۳ را (اشتباهاً) کبیسه حساب می‌کرد — درحالی‌که
   طبق تقویم رسمی ایران آخرین سال کبیسه ۱۳۹۹ بوده و بعدی ۱۴۰۸ است (کبیسه‌ی نامنظمِ
   ۵‌ساله). با الگوریتم استاندارد و منتشرشده‌ی Borkowski (همان‌که `jalaali-js` استفاده
   می‌کند) جایگزین شد و در برابر سه منبع مستقل تأیید شد: نمونه‌ی رسمی README
   `jalaali-js`، مقادیر مستندشده‌ی خودِ `jalCal` در آن کتابخانه، و Infobox زنده‌ی
   ویکی‌پدیای انگلیسی برای تاریخ شمسیِ همون لحظه — هر سه دقیقاً منطبق.
4. **دو باگ کوچک دیگر رفع شد**: `price_service.get_prices()` وقتی ورودی‌اش Asset تکراری
   داشت خروجی را dedupe نمی‌کرد؛ و `news_service._parse_rss()` با `findtext` فقط متنِ
   قبل از اولین تگ HTML تودرتوی داخل `<description>` را می‌گرفت و بقیه‌ی خلاصه‌ی خبر را
   بی‌صدا حذف می‌کرد (خیلی از فیدهای RSS واقعی HTML داخل توضیحات دارند) — با
   `itertext()` جایگزین شد.
5. **تست‌ها**: ۶ فایل تست جدید (`tests/test_date_service.py`,
   `tests/test_price_providers.py`, `tests/test_price_service.py`,
   `tests/test_news_service.py`, `tests/test_occasion_service.py`,
   `tests/test_daily_message_builder.py`) — همه بدون تماس شبکه‌ی واقعی
   (`requests.get`/`unittest.mock` Mock شده)، جمعاً ۷۴ تست جدید، به‌علاوه‌ی تأیید اینکه
   هر ۲۰۰ تست قبلی پروژه هم بدون رگرسیون پاس می‌شوند. چون پکیج `python-telegram-bot` در
   محیط تست (بدون دسترسی شبکه برای نصب) در دسترس نبود، لایه‌ی هندلر
   (`handlers/daily_notify.py`) با یک Stub سبک و موقتِ `telegram`/`telegram.ext`
   (خارج از پروژه، هرگز Commit/Ship نشده) به‌صورت end-to-end دستی تست شد: تمام ۷ دستور،
   دکمه‌های پنل (روشن/خاموش قیمت و خبر، انتخاب دارایی، Flagهای تاریخ/مناسبت، بستن پنل)،
   رد شدن کلیک از سمت غیر-Owner، عدم Duplicate شدن Job بعد از چند بار تغییر تنظیمات،
   و `reschedule_all()` (هم برای بازیابی بعد از Restart و هم برای اطمینان از عدم
   Duplicate شدن Job در فراخوانی دوباره) — یکی از این تست‌ها واقعاً به CoinGecko/BBC
   وصل شد، با ۴۰۳ مواجه شد، و دقیقاً طبق طراحی (بدون Crash، بدون داده‌ی جعلی، پیام
   مناسب «داده‌ی معتبری در دسترس نیست») رفتار کرد.

**فایل‌های تغییرکرده/اضافه‌شده در این فاز:** `services/date_service.py` (رفع باگ کبیسه)،
`services/price_service.py` (رفع باگ dedupe)، `services/news_service.py` (رفع باگ
استخراج متن)، `handlers/registry.py`، `core/bootstrap.py`، `core/menus.py`،
`locales/{fa,en,ar,tr,ru,es}.py`، `ARCHITECTURE.md`، `ROADMAP.md` (همین بخش)، و ۶ فایل
تست جدید زیر `tests/`. فایل‌های `services/occasion_service.py`، `services/price_providers.py`،
و خودِ `services/daily_message_builder.py` / `handlers/daily_notify.py` بدون تغییر باقی
ماندند (کیفیت‌شان در بررسی و در تست‌های end-to-end بالا تأیید شد).
