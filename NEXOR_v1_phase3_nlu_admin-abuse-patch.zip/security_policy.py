"""Pure authorization policy helpers (no Telegram/DB dependency)."""
from __future__ import annotations  # keep set[str]/int | None hints working on Python < 3.9/3.10


def has_required_capability(actual_rank: int, capabilities: set[str], capability: str, minimum_rank: int) -> bool:
    return actual_rank >= minimum_rank or capability in capabilities


def effective_rank(actual_rank: int, capabilities: set[str], capability: str, minimum_rank: int, delegated_rank: int) -> int:
    if actual_rank >= minimum_rank:
        return actual_rank
    if capability in capabilities:
        return max(actual_rank, delegated_rank)
    return actual_rank


def can_target(actor_rank: int | None, target_rank: int | None, *, allow_self: bool = False,
               same_user: bool = False) -> bool:
    if actor_rank is None or target_rank is None:
        return False
    if same_user and not allow_self:
        return False
    return actor_rank > target_rank
