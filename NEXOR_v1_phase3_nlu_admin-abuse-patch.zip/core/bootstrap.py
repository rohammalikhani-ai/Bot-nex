"""Application bootstrap: configuration, DB, Telegram wiring, and jobs."""
import logging

from telegram.ext import ApplicationBuilder

from repositories import store as db
from config import BOT_TOKEN, OWNER_ID, AD_SLOT_HOURS
from handlers import channel, errors, payments, ads, daily_notify
from handlers.registry import register_all
from core.menus import set_command_menus
from services import payments as payments_service
from services import ads as ads_service

logger = logging.getLogger(__name__)


def build_application():
    if BOT_TOKEN == "PUT_YOUR_TOKEN_HERE":
        raise SystemExit("لطفاً ابتدا BOT_TOKEN را تنظیم کنید (متغیر محیطی یا داخل config.py).")
    db.init_db()
    app = ApplicationBuilder().token(BOT_TOKEN).post_init(set_command_menus).build()
    channel.reschedule_recurring_posts(app)
    daily_notify.reschedule_all(app)
    register_all(app)
    if OWNER_ID and app.job_queue:
        app.job_queue.run_repeating(errors.healthcheck_job, interval=6 * 3600, first=6 * 3600)
    if app.job_queue and payments_service.ton_enabled():
        # هر ۲ دقیقه سفارش‌های TON در انتظار رو با تراکنش‌های تازه‌ی toncenter
        # تطبیق می‌ده. اگه TON_WALLET_ADDRESS در .env خالی باشه، اصلاً ثبت نمی‌شه.
        app.job_queue.run_repeating(payments.ton_check_job, interval=120, first=60)
    if app.job_queue:
        # 📢 Ads: به تعداد AD_SLOT_HOURS در روز، یک دور تحویل تبلیغ به گروه‌های
        # پلن رایگان متصل به ربات اجرا می‌شه (Slot اول همون Slotیه که تبلیغ
        # رایگان هم توش می‌ره — services/ads.py:run_delivery_slot).
        import datetime
        for idx, hour in enumerate(AD_SLOT_HOURS):
            app.job_queue.run_daily(
                ads_service.run_delivery_slot,
                time=datetime.time(hour=hour, minute=0),
                data=idx,
            )
        if ads_service.ton_enabled():
            app.job_queue.run_repeating(ads.ads_ton_check_job, interval=120, first=90)
    return app
