# -*- coding: utf-8 -*-
"""
منوی دستورات ربات (دکمه‌ی «/» کنار باکس تایپ تلگرام).

تلگرام اجازه می‌ده برای هر Scope (پی‌وی/گروه) *و* هر language_code یک لیست
دستور جدا ست کنی؛ تلگرام خودش بر اساس زبان اپ کاربر (نه زبان گروه تو ربات ما)
تصمیم می‌گیره کدوم لیست رو نشون بده. برای هر کدوم از ۶ زبان پشتیبانی‌شده‌ی
i18n یک نسخه‌ی ترجمه‌شده ست می‌کنیم، و یه نسخه‌ی بدون language_code هم
به‌عنوان fallback (زبان پیش‌فرض DEFAULT_LANG) برای زبان‌های اپ که پشتیبانی
نمی‌شن نگه می‌داریم.

⚠️ توجه: این زبانِ *اپ تلگرام* کاربره، نه همون زبانی که با /setlang برای
گروه تنظیم شده (اون یکی جدا و در repositories/store ذخیره می‌شه). این دو
مستقل از همدیگه‌ن چون تلگرام امکان ست کردن منو به ازای هر چت رو نمی‌ده،
فقط به ازای Scope کلی + زبان اپ کاربر.

اگه خواستی دستور جدیدی اضافه/کم کنی: هم اینجا (لیست کلیدها) و هم توی
locales/*.py (مقدار ترجمه‌شده‌ی هر cmd_desc_* رو برای هر ۶ زبان) ویرایش کن.
"""
from __future__ import annotations  # keep list[BotCommand] hints working on Python < 3.9

from telegram import BotCommand, BotCommandScopeAllPrivateChats, BotCommandScopeAllGroupChats

from i18n import SUPPORTED_LANGUAGES, DEFAULT_LANG, t

PRIVATE_COMMAND_KEYS = [
    ("start", "cmd_desc_start"),
    ("help", "cmd_desc_help"),
]

GROUP_COMMAND_KEYS = [
    ("help", "cmd_desc_help"),
    ("settings", "cmd_desc_settings"),
    ("setlang", "cmd_desc_setlang"),
    ("rules", "cmd_desc_rules"),
    ("warn", "cmd_desc_warn"),
    ("unwarn", "cmd_desc_unwarn"),
    ("warns", "cmd_desc_warns"),
    ("mute", "cmd_desc_mute"),
    ("unmute", "cmd_desc_unmute"),
    ("ban", "cmd_desc_ban"),
    ("unban", "cmd_desc_unban"),
    ("kick", "cmd_desc_kick"),
    ("del", "cmd_desc_del"),
    ("purge", "cmd_desc_purge"),
    ("lock", "cmd_desc_lock"),
    ("unlock", "cmd_desc_unlock"),
    ("locks", "cmd_desc_locks"),
    ("promote", "cmd_desc_promote"),
    ("demote", "cmd_desc_demote"),
    ("roles", "cmd_desc_roles"),
    ("logs", "cmd_desc_logs"),
    ("dailynotify", "cmd_desc_dailynotify"),
    ("copilot", "cmd_desc_copilot"),
    ("buyplan", "cmd_desc_buyplan"),
    ("ads", "cmd_desc_ads"),
    ("myads", "cmd_desc_myads"),
    ("adstats", "cmd_desc_adstats"),
    ("adadmin", "cmd_desc_adadmin"),
]


def _build(command_keys, lang: str) -> list[BotCommand]:
    return [BotCommand(name, t(lang, key)) for name, key in command_keys]


async def set_command_menus(app):
    """در استارت اپ یک‌بار اجرا می‌شه و منوی هر Scope رو برای هر زبان پشتیبانی‌شده
    جدا ست می‌کنه، به‌علاوه‌ی یک نسخه‌ی fallback بدون language_code."""
    # fallback بدون language_code (برای زبان‌های اپ که جزو ۶ زبان ما نیستن)
    await app.bot.set_my_commands(
        _build(PRIVATE_COMMAND_KEYS, DEFAULT_LANG), scope=BotCommandScopeAllPrivateChats()
    )
    await app.bot.set_my_commands(
        _build(GROUP_COMMAND_KEYS, DEFAULT_LANG), scope=BotCommandScopeAllGroupChats()
    )

    for lang in SUPPORTED_LANGUAGES:
        await app.bot.set_my_commands(
            _build(PRIVATE_COMMAND_KEYS, lang),
            scope=BotCommandScopeAllPrivateChats(),
            language_code=lang,
        )
        await app.bot.set_my_commands(
            _build(GROUP_COMMAND_KEYS, lang),
            scope=BotCommandScopeAllGroupChats(),
            language_code=lang,
        )
