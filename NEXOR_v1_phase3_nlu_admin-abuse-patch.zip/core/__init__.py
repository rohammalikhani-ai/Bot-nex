"""NEXOR_v1 application core."""
