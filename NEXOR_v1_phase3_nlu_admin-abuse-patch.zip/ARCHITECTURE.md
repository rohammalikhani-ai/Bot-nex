# NEXOR_v1 Architecture

NEXOR_v1 is Telegram-only. The dependency direction is intentionally simple:

`main.py -> core/bootstrap.py -> handlers -> services -> policy/db`

- **main.py**: process entry point only.
- **core/**: application bootstrap/lifecycle wiring.
- **handlers/**: Telegram commands, callbacks, and message pipelines.
- **services/**: cross-cutting business rules such as authorization.
- **security_policy.py**: pure permission policy functions.
- **db.py**: persistence layer (SQLite for now).
- **locales/** + **i18n.py**: localization.

Do not put Telegram-specific code into `services/` or `security_policy.py`.
Do not add new features by growing `main.py`; register them through the handler registry.


## Storage boundary

Handlers use `repositories.store` rather than importing the SQLite implementation
directly. `repositories.store` currently exposes the same data-access contract as
`db.py`; this is intentionally a compatibility layer so storage can later be
split into domain repositories or migrated to PostgreSQL without changing every
handler.

## Authorization boundary

Authorization decisions are centralized in `services.authorization` and the pure
`security_policy` module. A capability grants an action; it does not grant the
ability to outrank Telegram administrators. Target hierarchy is checked separately
and fails closed when Telegram cannot provide a reliable target rank.

## Database transaction safety

The DB cursor context now rolls back on exceptions instead of committing partial
work. Configuration import remains an explicit atomic transaction.

## NEXOR Copilot (AI module) boundary

`ai_copilot/` is an independent module, not a new layer in the main dependency
chain:

`handlers/ai_copilot.py -> ai_copilot/service.py -> ai_copilot/providers.py -> external API`

- `handlers/ai_copilot.py` is the **only** place allowed to import
  `ai_copilot.service`; it never imports `ai_copilot.providers` or
  `ai_copilot.prompts` directly. This keeps every Telegram handler decoupled
  from which AI provider (or vendor) is actually behind a plan.
- `ai_copilot/providers.py` implements `ai_copilot.provider.AIProvider` per
  plan (Free/Pro/Premium), each wired purely through environment variables
  (`NEXOR_AI_<PLAN>_API_KEY/URL/MODEL`). Swapping a plan's free API for a paid
  one later means changing those three env vars for that plan — no code change,
  no handler change.
- The AI module never calls `services.authorization` / `security_policy`
  itself and never touches Telegram's ban/mute/delete APIs. It only returns a
  structured `AIResult` (recommendation). Real enforcement always re-enters
  through the standard `authorize_action` + existing `handlers/moderation.py`
  primitives, triggered only by an explicit admin tap/command — see
  `handlers/ai_copilot.py::ai_action_callback`.
- Any provider/network/parsing failure is caught inside `ai_copilot/service.py`
  and turned into `AIResult(ok=False, error_code=...)`; it must never raise
  out to a handler (see `tests/test_ai_copilot.py::ServiceFailureHandlingTests`).
- Storage for AI usage/rate-limits/logging follows the existing convention
  (tables + functions live in `db.py`, re-exported through
  `repositories/store.py`) rather than introducing a second persistence path.

## Natural Language / Smart Router boundary

`handlers/text_commands.py` (exact-phrase dictionary, group 15) and
`handlers/natural_language.py` (free-form intent parsing + AI fallback,
group 16) are two different *inputs* into the same command handlers — never
a second implementation of a feature. Both ultimately call the exact
function registered for that command/intent in `handlers/registry.py`, with
the exact same permission check (`services/authorization.py`).

Router order inside `natural_language.py::_escalate_to_ai` (fast/free first,
AI last, admins/moderators only):

`nlu/intent_parser.py::parse()` (rules over TEXT_TRIGGERS + synonyms)
  → `nlu/learned_phrases.py` (phrases AI has previously confirmed)
  → `ai_copilot/service.py::interpret_request` (AI, only when both above miss)

`nlu/learned_phrases.py` is the JSON learning loop: when the AI fallback
classifies a previously-unseen phrase with confidence at or above
`LEARN_CONFIDENCE_THRESHOLD`, the normalized phrase → intent mapping is
persisted to `data/learned_phrases/<lang>.json`. On the next occurrence,
`nlu/intent_parser.py::parse()` resolves it directly — no AI call. This is
separate from `nlu/ai_escalation_log.py`, which keeps its own purpose (an
append-only JSONL audit trail of every AI escalation, for humans to review
and expand the hand-written vocabulary in `intent_parser.py`) and is not
replaced by it. Entity extraction for a learned phrase always comes from the
same deterministic helpers (e.g. `extract_duration_seconds`) used by the
fast layer — a learned/AI-classified intent is never trusted with
AI-guessed entities, matching the rule already documented in
`handlers/natural_language.py` for the AI-fallback path itself.

`KNOWN_INTENTS` only covers commands that are either parameter-free (e.g.
`show_ads_list`) or have a single safe enable/disable entity detected from
a fixed verb vocabulary (e.g. `configure_mention_protection`). Commands
with free-form/numeric/sensitive parameters (`setflood`, `createprofile`,
`importsettings`, `schedulerecurring`, `buyplan`, ...) are intentionally
left out of NLU/AI dispatch — they remain reachable only through the
exact-phrase dictionary in `handlers/text_commands.py`, never through
free-form interpretation.

## Daily Notify (سیستم اطلاع‌رسانی روزانه) boundary

`DailyMessageBuilder → DateService + OccasionService + PriceService + NewsService`,
wired to Telegram only through `handlers/daily_notify.py`:

`handlers/daily_notify.py -> services/daily_message_builder.py -> {date_service, occasion_service, price_service, news_service}`

- `services/daily_message_builder.py` is the **only** place that turns
  DateService/OccasionService/PriceService/NewsService output into the final
  message text. Handlers and job callbacks never format prices/news/dates
  themselves — this keeps the "no fake data" and i18n rules enforced in one
  spot instead of every call site.
- `services/price_service.py` + `services/price_providers.py` implement a
  Provider-based architecture (Navasan for gold18/USD/EUR/USDT-Toman,
  CoinGecko for crypto-in-USD, an optional manual-rate provider for Stars),
  each independently enable-able via env vars, isolated with try/except so a
  provider outage never affects another asset or crashes the bot, and never
  substituting a fabricated value when no provider has real data. **No AI is
  ever used for prices** — `price_service.py`/`price_providers.py` have zero
  dependency on `ai_copilot/`.
- `services/news_service.py` fetches from per-language RSS feeds (stdlib XML
  parsing, no extra dependency), fingerprints items by link for dedupe, and
  never raises out of `get_daily_news()` — network/parsing failures yield an
  empty list, never fake headlines.
- `services/date_service.py` resolves each group's own timezone/calendar
  (Jalali for `fa`, Gregorian otherwise) instead of server/UTC time, and
  `services/occasion_service.py` (Nager.Date, per-language country mapping)
  only ever returns an occasion when a real match exists for that exact
  local date — otherwise `None`, never a guess.
- Scheduling reuses the existing JobQueue (`python-telegram-bot`'s
  `run_daily`), one job per chat per kind (`daily_price_<chat_id>`,
  `daily_news_<chat_id>`), each job's fire time carrying the group's own
  `tzinfo` directly (JobQueue honors a timezone-aware `datetime.time`) rather
  than a second parallel scheduler. `handlers/daily_notify.py::schedule_group_jobs`
  always cancels any existing job with that name before adding a new one, so
  no settings change can ever create a duplicate job; `reschedule_all()` is
  called once at startup (`core/bootstrap.py`) to restore every group's jobs
  after a restart, mirroring `channel.reschedule_recurring_posts`.
- All per-group settings (enabled flags, send hours, selected assets,
  timezone override, independent date/occasion toggles for price vs. news,
  and the rolling "already-sent news fingerprints" list) live in one JSON
  blob under the existing generic `settings` key-value table
  (`db.get_daily_notify_config` / `set_daily_notify_config`) — no new table,
  and it is automatically included in `/exportsettings` and `/importsettings`
  for free.

