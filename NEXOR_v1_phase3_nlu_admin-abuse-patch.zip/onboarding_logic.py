# -*- coding: utf-8 -*-
"""
منطق تصمیم‌گیری Onboarding (بخش 12 پرامپت) — کاملاً مستقل از telegram،
تا بدون نصب python-telegram-bot قابل تست باشه. لایه‌ی telegram-facing
(handlers/onboarding.py) فقط از همین توابع خالص استفاده می‌کنه، نه اینکه
منطق تصمیم‌گیری رو خودش تکرار کنه.
"""
from __future__ import annotations

# دسترسی‌های ادمینی که NEXOR واقعاً برای کارکردن قابلیت‌های اصلی‌اش لازم
# داره؛ (attribute تلگرام روی ChatMemberAdministrator, کلید locale برای نمایش)
REQUIRED_ADMIN_PERMS = [
    ("can_restrict_members", "perm_restrict"),
    ("can_delete_messages", "perm_delete"),
    ("can_invite_users", "perm_invite"),
    ("can_pin_messages", "perm_pin"),
]

_ABSENT_STATUSES = ("left", "kicked")
_PRESENT_STATUSES = ("member", "administrator")


def should_send_welcome(old_status: str, new_status: str) -> bool:
    """True فقط برای لحظه‌ی واقعیِ «اضافه شدن به گروه» (از left/kicked به
    member/administrator) — نه هر تغییر دیگه‌ای در my_chat_member (مثل
    وقتی یک ادمین فقط دسترسی‌های ربات رو تغییر می‌ده، که نباید welcome رو
    دوباره بفرسته)."""
    return old_status in _ABSENT_STATUSES and new_status in _PRESENT_STATUSES


def missing_permission_keys(granted: dict) -> list[str]:
    """granted: دیکشنری {attribute_name: bool} (مثلاً از ChatMemberAdministrator).
    خروجی: لیست کلیدهای locale برای دسترسی‌های لازمی که داده نشدن، به همون
    ترتیب REQUIRED_ADMIN_PERMS."""
    return [key for attr, key in REQUIRED_ADMIN_PERMS if not granted.get(attr, False)]
