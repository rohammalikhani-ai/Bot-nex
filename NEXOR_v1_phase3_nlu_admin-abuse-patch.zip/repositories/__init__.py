"""Repository boundary for NEXOR_v1.

Handlers should import `repositories.store` instead of the concrete SQLite module.
The public API is intentionally compatible with the existing DB functions so the
storage engine can be replaced later without rewriting handlers.
"""
from . import store

__all__ = ["store"]
