import os
import unittest
import unittest.mock as mock

os.environ.setdefault("BOT_DB_PATH", "bot_data.sqlite3")

import db
from i18n import set_lang
from services import daily_message_builder as dmb
from services.price_providers import PriceQuote
from services.news_service import NewsItem
from services.occasion_service import Occasion
from config import DAILY_NOTIFY_MAX_SEEN_NEWS

db.init_db()

_CHAT_1 = -930001
_CHAT_2 = -930002
_CHAT_3 = -930003


def _reset(chat_id, lang="en"):
    set_lang(chat_id, lang)
    dmb.save_config(chat_id, dmb.default_config())


class ConfigRoundTripTests(unittest.TestCase):
    def test_default_config_for_unconfigured_chat(self):
        _reset(_CHAT_1)
        cfg = dmb.get_config(_CHAT_1)
        self.assertFalse(cfg["prices_enabled"])
        self.assertFalse(cfg["news_enabled"])
        self.assertEqual(cfg["seen_news_fingerprints"], [])

    def test_partial_stored_config_merges_with_defaults(self):
        _reset(_CHAT_1)
        db.set_daily_notify_config(_CHAT_1, {"prices_enabled": True})
        cfg = dmb.get_config(_CHAT_1)
        self.assertTrue(cfg["prices_enabled"])
        self.assertFalse(cfg["news_enabled"])  # پیش‌فرض حفظ شده
        self.assertIn("price_hour", cfg)

    def test_unknown_assets_are_filtered_out(self):
        _reset(_CHAT_1)
        db.set_daily_notify_config(_CHAT_1, {"assets": ["usd", "totally_fake_asset"]})
        cfg = dmb.get_config(_CHAT_1)
        self.assertEqual(cfg["assets"], ["usd"])

    def test_asset_label_key_known_and_unknown(self):
        self.assertEqual(dmb.asset_label_key("usd"), "asset_usd")
        self.assertEqual(dmb.asset_label_key("something_new"), "something_new")


class BuildPriceMessageTests(unittest.TestCase):
    def test_disabled_and_not_forced_returns_empty_result(self):
        _reset(_CHAT_1)
        result = dmb.build_price_message(_CHAT_1, force=False)
        self.assertIsNone(result.text)

    def test_forced_build_with_quotes_produces_text(self):
        _reset(_CHAT_1)
        db.set_daily_notify_config(_CHAT_1, {"assets": ["usd"]})
        fake_quote = PriceQuote(asset="usd", value=620000, unit="toman", source="Navasan")
        with mock.patch("services.daily_message_builder.price_service.get_prices", return_value=[fake_quote]):
            result = dmb.build_price_message(_CHAT_1, force=True)
        self.assertIsNotNone(result.text)
        self.assertIn("Navasan", result.text)
        self.assertIsNotNone(result.day_key)

    def test_no_quotes_available_yields_no_text_but_has_day_key(self):
        _reset(_CHAT_1)
        db.set_daily_notify_config(_CHAT_1, {"assets": ["usd"]})
        with mock.patch("services.daily_message_builder.price_service.get_prices", return_value=[]):
            result = dmb.build_price_message(_CHAT_1, force=True)
        self.assertIsNone(result.text)  # هیچ پیام گمراه‌کننده‌ای ساخته نمی‌شود
        self.assertIsNotNone(result.day_key)

    def test_price_service_exception_does_not_crash_builder(self):
        _reset(_CHAT_1)
        db.set_daily_notify_config(_CHAT_1, {"assets": ["usd"]})
        with mock.patch("services.daily_message_builder.price_service.get_prices",
                         side_effect=RuntimeError("boom")):
            result = dmb.build_price_message(_CHAT_1, force=True)
        self.assertIsNone(result.text)

    def test_no_assets_configured_yields_no_text(self):
        _reset(_CHAT_1)
        db.set_daily_notify_config(_CHAT_1, {"assets": []})
        result = dmb.build_price_message(_CHAT_1, force=True)
        self.assertIsNone(result.text)

    def test_date_and_occasion_lines_respect_toggles(self):
        _reset(_CHAT_1)
        db.set_daily_notify_config(_CHAT_1, {
            "assets": ["usd"], "date_before_price": False, "occasion_before_price": True,
        })
        fake_quote = PriceQuote(asset="usd", value=1, unit="usd", source="X")
        fake_occ = Occasion(name="Some Holiday")
        with mock.patch("services.daily_message_builder.price_service.get_prices", return_value=[fake_quote]), \
             mock.patch("services.daily_message_builder.occasion_service.get_today_occasion", return_value=fake_occ):
            result = dmb.build_price_message(_CHAT_1, force=True)
        self.assertIn("Some Holiday", result.text)
        self.assertNotIn("Today:", result.text)  # چون date_before_price خاموش است

    def test_occasion_lookup_exception_does_not_crash_and_omits_line(self):
        _reset(_CHAT_1)
        db.set_daily_notify_config(_CHAT_1, {"assets": ["usd"], "occasion_before_price": True})
        fake_quote = PriceQuote(asset="usd", value=1, unit="usd", source="X")
        with mock.patch("services.daily_message_builder.price_service.get_prices", return_value=[fake_quote]), \
             mock.patch("services.daily_message_builder.occasion_service.get_today_occasion",
                         side_effect=RuntimeError("network blip")):
            result = dmb.build_price_message(_CHAT_1, force=True)
        self.assertIsNotNone(result.text)  # کل پیام قربانیِ خطای occasion نمی‌شود


class BuildNewsMessageTests(unittest.TestCase):
    def test_disabled_and_not_forced_returns_empty_result(self):
        _reset(_CHAT_2)
        result = dmb.build_news_message(_CHAT_2, force=False)
        self.assertIsNone(result.text)

    def test_forced_build_with_items_produces_text_and_fingerprints(self):
        _reset(_CHAT_2)
        item = NewsItem(title="Big News", summary="Details here", source="BBC",
                         link="https://x/1", fingerprint="fp1")
        with mock.patch("services.daily_message_builder.news_service.get_daily_news", return_value=[item]):
            result = dmb.build_news_message(_CHAT_2, force=True)
        self.assertIn("Big News", result.text)
        self.assertEqual(result.new_fingerprints, ["fp1"])

    def test_already_seen_fingerprints_are_passed_through(self):
        _reset(_CHAT_2)
        db.set_daily_notify_config(_CHAT_2, {"seen_news_fingerprints": ["old1", "old2"]})
        with mock.patch("services.daily_message_builder.news_service.get_daily_news", return_value=[]) as m:
            dmb.build_news_message(_CHAT_2, force=True)
        called_lang, called_seen = m.call_args[0]
        self.assertEqual(called_seen, {"old1", "old2"})

    def test_no_items_yields_no_text(self):
        _reset(_CHAT_2)
        with mock.patch("services.daily_message_builder.news_service.get_daily_news", return_value=[]):
            result = dmb.build_news_message(_CHAT_2, force=True)
        self.assertIsNone(result.text)

    def test_news_service_exception_does_not_crash_builder(self):
        _reset(_CHAT_2)
        with mock.patch("services.daily_message_builder.news_service.get_daily_news",
                         side_effect=RuntimeError("boom")):
            result = dmb.build_news_message(_CHAT_2, force=True)
        self.assertIsNone(result.text)


class RecordSentTests(unittest.TestCase):
    def test_record_price_sent_updates_day_key(self):
        _reset(_CHAT_3)
        dmb.record_price_sent(_CHAT_3, "2024-03-20")
        cfg = dmb.get_config(_CHAT_3)
        self.assertEqual(cfg["last_price_sent_day"], "2024-03-20")

    def test_record_news_sent_appends_fingerprints_without_duplicates(self):
        _reset(_CHAT_3)
        dmb.record_news_sent(_CHAT_3, "2024-03-20", ["a", "b"])
        dmb.record_news_sent(_CHAT_3, "2024-03-21", ["b", "c"])
        cfg = dmb.get_config(_CHAT_3)
        self.assertEqual(cfg["seen_news_fingerprints"], ["a", "b", "c"])
        self.assertEqual(cfg["last_news_sent_day"], "2024-03-21")

    def test_seen_fingerprints_capped_at_max(self):
        _reset(_CHAT_3)
        many = [f"fp{i}" for i in range(DAILY_NOTIFY_MAX_SEEN_NEWS + 20)]
        dmb.record_news_sent(_CHAT_3, "2024-01-01", many)
        cfg = dmb.get_config(_CHAT_3)
        self.assertEqual(len(cfg["seen_news_fingerprints"]), DAILY_NOTIFY_MAX_SEEN_NEWS)
        # جدیدترین fingerprintها باید نگه داشته شوند (FIFO از قدیم حذف می‌شود).
        self.assertEqual(cfg["seen_news_fingerprints"][-1], many[-1])


if __name__ == "__main__":
    unittest.main()
