# -*- coding: utf-8 -*-
import unittest

from onboarding_logic import should_send_welcome, missing_permission_keys, REQUIRED_ADMIN_PERMS


class ShouldSendWelcomeTests(unittest.TestCase):
    def test_join_from_left_triggers_welcome(self):
        self.assertTrue(should_send_welcome("left", "member"))

    def test_join_from_kicked_triggers_welcome_as_admin(self):
        self.assertTrue(should_send_welcome("kicked", "administrator"))

    def test_permission_change_does_not_retrigger(self):
        # از member به administrator (یا برعکس) -> ربات از قبل حضور داشته،
        # این یه join جدید نیست.
        self.assertFalse(should_send_welcome("member", "administrator"))
        self.assertFalse(should_send_welcome("administrator", "member"))

    def test_bot_removed_does_not_trigger(self):
        self.assertFalse(should_send_welcome("member", "left"))
        self.assertFalse(should_send_welcome("administrator", "kicked"))

    def test_already_absent_stays_absent_does_not_trigger(self):
        self.assertFalse(should_send_welcome("left", "left"))
        self.assertFalse(should_send_welcome("kicked", "kicked"))


class MissingPermissionKeysTests(unittest.TestCase):
    def test_some_permissions_missing(self):
        granted = {
            "can_restrict_members": True,
            "can_delete_messages": False,
            "can_invite_users": False,
            "can_pin_messages": True,
        }
        self.assertEqual(missing_permission_keys(granted), ["perm_delete", "perm_invite"])

    def test_all_permissions_granted(self):
        granted = {attr: True for attr, _ in REQUIRED_ADMIN_PERMS}
        self.assertEqual(missing_permission_keys(granted), [])

    def test_no_permissions_granted(self):
        self.assertEqual(missing_permission_keys({}), [key for _, key in REQUIRED_ADMIN_PERMS])


if __name__ == "__main__":
    unittest.main()
