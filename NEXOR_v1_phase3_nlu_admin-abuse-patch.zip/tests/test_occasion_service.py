import unittest
import unittest.mock as mock

from services import occasion_service as os_


class FakeResponse:
    def __init__(self, json_data, status_ok=True):
        self._json = json_data
        self._status_ok = status_ok

    def raise_for_status(self):
        if not self._status_ok:
            raise RuntimeError("HTTP error")

    def json(self):
        return self._json


class OccasionServiceTests(unittest.TestCase):
    def setUp(self):
        # کش در-حافظه بین تست‌ها مشترک است؛ برای استقلال تست‌ها آن را خالی می‌کنیم.
        os_._cache.clear()

    def test_finds_matching_holiday(self):
        fake_data = [{"date": "2024-03-20", "localName": "Nowruz", "name": "Persian New Year"}]
        with mock.patch("services.occasion_service.requests.get", return_value=FakeResponse(fake_data)):
            occ = os_.get_today_occasion("fa", 2024, 3, 20)
        self.assertIsNotNone(occ)
        self.assertEqual(occ.name, "Nowruz")
        self.assertEqual(occ.source, "Nager.Date")

    def test_falls_back_to_name_when_local_name_missing(self):
        fake_data = [{"date": "2024-12-25", "name": "Christmas Day"}]
        with mock.patch("services.occasion_service.requests.get", return_value=FakeResponse(fake_data)):
            occ = os_.get_today_occasion("en", 2024, 12, 25)
        self.assertEqual(occ.name, "Christmas Day")

    def test_no_match_returns_none(self):
        fake_data = [{"date": "2024-01-01", "localName": "New Year"}]
        with mock.patch("services.occasion_service.requests.get", return_value=FakeResponse(fake_data)):
            occ = os_.get_today_occasion("en", 2024, 6, 15)
        self.assertIsNone(occ)

    def test_network_failure_returns_none_not_crash(self):
        with mock.patch("services.occasion_service.requests.get", side_effect=ConnectionError("down")):
            occ = os_.get_today_occasion("en", 2024, 1, 1)
        self.assertIsNone(occ)

    def test_unsupported_language_returns_none_without_network_call(self):
        with mock.patch("services.occasion_service.requests.get") as m:
            occ = os_.get_today_occasion("xx", 2024, 1, 1)
            m.assert_not_called()
        self.assertIsNone(occ)

    def test_malformed_item_in_list_is_skipped_not_crash(self):
        fake_data = ["not-a-dict", {"date": "2024-05-01", "localName": "Labour Day"}]
        with mock.patch("services.occasion_service.requests.get", return_value=FakeResponse(fake_data)):
            occ = os_.get_today_occasion("en", 2024, 5, 1)
        self.assertEqual(occ.name, "Labour Day")

    def test_result_is_cached_and_does_not_refetch(self):
        fake_data = [{"date": "2024-03-20", "localName": "Nowruz"}]
        with mock.patch("services.occasion_service.requests.get", return_value=FakeResponse(fake_data)) as m:
            os_.get_today_occasion("fa", 2024, 3, 20)
            os_.get_today_occasion("fa", 2024, 3, 21)  # همان سال/کشور، باید از کش بیاید
            self.assertEqual(m.call_count, 1)

    def test_empty_list_response_returns_none(self):
        with mock.patch("services.occasion_service.requests.get", return_value=FakeResponse([])):
            occ = os_.get_today_occasion("en", 2024, 1, 1)
        self.assertIsNone(occ)

    def test_all_six_languages_have_a_country_mapping(self):
        for lang in ["fa", "en", "ar", "tr", "ru", "es"]:
            self.assertIn(lang, os_.COUNTRY_BY_LANG)


if __name__ == "__main__":
    unittest.main()
