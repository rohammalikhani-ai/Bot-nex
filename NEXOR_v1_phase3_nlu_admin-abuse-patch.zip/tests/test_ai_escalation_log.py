# -*- coding: utf-8 -*-
import json
import tempfile
import unittest
from pathlib import Path

from nlu.ai_escalation_log import log_ai_interpretation, read_all


class AiEscalationLogTests(unittest.TestCase):
    def setUp(self):
        self._tmpdir = tempfile.TemporaryDirectory()
        self.path = Path(self._tmpdir.name) / "log.jsonl"

    def tearDown(self):
        self._tmpdir.cleanup()

    def test_read_all_on_missing_file_returns_empty_list(self):
        self.assertEqual(read_all(self.path), [])

    def test_log_then_read_roundtrip(self):
        log_ai_interpretation(
            chat_id=-100123, lang="fa", text="لینک‌ها رو ببند",
            intent="configure_link_protection", confidence=87, used_ai=True,
            path=self.path,
        )
        records = read_all(self.path)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["chat_id"], -100123)
        self.assertEqual(records[0]["text"], "لینک‌ها رو ببند")
        self.assertEqual(records[0]["intent"], "configure_link_protection")
        self.assertEqual(records[0]["confidence"], 87)
        self.assertTrue(records[0]["used_ai"])
        self.assertIn("ts", records[0])

    def test_multiple_entries_append_not_overwrite(self):
        for i in range(3):
            log_ai_interpretation(
                chat_id=1, lang="en", text=f"message {i}", intent=None,
                confidence=None, used_ai=True, path=self.path,
            )
        records = read_all(self.path)
        self.assertEqual(len(records), 3)
        self.assertEqual([r["text"] for r in records], ["message 0", "message 1", "message 2"])

    def test_logs_failed_ai_calls_too_with_error_code(self):
        log_ai_interpretation(
            chat_id=1, lang="fa", text="یه چیزی", intent=None, confidence=None,
            used_ai=True, error_code="not_configured", path=self.path,
        )
        records = read_all(self.path)
        self.assertEqual(records[0]["error_code"], "not_configured")
        self.assertIsNone(records[0]["intent"])

    def test_non_ascii_text_preserved_correctly(self):
        log_ai_interpretation(
            chat_id=1, lang="ru", text="заблокируй ссылки пожалуйста",
            intent="configure_link_protection", confidence=90, used_ai=True,
            path=self.path,
        )
        records = read_all(self.path)
        self.assertEqual(records[0]["text"], "заблокируй ссылки пожалуйста")

    def test_corrupted_line_is_skipped_not_fatal(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "w", encoding="utf-8") as f:
            f.write("not valid json\n")
            f.write(json.dumps({"chat_id": 1, "text": "ok line"}) + "\n")
        records = read_all(self.path)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["text"], "ok line")


if __name__ == "__main__":
    unittest.main()
