import unittest

from security_policy import can_target, effective_rank, has_required_capability
from config import RANK_USER, RANK_MODERATOR, RANK_ADMIN, RANK_OWNER


class SecurityPolicyTests(unittest.TestCase):
    def test_profile_grants_capability_without_changing_real_rank(self):
        caps = {"mute"}
        self.assertTrue(has_required_capability(RANK_USER, caps, "mute", RANK_MODERATOR))
        self.assertFalse(has_required_capability(RANK_USER, caps, "ban", RANK_ADMIN))
        self.assertEqual(effective_rank(RANK_USER, caps, "mute", RANK_MODERATOR, RANK_MODERATOR), RANK_MODERATOR)

    def test_delegated_user_can_target_user_but_not_moderator(self):
        self.assertTrue(can_target(RANK_MODERATOR, RANK_USER))
        self.assertFalse(can_target(RANK_MODERATOR, RANK_MODERATOR))
        self.assertFalse(can_target(RANK_MODERATOR, RANK_ADMIN))

    def test_admin_can_target_moderator_but_not_admin(self):
        self.assertTrue(can_target(RANK_ADMIN, RANK_MODERATOR))
        self.assertFalse(can_target(RANK_ADMIN, RANK_ADMIN))
        self.assertTrue(can_target(RANK_OWNER, RANK_ADMIN))
        self.assertFalse(can_target(RANK_ADMIN, RANK_OWNER))

    def test_unknown_rank_fails_closed(self):
        self.assertFalse(can_target(None, RANK_USER))
        self.assertFalse(can_target(RANK_ADMIN, None))

    def test_self_action_is_denied(self):
        self.assertFalse(can_target(RANK_ADMIN, RANK_ADMIN, same_user=True))


if __name__ == "__main__":
    unittest.main()
