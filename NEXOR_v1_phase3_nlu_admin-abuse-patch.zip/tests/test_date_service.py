import os
import unittest

os.environ.setdefault("BOT_DB_PATH", "bot_data.sqlite3")

import db
from repositories import store as dbstore
from i18n import set_lang, t
from services import date_service

db.init_db()

# چت‌های تست با شناسه‌ی بسیار منفی، تا با داده‌ی واقعی برخورد نکنند.
_CHAT_FA = -910001
_CHAT_EN = -910002
_CHAT_RU = -910003


class GregorianToJalaliTests(unittest.TestCase):
    """لنگرهای این تست‌ها از سه منبع مستقل و معتبر گرفته شده‌اند تا هیچ
    شکی در صحت تبدیل نماند:
      - نمونه‌ی رسمی README کتابخانه‌ی jalaali-js (پرکاربردترین پیاده‌سازی
        این الگوریتم، MIT، به‌طور گسترده در پروژه‌های فارسی استفاده می‌شود).
      - مقادیر مستند شده‌ی خودِ تابع jalCal در همان کتابخانه.
      - Infobox زنده‌ی ویکی‌پدیای انگلیسی (Solar_Hijri_calendar) که تاریخ
        شمسیِ همون لحظه را نمایش می‌دهد.
    نکته: نزدیکِ خودِ لحظه‌ی اعتدال بهاری (اوایل فروردین)، اگر لحظه‌ی دقیق
    اعتدال به وقت تهران خیلی نزدیک ظهر باشد، حتی منابع خبری فارسی هم گاهی
    یک روز اختلاف دارند (بحث عمومی «آیا ۱۴۰۳ کبیسه است» دقیقاً همین موضوع
    بود) — به همین دلیل این تست‌ها عمداً از لنگرهایی استفاده می‌کنند که در
    هیچ منبع معتبری محل اختلاف نیستند."""

    def test_jalaali_js_readme_example(self):
        self.assertEqual(date_service.gregorian_to_jalali(2016, 4, 11), (1395, 1, 23))

    def test_nowruz_1403_uncontested_anchor(self):
        self.assertEqual(date_service.gregorian_to_jalali(2024, 3, 20), (1403, 1, 1))

    def test_day_before_nowruz_1403(self):
        self.assertEqual(date_service.gregorian_to_jalali(2024, 3, 19), (1402, 12, 29))

    def test_day_after_nowruz_1403(self):
        self.assertEqual(date_service.gregorian_to_jalali(2024, 3, 21), (1403, 1, 2))

    def test_wikipedia_live_infobox_anchor(self):
        self.assertEqual(date_service.gregorian_to_jalali(2026, 9, 1), (1405, 6, 10))

    def test_year_info_matches_jalaali_js_documented_examples(self):
        # نمونه‌های دقیقاً از مستندات jalaali-js (jalCal) گرفته شده‌اند.
        self.assertEqual(date_service._jalali_year_info(1390), (3, 21))
        self.assertEqual(date_service._jalali_year_info(1391), (0, 20))
        self.assertEqual(date_service._jalali_year_info(1395), (0, 20))

    def test_year_is_monotonic_increasing(self):
        # هیچ رگرسیونی در محاسبه‌ی روز-شماره نباید سال را برگرداند.
        y1, _, _ = date_service.gregorian_to_jalali(2023, 6, 1)
        y2, _, _ = date_service.gregorian_to_jalali(2024, 6, 1)
        self.assertEqual(y2, y1 + 1)


class TimezoneResolutionTests(unittest.TestCase):
    def test_valid_timezone_accepted(self):
        self.assertTrue(date_service.is_valid_timezone("Asia/Tehran"))
        self.assertTrue(date_service.is_valid_timezone("UTC"))

    def test_invalid_timezone_rejected(self):
        self.assertFalse(date_service.is_valid_timezone("Not/ARealZone"))
        self.assertFalse(date_service.is_valid_timezone(""))

    def test_resolve_timezone_uses_explicit_override(self):
        tz = date_service.resolve_timezone("Europe/Berlin", "en")
        self.assertEqual(str(tz), "Europe/Berlin")

    def test_resolve_timezone_falls_back_to_lang_default(self):
        tz = date_service.resolve_timezone(None, "fa")
        self.assertEqual(str(tz), date_service.LANG_DEFAULT_TIMEZONE["fa"])

    def test_resolve_timezone_falls_back_to_utc_for_other_langs(self):
        tz = date_service.resolve_timezone(None, "en")
        self.assertEqual(str(tz), date_service.DEFAULT_TIMEZONE)

    def test_resolve_timezone_never_raises_on_garbage_input(self):
        # ورودی نامعتبر هرگز نباید Crash کند؛ باید quietly به یک fallback برسد.
        tz = date_service.resolve_timezone("Totally/Bogus", "en")
        self.assertEqual(str(tz), date_service.DEFAULT_TIMEZONE)


class ResolveTodayTests(unittest.TestCase):
    def test_persian_group_uses_jalali_calendar(self):
        set_lang(_CHAT_FA, "fa")
        resolved = date_service.resolve_today(_CHAT_FA, "fa", None)
        self.assertEqual(resolved.calendar, "jalali")
        self.assertEqual(resolved.timezone, "Asia/Tehran")
        # روز/ماه/سال باید دقیقا با تبدیل مستقیم یکی باشد.
        jy, jm, jd = date_service.gregorian_to_jalali(resolved.now.year, resolved.now.month, resolved.now.day)
        self.assertEqual((resolved.year, resolved.month, resolved.day), (jy, jm, jd))
        self.assertIn(resolved.weekday_name, [t("fa", k) for k in date_service._WEEKDAY_KEYS])
        self.assertTrue(resolved.date_str)  # هیچ‌وقت خالی نیست

    def test_non_persian_group_uses_gregorian_calendar(self):
        set_lang(_CHAT_EN, "en")
        resolved = date_service.resolve_today(_CHAT_EN, "en", "UTC")
        self.assertEqual(resolved.calendar, "gregorian")
        self.assertEqual(resolved.timezone, "UTC")
        self.assertEqual((resolved.year, resolved.month, resolved.day),
                          (resolved.now.year, resolved.now.month, resolved.now.day))
        self.assertTrue(resolved.date_str)

    def test_explicit_group_timezone_override_is_respected(self):
        set_lang(_CHAT_RU, "ru")
        resolved = date_service.resolve_today(_CHAT_RU, "ru", "Europe/Moscow")
        self.assertEqual(resolved.timezone, "Europe/Moscow")

    def test_day_key_str_is_gregorian_and_stable(self):
        resolved = date_service.resolve_today(_CHAT_EN, "en", "UTC")
        key = date_service.day_key_str(resolved)
        self.assertEqual(key, resolved.now.strftime("%Y-%m-%d"))


if __name__ == "__main__":
    unittest.main()
