import unittest
import unittest.mock as mock

from services import news_service as ns


_SAMPLE_RSS = """<?xml version="1.0"?>
<rss version="2.0"><channel>
  <title>Sample Feed</title>
  <item>
    <title>First headline</title>
    <link>https://example.com/1</link>
    <description>Some <b>bold</b> summary text.</description>
  </item>
  <item>
    <title>Second headline</title>
    <link>https://example.com/2</link>
    <description>Another summary.</description>
  </item>
  <item>
    <title></title>
    <link>https://example.com/notitle</link>
    <description>Should be skipped, no title.</description>
  </item>
</channel></rss>
"""


class FakeResponse:
    def __init__(self, text, status_ok=True):
        self.text = text
        self._status_ok = status_ok

    def raise_for_status(self):
        if not self._status_ok:
            raise RuntimeError("HTTP error")


class CleanTextTests(unittest.TestCase):
    def test_strips_html_tags(self):
        self.assertEqual(ns._clean_text("Hello <b>world</b>!"), "Hello world!")

    def test_truncates_long_text(self):
        long_text = "a" * (ns.MAX_SUMMARY_CHARS + 50)
        cleaned = ns._clean_text(long_text)
        self.assertTrue(cleaned.endswith("…"))
        self.assertLessEqual(len(cleaned), ns.MAX_SUMMARY_CHARS + 1)

    def test_handles_none_and_empty(self):
        self.assertEqual(ns._clean_text(None), "")
        self.assertEqual(ns._clean_text(""), "")


class FingerprintTests(unittest.TestCase):
    def test_same_link_same_fingerprint(self):
        f1 = ns._fingerprint("Title A", "https://x.com/1")
        f2 = ns._fingerprint("Title B (different title)", "https://x.com/1")
        self.assertEqual(f1, f2)  # لینک، مبنای اصلی یکتاسازی است

    def test_different_link_different_fingerprint(self):
        f1 = ns._fingerprint("Same title", "https://x.com/1")
        f2 = ns._fingerprint("Same title", "https://x.com/2")
        self.assertNotEqual(f1, f2)


class ParseRssTests(unittest.TestCase):
    def test_parses_items_and_skips_titleless_ones(self):
        items = ns._parse_rss(_SAMPLE_RSS, "https://feed.example.com/rss")
        self.assertEqual(len(items), 2)
        self.assertEqual(items[0].title, "First headline")
        self.assertEqual(items[0].summary, "Some bold summary text.")
        self.assertEqual(items[0].source, "BBC")

    def test_malformed_xml_returns_empty_list_not_crash(self):
        items = ns._parse_rss("<not><valid xml", "https://feed.example.com/rss")
        self.assertEqual(items, [])

    def test_no_channel_element_returns_empty(self):
        items = ns._parse_rss("<rss></rss>", "https://feed.example.com/rss")
        self.assertEqual(items, [])


class GetDailyNewsTests(unittest.TestCase):
    def test_returns_items_up_to_limit(self):
        with mock.patch("services.news_service.requests.get", return_value=FakeResponse(_SAMPLE_RSS)):
            items = ns.get_daily_news("en", set(), limit=1)
        self.assertEqual(len(items), 1)

    def test_excludes_already_seen_fingerprints(self):
        with mock.patch("services.news_service.requests.get", return_value=FakeResponse(_SAMPLE_RSS)):
            first_pass = ns.get_daily_news("en", set(), limit=5)
        seen = {first_pass[0].fingerprint}
        with mock.patch("services.news_service.requests.get", return_value=FakeResponse(_SAMPLE_RSS)):
            second_pass = ns.get_daily_news("en", seen, limit=5)
        self.assertNotIn(first_pass[0].fingerprint, [i.fingerprint for i in second_pass])
        self.assertEqual(len(second_pass), 1)  # فقط خبر دوم باقی می‌ماند

    def test_unknown_language_falls_back_to_english_feed(self):
        with mock.patch("services.news_service.requests.get", return_value=FakeResponse(_SAMPLE_RSS)) as m:
            ns.get_daily_news("xx-not-a-real-lang", set())
            m.assert_called_with(ns.FEEDS_BY_LANG["en"][0], timeout=ns.REQUEST_TIMEOUT_SECONDS,
                                  headers={"User-Agent": "NEXORBot/1.0"})

    def test_network_failure_returns_empty_not_crash(self):
        with mock.patch("services.news_service.requests.get", side_effect=ConnectionError("down")):
            items = ns.get_daily_news("en", set())
        self.assertEqual(items, [])

    def test_all_six_languages_have_a_feed_configured(self):
        for lang in ["fa", "en", "ar", "tr", "ru", "es"]:
            self.assertIn(lang, ns.FEEDS_BY_LANG)
            self.assertTrue(ns.FEEDS_BY_LANG[lang])


if __name__ == "__main__":
    unittest.main()
