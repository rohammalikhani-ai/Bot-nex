import unittest
import unittest.mock as mock

from services import price_service
from services.price_providers import PriceQuote


class FakeProvider:
    def __init__(self, name, assets_map, raise_on_fetch=False, is_enabled=True):
        self.name = name
        self._assets_map = assets_map  # {asset: value}
        self._raise = raise_on_fetch
        self._enabled = is_enabled

    def enabled(self):
        return self._enabled

    def fetch(self, assets):
        if self._raise:
            raise RuntimeError("provider exploded")
        return {
            a: PriceQuote(asset=a, value=v, unit="usd", source=self.name)
            for a, v in self._assets_map.items() if a in assets
        }


class GetPricesTests(unittest.TestCase):
    def test_empty_asset_list_returns_empty(self):
        self.assertEqual(price_service.get_prices([]), [])

    def test_first_successful_provider_wins_for_shared_asset(self):
        p1 = FakeProvider("first", {"usd": 100})
        p2 = FakeProvider("second", {"usd": 999})
        with mock.patch.object(price_service, "ALL_PROVIDERS", [p1, p2]):
            result = price_service.get_prices(["usd"])
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].value, 100)
        self.assertEqual(result[0].source, "first")

    def test_fallback_when_first_provider_lacks_asset(self):
        p1 = FakeProvider("first", {"usd": 100})
        p2 = FakeProvider("second", {"eur": 90})
        with mock.patch.object(price_service, "ALL_PROVIDERS", [p1, p2]):
            result = price_service.get_prices(["usd", "eur"])
        by_asset = {q.asset: q for q in result}
        self.assertEqual(by_asset["usd"].source, "first")
        self.assertEqual(by_asset["eur"].source, "second")

    def test_disabled_provider_is_skipped(self):
        p1 = FakeProvider("disabled", {"usd": 1}, is_enabled=False)
        p2 = FakeProvider("enabled", {"usd": 2})
        with mock.patch.object(price_service, "ALL_PROVIDERS", [p1, p2]):
            result = price_service.get_prices(["usd"])
        self.assertEqual(result[0].source, "enabled")

    def test_provider_exception_does_not_stop_others(self):
        p1 = FakeProvider("broken", {}, raise_on_fetch=True)
        p2 = FakeProvider("healthy", {"ton": 5})
        with mock.patch.object(price_service, "ALL_PROVIDERS", [p1, p2]):
            result = price_service.get_prices(["ton"])
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].source, "healthy")

    def test_all_providers_down_returns_empty_not_crash(self):
        p1 = FakeProvider("broken1", {}, raise_on_fetch=True)
        p2 = FakeProvider("broken2", {}, raise_on_fetch=True)
        with mock.patch.object(price_service, "ALL_PROVIDERS", [p1, p2]):
            result = price_service.get_prices(["usd", "eur"])
        self.assertEqual(result, [])

    def test_unknown_asset_never_appears_in_output(self):
        p1 = FakeProvider("p", {"usd": 1})
        with mock.patch.object(price_service, "ALL_PROVIDERS", [p1]):
            result = price_service.get_prices(["totally_unknown_asset"])
        self.assertEqual(result, [])

    def test_output_order_matches_requested_order(self):
        p1 = FakeProvider("p", {"usd": 1, "eur": 2, "ton": 3})
        with mock.patch.object(price_service, "ALL_PROVIDERS", [p1]):
            result = price_service.get_prices(["ton", "usd", "eur"])
        self.assertEqual([q.asset for q in result], ["ton", "usd", "eur"])

    def test_duplicate_requested_assets_are_deduplicated(self):
        p1 = FakeProvider("p", {"usd": 1})
        with mock.patch.object(price_service, "ALL_PROVIDERS", [p1]):
            result = price_service.get_prices(["usd", "usd", "usd"])
        self.assertEqual(len(result), 1)


if __name__ == "__main__":
    unittest.main()
