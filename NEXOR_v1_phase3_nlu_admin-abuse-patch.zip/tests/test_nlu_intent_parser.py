# -*- coding: utf-8 -*-
import unittest

from nlu.intent_parser import parse, extract_duration_seconds
from nlu.context_store import ContextStore


class LinkProtectionIntentTests(unittest.TestCase):
    def test_fa_close_links(self):
        r = parse("لینک‌ها رو ببند", "fa")
        self.assertEqual(r.intent, "configure_link_protection")
        self.assertTrue(r.entities["enabled"])

    def test_fa_question_form_how_to_stop_ad_links(self):
        r = parse("چطور جلوی لینک تبلیغاتی رو بگیرم؟", "fa")
        self.assertEqual(r.intent, "configure_link_protection")
        self.assertTrue(r.entities["enabled"])

    def test_en_block_links(self):
        r = parse("please block links in this group", "en")
        self.assertEqual(r.intent, "configure_link_protection")
        self.assertTrue(r.entities["enabled"])

    def test_en_allow_links(self):
        r = parse("allow links again", "en")
        self.assertEqual(r.intent, "configure_link_protection")
        self.assertFalse(r.entities["enabled"])

    def test_ar_block_links(self):
        r = parse("من فضلك امنع الروابط", "ar")
        self.assertEqual(r.intent, "configure_link_protection")
        self.assertTrue(r.entities["enabled"])

    def test_tr_block_links(self):
        r = parse("linkleri engelle lütfen", "tr")
        self.assertEqual(r.intent, "configure_link_protection")
        self.assertTrue(r.entities["enabled"])

    def test_es_block_links(self):
        r = parse("bloquea los enlaces por favor", "es")
        self.assertEqual(r.intent, "configure_link_protection")
        self.assertTrue(r.entities["enabled"])

    def test_ru_block_links(self):
        r = parse("пожалуйста заблокируй ссылки", "ru")
        self.assertEqual(r.intent, "configure_link_protection")
        self.assertTrue(r.entities["enabled"])

    def test_link_mentioned_without_verb_is_ambiguous(self):
        r = parse("لینک", "fa")
        self.assertTrue(r.ambiguous)
        self.assertIn("configure_link_protection", r.candidates)


class MuteIntentTests(unittest.TestCase):
    def test_fa_mute_with_spoken_duration(self):
        r = parse("این کاربر رو یک ساعت mute کن", "fa")
        self.assertEqual(r.intent, "mute_user")
        self.assertEqual(r.entities["duration_seconds"], 3600)

    def test_en_mute_with_spoken_duration(self):
        r = parse("mute this user for one hour", "en")
        self.assertEqual(r.intent, "mute_user")
        self.assertEqual(r.entities["duration_seconds"], 3600)

    def test_mute_without_duration_leaves_it_none(self):
        r = parse("این کاربر رو mute کن", "fa")
        self.assertEqual(r.intent, "mute_user")
        self.assertIsNone(r.entities["duration_seconds"])

    def test_digit_plus_unit_word(self):
        r = parse("mute this person for 2 hours", "en")
        self.assertEqual(r.entities["duration_seconds"], 7200)


class UnmuteBanKickWarnIntentTests(unittest.TestCase):
    def test_en_unmute_is_not_mistaken_for_mute(self):
        # باگ واقعی: "unmute" شامل substring "mute" است.
        r = parse("please unmute this user", "en")
        self.assertEqual(r.intent, "unmute_user")

    def test_fa_unmute(self):
        r = parse("لغو سکوت این کاربر", "fa")
        self.assertEqual(r.intent, "unmute_user")

    def test_ru_unban_is_not_mistaken_for_ban(self):
        # باگ واقعی: روسی "разбан" شامل substring "бан" است.
        r = parse("сделай разбан этому пользователю", "ru")
        self.assertEqual(r.intent, "unban_user")

    def test_es_unban_is_not_mistaken_for_ban(self):
        # باگ واقعی: اسپانیایی "desbanear" شامل substring "banear" است.
        r = parse("puedes desbanear a este usuario", "es")
        self.assertEqual(r.intent, "unban_user")

    def test_en_ban_with_duration(self):
        r = parse("ban this user for 1 day", "en")
        self.assertEqual(r.intent, "ban_user")
        self.assertEqual(r.entities["duration_seconds"], 86400)

    def test_fa_kick(self):
        r = parse("این کاربر رو اخراج کن", "fa")
        self.assertEqual(r.intent, "kick_user")

    def test_tr_kick_short_word_does_not_misfire_on_saat(self):
        # باگ واقعی: TEXT_TRIGGERS ترکی kick="at" که substring "saat"(=ساعت) است.
        r = parse("bu kullanıcıyı 1 saat mute et", "tr")
        self.assertNotEqual(r.intent, "kick_user")

    def test_tr_kick_actual_word_still_works(self):
        r = parse("bu kullanıcıyı gruptan at", "tr")
        self.assertEqual(r.intent, "kick_user")

    def test_en_warn(self):
        r = parse("warn this user please", "en")
        self.assertEqual(r.intent, "warn_user")

    def test_ru_three_letter_root_ban_no_false_positive_on_unrelated_word(self):
        # پس از پایین آوردن آستانه به ۳ حرف، مطمئن شو "бан" داخل افعال
        # نامرتبط دیگه (مثل "заблокируй") اشتباهاً پیدا نمی‌شه.
        r = parse("пожалуйста заблокируй ссылки", "ru")
        self.assertEqual(r.intent, "configure_link_protection")

    def test_ru_three_letter_root_kick_no_false_positive(self):
        r = parse("пожалуйста заблокируй ссылки", "ru")
        self.assertNotEqual(r.intent, "kick_user")


class DeleteMessageIntentTests(unittest.TestCase):
    def test_fa_delete_this(self):
        r = parse("این رو پاک کن", "fa")
        self.assertEqual(r.intent, "delete_message")

    def test_en_delete(self):
        r = parse("please delete this message", "en")
        self.assertEqual(r.intent, "delete_message")

    def test_ar_delete(self):
        r = parse("رجاءً احذف هذه الرسالة", "ar")
        self.assertEqual(r.intent, "delete_message")

    def test_delete_does_not_collide_with_mute(self):
        r = parse("این کاربر رو یک ساعت mute کن", "fa")
        self.assertEqual(r.intent, "mute_user")


class UpdateRulesIntentTests(unittest.TestCase):
    def test_fa_setrules_with_colon(self):
        r = parse("تنظیم قوانین: فحش ندید، تبلیغ ممنوع", "fa")
        self.assertEqual(r.intent, "update_rules")
        self.assertEqual(r.entities["rules_text"], "فحش ندید، تبلیغ ممنوع")

    def test_en_setrules_with_colon(self):
        r = parse("set rules: no spam, be respectful", "en")
        self.assertEqual(r.intent, "update_rules")
        self.assertEqual(r.entities["rules_text"], "no spam, be respectful")

    def test_setrules_without_colon_is_ambiguous_not_guessed(self):
        # طبق بخش 9/11: بدون فرمت روشن، حدس نمی‌زنیم و متن رو به‌عنوان
        # قوانین ذخیره نمی‌کنیم.
        r = parse("تنظیم قوانین لطفا یه فکری کن", "fa")
        self.assertIsNone(r.intent)
        self.assertTrue(r.ambiguous)
        self.assertIn("update_rules", r.candidates)

    def test_setrules_does_not_get_confused_with_show_rules(self):
        r = parse("تنظیم قوانین: احترام به همه", "fa")
        self.assertEqual(r.intent, "update_rules")

    def test_plain_show_rules_still_works(self):
        r = parse("قوانین گروه چیه؟", "fa")
        self.assertEqual(r.intent, "show_rules")

    def test_ru_setrules_with_colon(self):
        r = parse("установить правила: без спама", "ru")
        self.assertEqual(r.intent, "update_rules")
        self.assertEqual(r.entities["rules_text"], "без спама")


class ListAutoAnswersIntentTests(unittest.TestCase):
    def test_fa_answerlist(self):
        r = parse("لیست پاسخ رو نشون بده", "fa")
        self.assertEqual(r.intent, "list_auto_answers")

    def test_en_answerlist(self):
        r = parse("show me the answer list please", "en")
        self.assertEqual(r.intent, "list_auto_answers")

    def test_ru_answerlist(self):
        r = parse("покажи список автоответов", "ru")
        self.assertEqual(r.intent, "list_auto_answers")


class CreateDeleteAutoAnswerIntentTests(unittest.TestCase):
    def test_fa_setanswer(self):
        r = parse("میخوام تنظیم پاسخ کنم", "fa")
        self.assertEqual(r.intent, "create_auto_answer")

    def test_en_setanswer(self):
        r = parse("please set answer for hello", "en")
        self.assertEqual(r.intent, "create_auto_answer")

    def test_fa_delanswer_with_colon(self):
        r = parse("حذف پاسخ: سلام", "fa")
        self.assertEqual(r.intent, "delete_auto_answer")
        self.assertEqual(r.entities["keyword"], "سلام")

    def test_en_delanswer_with_colon(self):
        r = parse("remove answer: hello", "en")
        self.assertEqual(r.intent, "delete_auto_answer")
        self.assertEqual(r.entities["keyword"], "hello")

    def test_delanswer_without_colon_is_ambiguous_not_guessed(self):
        r = parse("حذف پاسخ اون یکی که گذاشتم", "fa")
        self.assertIsNone(r.intent)
        self.assertTrue(r.ambiguous)
        self.assertIn("delete_auto_answer", r.candidates)

    def test_setanswer_and_delanswer_do_not_collide(self):
        r1 = parse("تنظیم پاسخ", "fa")
        r2 = parse("حذف پاسخ: سلام", "fa")
        self.assertEqual(r1.intent, "create_auto_answer")
        self.assertEqual(r2.intent, "delete_auto_answer")


class GroupHealthIntentTests(unittest.TestCase):
    def test_fa_group_health_question_form(self):
        r = parse("وضعیت سلامت گروه چطوره؟", "fa")
        self.assertEqual(r.intent, "group_health_report")

    def test_en_group_health(self):
        r = parse("can you check group health for me?", "en")
        self.assertEqual(r.intent, "group_health_report")

    def test_generic_trouble_words_do_not_trigger_ai_call(self):
        # عمداً trigger نمی‌شه — بخش 6/19: هزینه‌ی واقعی (AI call) نباید
        # برای هر جمله‌ی عمومی که کلمه‌ی «اسپم» توش هست فعال بشه.
        r = parse("این گروه خیلی اسپم می‌گیره واقعا", "fa")
        self.assertIsNone(r.intent)
        self.assertFalse(r.ambiguous)


class ShowModerationReportIntentTests(unittest.TestCase):
    def test_fa_open_reports_question_form(self):
        r = parse("گزارش‌های باز رو نشون بده", "fa")
        self.assertEqual(r.intent, "show_moderation_report")

    def test_en_open_reports(self):
        r = parse("can you show me the open reports?", "en")
        self.assertEqual(r.intent, "show_moderation_report")

    def test_ru_open_reports(self):
        r = parse("покажи жалобы пожалуйста", "ru")
        self.assertEqual(r.intent, "show_moderation_report")


class RulesHelpIntentTests(unittest.TestCase):
    def test_fa_rules_in_question_form(self):
        r = parse("قوانین گروه چیه؟", "fa")
        self.assertEqual(r.intent, "show_rules")

    def test_en_show_rules(self):
        r = parse("what are the rules here", "en")
        self.assertEqual(r.intent, "show_rules")

    def test_fa_help(self):
        r = parse("یه راهنما میخوام", "fa")
        self.assertEqual(r.intent, "help")


class DurationExtractionTests(unittest.TestCase):
    def test_compact_token_anywhere_in_sentence(self):
        self.assertEqual(extract_duration_seconds("mute him 2h please", "en"), 7200)

    def test_word_number_fa(self):
        self.assertEqual(extract_duration_seconds("دو ساعت", "fa"), 7200)

    def test_no_duration_present(self):
        self.assertIsNone(extract_duration_seconds("mute this user", "en"))


class UnknownInputTests(unittest.TestCase):
    def test_unrelated_text_is_unrecognized_not_guessed(self):
        r = parse("امروز هوا خیلی خوبه", "fa")
        self.assertIsNone(r.intent)
        self.assertFalse(r.ambiguous)

    def test_empty_text(self):
        r = parse("", "en")
        self.assertIsNone(r.intent)

    def test_unsupported_language_falls_back_to_default(self):
        # نباید crash کنه؛ باید مثل زبان پیش‌فرض رفتار کنه.
        r = parse("لینک‌ها رو ببند", "xx")
        self.assertEqual(r.intent, "configure_link_protection")


class ContextStoreTests(unittest.TestCase):
    def test_pending_roundtrip(self):
        store = ContextStore(ttl_seconds=60)
        store.put_pending(1, 2, {"intent": "mute_user", "target_id": 99})
        self.assertEqual(store.peek_pending(1, 2)["target_id"], 99)
        popped = store.pop_pending(1, 2)
        self.assertEqual(popped["target_id"], 99)
        # یک‌بار مصرف: بار دوم باید خالی باشه
        self.assertIsNone(store.pop_pending(1, 2))

    def test_pending_expires(self):
        store = ContextStore(ttl_seconds=-1)  # بلافاصله منقضی
        store.put_pending(1, 2, {"x": 1})
        self.assertIsNone(store.peek_pending(1, 2))

    def test_token_roundtrip_is_single_use(self):
        store = ContextStore(ttl_seconds=60)
        token = store.put_token({"intent": "mute_user"})
        self.assertEqual(store.peek_token(token)["intent"], "mute_user")
        self.assertIsNotNone(store.pop_token(token))
        self.assertIsNone(store.pop_token(token))

    def test_different_users_do_not_collide(self):
        store = ContextStore(ttl_seconds=60)
        store.put_pending(1, 2, {"who": "a"})
        store.put_pending(1, 3, {"who": "b"})
        self.assertEqual(store.peek_pending(1, 2)["who"], "a")
        self.assertEqual(store.peek_pending(1, 3)["who"], "b")


if __name__ == "__main__":
    unittest.main()
