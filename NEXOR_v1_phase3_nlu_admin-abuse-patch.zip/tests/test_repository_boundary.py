import unittest
from repositories import store


class RepositoryBoundaryTests(unittest.TestCase):
    def test_store_exposes_db_contract(self):
        self.assertTrue(callable(store.get_setting))
        self.assertTrue(callable(store.set_setting))
        self.assertTrue(callable(store.replace_chat_config))

    def test_store_exposes_ai_copilot_contract(self):
        self.assertTrue(callable(store.ai_get_usage))
        self.assertTrue(callable(store.ai_increment_usage))
        self.assertTrue(callable(store.ai_log_request))


if __name__ == "__main__":
    unittest.main()
