import unittest
from unittest.mock import AsyncMock, patch

from telegram.constants import ChatMemberStatus

from handlers.common import can_act_on, has_capability, reset_rank_cache
from config import RANK_USER, RANK_MODERATOR, RANK_ADMIN, RANK_OWNER


class FakeBot:
    def __init__(self, ranks):
        self.ranks = ranks

    async def get_chat_member(self, chat_id, user_id):
        status = self.ranks[user_id]
        return type("Member", (), {"status": status})()


class FakeContext:
    def __init__(self, ranks):
        self.bot = FakeBot(ranks)


class PermissionTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        # get_rank حالا با TTL کش می‌شه؛ بین تست‌ها خالی‌اش می‌کنیم تا یک تست
        # روی نتیجه‌ی کش‌شده‌ی تست قبلی سوار نشه (هم‌روال با
        # providers.reset_provider_cache در tests/test_ai_copilot.py).
        reset_rank_cache()

    async def test_hierarchy_user_cannot_act(self):
        ctx = FakeContext({1: ChatMemberStatus.MEMBER, 2: ChatMemberStatus.MEMBER})
        ok, _ = await can_act_on(ctx, -1, 1, 2)
        self.assertFalse(ok)

    async def test_moderator_can_act_on_user(self):
        ctx = FakeContext({1: ChatMemberStatus.MEMBER, 2: ChatMemberStatus.MEMBER})
        with patch("handlers.common.db.get_role", side_effect=lambda c, u: "moderator" if u == 1 else None):
            ok, _ = await can_act_on(ctx, -1, 1, 2)
        self.assertTrue(ok)

    async def test_admin_cannot_act_on_admin(self):
        ctx = FakeContext({1: ChatMemberStatus.ADMINISTRATOR, 2: ChatMemberStatus.ADMINISTRATOR})
        ok, _ = await can_act_on(ctx, -1, 1, 2)
        self.assertFalse(ok)

    async def test_owner_can_act_on_admin(self):
        ctx = FakeContext({1: ChatMemberStatus.OWNER, 2: ChatMemberStatus.ADMINISTRATOR})
        ok, _ = await can_act_on(ctx, -1, 1, 2)
        self.assertTrue(ok)

    async def test_api_failure_is_fail_closed(self):
        class BrokenBot:
            async def get_chat_member(self, chat_id, user_id):
                raise RuntimeError("telegram unavailable")
        ctx = type("C", (), {"bot": BrokenBot()})()
        with patch("handlers.common.db.get_role", return_value="moderator"):
            ok, _ = await can_act_on(ctx, -1, 1, 2)
        self.assertFalse(ok)

    async def test_profile_capability(self):
        ctx = FakeContext({1: ChatMemberStatus.MEMBER})
        with patch("handlers.common.db.get_profile_assignment", return_value="helper"), \
             patch("handlers.common.db.get_permission_profile", return_value="mute,delete"):
            self.assertTrue(await has_capability(ctx, -1, 1, "mute", RANK_ADMIN))
            self.assertFalse(await has_capability(ctx, -1, 1, "ban", RANK_ADMIN))


if __name__ == "__main__":
    unittest.main()
