from __future__ import annotations  # keep list[str] hints working on Python < 3.9

import unittest
from utils import parse_duration, strip_prefix_words


class DurationTests(unittest.TestCase):
    def test_valid_durations(self):
        self.assertEqual(parse_duration("10m"), 600)
        self.assertEqual(parse_duration("2h"), 7200)
        self.assertEqual(parse_duration("1d"), 86400)

    def test_invalid_duration(self):
        self.assertIsNone(parse_duration("nonsense"))
        self.assertIsNone(parse_duration("-5m"))


class StripPrefixWordsTests(unittest.TestCase):
    def test_single_word_prefix_like_slash_command(self):
        # مسیر واقعی «/setrules fa\nخط اول\nخط دوم»
        text = "/setrules fa\nخط اول\nخط دوم"
        self.assertEqual(strip_prefix_words(text, 1), "fa\nخط اول\nخط دوم")

    def test_two_word_prefix_bug_regression(self):
        # این دقیقاً همون باگ واقعی‌ایه که در handlers/rules.py::setrules_cmd
        # پیدا و رفع شد: Alias دوکلمه‌ای «تنظیم قوانین» نباید کلمه‌ی دومش
        # («قوانین») رو به متن قوانین بچسبونه.
        text = "تنظیم قوانین قانون اول: فحش ندید"
        self.assertEqual(strip_prefix_words(text, 2), "قانون اول: فحش ندید")

    def test_preserves_internal_newlines_after_multiword_prefix(self):
        text = "set rules line one\nline two\nline three"
        # پیشوند اینجا سه کلمه‌ست: "set", "rules", "line" -> نه، دقت کن:
        # "set rules" پیشوند دوکلمه‌ایه، پس n=2.
        self.assertEqual(strip_prefix_words(text, 2), "line one\nline two\nline three")

    def test_zero_prefix_returns_text_unchanged(self):
        self.assertEqual(strip_prefix_words("hello world", 0), "hello world")

    def test_prefix_longer_than_text_returns_empty(self):
        self.assertEqual(strip_prefix_words("one two", 5), "")

    def test_simulated_setrules_dispatch_both_paths_agree(self):
        # شبیه‌سازی خودِ منطق setrules_cmd (بدون وابستگی به telegram):
        # مسیر «/» و مسیر Alias باید هر دو دقیقاً همون متن قوانین رو بدن.
        def simulate(full_text: str, args: list[str]) -> str:
            total_words = len(full_text.split())
            prefix_word_count = total_words - len(args)
            return strip_prefix_words(full_text, prefix_word_count)

        slash_text = "/setrules قانون اول: فحش ندید"
        slash_args = ["قانون", "اول:", "فحش", "ندید"]
        alias_text = "تنظیم قوانین قانون اول: فحش ندید"
        alias_args = ["قانون", "اول:", "فحش", "ندید"]

        self.assertEqual(simulate(slash_text, slash_args), "قانون اول: فحش ندید")
        self.assertEqual(simulate(alias_text, alias_args), "قانون اول: فحش ندید")
        # قبل از رفع باگ، حالت alias این رو می‌داد: "قوانین قانون اول: فحش ندید"


if __name__ == "__main__":
    unittest.main()
