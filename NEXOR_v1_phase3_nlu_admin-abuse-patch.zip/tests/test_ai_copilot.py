import os
import time
import unittest
import unittest.mock

os.environ.setdefault("BOT_DB_PATH", "bot_data.sqlite3")

import db
from repositories import store as dbstore
from ai_copilot import plans, rate_limiter, pipeline, providers, service
from ai_copilot.provider import AIProvider, AIProviderConfigError, AIProviderError
from config import (
    AI_PLAN_FREE, AI_PLAN_PRO, AI_FEATURE_GROUP_HEALTH, AI_FEATURE_ANALYZE_MESSAGE,
)

db.init_db()

# چت‌های تست با شناسه‌ی بسیار منفی، تا با داده‌ی واقعی برخورد نکنند.
_TEST_CHAT = -900001
_TEST_CHAT_2 = -900002
_TEST_USER = -800001


class PlanMatrixTests(unittest.TestCase):
    def test_free_plan_excludes_advanced_features(self):
        self.assertTrue(plans.plan_allows(AI_PLAN_FREE, AI_FEATURE_ANALYZE_MESSAGE))
        self.assertFalse(plans.plan_allows(AI_PLAN_FREE, AI_FEATURE_GROUP_HEALTH))

    def test_pro_plan_includes_group_health(self):
        self.assertTrue(plans.plan_allows(AI_PLAN_PRO, AI_FEATURE_GROUP_HEALTH))

    def test_default_plan_is_free_when_unset(self):
        self.assertEqual(plans.get_chat_plan(_TEST_CHAT_2), AI_PLAN_FREE)

    def test_set_chat_plan_rejects_unknown_plan(self):
        self.assertFalse(plans.set_chat_plan(_TEST_CHAT, "enterprise"))

    def test_set_chat_plan_roundtrip(self):
        self.assertTrue(plans.set_chat_plan(_TEST_CHAT, AI_PLAN_PRO))
        self.assertEqual(plans.get_chat_plan(_TEST_CHAT), AI_PLAN_PRO)
        plans.set_chat_plan(_TEST_CHAT, AI_PLAN_FREE)  # reset for other tests


class RateLimiterTests(unittest.TestCase):
    def setUp(self):
        # یک کاربر تازه هر بار، تا شمارنده‌ی روزانه بین تست‌ها تداخل نکنه.
        self.user_id = -800100 - int(time.time() * 1000) % 100000

    def test_consumes_up_to_limit_then_blocks(self):
        # با پلن Free (سقف پیش‌فرض تست‌محور کوچیک لازم نیست، فقط رفتار رو چک می‌کنیم)
        limit = plans.daily_limit_for(AI_PLAN_FREE)
        allowed_count = 0
        for _ in range(limit):
            ok, _remaining = rate_limiter.check_and_consume(_TEST_CHAT, self.user_id, AI_PLAN_FREE)
            self.assertTrue(ok)
            allowed_count += 1
        ok, remaining = rate_limiter.check_and_consume(_TEST_CHAT, self.user_id, AI_PLAN_FREE)
        self.assertFalse(ok)
        self.assertEqual(remaining, 0)
        self.assertEqual(allowed_count, limit)


class LocalPrefilterTests(unittest.TestCase):
    def test_short_benign_text_skips_ai(self):
        result = pipeline.local_prefilter(text="سلام", is_forward=False, is_new_member=False)
        self.assertFalse(result["needs_ai"])
        self.assertEqual(result["local_risk"], "low")

    def test_link_forces_ai(self):
        result = pipeline.local_prefilter(text="سلام", is_forward=False, is_new_member=False)
        self.assertFalse(result["needs_ai"])
        result2 = pipeline.local_prefilter(text="بیا تو گروه من https://example.com", is_forward=False, is_new_member=False)
        self.assertTrue(result2["needs_ai"])
        self.assertIn("link", result2["signals"])

    def test_forward_forces_ai(self):
        result = pipeline.local_prefilter(text="ok", is_forward=True, is_new_member=False)
        self.assertTrue(result["needs_ai"])
        self.assertIn("forward", result["signals"])


class ProviderConfigTests(unittest.TestCase):
    def setUp(self):
        providers.reset_provider_cache()
        for key in ("NEXOR_AI_FREE_API_KEY", "NEXOR_AI_FREE_API_URL", "NEXOR_AI_FREE_MODEL"):
            os.environ.pop(key, None)

    def tearDown(self):
        providers.reset_provider_cache()
        for key in ("NEXOR_AI_FREE_API_KEY", "NEXOR_AI_FREE_API_URL", "NEXOR_AI_FREE_MODEL"):
            os.environ.pop(key, None)

    def test_missing_env_raises_config_error_not_crash(self):
        with self.assertRaises(AIProviderConfigError):
            providers.get_provider(AI_PLAN_FREE)

    def test_configured_env_builds_provider(self):
        os.environ["NEXOR_AI_FREE_API_KEY"] = "test-key"
        os.environ["NEXOR_AI_FREE_API_URL"] = "https://example.invalid/v1"
        os.environ["NEXOR_AI_FREE_MODEL"] = "test-model"
        provider = providers.get_provider(AI_PLAN_FREE)
        self.assertEqual(provider.name, AI_PLAN_FREE)
        self.assertEqual(provider.model, "test-model")


class _FakeProvider(AIProvider):
    """Provider جعلی برای تست service.py — بدون نیاز به شبکه/httpx واقعی."""

    def __init__(self, response_text=None, raise_error: Exception = None):
        self.name = "fake"
        self.response_text = response_text
        self.raise_error = raise_error

    async def complete(self, system_prompt, user_prompt, *, max_tokens: int = 700):
        if self.raise_error:
            raise self.raise_error
        return self.response_text


class ServiceFailureHandlingTests(unittest.IsolatedAsyncioTestCase):
    """
    قلب الزام امنیتی «خطای API نباید باعث Crash شدن Bot شود»: در همه‌ی این
    حالت‌ها service باید یک AIResult با ok=False برگردونه، نه Exception.
    """

    def setUp(self):
        plans.set_chat_plan(_TEST_CHAT, AI_PLAN_PRO)  # همه‌ی Featureها فعال باشن

    async def test_plan_not_allowed_is_reported_not_raised(self):
        plans.set_chat_plan(_TEST_CHAT, AI_PLAN_FREE)
        result = await service.group_health(_TEST_CHAT, _TEST_USER, stats={})
        self.assertFalse(result.ok)
        self.assertEqual(result.error_code, "plan_not_allowed")
        plans.set_chat_plan(_TEST_CHAT, AI_PLAN_PRO)

    async def test_provider_error_does_not_raise(self):
        with unittest.mock.patch("ai_copilot.service.providers.get_provider",
                                  return_value=_FakeProvider(raise_error=AIProviderError("boom"))):
            result = await service.group_health(_TEST_CHAT, _TEST_USER, stats={"deleted": 0})
        self.assertFalse(result.ok)
        self.assertEqual(result.error_code, "provider_error")

    async def test_non_json_response_does_not_raise(self):
        with unittest.mock.patch("ai_copilot.service.providers.get_provider",
                                  return_value=_FakeProvider(response_text="این یک متن عادیه، نه JSON.")):
            result = await service.group_health(_TEST_CHAT, _TEST_USER, stats={"deleted": 0})
        self.assertFalse(result.ok)
        self.assertEqual(result.error_code, "bad_response")

    async def test_unexpected_exception_does_not_raise(self):
        class _ExplodingProvider(AIProvider):
            name = "exploding"

            async def complete(self, *a, **kw):
                raise RuntimeError("totally unexpected")

        with unittest.mock.patch("ai_copilot.service.providers.get_provider",
                                  return_value=_ExplodingProvider()):
            result = await service.group_health(_TEST_CHAT, _TEST_USER, stats={"deleted": 0})
        self.assertFalse(result.ok)
        self.assertEqual(result.error_code, "unknown_error")

    async def test_valid_json_response_is_parsed_and_clamped(self):
        payload = (
            '{"risk": "high", "spam_pct": 250, "advertisement_pct": -5, '
            '"suspicious_pct": 80, "toxic_pct": 10, "summary": "ok", '
            '"recommendation": {"action": "delete_warn", "reason": "spam"}}'
        )
        with unittest.mock.patch("ai_copilot.service.providers.get_provider",
                                  return_value=_FakeProvider(response_text=payload)):
            result = await service.analyze_message(
                _TEST_CHAT, _TEST_USER, message_text="آگهی فروش ویژه با تخفیف https://spam.example",
                is_forward=False, has_link=True, sender_warn_count=0, sender_is_new=False,
            )
        self.assertTrue(result.ok)
        self.assertEqual(result.data["spam_pct"], 100)  # clamp بالای ۱۰۰
        self.assertEqual(result.data["advertisement_pct"], 0)  # clamp زیر ۰
        self.assertEqual(result.data["recommendation"]["action"], "delete_warn")

    async def test_trivial_message_skips_ai_entirely(self):
        with unittest.mock.patch("ai_copilot.service.providers.get_provider") as mock_get:
            result = await service.analyze_message(
                _TEST_CHAT, _TEST_USER, message_text="سلام", is_forward=False,
                has_link=False, sender_warn_count=0, sender_is_new=False,
            )
        mock_get.assert_not_called()
        self.assertTrue(result.ok)
        self.assertFalse(result.used_ai)
        self.assertEqual(result.data["risk"], "low")


class InterpretRequestServiceTests(unittest.IsolatedAsyncioTestCase):
    """تست‌های لایه‌ی سوم Smart Router (nlu escalation) — service.interpret_request.
    این‌ها هیچ شبکه/API key واقعی لازم ندارن (Provider جعلی، دقیقاً مثل بقیه‌ی
    این فایل) و واقعاً همین‌جا اجرا و pass می‌شن؛ تنها چیزی که در این sandbox
    قابل تست نیست، فراخوان HTTP واقعی به یک سرویس AI واقعیه."""

    def setUp(self):
        plans.set_chat_plan(_TEST_CHAT, AI_PLAN_PRO)

    async def test_not_configured_when_no_api_key_set(self):
        # دقیقاً وضعیت واقعی این sandbox الان: هیچ NEXOR_AI_*_API_KEY ای ست نشده.
        providers.reset_provider_cache()
        for var in ("NEXOR_AI_PRO_API_KEY", "NEXOR_AI_PRO_API_URL", "NEXOR_AI_PRO_MODEL"):
            os.environ.pop(var, None)
        result = await service.interpret_request(_TEST_CHAT, _TEST_USER, text="لینک‌ها رو ببند", lang="fa")
        self.assertFalse(result.ok)
        self.assertEqual(result.error_code, "not_configured")

    async def test_valid_response_maps_to_known_intent(self):
        payload = '{"intent": "configure_link_protection", "confidence": 87}'
        with unittest.mock.patch("ai_copilot.service.providers.get_provider",
                                  return_value=_FakeProvider(response_text=payload)):
            result = await service.interpret_request(
                _TEST_CHAT, _TEST_USER, text="جلوی تبلیغات رو بگیر لطفا", lang="fa",
            )
        self.assertTrue(result.ok)
        self.assertEqual(result.data["intent"], "configure_link_protection")
        self.assertEqual(result.data["confidence"], 87)

    async def test_null_intent_is_preserved_not_guessed(self):
        payload = '{"intent": null, "confidence": 0}'
        with unittest.mock.patch("ai_copilot.service.providers.get_provider",
                                  return_value=_FakeProvider(response_text=payload)):
            result = await service.interpret_request(_TEST_CHAT, _TEST_USER, text="امروز هوا خوبه", lang="fa")
        self.assertTrue(result.ok)
        self.assertIsNone(result.data["intent"])

    async def test_confidence_is_clamped(self):
        payload = '{"intent": "show_rules", "confidence": 999}'
        with unittest.mock.patch("ai_copilot.service.providers.get_provider",
                                  return_value=_FakeProvider(response_text=payload)):
            result = await service.interpret_request(_TEST_CHAT, _TEST_USER, text="قوانین چیه", lang="fa")
        self.assertEqual(result.data["confidence"], 100)

    async def test_provider_error_degrades_gracefully_not_raise(self):
        with unittest.mock.patch("ai_copilot.service.providers.get_provider",
                                  return_value=_FakeProvider(raise_error=AIProviderError("boom"))):
            result = await service.interpret_request(_TEST_CHAT, _TEST_USER, text="یه چیزی", lang="fa")
        self.assertFalse(result.ok)
        self.assertEqual(result.error_code, "provider_error")

    async def test_hallucinated_unknown_intent_name_is_not_in_known_intents(self):
        # مدل ممکنه یه اسم من‌درآوردی برگردونه (توهم مدل) — service.py خودش
        # این رو فیلتر نمی‌کنه (فقط type/emptiness چک می‌کنه)، پس این چک باید
        # در لایه‌ی بالاتر (natural_language.py، قبل از dispatch) انجام بشه؛
        # این تست همون فرض رو مستند و مطمئن می‌کنه.
        from nlu.intent_parser import KNOWN_INTENTS
        payload = '{"intent": "launch_the_nukes", "confidence": 99}'
        with unittest.mock.patch("ai_copilot.service.providers.get_provider",
                                  return_value=_FakeProvider(response_text=payload)):
            result = await service.interpret_request(_TEST_CHAT, _TEST_USER, text="؟؟؟", lang="fa")
        self.assertTrue(result.ok)
        self.assertNotIn(result.data["intent"], KNOWN_INTENTS)


if __name__ == "__main__":
    unittest.main()
