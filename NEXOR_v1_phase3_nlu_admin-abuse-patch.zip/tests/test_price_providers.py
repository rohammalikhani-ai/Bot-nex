import unittest
import unittest.mock as mock

from services import price_providers as pp


class FakeResponse:
    def __init__(self, json_data, status_ok=True):
        self._json = json_data
        self._status_ok = status_ok

    def raise_for_status(self):
        if not self._status_ok:
            raise RuntimeError("HTTP error")

    def json(self):
        return self._json


class NavasanProviderTests(unittest.TestCase):
    def setUp(self):
        self.provider = pp.NavasanProvider()

    def test_disabled_without_api_key(self):
        with mock.patch.object(pp, "NAVASAN_API_KEY", ""):
            self.assertFalse(self.provider.enabled())
            self.assertEqual(self.provider.fetch(["gold18", "usd"]), {})

    def test_parses_successful_response(self):
        fake_data = {"18ayar": "35,120,000", "usd_sell": "620000", "eur_sell": "670000", "usdt": "62000"}
        with mock.patch.object(pp, "NAVASAN_API_KEY", "fake-key"), \
             mock.patch("services.price_providers.requests.get", return_value=FakeResponse(fake_data)) as m:
            result = self.provider.fetch(["gold18", "usd", "eur", "usdt"])
            m.assert_called_once()
        self.assertEqual(set(result.keys()), {"gold18", "usd", "eur", "usdt"})
        self.assertEqual(result["gold18"].value, 35120000.0)
        self.assertEqual(result["gold18"].unit, "toman")
        self.assertEqual(result["gold18"].source, "Navasan")

    def test_ignores_unsupported_assets(self):
        with mock.patch.object(pp, "NAVASAN_API_KEY", "fake-key"), \
             mock.patch("services.price_providers.requests.get", return_value=FakeResponse({})):
            result = self.provider.fetch(["ton", "stars"])  # هیچ‌کدام مسئولیت Navasan نیستند
        self.assertEqual(result, {})

    def test_skips_missing_or_non_positive_values_never_fakes_data(self):
        fake_data = {"18ayar": None, "usd_sell": "0", "eur_sell": "-5", "usdt": "not-a-number"}
        with mock.patch.object(pp, "NAVASAN_API_KEY", "fake-key"), \
             mock.patch("services.price_providers.requests.get", return_value=FakeResponse(fake_data)):
            result = self.provider.fetch(["gold18", "usd", "eur", "usdt"])
        self.assertEqual(result, {})  # هیچ مقدار جعلی/نامعتبری نباید برگردد

    def test_network_failure_never_raises(self):
        with mock.patch.object(pp, "NAVASAN_API_KEY", "fake-key"), \
             mock.patch("services.price_providers.requests.get", side_effect=ConnectionError("boom")):
            result = self.provider.fetch(["gold18"])
        self.assertEqual(result, {})

    def test_non_dict_response_handled_gracefully(self):
        with mock.patch.object(pp, "NAVASAN_API_KEY", "fake-key"), \
             mock.patch("services.price_providers.requests.get", return_value=FakeResponse([1, 2, 3])):
            result = self.provider.fetch(["gold18"])
        self.assertEqual(result, {})

    def test_field_name_can_be_overridden_via_env(self):
        fake_data = {"my_custom_gold_field": "40000000"}
        with mock.patch.object(pp, "NAVASAN_API_KEY", "fake-key"), \
             mock.patch.dict("os.environ", {"NAVASAN_FIELD_GOLD18": "my_custom_gold_field"}), \
             mock.patch("services.price_providers.requests.get", return_value=FakeResponse(fake_data)):
            result = self.provider.fetch(["gold18"])
        self.assertIn("gold18", result)
        self.assertEqual(result["gold18"].value, 40000000.0)


class CoinGeckoProviderTests(unittest.TestCase):
    def setUp(self):
        self.provider = pp.CoinGeckoProvider()

    def test_always_enabled_no_key_needed(self):
        self.assertTrue(self.provider.enabled())

    def test_parses_successful_response(self):
        fake_data = {"the-open-network": {"usd": 5.42}, "bitcoin": {"usd": 65000}}
        with mock.patch("services.price_providers.requests.get", return_value=FakeResponse(fake_data)):
            result = self.provider.fetch(["ton", "btc", "gold18"])  # gold18 مسئولیت این Provider نیست
        self.assertEqual(set(result.keys()), {"ton", "btc"})
        self.assertEqual(result["ton"].value, 5.42)
        self.assertEqual(result["ton"].unit, "usd")

    def test_network_failure_never_raises(self):
        with mock.patch("services.price_providers.requests.get", side_effect=TimeoutError("slow")):
            result = self.provider.fetch(["ton"])
        self.assertEqual(result, {})

    def test_missing_asset_in_response_is_skipped(self):
        with mock.patch("services.price_providers.requests.get", return_value=FakeResponse({})):
            result = self.provider.fetch(["ton"])
        self.assertEqual(result, {})


class ManualStarsProviderTests(unittest.TestCase):
    def setUp(self):
        self.provider = pp.ManualStarsProvider()

    def test_disabled_by_default_no_fake_rate(self):
        with mock.patch.object(pp, "STARS_MANUAL_RATE_TOMAN", ""):
            self.assertFalse(self.provider.enabled())
            self.assertEqual(self.provider.fetch(["stars"]), {})

    def test_returns_manual_rate_when_configured(self):
        with mock.patch.object(pp, "STARS_MANUAL_RATE_TOMAN", "1500"):
            result = self.provider.fetch(["stars"])
        self.assertEqual(result["stars"].value, 1500.0)
        self.assertEqual(result["stars"].source, "manual")

    def test_invalid_manual_rate_yields_no_fake_value(self):
        with mock.patch.object(pp, "STARS_MANUAL_RATE_TOMAN", "not-a-number"):
            self.assertTrue(self.provider.enabled())  # non-empty string => "configured"
            self.assertEqual(self.provider.fetch(["stars"]), {})


if __name__ == "__main__":
    unittest.main()
