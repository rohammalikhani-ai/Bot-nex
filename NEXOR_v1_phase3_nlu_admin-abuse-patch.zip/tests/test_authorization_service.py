import unittest
from security_policy import can_target, effective_rank, has_required_capability
from config import RANK_USER, RANK_MODERATOR, RANK_ADMIN, RANK_OWNER
from services.authorization import authorize


class AuthorizationPolicyTests(unittest.TestCase):
    def test_delegated_capability_targets_only_lower_rank(self):
        caps = {"mute"}
        self.assertTrue(authorize(RANK_USER, RANK_USER, caps, "mute", RANK_MODERATOR))
        self.assertFalse(authorize(RANK_USER, RANK_MODERATOR, caps, "mute", RANK_MODERATOR))

    def test_real_admin_keeps_real_hierarchy(self):
        self.assertTrue(authorize(RANK_ADMIN, RANK_MODERATOR, set(), "ban", RANK_ADMIN))
        self.assertFalse(authorize(RANK_ADMIN, RANK_ADMIN, set(), "ban", RANK_ADMIN))
        self.assertTrue(authorize(RANK_OWNER, RANK_ADMIN, set(), "ban", RANK_ADMIN))
        self.assertFalse(authorize(RANK_ADMIN, RANK_OWNER, set(), "ban", RANK_ADMIN))

    def test_missing_target_rank_fails_closed(self):
        # No target means this is a non-targeted action (e.g. changing settings).
        self.assertTrue(authorize(RANK_ADMIN, None, set(), "ban", RANK_ADMIN))
        self.assertFalse(can_target(None, RANK_USER))

    def test_self_action_is_denied(self):
        self.assertFalse(can_target(RANK_OWNER, RANK_OWNER, same_user=True))

    def test_capability_does_not_change_stored_rank(self):
        caps = {"mute"}
        self.assertEqual(effective_rank(RANK_USER, caps, "mute", RANK_MODERATOR, RANK_MODERATOR), RANK_MODERATOR)
        self.assertFalse(has_required_capability(RANK_USER, caps, "ban", RANK_ADMIN))


if __name__ == "__main__":
    unittest.main()
