# -*- coding: utf-8 -*-
STRINGS = {
    "rank_user": "عضو",
    "rank_moderator": "مشرف (Moderator)",
    "rank_admin": "مسؤول",
    "rank_owner": "المالك",

    "err_need_rank": "⛔️ هذا الأمر يتطلب صلاحية «{rank}» أو أعلى.",
    "err_self_action": "لا يمكنك تنفيذ هذا الإجراء على نفسك! 😅",
    "err_rank_too_low": "⛔️ لا تملك الصلاحية الكافية للتصرف مع هذا المستخدم (رتبته مساوية أو أعلى من رتبتك).",
    "err_user_not_found_username": "❌ لم أتمكن من العثور على هذا المستخدم (يجب أن يكون قد أرسل رسالة واحدة على الأقل في هذه المجموعة ليتعرف عليه البوت).",
    "err_need_target": "❗️لم يتم العثور على المستخدم المستهدف.\nالاستخدام: {usage}",

    "warn_given": "⚠️ حصل {name} على تحذير. ({count}/{max})",
    "warn_reason_line": "\nالسبب: {reason}",
    "warn_removed": "➖ تم إزالة تحذير عن {name}. ({count}/{max})",
    "warn_escalate_mute": "🔇 تم كتم {name} لمدة {duration} بعد الوصول إلى {max} تحذيرات.",
    "warn_escalate_ban": "🚫 تم حظر {name} بعد الوصول إلى {max} تحذيرات.",
    "warns_header": "⚠️ تحذيرات {name}: {count}/{max}",
    "warns_history_line": "• {when} — {reason} (بواسطة {actor})",
    "warns_no_reason": "بدون سبب",
    "setwarnaction_usage": "الاستخدام: /setwarnaction mute أو /setwarnaction ban",
    "setwarnaction_done": "✅ الإجراء بعد بلوغ الحد الأقصى للتحذيرات: {action}",
    "setmaxwarns_usage": "الاستخدام: /setmaxwarns رقم (مثلاً 3)",
    "setmaxwarns_done": "✅ تم تغيير الحد الأقصى للتحذيرات إلى {n}.",

    "mute_done": "🔇 تم كتم {name} (المدة: {duration}).",
    "unmute_done": "🔊 تم إلغاء كتم {name}.",

    "ban_done": "🚫 تم حظر {name} (المدة: {duration}).",
    "unban_done": "✅ تم رفع الحظر عن {name}.",
    "duration_permanent": "دائم",

    "kick_done": "👢 تم طرد {name} من المجموعة.",

    "del_usage": "الرجاء الرد على الرسالة التي تريد حذفها.",
    "purge_usage": "الاستخدام: رد على رسالة مع /purge، أو /purge <عدد>",
    "purge_done": "🧹 تم حذف {count} رسالة.",

    "promote_usage": "الرجاء الرد على المستخدم المطلوب أو إعطاء @username/ID.",
    "promote_already_admin": "هذا المستخدم مسؤول حقيقي في تيليجرام بالفعل؛ لا حاجة لدور داخلي.",
    "promote_done": "⭐️ تم تعيين {name} كمشرف داخلي للبوت.",
    "demote_done": "⬇️ تم سحب دور المشرف من {name}.",
    "roles_empty": "لا يوجد مشرفون داخليون مسجّلون. (استخدم لوحة تيليجرام نفسها لرؤية المسؤولين الحقيقيين.)",
    "roles_header": "⭐️ المشرفون الداخليون في هذه المجموعة:",
    "logs_empty": "لم يتم تسجيل أي إجراء بعد.",
    "logs_header": "🧾 آخر إجراءات الإشراف:",

    "btn_remove_warn": "➖ إزالة تحذير",
    "btn_mute": "🔇 كتم",
    "btn_ban": "🚫 حظر",
    "modact_invalid_data": "بيانات غير صالحة.",
    "modact_wrong_chat": "هذا الزر ليس لهذه المجموعة.",
    "modact_no_permission": "⛔️ لا تملك الصلاحية اللازمة لهذا الإجراء.",
    "modact_done": "تم ✅",
    "modact_unwarn_result": "➖ {name} — تمت إزالة تحذير واحد. ({count})",
    "modact_mute_result": "🔇 تم كتم {name} لمدة {minutes} دقيقة.",
    "modact_ban_result": "🚫 تم حظر {name}.",

    "start_msg": (
        "مرحباً {mention} 🌹\n\n"
        "🔰 تعرّف على *NEXOR* — أكثر بوتات إدارة المجموعات احترافية\n"
        "🔰 مساعد قوي للنظام والأمان والتحكم الكامل في مجموعات تيليجرام\n\n"
        "✨ *الميزات الرئيسية:*\n"
        "✅ إدارة كاملة للأعضاء (تحذير، كتم، حظر، طرد)\n"
        "✅ أقفال ذكية للمحتوى (الروابط، إعادة التوجيه، الوسائط، وغيرها)\n"
        "✅ فلترة متقدمة للكلمات والعبارات الممنوعة\n"
        "✅ كابتشا عند الانضمام لمنع البوتات المزعجة\n"
        "✅ حماية متقدمة من السبام والفلود\n"
        "✅ حماية من الغارات الجماعية (Anti-Raid)\n"
        "✅ إدارة القناة المتصلة (نشر، جدولة، تعديل، حذف)\n"
        "✅ نظام اتحاد بين عدة مجموعات\n"
        "✅ أدوار داخلية وسجلّات وتقارير كاملة\n"
        "✅ متعدد اللغات (الفارسية، الإنجليزية، العربية، التركية، الروسية، الإسبانية)\n\n"
        "🤖 *NEXOR Copilot — مساعد الذكاء الاصطناعي لمجموعتك:*\n"
        "✅ بالرد على أي رسالة مشبوهة، يحلّل الخطورة في ثوانٍ\n"
        "✅ اسأله «لماذا؟» فيشرح لك بالضبط سبب أي تحذير/كتم/حظر\n"
        "✅ يعطيك تقرير صحة كامل للمجموعة: أين المشاكل وأين يجب التشديد\n"
        "✅ فقط صف مشكلتك بكلماتك («زاد الإعلان كثيرًا») وسيقترح ويبني لك قاعدة تلقائية\n"
        "✅ يحلّل ويرتّب أولوية بلاغات الأعضاء والحوادث الأخيرة قبل اتخاذ القرار\n"
        "جرّبه بكتابة /copilot! ✨\n"
        "\n"
        "🚀 *التثبيت والتفعيل:*\n"
        "١. أضف البوت إلى مجموعتك عبر الزر أدناه\n"
        "٢. امنحه صلاحيات المشرف الكاملة ليعمل بشكل صحيح\n\n"
        "📌 *ملاحظات مهمة:*\n"
        "• يجب أن تكون المجموعة سوبر غروب\n"
        "• يُنصح بمنحه كل صلاحيات المشرف للحصول على أفضل أداء\n\n"
        "استخدم /help لرؤية القائمة الكاملة للأوامر."
    ),
    "add_to_group_button": "➕ إضافة إلى المجموعة",
    "settings_header": "⚙️ *إعدادات المجموعة الحالية*",
    "settings_locks": "🔒 القيود: {locks}",
    "settings_filters": "🚫 الفلاتر: {filters}",
    "settings_captcha": "🛡️ التحقق (CAPTCHA): {state}",
    "settings_warns": "⚠️ الحد الأقصى للتحذيرات: {max} ← الإجراء: {action}",
    "settings_channel": "📢 القناة المرتبطة: {channel}",
    "settings_logchannel": "🧾 قناة السجل: {log}",
    "settings_lang": "🌐 اللغة: {lang}",
    "none": "لا شيء",
    "not_set": "—",

    "setlang_prompt": "🌐 اختر لغة المجموعة:",
    "setlang_done": "✅ تم تغيير لغة المجموعة إلى {lang_name}.",

    "welcome_simple": "أهلاً بك {mention} في {chat}! 🌹",
    "welcome_captcha": "أهلاً بك {mention} في {chat}! 🌹\nالرجاء الضغط على الزر أدناه للتحقق من أنك لست روبوتاً.",
    "welcome_simple_multi": "أهلاً بكم في {chat}: {mentions} 🌹",
    "welcome_captcha_multi": "أهلاً بكم في {chat}: {mentions} 🌹\nعلى كل شخص الضغط على الزر بجانب اسمه للتحقق.",
    "captcha_btn": "✅ لست روبوتاً",
    "captcha_not_yours": "هذا الزر ليس لك.",
    "captcha_expired": "انتهت صلاحية هذا التحقق.",
    "captcha_verified_alert": "✅ تم التحقق، أهلاً بك!",
    "captcha_verified_msg": "✅ تم التحقق من {name} ويمكنه الآن الكتابة.",
    "captcha_timeout_msg": "⛔️ انتهت مهلة التحقق وتم إزالة المستخدم من المجموعة.",
    "captcha_toggle_usage": "الاستخدام: /captcha on أو /captcha off",
    "captcha_toggle_done": "🛡️ تم {state} التحقق.",
    "captcha_on": "تفعيل",
    "captcha_off": "تعطيل",
    "goodbye_msg": "غادر {name} المجموعة. 👋",

    "lock_usage": "الاستخدام: /lock {options}",
    "lock_done": "🔒 تم قفل {kind}.",
    "unlock_usage": "الاستخدام: /unlock {options}",
    "unlock_done": "🔓 تم فتح {kind}.",
    "locks_active": "🔒 القيود الفعّالة: {locks}",
    "filter_usage": "الاستخدام: /filter كلمة",
    "filter_added": "➕ تمت إضافة الكلمة «{word}» إلى الفلتر.",
    "stopfilter_usage": "الاستخدام: /stopfilter كلمة",
    "filter_removed": "➖ تمت إزالة الكلمة «{word}» من الفلتر.",
    "filters_active": "🚫 الفلاتر الفعّالة: {filters}",
    "flood_muted": "🚨 تم كتم {name} لمدة {minutes} دقيقة بسبب إرسال رسائل كثيرة بسرعة.",

    "save_usage": "الاستخدام: /save الاسم النص (أو بالرد على رسالة: /save الاسم)",
    "save_empty": "لم يتم العثور على نص لحفظه.",
    "save_done": "📝 تم حفظ الملاحظة «{name}». يمكن عرضها بـ /get {name} أو #{name}.",
    "get_usage": "الاستخدام: /get الاسم",
    "get_not_found": "لم يتم العثور على ملاحظة بهذا الاسم.",
    "notes_empty": "لا توجد ملاحظات محفوظة بعد.",
    "notes_list_header": "📝 الملاحظات المتوفرة:",
    "clear_usage": "الاستخدام: /clear الاسم",
    "clear_done": "🗑️ تم حذف الملاحظة «{name}».",

    "setlogchannel_usage": "الاستخدام: /setlogchannel @channel＿username أو المعرف الرقمي للقناة",
    "setlogchannel_error": "❌ لم أتمكن من العثور على القناة: {error}",
    "setlogchannel_done": "🧾 سيتم تسجيل إجراءات الإدارة من الآن في «{title}».",
    "setlogchannel_channel_confirm": "✅ تم تعيين هذه القناة كقناة سجل إدارة المجموعة.",

    "fed_new_usage": "الاستخدام: /fnew اسم＿الاتحاد",
    "fed_new_done": "🌐 تم إنشاء الاتحاد «{name}» (المعرف: {id}).\nتمت إضافة هذه المجموعة كأول عضو.\nلإضافة مجموعات أخرى، نفّذ هذا فيها:\n/fjoin {id}",
    "fed_join_usage": "الاستخدام: /fjoin معرف＿الاتحاد",
    "fed_join_invalid_id": "معرف الاتحاد غير صالح.",
    "fed_not_found": "لم يتم العثور على اتحاد بهذا المعرف.",
    "fed_join_done": "✅ انضمت هذه المجموعة إلى اتحاد «{name}».",
    "fed_not_member": "هذه المجموعة ليست عضواً في أي اتحاد.",
    "fed_left": "👋 غادرت هذه المجموعة اتحاد «{name}».",
    "fed_info": "🌐 الاتحاد: {name}\n🆔 المعرف: {id}\n👥 عدد المجموعات الأعضاء: {count}",
    "fed_ban_no_target": "الرجاء الرد على رسالة المستخدم المطلوب أو إعطاء @username/ID.",
    "fed_ban_not_member": "هذه المجموعة ليست في أي اتحاد بعد. نفّذ /fnew أو /fjoin أولاً.",
    "fed_ban_done": "🚫 تم حظر {name} في اتحاد «{fed}».\n✅ نجاح: {success} مجموعة | ❌ فشل: {failed} مجموعة\nالسبب: {reason}",
    "fed_unban_done": "✅ تم رفع حظر {name} في {success} مجموعة من اتحاد «{fed}».",
    "fed_ban_no_reason": "بدون سبب مذكور",
    "fed_raid_kick_notice": "🚫 كان {name} محظوراً في الاتحاد وتمت إزالته تلقائياً.",

    "help_text": (
        "📋 *أوامر الإدارة*\n\n"
        "✨ *معلومة ممتعة:* لست مضطرًا لكتابة الشرطة المائلة دائمًا! لكل أمر كلمة عادية توأم تقوم بنفس المهمة تمامًا — مثلًا كتابة «إبلاغ» تعمل تمامًا مثل /report، وكتابة «مساعدة» تفتح لك نفس هذه القائمة. تعمل هذه الميزة في جميع اللغات الست التي يدعمها البوت، كل لغة بكلماتها الخاصة، فيستطيع كل عضو التحكم بالبوت بلغته دون حفظ أي أمر بالشرطة المائلة! 🗣️\n\n"
        "👮 *إدارة الأعضاء* (بالرد، أو @username، أو user＿id)\n"
        "/warn [المدة] [السبب]   /unwarn   /warns — سجل التحذيرات\n"
        "/mute [المدة] [السبب]   /unmute\n"
        "/ban [المدة] [السبب]   /unban\n"
        "/kick [السبب]\n"
        "مثال: /ban 2h سبام كثير   أو   /mute @user 30m\n"
        "/setmaxwarns رقم   /setwarnaction mute|ban\n\n"
        "🧹 *حذف الرسائل*\n"
        "/del — حذف الرسالة التي تم الرد عليها\n"
        "/purge — حذف من الرسالة التي تم الرد عليها حتى الآن (أو /purge عدد)\n\n"
        "⭐️ *الأدوار الداخلية*\n"
        "/promote /demote — دور المشرف الداخلي للبوت (أقل من المسؤول الحقيقي)\n"
        "/roles — قائمة المشرفين الداخليين\n"
        "/logs — آخر إجراءات الإشراف (سجل التدقيق)\n\n"
        "🔒 *قيود المحتوى*\n"
        "/lock link|invitelink|channellink|photo|video|sticker|voice|forward|gif|video＿note|document|poll\n"
        "/unlock نفس الخيارات\n"
        "/locks — عرض القيود الفعّالة\n\n"
        "🌐 *حماية الروابط*\n"
        "/blockdomain دومين   /unblockdomain دومين\n"
        "/allowdomain دومين   /unallowdomain دومين\n"
        "/domains — عرض القوائم\n\n"
        "🚫 *فلاتر الكلمات*\n"
        "/filter كلمة\n/stopfilter كلمة\n/filters\n"
        "/setfilteraction delete|warn|mute|ban\n"
        "/allowword كلمة — استثناء   /disallowword كلمة\n\n"
        "🕵️ *مكافحة السبام*\n"
        "/antispam on|off\n/setspamaction delete|warn|mute|ban\n"
        "/dupcross on|off   /setdupcross العتبة الثواني\n\n"
        "↪️ *حماية التوجيه*\n"
        "/allowforward المصدر   /blockforward المصدر   /unruleforward المصدر\n"
        "/forwardrules — عرض القواعد (المصدر: @username أو ID أو اسم)\n\n"
        "📛 *حماية الإشارات*\n"
        "/mentionprotection on|off\n/setmentionlimit رقم\n/setmentionaction delete|warn|mute|ban\n\n"
        "🚨 *مكافحة الفيضان*\n"
        "/setflood العدد الثواني\n/setfloodaction delete|warn|mute|ban\n\n"
        "🛡️ *مكافحة الغارات*\n"
        "/antiraid on|off\n/setraidthreshold رقم\n"
        "/lockdown — قفل كل المجموعة فوراً   /unlockchat — فتح القفل\n\n"
        "🛡️ *التحقق (CAPTCHA)*\n"
        "/captcha on|off — تفعيل/تعطيل التحقق من الأعضاء الجدد\n\n"
        "📝 *الملاحظات*\n"
        "/save الاسم (بالرد أو بالنص) — حفظ ملاحظة\n"
        "/get الاسم أو #الاسم — عرض ملاحظة\n"
        "/notes — قائمة الملاحظات\n"
        "/clear الاسم — حذف ملاحظة\n\n"
        "📢 *إدارة القناة (تُنفَّذ من المجموعة)*\n"
        "/setchannel @channel＿username — ربط قناة\n"
        "/post النص — نشر فوري (زر بصيغة \"نص|رابط\"، وفاصلة منقوطة بين الأزرار)\n"
        "/schedulepost الدقائق | النص — منشور مجدول\n"
        "/editpost معرف＿الرسالة | نص جديد\n"
        "/delpost معرف＿الرسالة\n"
        "/channelstats — إحصائيات القناة\n\n"
        "🧾 *سجل الإدارة*\n"
        "/setlogchannel @channel＿username — تسجيل إجراءات الإدارة في قناة\n\n"
        "🌐 *الاتحاد (قائمة حظر مشتركة)*\n"
        "/fnew الاسم — إنشاء اتحاد جديد\n"
        "/fjoin المعرف — انضمام هذه المجموعة إلى اتحاد\n"
        "/fleave — مغادرة الاتحاد\n"
        "/finfo — معلومات الاتحاد الحالي\n"
        "/fban (رد) السبب — حظر في جميع مجموعات الاتحاد\n"
        "/funban (رد) — إلغاء الحظر في جميع مجموعات الاتحاد\n\n"
        "🆕 *الأعضاء الجدد والأتمتة*\n"
        "/setwelcomedelete ثواني|off — حذف رسالة الترحيب تلقائيًا\n"
        "/setgoodbye نص   /resetgoodbye   /goodbye on|off\n"
        "/rules   /setrules [لغة] نص   /clearrules [لغة]\n"
        "/addkeyword كلمة رد   /delkeyword كلمة   /keywords\n"
        "/addcmd اسم رد   /delcmd اسم   /cmds\n"
        "/schedulerecurring daily|weekly|monthly ... — منشورات متكررة في القناة\n"
        "/recurringposts   /delrecurring المعرف\n"
        "/addautoaction شرط إجراء   /delautoaction المعرف   /autoactions   /autoactiontoggle on|off\n\n"
        "🗂️ *ملفات الصلاحيات (Permission Profiles)*\n"
        "/createprofile الاسم صلاحية1,صلاحية2,...   /delprofile الاسم   /profiles\n"
        "/assignprofile [رد|@user|id] اسم＿الملف   /unassignprofile [رد|@user|id]   /myperms\n\n"
        "🚩 *البلاغات (Reports)*\n"
        "/report [السبب] (رد على رسالة)   /reports — البلاغات المفتوحة\n\n"
        "🔔 *تنبيهات المشرفين*\n"
        "/setalertchannel chat＿id   /alerts — التنبيهات الأخيرة\n\n"
        "📦 *استيراد/تصدير الإعدادات*\n"
        "/exportsettings   /importsettings (رد على ملف .json)\n\n"
        "🔔 *الإشعارات اليومية* (💰 أسعار + 📰 أخبار + 📅 تاريخ/مناسبة)\n"
        "/dailynotify — لوحة الإعدادات (تفعيل/تعطيل، الأصول، إرسال تجريبي)\n"
        "/setpricetime HH:MM   /setnewstime HH:MM   /setdailytz المنطقة_الزمنية\n"
        "/testdailyprice   /testdailynews   /dailyassets\n\n"
        "🌐 /setlang — تغيير لغة المجموعة\n"
        "⚙️ /settings — عرض إعدادات المجموعة الحالية"
    ),

    "help_words_text": (
        "📖 *القائمة الكاملة للكلمات البديلة للأوامر*\n"
        "كل سطر يعني: اكتب هذه الكلمة = ينفّذ نفس الأمر بالضبط\n"
        "\n"
        "*👮 إدارة الأعضاء*\n"
        "تحذير = /warn\n"
        "إزالة تحذير = /unwarn\n"
        "التحذيرات = /warns\n"
        "كتم = /mute\n"
        "إلغاء الكتم = /unmute\n"
        "حظر = /ban\n"
        "إلغاء الحظر = /unban\n"
        "طرد = /kick\n"
        "حذف = /del\n"
        "تنظيف = /purge\n"
        "\n"
        "*⭐️ الرتب والسجل*\n"
        "ترقية = /promote\n"
        "تنزيل الرتبة = /demote\n"
        "المشرفون = /roles\n"
        "السجل = /logs\n"
        "تغيير اللغة = /setlang\n"
        "\n"
        "*🔒 الأقفال والفلاتر*\n"
        "قفل = /lock\n"
        "فتح القفل = /unlock\n"
        "الأقفال = /locks\n"
        "فلتر = /filter\n"
        "إزالة الفلتر = /stopfilter\n"
        "الفلاتر = /filters\n"
        "النطاقات المحظورة = /domains\n"
        "قواعد إعادة التوجيه = /forwardrules\n"
        "\n"
        "*🛡️ أمن المجموعة*\n"
        "مكافحة الغارات = /antiraid\n"
        "إغلاق كامل = /lockdown\n"
        "فتح المجموعة = /unlockchat\n"
        "كابتشا = /captcha\n"
        "وداعا = /goodbye\n"
        "\n"
        "*📝 الملاحظات*\n"
        "حفظ = /save\n"
        "إحضار = /get\n"
        "الملاحظات = /notes\n"
        "مسح ملاحظة = /clear\n"
        "\n"
        "*📢 القناة*\n"
        "تعيين القناة = /setchannel\n"
        "نشر = /post\n"
        "جدولة منشور = /schedulepost\n"
        "تعديل المنشور = /editpost\n"
        "حذف المنشور = /delpost\n"
        "إحصائيات القناة = /channelstats\n"
        "تعيين قناة السجل = /setlogchannel\n"
        "\n"
        "*🌐 الاتحاد*\n"
        "اتحاد جديد = /fnew\n"
        "انضمام للاتحاد = /fjoin\n"
        "مغادرة الاتحاد = /fleave\n"
        "معلومات الاتحاد = /finfo\n"
        "حظر الاتحاد = /fban\n"
        "إلغاء حظر الاتحاد = /funban\n"
        "\n"
        "*🆕 الترحيب والأتمتة*\n"
        "القوانين = /rules\n"
        "تعيين القوانين = /setrules\n"
        "مسح القوانين = /clearrules\n"
        "إضافة كلمة مفتاحية = /addkeyword\n"
        "حذف كلمة مفتاحية = /delkeyword\n"
        "الكلمات المفتاحية = /keywords\n"
        "إضافة أمر = /addcmd\n"
        "حذف أمر = /delcmd\n"
        "الأوامر = /cmds\n"
        "إضافة إجراء تلقائي = /addautoaction\n"
        "حذف إجراء تلقائي = /delautoaction\n"
        "الإجراءات التلقائية = /autoactions\n"
        "\n"
        "*🗂️ الصلاحيات والبلاغات*\n"
        "الملفات الشخصية = /profiles\n"
        "صلاحياتي = /myperms\n"
        "إبلاغ = /report\n"
        "البلاغات = /reports\n"
        "التنبيهات = /alerts\n"
        "تصدير الإعدادات = /exportsettings\n"
        "\n"
        "*🤖 مساعد NEXOR*\n"
        "الإدارة = /adminpanel\n"
        "مساعد = /copilot\n"
        "فحص الذكاء الاصطناعي = /aicheck\n"
        "شرح الإجراء = /aiexplain\n"
        "تحليل البلاغات = /aireports\n"
        "صحة المجموعة = /aihealth\n"
        "اقتراح قاعدة = /airule\n"
        "تحسين القواعد = /aioptimize\n"
        "تحليل الحادثة = /aiincident\n"
        "خطة الذكاء الاصطناعي = /aiplan\n"
        "\n"
        "*⚙️ عام*\n"
        "الإعدادات = /settings\n"
        "مساعدة = /help\n"
        "\n"
        "💡 للعبارات المكوّنة من أكثر من كلمة (مثل «إزالة تحذير»)، اكتبها بالضبط كما هي متتالية."
    ),

    "channel_set_usage": "الاستخدام: /setchannel @channel＿username أو المعرف الرقمي للقناة",
    "channel_set_error": "❌ لم أتمكن من العثور على القناة: {error}",
    "channel_set_done": "📢 تم ربط القناة «{title}» بهذه المجموعة.",
    "channel_no_channel": "اربط قناة أولاً باستخدام /setchannel.",
    "channel_post_empty": "نص المنشور فارغ. الاستخدام: /post نص الرسالة",
    "channel_post_sent": "✅ تم إرسال المنشور. معرف الرسالة: {id}",
    "channel_post_failed": "❌ فشل إرسال المنشور: {error}",
    "channel_schedule_usage": "الاستخدام: /schedulepost الدقائق ثم نص المنشور في السطر التالي",
    "channel_schedule_invalid_minutes": "عدد الدقائق غير صالح.",
    "channel_schedule_empty": "نص المنشور فارغ.",
    "channel_schedule_done": "⏰ تمت جدولة المنشور بعد {minutes} دقيقة.",
    "channel_scheduled_sent": "✅ تم إرسال المنشور المجدول. المعرف: {id}",
    "channel_scheduled_failed": "❌ فشل إرسال المنشور المجدول: {error}",
    "channel_editpost_usage": "الاستخدام: /editpost معرف＿الرسالة ثم النص الجديد في السطر التالي",
    "channel_editpost_invalid_id": "معرف الرسالة غير صالح.",
    "channel_editpost_empty": "النص الجديد فارغ.",
    "channel_editpost_done": "✅ تم تعديل المنشور.",
    "channel_editpost_failed": "❌ فشل التعديل: {error}",
    "channel_delpost_usage": "الاستخدام: /delpost معرف＿الرسالة",
    "channel_delpost_done": "🗑️ تم حذف المنشور.",
    "channel_delpost_failed": "❌ فشل الحذف: {error}",
    "channel_stats_text": "📊 إحصائيات قناة «{title}»\n👥 عدد الأعضاء: {count}",
    "channel_stats_failed": "❌ فشل جلب الإحصائيات: {error}",

    "state_on": "مفعّل",
    "state_off": "معطّل",

    "antispam_toggle_usage": "الاستخدام: /antispam on أو /antispam off",
    "antispam_toggle_done": "🕵️ مكافحة السبام {state}.",
    "adminabuseprotection_toggle_usage": "الاستخدام: /adminabuseprotection on أو /adminabuseprotection off (لمالك المجموعة فقط)",
    "adminabuseprotection_toggle_done": "🚷 كشف إساءة استخدام المشرف {state}.",
    "setspamaction_usage": "الاستخدام: /setspamaction delete|warn|mute|ban",
    "setspamaction_done": "✅ إجراء مكافحة السبام: {action}",
    "spam_reason_duplicate": "إرسال رسالة مكررة",
    "spam_reason_newlink": "نشر رابط مباشرة بعد الانضمام",

    "setflood_usage": "الاستخدام: /setflood العدد الثواني (مثال: /setflood 5 10)",
    "setflood_done": "✅ مكافحة الفيضان: {limit} رسالة كل {window} ثانية",
    "setfloodaction_usage": "الاستخدام: /setfloodaction delete|warn|mute|ban",
    "setfloodaction_done": "✅ إجراء مكافحة الفيضان: {action}",
    "flood_reason": "إرسال رسائل بسرعة كبيرة",

    "setfilteraction_usage": "الاستخدام: /setfilteraction delete|warn|mute|ban",
    "setfilteraction_done": "✅ إجراء فلتر الكلمات: {action}",
    "allowword_usage": "الاستخدام: /allowword كلمة",
    "allowword_done": "➕ تمت إضافة «{word}» إلى قائمة الاستثناءات.",
    "disallowword_usage": "الاستخدام: /disallowword كلمة",
    "disallowword_done": "➖ تمت إزالة «{word}» من قائمة الاستثناءات.",
    "filter_reason": "كلمة محظورة",

    "blockdomain_usage": "الاستخدام: /blockdomain دومين (مثل example.com)",
    "blockdomain_done": "🚫 تم حظر الدومين «{domain}».",
    "unblockdomain_usage": "الاستخدام: /unblockdomain دومين",
    "unblockdomain_done": "✅ تم إلغاء حظر الدومين «{domain}».",
    "allowdomain_usage": "الاستخدام: /allowdomain دومين",
    "allowdomain_done": "✅ تمت إضافة الدومين «{domain}» إلى القائمة البيضاء.",
    "unallowdomain_usage": "الاستخدام: /unallowdomain دومين",
    "unallowdomain_done": "➖ تمت إزالة الدومين «{domain}» من القائمة البيضاء.",
    "domains_header_block": "🚫 الدومينات المحظورة:",
    "domains_header_allow": "✅ الدومينات في القائمة البيضاء:",
    "domains_empty": "لا توجد دومينات مسجلة.",
    "link_reason_blacklisted": "رابط دومين محظور",

    "antiraid_toggle_usage": "الاستخدام: /antiraid on أو /antiraid off",
    "antiraid_toggle_done": "🛡️ مكافحة الغارات {state}.",
    "setraidthreshold_usage": "الاستخدام: /setraidthreshold رقم (مثال: 8)",
    "setraidthreshold_done": "✅ تم تغيير حد اكتشاف الغارة إلى {n} مستخدم.",
    "raid_detected_alert": "🚨 *تنبيه غارة!*\nانضم عدد غير طبيعي من الأعضاء الجدد ({count} خلال {window} ثانية) إلى المجموعة.\nتم قفل المجموعة لمدة {minutes} دقيقة (المسؤولون فقط يمكنهم الكتابة).",
    "raid_auto_unlock": "🔓 تم رفع القفل الأمني التلقائي.",
    "lockdown_done": "🔒 تم قفل المجموعة؛ المسؤولون فقط يمكنهم الكتابة.",
    "unlock_done_manual": "🔓 تم رفع قفل المجموعة.",
    "already_locked": "المجموعة مقفلة بالفعل.",
    "already_unlocked": "المجموعة غير مقفلة.",
    "btn_unlock_now": "🔓 فتح القفل الآن",

    # --- Priority 3: Content Control (Forward Protection / Mention Protection / Cross-user Duplicate) ---
    "allowforward_usage": "الاستخدام: /allowforward @username|ID|اسم",
    "allowforward_done": "✅ التوجيه من «{source}» مسموح دائمًا الآن.",
    "blockforward_usage": "الاستخدام: /blockforward @username|ID|اسم",
    "blockforward_done": "🚫 التوجيه من «{source}» محظور دائمًا الآن.",
    "unruleforward_usage": "الاستخدام: /unruleforward @username|ID|اسم",
    "unruleforward_done": "➖ تمت إزالة قاعدة التوجيه لـ «{source}».",
    "forwardrules_header_block": "🚫 مصادر محظورة دائمًا:",
    "forwardrules_header_allow": "✅ مصادر مسموحة دائمًا:",
    "forwardrules_empty": "لا توجد قواعد توجيه.",
    "forward_reason_blocked_source": "توجيه من مصدر محظور ({source})",
    "mentionprotection_usage": "الاستخدام: /mentionprotection on أو /mentionprotection off",
    "mentionprotection_done": "🛡️ حماية الإشارات {state}.",
    "setmentionlimit_usage": "الاستخدام: /setmentionlimit رقم (مثلاً 5)",
    "setmentionlimit_done": "✅ تم تغيير حد الإشارات إلى {n}.",
    "setmentionaction_usage": "الاستخدام: /setmentionaction delete|warn|mute|ban",
    "setmentionaction_done": "✅ إجراء إساءة الإشارات: {action}",
    "mention_reason": "إساءة استخدام الإشارات الجماعية ({count} إشارة)",
    "dupcross_usage": "الاستخدام: /dupcross on أو /dupcross off",
    "dupcross_done": "🕵️ كشف الرسائل المكررة بين عدة مستخدمين {state}.",
    "setdupcross_usage": "الاستخدام: /setdupcross العتبة الثواني (مثلاً 3 45)",
    "setdupcross_done": "✅ إعدادات التكرار بين المستخدمين: {threshold} مستخدم خلال {window} ثانية.",
    "spam_reason_cross_duplicate": "رسالة مكررة من عدة مستخدمين (نسخ ولصق جماعي)",

    # --- Priority 4: New Members & Automation (Welcome auto-delete, Goodbye, Rules, Filters, Custom Commands, Scheduled Messages, Auto Actions) ---
    "setwelcomedelete_usage": "الاستخدام: /setwelcomedelete ثواني (مثلاً 60) أو /setwelcomedelete off",
    "setwelcomedelete_done": "✅ سيتم الآن حذف رسالة الترحيب تلقائيًا بعد {seconds} ثانية.",
    "setwelcomedelete_off": "✅ تم تعطيل الحذف التلقائي لرسالة الترحيب.",
    "setgoodbye_usage": "الاستخدام: /setgoodbye <النص>\nالمتغيرات المتاحة: {name} {username} {mention} {chat} {count}",
    "setgoodbye_done": "✅ تم حفظ رسالة الوداع المخصصة.",
    "resetgoodbye_done": "✅ تمت إعادة رسالة الوداع إلى الوضع الافتراضي.",
    "goodbye_toggle_usage": "الاستخدام: /goodbye on أو /goodbye off",
    "goodbye_toggle_done": "👋 رسائل الوداع {state}.",
    "rules_empty": "لم يتم تعيين قوانين لهذه المجموعة بعد.",
    "rules_header": "📜 *قوانين المجموعة*",
    "setrules_usage": "الاستخدام: /setrules [رمز اللغة] <نص القوانين>\nمثال: /setrules يرجى احترام الجميع.\nمع رمز اللغة: /setrules en Please be respectful.",
    "setrules_done": "✅ تم حفظ القوانين ({lang}).",
    "clearrules_done": "🗑️ تم حذف القوانين ({lang}).",
    "clearrules_notfound": "لم يتم تعيين قوانين لهذه اللغة.",
    "addkeyword_usage": "الاستخدام: /addkeyword <الكلمة المفتاحية> <الرد>\nأو بالرد على رسالة: /addkeyword <الكلمة المفتاحية>",
    "addkeyword_done": "✅ تمت إضافة مشغّل الكلمة المفتاحية «{keyword}».",
    "addkeyword_updated": "♻️ تم تحديث مشغّل الكلمة المفتاحية «{keyword}».",
    "delkeyword_usage": "الاستخدام: /delkeyword <الكلمة المفتاحية>",
    "delkeyword_done": "🗑️ تم حذف مشغّل الكلمة المفتاحية «{keyword}».",
    "delkeyword_notfound": "لا يوجد مثل هذا المشغّل.",
    "keywords_empty": "لا توجد مشغّلات كلمات مفتاحية.",
    "keywords_header": "🔑 مشغّلات الكلمات المفتاحية:",
    "autoanswer_ask_audience": "⚙️ إعداد الرد التلقائي لـ «{title}»\n\nلمن يجب أن يرد البوت على هذه الكلمة المفتاحية؟",
    "autoanswer_ask_keyword": "✏️ الآن أرسل الكلمة أو الجملة المفتاحية (مثلاً: السعر، القوانين، الأدمن...).",
    "autoanswer_ask_response": "📎 تم حفظ الكلمة المفتاحية «{keyword}».\n\nالآن أرسل الرسالة أو الوسائط التي تريد أن يرد بها البوت (نص، صورة، فيديو، رسالة صوتية، صوت، ملف، GIF، ملصق، أو فيديو دائري).\n\nيمكنك إرسال حتى ٢٠ رداً مختلفاً ليختار البوت واحداً عشوائياً في كل مرة. عند الانتهاء، اضغط «إنهاء».",
    "autoanswer_audience_admins": "🛡 المشرفون فقط",
    "autoanswer_audience_all": "👥 جميع المستخدمين",
    "autoanswer_audience_owners": "👑 المالك فقط",
    "autoanswer_btn_cancel": "❌ إلغاء",
    "autoanswer_btn_done": "✅ إنهاء",
    "autoanswer_cancelled": "❌ تم الإلغاء؛ لم يتم حفظ أي رد تلقائي.",
    "autoanswer_cleaned": "🗑️ تم حذف {count} رد تلقائي.",
    "autoanswer_expired": "هذه المرحلة لم تعد صالحة؛ أرسل أمر «تعيين رد تلقائي» مرة أخرى داخل المجموعة.",
    "autoanswer_group_only": "هذا الأمر يُستخدم داخل المجموعة فقط.",
    "autoanswer_invalid_link": "هذا الرابط غير صالح أو منتهي الصلاحية. أرسل أمر «تعيين رد تلقائي» مرة أخرى داخل المجموعة.",
    "autoanswer_list_empty": "لا توجد ردود تلقائية مسجّلة.",
    "autoanswer_list_header": "◄ قائمة الردود التلقائية:",
    "autoanswer_list_item": "• «{keyword}» — الفئة المستهدفة: {audience} — {count} رد",
    "autoanswer_max_responses": "⛔️ لقد وصلت إلى الحد الأقصى ({max} رداً). اضغط «إنهاء» للحفظ.",
    "autoanswer_need_one_response": "لم تُضِف أي رد بعد؛ أرسل رسالة أو وسائط واحدة على الأقل.",
    "autoanswer_not_admin": "⛔️ يجب أن تكون مشرفاً أو مالك تلك المجموعة لإعداد الرد التلقائي.",
    "autoanswer_pm_button": "🔐 الدخول للخاص لإعداد الرد التلقائي",
    "autoanswer_response_added": "✅ تم حفظ الرد {count} من {max}.\nأرسل الرد التالي أو اضغط «إنهاء».",
    "autoanswer_saved": "✅ تم حفظ الرد التلقائي لـ «{title}».\nالكلمة المفتاحية: {keyword}\nالفئة المستهدفة: {audience}\nعدد الردود: {count}",
    "autoanswer_setup_intro": "◄ الرد التلقائي (Auto-Answer)\n\nلإعداد رد تلقائي جديد لـ «{title}»، اضغط على الزر أدناه وتابع الخطوات في الخاص.",
    "autoanswer_unsupported_content": "هذا النوع من المحتوى غير مدعوم. أرسل نصاً، صورة، فيديو، رسالة صوتية، صوتاً، ملفاً، GIF، ملصقاً، أو فيديو دائرياً.",
    "autoanswer_updated": "♻️ تم تحديث الرد التلقائي «{keyword}» لـ «{title}».\nالفئة المستهدفة: {audience}\nعدد الردود: {count}",
    "delanswer_done": "🗑️ تم حذف الرد التلقائي «{keyword}».",
    "delanswer_notfound": "لا يوجد رد تلقائي كهذا.",
    "delanswer_usage": "الاستخدام: /delanswer <الكلمة المفتاحية>",
    "addcmd_usage": "الاستخدام: /addcmd <الاسم> <الرد>\nأو بالرد على رسالة: /addcmd <الاسم>",
    "addcmd_reserved": "⛔ هذا الاسم محجوز لأمر مدمج.",
    "addcmd_done": "✅ تمت إضافة الأمر المخصص /{name}.",
    "addcmd_updated": "♻️ تم تحديث الأمر المخصص /{name}.",
    "delcmd_usage": "الاستخدام: /delcmd <الاسم>",
    "delcmd_done": "🗑️ تم حذف الأمر المخصص /{name}.",
    "delcmd_notfound": "لا يوجد أمر مخصص كهذا.",
    "cmds_empty": "لا توجد أوامر مخصصة معرّفة.",
    "cmds_header": "⚙️ الأوامر المخصصة:",
    "schedulerecurring_usage": "الاستخدام:\n/schedulerecurring daily HH:MM <نص>\n/schedulerecurring weekly mon HH:MM <نص>\n/schedulerecurring monthly DAY HH:MM <نص>\n(أيام الأسبوع: mon tue wed thu fri sat sun — اليوم: 1-28)",
    "schedulerecurring_invalid_time": "وقت غير صالح. استخدم الصيغة HH:MM (مثلاً 14:30).",
    "schedulerecurring_invalid_day": "يوم الشهر غير صالح. استخدم رقمًا بين 1 و28.",
    "schedulerecurring_invalid_weekday": "يوم الأسبوع غير صالح. استخدم أحد: mon tue wed thu fri sat sun",
    "schedulerecurring_empty_text": "نص الرسالة مطلوب (في السطر/الأسطر بعد الأمر).",
    "schedulerecurring_done": "✅ تمت جدولة منشور متكرر (المعرف {id}).",
    "recurringposts_header": "🔁 المنشورات المتكررة:",
    "recurringposts_empty": "لا توجد منشورات متكررة مجدولة.",
    "recurringposts_item": "#{id} — {schedule} — {preview}",
    "recurring_desc_daily": "يوميًا الساعة {time}",
    "recurring_desc_weekly": "أسبوعيًا يوم {weekday} الساعة {time}",
    "recurring_desc_monthly": "شهريًا في اليوم {day} الساعة {time}",
    "delrecurring_usage": "الاستخدام: /delrecurring <المعرف>",
    "delrecurring_done": "🗑️ تم حذف المنشور المتكرر #{id}.",
    "delrecurring_notfound": "لا يوجد منشور متكرر بهذا المعرف.",
    "addautoaction_usage": "الاستخدام: /addautoaction <الشرط> <الإجراء>\nالشروط: message＿type:<photo|video|sticker|voice|gif|video＿note|document|poll|forward|link|text>، user＿role:<user|moderator|admin>، warns＿gte:<رقم>\nالإجراءات: delete, warn, mute:<دقائق>, ban, kick",
    "addautoaction_invalid_condition": "شرط غير صالح. شغّل /addautoaction بدون معطيات لرؤية الصيغة.",
    "addautoaction_invalid_action": "إجراء غير صالح. شغّل /addautoaction بدون معطيات لرؤية الصيغة.",
    "addautoaction_done": "✅ تمت إضافة قاعدة Auto Action (المعرف {id}): {condition} → {action}",
    "delautoaction_usage": "الاستخدام: /delautoaction <المعرف>",
    "delautoaction_done": "🗑️ تم حذف قاعدة Auto Action رقم {id}.",
    "delautoaction_notfound": "لا توجد قاعدة Auto Action بهذا المعرف.",
    "autoactions_header": "🤖 قواعد Auto Action:",
    "autoactions_empty": "لا توجد قواعد Auto Action معرّفة.",
    "autoactiontoggle_usage": "الاستخدام: /autoactiontoggle on أو /autoactiontoggle off",
    "autoactiontoggle_done": "🤖 Auto Actions {state}.",
    "autoaction_reason": "قاعدة Auto Action (#{id})",
    "settings_goodbye": "👋 رسائل الوداع: {state}",
    "settings_autoaction": "🤖 Auto Actions: {state}",

    # Priority 5, Item 25 — Permission Profiles
    "createprofile_usage": "الاستخدام: /createprofile <الاسم> <صلاحية1,صلاحية2,...>\nالصلاحيات المتاحة: {caps}",
    "profile_invalid_caps": "❌ صلاحية غير معروفة: {invalid}\nالصلاحيات المتاحة: {caps}",
    "createprofile_done": "✅ تم إنشاء الملف «{name}» بالصلاحيات: {caps}",
    "createprofile_updated": "♻️ تم تحديث الملف «{name}» بالصلاحيات: {caps}",
    "delprofile_usage": "الاستخدام: /delprofile <الاسم>",
    "delprofile_notfound": "لا يوجد ملف بهذا الاسم.",
    "delprofile_done": "🗑️ تم حذف الملف «{name}».",
    "profiles_empty": "لا توجد ملفات صلاحيات مخصصة بعد.",
    "profiles_header": "🗂️ ملفات الصلاحيات:",
    "profile_item": "• «{name}» — {caps}\n   الأعضاء: {members}",
    "assignprofile_usage": "الاستخدام: /assignprofile [رد|@user|id] <اسم الملف>",
    "assignprofile_notfound_profile": "لا يوجد ملف باسم «{name}». أنشئه أولاً بـ /createprofile.",
    "assignprofile_done": "✅ تم تعيين الملف «{profile}» لـ {name}.",
    "unassignprofile_usage": "الاستخدام: /unassignprofile [رد|@user|id]",
    "unassignprofile_notfound": "لا يوجد ملف معيّن لهذا المستخدم.",
    "unassignprofile_done": "➖ تمت إزالة الملف من {name}.",
    "myperms_with_profile": "رتبتك: {rank}\nالملف المعيّن: «{profile}»\nالصلاحيات: {caps}",
    "myperms_no_profile": "رتبتك: {rank}\nلا يوجد ملف مخصص معيّن.",

    # Priority 5, Item 26 — Reports
    "report_need_reply": "الرجاء الرد على الرسالة التي تريد الإبلاغ عنها.",
    "report_self": "لا يمكنك الإبلاغ عن نفسك! 😅",
    "report_already": "لقد أبلغت عن هذه الرسالة مؤخراً.",
    "report_done": "✅ تم إرسال بلاغك إلى المشرفين. شكراً!",
    "report_alert_header": "🚩 بلاغ جديد #{id}\nالمُبلِّغ: {reporter}\nالمُبلَّغ عنه: {target}\nالسبب: {reason}",
    "alert_multi_reports_text": "تلقى {target} {count} بلاغات منفصلة خلال آخر {window} ثانية.",
    "reports_empty": "لا توجد بلاغات مفتوحة.",
    "reports_header": "🚩 البلاغات المفتوحة:",
    "report_item": "• #{id} [{when}] {reporter} ← {target} ({reason})",
    "btn_report_mute": "🔇 كتم",
    "btn_report_ban": "🚫 حظر",
    "btn_report_delete": "🗑️ حذف الرسالة",
    "btn_report_dismiss": "✖️ تجاهل",
    "report_not_found": "هذا البلاغ لم يعد موجوداً أو تمت معالجته.",
    "report_action_done_dismiss": "✖️ تم تجاهل البلاغ #{id} عن {target}.",
    "report_action_done_mute": "🔇 تم كتم {target} لمدة {minutes} دقيقة من خلال البلاغ.",
    "report_action_done_ban": "🚫 تم حظر {target} من خلال البلاغ.",
    "report_action_done_delete": "🗑️ تم حذف الرسالة المُبلَّغ عنها من {target}.",

    # Priority 5, Item 27 — Admin Alerts
    "setalertchannel_usage": "الاستخدام: /setalertchannel <chat＿id> (بدون معطيات = مسح)",
    "setalertchannel_done": "✅ تم تعيين وجهة التنبيهات إلى {channel}.",
    "setalertchannel_cleared": "✅ تم مسح وجهة التنبيهات (ستُرسل التنبيهات في هذه المجموعة/قناة السجل).",
    "alerts_empty": "لا توجد تنبيهات مسجّلة بعد.",
    "alerts_header": "🔔 التنبيهات الأخيرة:",
    "alert_type_multi_reports": "بلاغات متعددة",
    "alert_type_suspicious": "نشاط مشبوه",
    "alert_type_security": "حدث أمني",
    "alert_type_abnormal": "سلوك غير طبيعي",
    "alert_type_admin_abuse": "إساءة استخدام محتملة من مشرف",
    "admin_abuse_alert_detail": "🧑‍💼 قام {name} بتنفيذ {count} إجراء تخريبي (حظر/كتم/طرد/تحذير) خلال آخر {minutes} دقيقة — قد يكون حسابه مخترقًا أو إساءة استخدام متعمدة. يُرجى المراجعة.",
    "alert_type_raid": "تم رصد هجوم (Raid)",
    "alert_type_generic": "تنبيه",

    # Priority 5, Item 28 — Import / Export Settings
    "exportsettings_caption": "📦 تصدير إعدادات المجموعة.\n{summary}",
    "importsettings_usage": "قم بالرد على ملف .json للإعدادات مع إرسال /importsettings.",
    "importsettings_invalid_json": "❌ تعذّرت قراءة هذا الملف كـ JSON صالح.",
    "importsettings_invalid_schema": "❌ ملف إعدادات غير صالح (المشكلة: {detail}).",
    "importsettings_confirm_prompt": "⚠️ سيؤدي هذا إلى *استبدال* إعدادات المجموعة الحالية بما يلي:\n{summary}\nهل أنت متأكد؟",
    "importsettings_cancelled": "❌ تم إلغاء الاستيراد.",
    "importsettings_done": "✅ تم استيراد الإعدادات بنجاح.\n{summary}",
    "btn_import_confirm": "✅ تأكيد الاستيراد",
    "btn_import_cancel": "❌ إلغاء",

    # لوحة تحكم الأدمن الشخصية
    "panel_header": "🛠 لوحة تحكم {name}\n\nاختر قسماً:",
    "panel_btn_settings": "⚙️ الإعدادات",
    "panel_btn_locks": "🔒 الأقفال",
    "panel_btn_filters": "🚫 الفلاتر",
    "panel_btn_rules": "📜 القوانين",
    "panel_btn_reports": "🚩 البلاغات المفتوحة",
    "panel_btn_logs": "🗒 السجل",
    "panel_btn_roles": "👮 المشرفون",
    "panel_btn_daily": "🔔 الإشعارات اليومية",
    "panel_daily_hint": "لتغيير الإعدادات: /dailynotify",
    "panel_btn_back": "🔙 رجوع",
    "panel_btn_close": "❌ إغلاق",
    "panel_not_yours": "هذه اللوحة مخصصة فقط لمن فتحها.",
    "panel_closed": "تم إغلاق اللوحة.",

    "ai_panel_header": "🤖 NEXOR Copilot\nمساعد الذكاء الاصطناعي للمشرفين — اختر قسماً:",
    "ai_btn_analyze": "🔍 تحليل رسالة",
    "ai_btn_explain": "❓ شرح إجراء",
    "ai_btn_health": "📊 صحة المجموعة",
    "ai_btn_reports": "🗂 مراجعة البلاغات",
    "ai_btn_optimize": "🛠 تحسين القواعد",
    "ai_btn_incident": "🚨 تحليل حادثة",
    "ai_btn_rule": "➕ اقتراح قاعدة",
    "ai_btn_close": "❌ إغلاق",
    "ai_working": "⏳ جارٍ التحليل بالذكاء الاصطناعي...",
    "ai_guide_analyze": "🔍 تحليل رسالة\nقم بالرد على الرسالة المطلوب فحصها وأرسل:\naicheck",
    "ai_guide_explain": "❓ شرح إجراء\nمثال:\naiexplain @username لماذا تم تحذير هذا المستخدم؟\n(أو رُدّ على رسالة المستخدم وأرسل aiexplain)",
    "ai_guide_rule": "➕ اقتراح قاعدة\nصف المشكلة، مثلاً:\nairule نتلقى الكثير من الرسائل الإعلانية المزعجة",
    "ai_need_reply": "رُدّ على رسالة لتشغيل تحليل الرسالة.",
    "ai_explain_usage": "لم يتم العثور على المستخدم المستهدف. رُدّ على رسالته أو أرسل:\naiexplain @username [السؤال]",
    "ai_explain_default_question": "لماذا تم اتخاذ إجراء إشرافي مؤخراً بحق {name}؟",
    "ai_rule_usage": "صف المشكلة، مثلاً:\nairule نتلقى الكثير من الرسائل الإعلانية المزعجة",
    "ai_reports_empty_for_ai": "لا توجد بلاغات مفتوحة لتحليلها.",
    "ai_optimize_empty": "لا توجد قواعد إجراء تلقائي لمراجعتها.",
    "ai_incident_empty": "لم يتم العثور على نشاط حديث ملحوظ لتحليله.",
    "ai_rule_not_applicable": "⚠️ هذا الأمر لا يمكن لمحرك القواعد الحالي في NEXOR تغطيته؛ جرّب وصفاً أكثر تحديداً، أو أضف قاعدة يدوياً عبر addautoaction.",
    "ai_rule_cancelled": "تم الإلغاء؛ لم يتم إنشاء أي قاعدة.",
    "ai_rule_created": "✅ تم إنشاء القاعدة #{id}.\nالمحفّز: {condition}\nالإجراء: {action}",
    "ai_dismissed": "تم التجاهل؛ لم يُتخذ أي إجراء على المجموعة.",
    "ai_reason_copilot": "اقتراح NEXOR Copilot (بموافقة المشرف)",
    "ai_action_done_delwarn": "🗑️ تم حذف الرسالة وتحذير {name}.",
    "ai_plan_status": "خطة الذكاء الاصطناعي الحالية لهذه المجموعة: {plan}",
    "ai_plan_set_done": "✅ تم ضبط خطة الذكاء الاصطناعي لهذه المجموعة على \"{plan}\".",
    "ai_plan_set_invalid": "خطة غير صالحة. استخدم واحدة من: free, pro, premium",
    "ai_err_plan_not_allowed": "⛔️ هذه الميزة غير متاحة ضمن خطة هذه المجموعة الحالية.",
    "ai_err_rate_limited": "⏳ لقد استنفدت حد الطلبات اليومي للذكاء الاصطناعي؛ حاول مجدداً غداً.",
    "ai_err_not_configured": "⚙️ لم يتم تفعيل الذكاء الاصطناعي لخطة هذه المجموعة بعد (أبلغ مسؤول البوت).",
    "ai_err_provider_error": "⚠️ تعذّر الوصول إلى خدمة الذكاء الاصطناعي؛ حاول مرة أخرى بعد قليل.",
    "ai_err_bad_response": "⚠️ رد الذكاء الاصطناعي لم يكن مفهوماً؛ حاول مرة أخرى.",
    "ai_err_unknown": "⚠️ خطأ غير متوقع في NEXOR Copilot؛ تم تسجيله.",
    "ai_err_action_failed": "⚠️ فشل تنفيذ الإجراء.",
    "ai_risk_low": "منخفض",
    "ai_risk_medium": "متوسط",
    "ai_risk_high": "مرتفع",
    "ai_priority_high": "أولوية عالية",
    "ai_priority_suspicious": "مشبوه",
    "ai_priority_low": "أولوية منخفضة",
    "ai_priority_false": "بلاغ كاذب على الأرجح",
    "ai_action_none": "لا إجراء",
    "ai_action_delete": "حذف الرسالة",
    "ai_action_warn": "تحذير",
    "ai_action_delete_warn": "حذف + تحذير",
    "ai_action_mute": "كتم",
    "ai_action_ban": "حظر",
    "ai_trend_up": "في ارتفاع 📈",
    "ai_trend_down": "في انخفاض 📉",
    "ai_trend_stable": "مستقر ➖",
    "ai_btn_apply_delwarn": "🗑️+⚠️ حذف وتحذير",
    "ai_btn_apply_mute": "🔇 كتم",
    "ai_btn_apply_ban": "🚫 حظر",
    "ai_btn_dismiss": "تجاهل",
    "ai_btn_confirm": "✅ تأكيد وإنشاء",
    "ai_btn_cancel": "❌ إلغاء",
    "ai_analyze_message_result": "🤖 تحليل NEXOR Copilot\n\nالخطورة: {risk}\nسبام: {spam}%\nإعلانات: {ad}%\nمشبوه: {suspicious}%\nمسيء: {toxic}%\n\nالملخص: {summary}\n\n💡 التوصية: {action}\nالسبب: {reason}\n\nالقرار النهائي لك:",
    "ai_explain_result": "🤖 شرح NEXOR Copilot\n\n{explanation}\n\nالعوامل الرئيسية:\n{factors}",
    "ai_reports_header": "🗂 البلاغات المفتوحة، مصنّفة:",
    "ai_reports_item": "• #{id} — {priority}: {reason}",
    "ai_reports_summary": "\nالملخص: {summary}",
    "ai_health_result": "📊 صحة المجموعة\n\nمستوى السبام: {spam_level}\nاتجاه المخالفات: {trend}\n\nالمخاطر:\n{risks}\n\n💡 التوصية: {recommendation}",
    "ai_rule_advisor_result": "➕ اقتراح مستشار القواعد\n\nالمحفّز: {trigger}\nالإجراء: {action}\nالنطاق: {scope}\nالسبب: {reason}\nمستوى الثقة: {confidence}%\n\nأكّد لإنشاء هذه القاعدة:",
    "ai_optimize_result": "🛠 نتيجة تحسين القواعد\n\nمكرر: {duplicates}\nمتعارض: {conflicts}\nيعمل بكثرة: {too_frequent}\nإعدادات خطرة: {dangerous}\n\nالاقتراحات:\n{suggestions}",
    "ai_incident_result": "🚨 ملخص الحادثة\n\n{summary}\n\nالخطورة: {severity}\n\nالجدول الزمني:\n{timeline}\n\n💡 التوصية: {recommendation}",
    "ai_local_summary_safe": "رسالة قصيرة بلا مؤشرات خطر؛ تم تصنيفها محلياً بخطورة منخفضة.",
    "ai_local_reason_no_ai_needed": "لم تكن هناك حاجة لمراجعة الذكاء الاصطناعي.",

    # ==================== Guide Panel ====================
    "guide_intro": "📖 دليل NEXOR\nاضغط على أي قسم لترى وظيفته — ثم اضغط على أي كلمة تحته لترى الكلمة التي تكتبها فعلاً في الدردشة بدلاً من أمر.",
    "guide_btn_locks": "🔒 الأقفال والفلاتر",
    "guide_btn_moderation": "🛡 الإدارة والعقوبات",
    "guide_btn_roles": "👮 ترقية / تنزيل الأعضاء",
    "guide_btn_settings": "⚙️ إعدادات المجموعة",
    "guide_btn_security": "🚨 مكافحة الغارات والإغلاق",
    "guide_btn_rules": "📜 قوانين المجموعة",
    "guide_btn_autoreply": "💬 الكلمات المفتاحية والأوامر المخصصة",
    "guide_btn_channel": "📢 القناة والمنشورات",
    "guide_btn_autoactions": "🤖 الإجراءات التلقائية",
    "guide_btn_notes": "📝 الملاحظات",
    "guide_btn_reports_logs": "🚩 التقارير والسجل",
    "guide_btn_federation": "🌐 الاتحاد",
    "guide_btn_ai_copilot": "🧠 مساعد NEXOR الذكي",
    "guide_title_locks": "🔒 الأقفال والفلاتر",
    "guide_title_moderation": "🛡 الإدارة والعقوبات",
    "guide_title_roles": "👮 ترقية / تنزيل الأعضاء",
    "guide_title_settings": "⚙️ إعدادات المجموعة",
    "guide_title_security": "🚨 مكافحة الغارات والإغلاق",
    "guide_title_rules": "📜 قوانين المجموعة",
    "guide_title_autoreply": "💬 الكلمات المفتاحية والأوامر المخصصة",
    "guide_title_channel": "📢 القناة والمنشورات",
    "guide_title_autoactions": "🤖 الإجراءات التلقائية",
    "guide_title_notes": "📝 الملاحظات",
    "guide_title_reports_logs": "🚩 التقارير والسجل",
    "guide_title_federation": "🌐 الاتحاد",
    "guide_title_ai_copilot": "🧠 مساعد NEXOR الذكي",
    "guide_desc_locks": "أقفل أي محتوى خطير — روابط، صور، ملصقات، توجيه وغيرها — ليُحذف فور إرساله. أضف فلاتر كلمات أو نطاقات لأي شيء آخر تريد إزالته تلقائياً.",
    "guide_desc_moderation": "أنذر المخالفين أو اكتمهم أو اطردهم أو احظرهم، احذف رسالة واحدة أو نظّف نطاقاً كاملاً دفعة واحدة — كل أدوات ضبط الدردشة.",
    "guide_desc_roles": "رقّ الأعضاء الموثوقين إلى مشرفين داخليين، نزّلهم لاحقاً، وشاهد من يملك أي دور أو صلاحية بنظرة واحدة.",
    "guide_desc_settings": "شاشة واحدة تجمع كل شيء عن هذه المجموعة — الأقفال، الفلاتر، الكابتشا، الإنذارات، اللغة — بالإضافة إلى وصول سريع للوحة الإدارة.",
    "guide_desc_security": "الكشف التلقائي عن الغارات يرصد تدفق الانضمام المفاجئ؛ والإغلاق الكامل يقفل المجموعة كلها بضغطة واحدة عند تفاقم الأمور.",
    "guide_desc_rules": "اكتب قوانين مجموعتك مرة واحدة، اعرضها لمن يسأل، أو امسحها تماماً وابدأ من جديد.",
    "guide_desc_autoreply": "علّم البوت الرد تلقائياً على كلمات معينة، أو ابنِ أوامر نصية مخصصة جديدة كلياً.",
    "guide_desc_channel": "اربط قناة بمجموعتك، انشر أو جدول منشورات، عدّلها أو احذفها لاحقاً، وتابع إحصائيات القناة.",
    "guide_desc_autoactions": "قواعد بسيطة من نوع «إذا حدث كذا فافعل كذا» — يتفاعل البوت تلقائياً حسب نوع الرسالة أو عدد الإنذارات.",
    "guide_desc_notes": "احفظ نصاً أو ملفاً مرة واحدة، ثم استرجعه فوراً بوسم قصير كلما احتجته.",
    "guide_desc_reports_logs": "يبلّغ الأعضاء عن المشاكل بضغطة واحدة؛ وأنت تحصل على سجل كامل لكل إجراء اتخذه أي مشرف.",
    "guide_desc_federation": "قائمة حظر واحدة مشتركة بين عدة مجموعات — احظر شخصاً مرة، ويُحظر في كل الاتحاد.",
    "guide_desc_ai_copilot": "مساعد ذكاء اصطناعي مخصص للمشرفين: يحلل الرسائل، يشرح الإجراءات السابقة، ويقترح قواعد جديدة.",
    "guide_kw_lock": "أقفل نوع محتوى (مثل الروابط أو الصور) ليُحذف تلقائياً.",
    "guide_kw_unlock": "أزل قفلاً نشطاً.",
    "guide_kw_locks": "اعرض كل الأقفال النشطة في هذه المجموعة.",
    "guide_kw_filter": "أضف كلمة أو عبارة محظورة تُحذف تلقائياً.",
    "guide_kw_stopfilter": "أزل فلتر كلمة.",
    "guide_kw_filters": "اعرض كل فلاتر الكلمات النشطة.",
    "guide_kw_domains": "اعرض أو أدر قائمة النطاقات المحظورة.",
    "guide_kw_forwardrules": "اعرض قواعد السماح/الحظر للرسائل المُعاد توجيهها.",
    "guide_kw_warn": "أعطِ عضواً إنذاراً.",
    "guide_kw_unwarn": "أزل إنذاراً واحداً من عضو.",
    "guide_kw_warns": "اعرض عدد إنذارات عضو.",
    "guide_kw_mute": "أسكت عضواً لمدة محددة.",
    "guide_kw_unmute": "ارفع الكتم عن عضو.",
    "guide_kw_ban": "احظر عضواً نهائياً من المجموعة.",
    "guide_kw_unban": "اسمح لعضو محظور بالعودة.",
    "guide_kw_kick": "اطرد عضواً (يمكنه الانضمام مجدداً).",
    "guide_kw_del": "احذف رسالة — رد عليها أولاً.",
    "guide_kw_purge": "احذف نطاقاً كاملاً من الرسائل دفعة واحدة.",
    "guide_kw_promote": "رقّ عضواً إلى مشرف داخلي.",
    "guide_kw_demote": "أزل دور المشرف الداخلي عن عضو.",
    "guide_kw_roles": "اعرض كل من لديه دور مشرف داخلي.",
    "guide_kw_profiles": "أدر ملفات الصلاحيات المخصصة.",
    "guide_kw_myperms": "اعرض صلاحياتك الحالية.",
    "guide_kw_settings": "نظرة عامة على كل إعدادات هذه المجموعة.",
    "guide_kw_setlang": "غيّر لغة المجموعة.",
    "guide_kw_captcha": "فعّل أو عطّل كابتشا العضو الجديد.",
    "guide_kw_goodbye": "فعّل أو عطّل رسالة الوداع.",
    "guide_kw_adminpanel": "افتح لوحة اختصارات الإدارة السريعة.",
    "guide_kw_antiraid": "فعّل أو عطّل الكشف التلقائي عن الغارات.",
    "guide_kw_lockdown": "أقفل المجموعة بالكامل فوراً.",
    "guide_kw_unlockchat": "ارفع الإغلاق الكامل.",
    "guide_kw_rules": "اعرض قوانين المجموعة.",
    "guide_kw_setrules": "اكتب أو حدّث قوانين المجموعة.",
    "guide_kw_clearrules": "احذف قوانين المجموعة.",
    "guide_kw_addkeyword": "أضف كلمة تُفعّل رداً تلقائياً.",
    "guide_kw_delkeyword": "أزل كلمة مفتاحية للرد التلقائي.",
    "guide_kw_keywords": "اعرض كل كلمات الرد التلقائي.",
    "guide_kw_addcmd": "أنشئ أمراً نصياً مخصصاً خاصاً بك.",
    "guide_kw_delcmd": "احذف أمراً مخصصاً.",
    "guide_kw_cmds": "اعرض كل الأوامر المخصصة.",
    "guide_kw_setanswer": "إعداد رد تلقائي (نص/وسائط، حتى ٢٠ رداً عشوائياً) لكلمة مفتاحية.",
    "guide_kw_answerlist": "اعرض قائمة الردود التلقائية المُعدّة.",
    "guide_kw_delanswer": "احذف رداً تلقائياً بكلمته المفتاحية.",
    "guide_kw_cleananswerlist": "امسح كل الردود التلقائية في هذه المجموعة.",
    "guide_kw_setchannel": "اربط قناة بهذه المجموعة.",
    "guide_kw_post": "انشر منشوراً في القناة المرتبطة.",
    "guide_kw_schedulepost": "جدول منشوراً لوقت لاحق.",
    "guide_kw_editpost": "عدّل منشوراً تم نشره بالفعل.",
    "guide_kw_delpost": "احذف منشوراً منشوراً.",
    "guide_kw_channelstats": "اعرض إحصائيات القناة المرتبطة.",
    "guide_kw_addautoaction": "أنشئ قاعدة تلقائية «إذا... فافعل».",
    "guide_kw_delautoaction": "أزل قاعدة تلقائية.",
    "guide_kw_autoactions": "اعرض كل القواعد التلقائية.",
    "guide_kw_save": "احفظ ملاحظة أو مقتطفاً قابلاً لإعادة الاستخدام.",
    "guide_kw_get": "استرجع ملاحظة محفوظة باسمها.",
    "guide_kw_notes": "اعرض كل الملاحظات المحفوظة.",
    "guide_kw_clear": "احذف ملاحظة محفوظة.",
    "guide_kw_report": "بلّغ الإدارة عن رسالة.",
    "guide_kw_reports": "اعرض التقارير المفتوحة غير المحلولة.",
    "guide_kw_alerts": "أدر وجهة إرسال تنبيهات الإدارة.",
    "guide_kw_adminabuseprotection": "ينبهك إذا نفّذ أحد المشرفين فجأة عددًا كبيرًا من الإجراءات التخريبية.",
    "guide_kw_logs": "اعرض أحدث إجراءات الإدارة.",
    "guide_kw_exportsettings": "صدّر إعدادات هذه المجموعة كنسخة احتياطية.",
    "guide_kw_setlogchannel": "حدد القناة التي تستقبل سجل التدقيق.",
    "guide_kw_fnew": "أنشئ اتحاداً جديداً (قائمة حظر مشتركة).",
    "guide_kw_fjoin": "أضف هذه المجموعة إلى اتحاد موجود.",
    "guide_kw_fleave": "غادر الاتحاد الحالي.",
    "guide_kw_finfo": "اعرض معلومات عن الاتحاد الحالي.",
    "guide_kw_fban": "احظر مستخدماً عبر الاتحاد بالكامل.",
    "guide_kw_funban": "ألغِ حظر مستخدم عبر الاتحاد بالكامل.",
    "guide_kw_copilot": "افتح قائمة مساعد NEXOR الذكي.",
    "guide_kw_aicheck": "اطلب من الذكاء الاصطناعي تحليل رسالة — رد عليها أولاً.",
    "guide_kw_aiexplain": "اسأل الذكاء الاصطناعي لماذا اتُخذ إجراء بحق أحدهم.",
    "guide_kw_aireports": "دع الذكاء الاصطناعي يرتب التقارير المفتوحة حسب الأولوية.",
    "guide_kw_aihealth": "احصل على ملخص ذكاء اصطناعي لصحة المجموعة.",
    "guide_kw_airule": "صف مشكلة، واحصل على قاعدة مقترحة من الذكاء الاصطناعي.",
    "guide_kw_aioptimize": "اطلب من الذكاء الاصطناعي مراجعة قواعدك التلقائية.",
    "guide_kw_aiincident": "احصل على ملخص ذكاء اصطناعي لحادثة أخيرة.",
    "guide_kw_aiplan": "اعرض أو حدد خطة الذكاء الاصطناعي لهذه المجموعة.",

    # --- طبقة اللغة الطبيعية (المبنية على النية) — nlu/ ---
    "nlu_confirm_mute": "هل تريد كتم {name} لمدة {duration}؟",
    "nlu_btn_confirm": "✅ تأكيد",
    "nlu_btn_cancel": "❌ إلغاء",
    "nlu_ask_duration": "لكم من الوقت تريد كتم {name}؟ (مثلاً: 30m، 2h، 1d)",
    "nlu_context_expired": "⌛️ انتهت صلاحية هذا الطلب. حاول مرة أخرى.",
    "nlu_not_your_confirmation": "هذا الزر ليس لطلبك.",
    "nlu_need_reply_target": "❗️قم بالرد على رسالة ذلك المستخدم لأعرف من تقصد.",
    "nlu_fallback_intro": "🤔 لم أفهم ذلك تمامًا. جرّب /help أو وضّح طلبك أكثر.",
    "nlu_confirm_unmute": "هل تريد إلغاء كتم {name}؟",
    "nlu_confirm_ban": "هل تريد حظر {name} لمدة {duration}؟",
    "nlu_confirm_unban": "هل تريد إلغاء حظر {name}؟",
    "nlu_confirm_kick": "هل تريد طرد {name} من المجموعة؟",
    "nlu_action_cancelled": "❌ تم الإلغاء؛ لم يتم فعل أي شيء.",
    "nlu_confirm_delete": "هل تريد حذف هذه الرسالة؟",
    "nlu_delete_done": "🗑 تم حذف الرسالة.",
    "nlu_confirm_setrules": "هل تريد استبدال قوانين المجموعة بهذا النص؟\n\n{text}",
    "nlu_setrules_format_hint": "لتعيين القوانين بهذه الطريقة، استخدم هذا التنسيق:\n«تعيين القوانين: نص القانون» (كل ما بعد «:» يُحفظ كما هو بالضبط).",

    # --- Onboarding (handlers/onboarding.py + onboarding_logic.py) ---
    "onboarding_welcome": "👋 مرحبًا! أنا NEXOR — أساعد في إبقاء هذه المجموعة آمنة ومنظمة: الإشراف، مكافحة السبام، الترحيب/القوانين، الردود التلقائية والمزيد.",
    "onboarding_needs_admin": "⚠️ لستُ مشرفًا هنا بعد، لذا معظم الميزات لن تعمل. اجعلني مشرفًا (على الأقل: حذف الرسائل، تقييد الأعضاء، دعوة المستخدمين، تثبيت الرسائل) وسأبدأ من هناك.",
    "onboarding_missing_perms": "⚠️ أنا مشرف، لكن تنقصني: {perms}. بعض الميزات تحتاج إليها — يمكنك منحها في أي وقت من إعدادات المجموعة.",
    "onboarding_all_set": "✅ لدي كل الصلاحيات اللازمة. لنبدأ بالإعدادات الأساسية.",
    "onboarding_btn_security": "🛡 إعداد الأمان",
    "onboarding_btn_help": "❓ ماذا يمكنك أن تفعل؟",
    "perm_restrict": "تقييد الأعضاء (كتم/طرد/حظر)",
    "perm_delete": "حذف الرسائل",
    "perm_invite": "دعوة المستخدمين",
    "perm_pin": "تثبيت الرسائل",
    "err_unexpected": "⚠️ حدث خطأ أثناء تنفيذ ذلك. حاول مرة أخرى — إذا تكرر الأمر، أخبر أحد مشرفي المجموعة.",
    "nlu_delanswer_format_hint": "لحذف رد تلقائي بهذه الطريقة، استخدم هذا التنسيق:\n«حذف رد تلقائي: الكلمة المفتاحية» (الكلمة المفتاحية المطلوب حذفها بالضبط).",
    "nlu_confirm_delanswer": "هل تريد حذف الرد التلقائي للكلمة المفتاحية «{keyword}»؟",
    # ---- Ads system (added) ----
    'ads_btn_cancel': '❌ إلغاء',
    'ads_btn_free': '🆓 نشر إعلان مجاني (مرة واحدة يوميًا)',
    'ads_btn_paid': '💳 شراء إعلانات (١ إلى ٥ مرات يوميًا)',
    'ads_intro': '📢 نظام إعلانات NEXOR\n\nتظهر الإعلانات فقط في المجموعات ذات الخطة المجانية (مجموعات Pro/Premium لا تشاهد إعلانات).\nالإعلان المجاني يُعرض مرة واحدة يوميًا فقط؛ أما الإعلان المدفوع فيمكن عرضه من ١ إلى ٥ مرات يوميًا (يزداد السعر بنفس النسبة).\n\nأي واحد تريد؟',
    'ads_ask_banner': '🖼 أرسل أولًا صورة (بانر) للإعلان.\nإذا لا تريد صورة، اكتب: تخطي',
    'ads_banner_invalid': 'أرسل صورة، أو اكتب «تخطي» للمتابعة بدون بانر.',
    'ads_ask_text': '✍️ الآن أرسل نص الإعلان (ما سيظهر داخل المجموعات).',
    'ads_text_empty': 'نص الإعلان لا يمكن أن يكون فارغًا. أرسله مرة أخرى.',
    'ads_times_btn': '{n}×/يوم',
    'ads_ask_times': '📅 كم مرة تريد عرض إعلانك يوميًا؟ (كلما زاد العدد، زاد السعر)',
    'ads_free_submitted': '✅ تم إرسال الإعلان المجاني #{id} لمراجعة المشرف.\nبعد الموافقة، سيُعرض مرة واحدة يوميًا في المجموعات المجانية المرتبطة بالبوت.',
    'ads_duration_btn': '{days} يوم — ⭐{stars}',
    'ads_ask_duration': 'اختر مدة عرض الإعلان (عدد مرات العرض المختارة: {times}×/يوم):',
    'ads_btn_pay_stars': '⭐ الدفع بـ Stars ({stars})',
    'ads_btn_pay_ton': '💎 الدفع بـ TON ({ton})',
    'ads_order_summary': 'ملخص الطلب #{id}:\n• عدد مرات العرض: {times}×/يوم\n• المدة: {days} يوم\n• السعر: ⭐{stars}',
    'ads_order_summary_ton_suffix': ' / 💎{ton} TON',
    'ads_order_summary_footer': '\n\nاختر طريقة الدفع:',
    'ads_order_invalid': '⚠️ هذا الطلب لم يعد صالحًا.',
    'ads_sending_invoice': '⭐ جارٍ إرسال فاتورة الدفع عبر Telegram Stars...',
    'ads_invoice_title': '📢 شراء إعلان — الطلب #{id}',
    'ads_invoice_desc': 'شراء عرض إعلان داخل المجموعات المرتبطة بـ NEXOR (الخطة المجانية فقط).',
    'ads_invoice_label': 'إعلانات NEXOR',
    'ads_ton_disabled': '⚠️ الدفع عبر TON غير مفعّل حاليًا، أو هذا الطلب غير صالح.',
    'ads_ton_payment_info': '💎 الدفع بـ TON — الطلب #{id}\n\nالمبلغ: {amount} TON\nعنوان المحفظة: {address}\n⚠️ تأكد من إدخال هذا الكود بالضبط في خانة Comment/Memo عند التحويل:\n{memo}\n\nرابط مباشر: {link}\n\nبعد التحويل، سيتم فحص العملية تلقائيًا وسيدخل الإعلان في قائمة انتظار مراجعة المشرف.',
    'ads_cancelled': 'تم الإلغاء.',
    'ads_ton_confirmed': '✅ تم تأكيد الدفع عبر TON! تم إرسال طلب الإعلان #{id} لمراجعة المشرف.',
    'ads_admin_none_pending': 'لا توجد إعلانات في قائمة الانتظار.',
    'ads_btn_approve': '✅ موافقة',
    'ads_btn_reject': '❌ رفض',
    'ads_kind_free': '🆓 مجاني',
    'ads_kind_paid': '💳 مدفوع',
    'ads_admin_caption': '#{id} — {kind}\nعدد المرات/اليوم: {times} — المدة: {days} يوم\n\n{text}',
    'ads_approved_toast': 'تمت الموافقة ✅',
    'ads_approved_notify': '✅ تمت الموافقة على الإعلان #{id} وسيُعرض في المجموعات المجانية حسب الجدول.',
    'ads_rejected_toast': 'تم الرفض ❌',
    'ads_none_yet': 'لم تنشر أي إعلان بعد. ابدأ بـ /ads.',
    'ads_status_draft': 'مسودة',
    'ads_status_pending_payment': 'بانتظار الدفع',
    'ads_status_pending_review': 'قيد المراجعة',
    'ads_status_active': 'نشط',
    'ads_status_rejected': 'مرفوض',
    'ads_status_expired': 'منتهٍ',
    'ads_status_active2': '✅ نشط',
    'ads_status_rejected2': '❌ مرفوض',
    'ads_status_expired2': '⌛ منتهٍ',
    'ads_myads_header': '📋 إعلاناتك:\n',
    'ads_myads_line': '#{id} — {status} — {times}×/يوم — {days} يوم',
    'ads_myads_footer': '\nلمشاهدة إحصائيات أي إعلان: /adstats <رقم الإعلان> — مثلاً /adstats {id}',
    'ads_stats_usage': 'أضف رقم الإعلان أيضًا، مثلًا:\n/adstats 3\n\nيمكنك رؤية أرقام إعلاناتك عبر /myads.',
    'ads_stats_not_found': 'لم يتم العثور على هذا الإعلان أو أنه ليس ملكك.',
    'ads_stats_title': '📊 إحصائيات الإعلان #{id}',
    'ads_stats_status': 'الحالة: {status}',
    'ads_stats_quota': 'الحصة اليومية: {quota}×/يوم',
    'ads_stats_today': 'المرسل اليوم: {today} من {quota}',
    'ads_stats_total': 'إجمالي المشاهدات (منذ البداية): {total}',
    'ads_stats_unique': 'عدد المجموعات الفريدة التي ظهر فيها هذا الإعلان: {n}',
    'ads_stats_perday_header': '\nتفاصيل يومية (آخر الأيام):',
    'ads_stats_perday_line': '  {day}: {count} مرة',
    'ads_stats_no_views': '\nلم يتم تسجيل أي مشاهدة لهذا الإعلان بعد (أو لم تتم الموافقة عليه/تفعيله بعد).',
    'ads_stars_confirmed': '✅ تم تأكيد الدفع! تم إرسال طلب الإعلان #{id} لمراجعة المشرف.',
    'err_invalid_language': 'لغة غير صالحة.',
    # ---- Buyplan payments (added) ----
    'buyplan_invoice_title': '👑 اشتراك {plan} ({months} شهر)',
    'buyplan_invoice_desc': 'ترقية المجموعة إلى خطة {plan} لمدة {months} شهر.',
    'buyplan_invoice_price_label': '{plan} — {months} شهر',
    'err_order_invalid': 'هذا الطلب لم يعد صالحًا.',
    'buyplan_stars_confirmed': '✅ تم تأكيد الدفع!\n👑 تمت ترقية المجموعة إلى خطة {plan}.',
    'buyplan_card_order_not_found': '⚠️ لم يتم العثور على الطلب أو أنه تمت معالجته مسبقًا.',
    'buyplan_card_confirmed_dm': '✅ تم تأكيد الدفع بالبطاقة!\n👑 تمت ترقية المجموعة إلى خطة {plan}.',
    'buyplan_card_admin_confirmed': '✅ تم تأكيد الطلب #{id} وتفعيل خطة {plan}.',
    'buyplan_card_admin_rejected': '❌ تم رفض الطلب #{id}.',
    'buyplan_card_none_pending': 'لا توجد طلبات بطاقة بانتظار المراجعة.',
    'buyplan_card_pending_header': '💳 طلبات البطاقة بانتظار التأكيد:\n',
    'buyplan_card_pending_line': '#{id} — {plan} × {months} شهر — الكود: {code}',
    'buyplan_ton_instructions': '💎 شراء اشتراك {plan} عبر TON\n\nالمبلغ: {amount} TON\nعنوان المحفظة: {address}\n⚠️ تأكد من إدخال هذا الكود بالضبط في خانة Comment/Memo عند التحويل:\n{memo}\n\nأو استخدم هذا الرابط في محفظتك:\n{link}\n\nبعد الاستلام، يتم فحص العملية تلقائيًا ويُفعّل الاشتراك (قد يستغرق ذلك بضع دقائق).',
    'buyplan_ton_confirmed': '✅ تم تأكيد الدفع عبر TON!\n👑 تمت ترقية المجموعة إلى خطة {plan}.',
    'buyplan_card_header': '💳 شراء اشتراك {plan} عبر التحويل البنكي\n',
    'buyplan_card_amount': 'المبلغ: {amount} تومان',
    'buyplan_card_number': 'رقم البطاقة: {number}',
    'buyplan_card_holder': 'باسم: {holder}',
    'buyplan_card_reference': '\nكود متابعة الطلب: {ref}',
    'buyplan_card_instructions': 'بعد التحويل، أرسل صورة الإيصال مع كود المتابعة أعلاه إلى مشرف البوت ليتم تأكيد اشتراكك وتفعيله يدويًا.',
    'buyplan_header': '👑 ترقية خطة NEXOR Copilot\nاختر الخطة المطلوبة:',
    'buyplan_choose_method': 'خطة {plan} — اختر طريقة الدفع:',
    'buyplan_closed': 'تم الإغلاق.',
    'buyplan_dm_failed': '⚠️ لم أتمكن من إرسال رسالة خاصة إليك. ابدأ محادثة خاصة مع البوت عبر /start أولًا، ثم جرّب /buyplan مرة أخرى.',
    'buyplan_stars_sent': '⭐ تم إرسال فاتورة الدفع عبر Stars إلى محادثتك الخاصة مع البوت. أكمل الدفع هناك.',
    'buyplan_ton_sent': '💎 تم إرسال تعليمات الدفع عبر TON (عنوان المحفظة + كود Memo) إلى محادثتك الخاصة مع البوت.',
    'buyplan_ton_unavailable': '⚠️ الدفع عبر TON غير متاح حاليًا لهذه الخطة.',
    # ---- Command menu descriptions (added) ----
    'cmd_desc_start': 'بدء استخدام البوت',
    'cmd_desc_help': 'دليل الأوامر',
    'cmd_desc_settings': 'إعدادات المجموعة',
    'cmd_desc_setlang': 'تغيير لغة المجموعة (مشرف)',
    'cmd_desc_rules': 'قوانين المجموعة',
    'cmd_desc_warn': 'تحذير عضو',
    'cmd_desc_unwarn': 'إزالة تحذير واحد',
    'cmd_desc_warns': 'عرض تحذيرات عضو',
    'cmd_desc_mute': 'كتم عضو',
    'cmd_desc_unmute': 'إلغاء الكتم',
    'cmd_desc_ban': 'حظر عضو',
    'cmd_desc_unban': 'إلغاء الحظر',
    'cmd_desc_kick': 'طرد عضو',
    'cmd_desc_del': 'حذف رسالة (بالرد)',
    'cmd_desc_purge': 'حذف جماعي للرسائل',
    'cmd_desc_lock': 'قفل نوع محتوى',
    'cmd_desc_unlock': 'فتح قفل',
    'cmd_desc_locks': 'عرض الأقفال المفعّلة',
    'cmd_desc_promote': 'ترقية إلى مشرف داخلي',
    'cmd_desc_demote': 'إزالة من مشرف داخلي',
    'cmd_desc_roles': 'قائمة المشرفين الداخليين',
    'cmd_desc_logs': 'آخر إجراءات الإدارة',
    'cmd_desc_copilot': '🤖 NEXOR Copilot (مساعد الذكاء الاصطناعي للمشرفين)',
    'cmd_desc_buyplan': '👑 ترقية الخطة (Stars / TON) — بدون إعلانات',
    'cmd_desc_ads': '📢 نشر إعلان مجاني أو شراء إعلانات',
    'cmd_desc_myads': '📋 إعلاناتي',
    'cmd_desc_adstats': '📊 إحصائيات إعلان',
    'cmd_desc_adadmin': '🛠 قائمة مراجعة الإعلانات (مشرف)',

    # ==================== الإشعارات اليومية (Daily Notify) ====================
    "day_mon": "الاثنين", "day_tue": "الثلاثاء", "day_wed": "الأربعاء", "day_thu": "الخميس",
    "day_fri": "الجمعة", "day_sat": "السبت", "day_sun": "الأحد",
    "month_g_1": "يناير", "month_g_2": "فبراير", "month_g_3": "مارس", "month_g_4": "أبريل",
    "month_g_5": "مايو", "month_g_6": "يونيو", "month_g_7": "يوليو", "month_g_8": "أغسطس",
    "month_g_9": "سبتمبر", "month_g_10": "أكتوبر", "month_g_11": "نوفمبر", "month_g_12": "ديسمبر",
    "month_j_1": "Farvardin", "month_j_2": "Ordibehesht", "month_j_3": "Khordad", "month_j_4": "Tir",
    "month_j_5": "Mordad", "month_j_6": "Shahrivar", "month_j_7": "Mehr", "month_j_8": "Aban",
    "month_j_9": "Azar", "month_j_10": "Dey", "month_j_11": "Bahman", "month_j_12": "Esfand",
    "date_format_gregorian": "{weekday}، {day} {month} {year}",
    "date_format_jalali": "{weekday}، {day} {month} {year}",

    "daily_date_line": "📅 اليوم: {date}",
    "daily_occasion_line": "🎉 المناسبة: {occasion}",

    "daily_price_header": "💰 أسعار اليوم",
    "daily_price_line": "• {asset}: {value} {unit}",
    "daily_price_footer": "المصدر: {sources}",

    "daily_news_header": "📰 أخبار اليوم",
    "daily_news_item": "{n}. {title}",
    "daily_news_summary": "   {summary}",
    "daily_news_source": "   🔗 المصدر: {source}",

    "asset_gold18": "ذهب عيار ١٨", "asset_usd": "دولار أمريكي (USD)", "asset_eur": "يورو (EUR)",
    "asset_usdt": "تيثر (USDT)", "asset_ton": "تون كوين (TON)", "asset_stars": "نجوم تيليجرام (Stars)",
    "asset_btc": "بيتكوين (BTC)", "asset_eth": "إيثريوم (ETH)",
    "unit_toman": "تومان", "unit_usd": "دولار",

    "panel_not_owner": "هذه اللوحة تعمل فقط مع من فتحها.",

    "dn_menu_header": "🔔 *الإشعارات اليومية*",
    "dn_menu_prices": "💰 الأسعار: {state} — الساعة {time}",
    "dn_menu_assets_line": "   الأصول المفعّلة: {assets}",
    "dn_menu_news": "📰 الأخبار: {state} — الساعة {time}",
    "dn_menu_timezone": "🌍 المنطقة الزمنية: {tz}",
    "dn_menu_date_flags": "📅 التاريخ/المناسبة — الأسعار: {dp}/{op}   الأخبار: {dn}/{on}",

    "dn_btn_toggle_prices": "💰 تفعيل/تعطيل الأسعار",
    "dn_btn_toggle_news": "📰 تفعيل/تعطيل الأخبار",
    "dn_btn_assets": "🪙 اختيار الأصول",
    "dn_btn_flags": "📅 إعدادات التاريخ/المناسبة",
    "dn_btn_test_price": "🧪 اختبار الأسعار",
    "dn_btn_test_news": "🧪 اختبار الأخبار",
    "dn_btn_help": "❓ مساعدة",
    "dn_btn_close": "❌ إغلاق",

    "dn_assets_header": "🪙 اضغط على أصل لتفعيله/تعطيله:",
    "dn_flags_header": "📅 اضبط عرض التاريخ/المناسبة بشكل مستقل للأسعار والأخبار:",
    "dn_flag_date_price": "التاريخ في رسالة الأسعار",
    "dn_flag_occasion_price": "المناسبة في رسالة الأسعار",
    "dn_flag_date_news": "التاريخ في رسالة الأخبار",
    "dn_flag_occasion_news": "المناسبة في رسالة الأخبار",

    "dn_help_text": (
        "📖 *دليل الإشعارات اليومية*\n\n"
        "💰 الأسعار و📰 الأخبار تُرسل لهذه المجموعة كل يوم في الوقت الذي تحدده.\n\n"
        "/setpricetime HH:MM — وقت إرسال الأسعار\n"
        "/setnewstime HH:MM — وقت إرسال الأخبار\n"
        "/setdailytz المنطقة_الزمنية — مثلاً Asia/Tehran (افتراضياً حسب لغة المجموعة)\n"
        "/testdailyprice   /testdailynews — إرسال تجريبي فوري\n"
        "/dailyassets — اختيار الأصول المعروضة\n"
        "بقية الإعدادات (تفعيل/تعطيل، التاريخ/المناسبة) يمكن تغييرها من الأزرار أعلاه."
    ),
    "dn_toast_saved": "✅ تم الحفظ.",
    "dn_toast_sending": "⏳ جارٍ الإرسال...",
    "dn_test_no_data": "⚠️ لا توجد بيانات صالحة حالياً (المزوّد غير متاح أو لا توجد عناصر جديدة بعد).",

    "dn_log_toggle_prices": "إشعار الأسعار اليومي: {state}",
    "dn_log_toggle_news": "إشعار الأخبار اليومي: {state}",
    "dn_log_settime": "وقت إرسال {what}: {time}",
    "dn_log_settz": "المنطقة الزمنية للإشعار اليومي: {tz}",

    "dn_settime_usage": "الاستخدام: {cmd} HH:MM (مثلاً 09:00)",
    "dn_settime_invalid": "⛔️ صيغة الوقت غير صالحة. استخدم HH:MM (مثلاً 09:00).",
    "dn_settime_done": "✅ تم ضبط وقت الإرسال على {time}.",
    "dn_settz_usage": "الاستخدام: /setdailytz المنطقة_الزمنية (مثلاً Asia/Tehran)",
    "dn_settz_invalid": "⛔️ منطقة زمنية غير صالحة. أدخل منطقة زمنية IANA صالحة مثل Asia/Tehran.",
    "dn_settz_done": "✅ المنطقة الزمنية للمجموعة: {tz}",

    "cmd_desc_dailynotify": "🔔 إعدادات الإشعارات اليومية (أسعار/أخبار)",
}


# ---------------------------------------------------------------------------
# TEXT_TRIGGERS (العربية) — کلمه/عبارتی که کاربر به‌جای دستور "/" تایپ می‌کند
# تا با همون تابع handlers/text_commands.py وصل بشه. هر شناسه (کلید) دقیقاً
# با همون نامی که در handlers/text_commands.py::COMMANDS استفاده شده باید یکی باشه.
# ---------------------------------------------------------------------------
TEXT_TRIGGERS = {
    "help": ["مساعدة", "المساعدة"],
    "settings": ["الإعدادات"],
    "warn": ["تحذير"],
    "unwarn": ["إزالة تحذير"],
    "warns": ["التحذيرات"],
    "mute": ["كتم"],
    "unmute": ["إلغاء الكتم"],
    "ban": ["حظر"],
    "unban": ["إلغاء الحظر"],
    "kick": ["طرد"],
    "del": ["حذف"],
    "purge": ["تنظيف"],
    "promote": ["ترقية"],
    "demote": ["تنزيل الرتبة"],
    "roles": ["المشرفون"],
    "logs": ["السجل"],
    "setlang": ["تغيير اللغة"],
    "lock": ["قفل"],
    "unlock": ["فتح القفل"],
    "locks": ["الأقفال"],
    "filter": ["فلتر"],
    "stopfilter": ["إزالة الفلتر"],
    "filters": ["الفلاتر"],
    "domains": ["النطاقات المحظورة"],
    "forwardrules": ["قواعد إعادة التوجيه"],
    "antiraid": ["مكافحة الغارات"],
    "lockdown": ["إغلاق كامل"],
    "unlockchat": ["فتح المجموعة"],
    "captcha": ["كابتشا"],
    "goodbye": ["وداعا"],
    "rules": ["القوانين"],
    "setrules": ["تعيين القوانين"],
    "clearrules": ["مسح القوانين"],
    "addkeyword": ["إضافة كلمة مفتاحية"],
    "delkeyword": ["حذف كلمة مفتاحية"],
    "keywords": ["الكلمات المفتاحية"],
    "setanswer": ["تعيين رد تلقائي"],
    "answerlist": ["قائمة الردود التلقائية"],
    "cleananswerlist": ["مسح قائمة الردود التلقائية"],
    "delanswer": ["حذف رد تلقائي"],
    "addcmd": ["إضافة أمر"],
    "delcmd": ["حذف أمر"],
    "cmds": ["الأوامر"],
    "setchannel": ["تعيين القناة"],
    "post": ["نشر"],
    "schedulepost": ["جدولة منشور"],
    "editpost": ["تعديل المنشور"],
    "delpost": ["حذف المنشور"],
    "channelstats": ["إحصائيات القناة"],
    "addautoaction": ["إضافة إجراء تلقائي"],
    "delautoaction": ["حذف إجراء تلقائي"],
    "autoactions": ["الإجراءات التلقائية"],
    "profiles": ["الملفات الشخصية"],
    "myperms": ["صلاحياتي"],
    "report": ["إبلاغ"],
    "reports": ["البلاغات"],
    "alerts": ["التنبيهات"],
    "exportsettings": ["تصدير الإعدادات"],
    "save": ["حفظ"],
    "get": ["إحضار"],
    "notes": ["الملاحظات"],
    "clear": ["مسح ملاحظة"],
    "setlogchannel": ["تعيين قناة السجل"],
    "fnew": ["اتحاد جديد"],
    "fjoin": ["انضمام للاتحاد"],
    "fleave": ["مغادرة الاتحاد"],
    "finfo": ["معلومات الاتحاد"],
    "adminpanel": ["الإدارة", "اللوحة"],
    "fban": ["حظر الاتحاد"],
    "funban": ["إلغاء حظر الاتحاد"],
    "copilot": ["مساعد", "المساعد الذكي", "كوبايلوت"],
    "aicheck": ["فحص الذكاء الاصطناعي"],
    "aiexplain": ["شرح الإجراء"],
    "aireports": ["تحليل البلاغات"],
    "aihealth": ["صحة المجموعة"],
    "airule": ["اقتراح قاعدة"],
    "aioptimize": ["تحسين القواعد"],
    "aiincident": ["تحليل الحادثة"],
    "aiplan": ["خطة الذكاء الاصطناعي"],
    # ==================== Phase 3 migration additions ====================
    "allowword": ["السماح بكلمة"],
    "disallowword": ["منع كلمة"],
    "blockdomain": ["حظر النطاق"],
    "unblockdomain": ["إلغاء حظر النطاق"],
    "allowdomain": ["السماح بالنطاق"],
    "unallowdomain": ["إلغاء السماح بالنطاق"],
    "allowforward": ["السماح بإعادة التوجيه"],
    "blockforward": ["حظر إعادة التوجيه"],
    "unruleforward": ["إزالة قاعدة إعادة التوجيه"],
    "setfilteraction": ["تعيين إجراء الفلتر"],
    "mentionprotection": ["حماية الإشارة"],
    "setmentionlimit": ["تعيين حد الإشارات"],
    "setmentionaction": ["تعيين إجراء الإشارة"],
    "antispam": ["مكافحة البريد المزعج"],
    "setspamaction": ["تعيين إجراء البريد المزعج"],
    "dupcross": ["تكرار عبر المجموعات"],
    "setdupcross": ["تعيين التكرار عبر المجموعات"],
    "setflood": ["تعيين الفيضان"],
    "setfloodaction": ["تعيين إجراء الفيضان"],
    "setraidthreshold": ["تعيين حد الغارة"],
    "setmaxwarns": ["تعيين الحد الأقصى للتحذيرات"],
    "setwarnaction": ["تعيين إجراء التحذير"],
    "setwelcomedelete": ["حذف رسالة الترحيب تلقائيًا"],
    "setgoodbye": ["تعيين رسالة الوداع"],
    "resetgoodbye": ["إعادة تعيين رسالة الوداع"],
    "createprofile": ["إنشاء ملف تعريف"],
    "delprofile": ["حذف ملف التعريف"],
    "assignprofile": ["تعيين ملف التعريف"],
    "unassignprofile": ["إلغاء تعيين ملف التعريف"],
    "setalertchannel": ["تعيين قناة التنبيه"],
    "importsettings": ["استيراد الإعدادات"],
    "schedulerecurring": ["جدولة منشور متكرر"],
    "recurringposts": ["المنشورات المتكررة"],
    "delrecurring": ["حذف المنشور المتكرر"],
    "autoactiontoggle": ["تبديل الإجراء التلقائي"],
    "dailynotify": ["الإشعار اليومي"],
    "setpricetime": ["تعيين وقت السعر"],
    "setnewstime": ["تعيين وقت الأخبار"],
    "setdailytz": ["تعيين المنطقة الزمنية اليومية"],
    "testdailyprice": ["اختبار السعر اليومي"],
    "testdailynews": ["اختبار الأخبار اليومية"],
    "dailyassets": ["الأصول اليومية"],
    "ads": ["الإعلانات"],
    "myads": ["إعلاناتي"],
    "adadmin": ["إدارة الإعلانات"],
    "adstats": ["إحصائيات الإعلانات"],
    "buyplan": ["شراء خطة"],
}
