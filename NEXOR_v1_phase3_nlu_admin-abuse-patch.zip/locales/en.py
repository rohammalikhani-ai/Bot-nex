# -*- coding: utf-8 -*-
STRINGS = {
    "rank_user": "User",
    "rank_moderator": "Moderator",
    "rank_admin": "Admin",
    "rank_owner": "Owner",

    "err_need_rank": "⛔️ This command requires «{rank}» access or higher.",
    "err_self_action": "You can't do that to yourself! 😅",
    "err_rank_too_low": "⛔️ You don't have enough rank to act on this user (they are equal or higher rank than you).",
    "err_user_not_found_username": "❌ Couldn't find this user (they must have sent at least one message in this group before the bot can recognize them).",
    "err_need_target": "❗️Target user not found.\nUsage: {usage}",

    "warn_given": "⚠️ {name} received a warning. ({count}/{max})",
    "warn_reason_line": "\nReason: {reason}",
    "warn_removed": "➖ Warning removed from {name}. ({count}/{max})",
    "warn_escalate_mute": "🔇 {name} was muted for {duration} after reaching {max} warnings.",
    "warn_escalate_ban": "🚫 {name} was banned after reaching {max} warnings.",
    "warns_header": "⚠️ Warnings for {name}: {count}/{max}",
    "warns_history_line": "• {when} — {reason} (by {actor})",
    "warns_no_reason": "no reason given",
    "setwarnaction_usage": "Usage: /setwarnaction mute or /setwarnaction ban",
    "setwarnaction_done": "✅ Action after reaching max warnings: {action}",
    "setmaxwarns_usage": "Usage: /setmaxwarns number (e.g. 3)",
    "setmaxwarns_done": "✅ Max warnings changed to {n}.",

    "mute_done": "🔇 {name} was muted (duration: {duration}).",
    "unmute_done": "🔊 {name} is no longer muted.",

    "ban_done": "🚫 {name} was banned (duration: {duration}).",
    "unban_done": "✅ {name}'s ban was lifted.",
    "duration_permanent": "permanent",

    "kick_done": "👢 {name} was kicked from the group.",

    "del_usage": "Please reply to the message you want deleted.",
    "purge_usage": "Usage: reply to a message with /purge, or /purge <count>",
    "purge_done": "🧹 {count} messages deleted.",

    "promote_usage": "Please reply to the target user or provide @username/ID.",
    "promote_already_admin": "This user is already a real Telegram admin; no internal role needed.",
    "promote_done": "⭐️ {name} was appointed as an internal Moderator.",
    "demote_done": "⬇️ Moderator role removed from {name}.",
    "roles_empty": "No internal Moderators registered. (Use Telegram's own group panel to see real admins.)",
    "roles_header": "⭐️ Internal Moderators in this group:",
    "logs_empty": "No actions logged yet.",
    "logs_header": "🧾 Recent moderation actions:",

    "btn_remove_warn": "➖ Remove warning",
    "btn_mute": "🔇 Mute",
    "btn_ban": "🚫 Ban",
    "modact_invalid_data": "Invalid data.",
    "modact_wrong_chat": "This button isn't for this chat.",
    "modact_no_permission": "⛔️ You don't have permission for this action.",
    "modact_done": "Done ✅",
    "modact_unwarn_result": "➖ {name} — one warning removed. ({count})",
    "modact_mute_result": "🔇 {name} was muted for {minutes} minutes.",
    "modact_ban_result": "🚫 {name} was banned.",

    "start_msg": (
        "Hello {mention} 🌹\n\n"
        "🔰 Meet *NEXOR* — the most professional group management bot\n"
        "🔰 A powerful assistant for order, security, and full control over your Telegram groups\n\n"
        "✨ *Key features:*\n"
        "✅ Full member management (warn, mute, ban, kick)\n"
        "✅ Smart content locks (links, forwards, media, and more)\n"
        "✅ Advanced filtering of banned words and phrases\n"
        "✅ Join captcha to block unwanted bots\n"
        "✅ Advanced anti-spam and anti-flood protection\n"
        "✅ Anti-raid protection for your group\n"
        "✅ Connected channel management (post, schedule, edit, delete)\n"
        "✅ Federation system across multiple groups\n"
        "✅ Built-in roles, logging, and full reporting\n"
        "✅ Multilingual (Persian, English, Arabic, Turkish, Russian, Spanish)\n\n"
        "🤖 *NEXOR Copilot — your group's AI assistant:*\n"
        "✅ Reply to any suspicious message and it analyzes the risk in seconds\n"
        "✅ Ask \"why?\" and it explains exactly what led to a warn/mute/ban\n"
        "✅ Get a full group health report: where things are heating up, where to tighten rules\n"
        "✅ Just describe your problem in plain words (\"too much spam lately\") and it drafts an automation rule for you\n"
        "✅ Prioritizes and analyzes user reports and recent incidents before you decide\n"
        "Try it with /copilot! ✨\n"
        "\n"
        "🚀 *Setup:*\n"
        "1. Add the bot to your group using the button below\n"
        "2. Grant it full admin rights so it can work properly\n\n"
        "📌 *Important notes:*\n"
        "• The group must be a supergroup\n"
        "• For best performance, full admin access is recommended\n\n"
        "Use /help to see the full list of commands."
    ),
    "add_to_group_button": "➕ Add to group",
    "settings_header": "⚙️ *Current group settings*",
    "settings_locks": "🔒 Locks: {locks}",
    "settings_filters": "🚫 Filters: {filters}",
    "settings_captcha": "🛡️ CAPTCHA: {state}",
    "settings_warns": "⚠️ Max warnings: {max} → action: {action}",
    "settings_channel": "📢 Linked channel: {channel}",
    "settings_logchannel": "🧾 Log channel: {log}",
    "settings_lang": "🌐 Language: {lang}",
    "none": "none",
    "not_set": "—",

    "setlang_prompt": "🌐 Choose the group's language:",
    "setlang_done": "✅ Group language changed to {lang_name}.",

    "welcome_simple": "Welcome {mention} to {chat}! 🌹",
    "welcome_captcha": "Welcome {mention} to {chat}! 🌹\nPlease tap the button below to verify you're not a bot.",
    "welcome_simple_multi": "Welcome to {chat}: {mentions} 🌹",
    "welcome_captcha_multi": "Welcome to {chat}: {mentions} 🌹\nEach person should tap the button next to their own name to verify.",
    "captcha_btn": "✅ I'm not a robot",
    "captcha_not_yours": "This button isn't for you.",
    "captcha_expired": "This verification has expired.",
    "captcha_verified_alert": "✅ Verified, welcome!",
    "captcha_verified_msg": "✅ {name} was verified and can now chat.",
    "captcha_timeout_msg": "⛔️ Verification time expired; the user was removed.",
    "captcha_toggle_usage": "Usage: /captcha on or /captcha off",
    "captcha_toggle_done": "🛡️ CAPTCHA {state}.",
    "captcha_on": "enabled",
    "captcha_off": "disabled",
    "goodbye_msg": "{name} left the group. 👋",

    "lock_usage": "Usage: /lock {options}",
    "lock_done": "🔒 {kind} locked.",
    "unlock_usage": "Usage: /unlock {options}",
    "unlock_done": "🔓 {kind} unlocked.",
    "locks_active": "🔒 Active locks: {locks}",
    "filter_usage": "Usage: /filter word",
    "filter_added": "➕ Word «{word}» added to the filter.",
    "stopfilter_usage": "Usage: /stopfilter word",
    "filter_removed": "➖ Word «{word}» removed from the filter.",
    "filters_active": "🚫 Active filters: {filters}",
    "flood_muted": "🚨 {name} was muted for {minutes} minutes for sending too many messages too fast.",

    "save_usage": "Usage: /save name text  (or reply to a message: /save name)",
    "save_empty": "No text found to save.",
    "save_done": "📝 Note «{name}» saved. View it with /get {name} or #{name}.",
    "get_usage": "Usage: /get name",
    "get_not_found": "No note found with that name.",
    "notes_empty": "No notes saved yet.",
    "notes_list_header": "📝 Available notes:",
    "clear_usage": "Usage: /clear name",
    "clear_done": "🗑️ Note «{name}» deleted.",

    "setlogchannel_usage": "Usage: /setlogchannel @channel＿username or numeric channel ID",
    "setlogchannel_error": "❌ Couldn't find that channel: {error}",
    "setlogchannel_done": "🧾 Admin actions will now be logged in «{title}».",
    "setlogchannel_channel_confirm": "✅ This channel was set as the group's management log channel.",

    "fed_new_usage": "Usage: /fnew federation＿name",
    "fed_new_done": "🌐 Federation «{name}» created (ID: {id}).\nThis group was added as the first member.\nTo add other groups, run this there:\n/fjoin {id}",
    "fed_join_usage": "Usage: /fjoin federation＿id",
    "fed_join_invalid_id": "Invalid federation ID.",
    "fed_not_found": "No federation found with that ID.",
    "fed_join_done": "✅ This group joined federation «{name}».",
    "fed_not_member": "This group isn't a member of any federation.",
    "fed_left": "👋 This group left federation «{name}».",
    "fed_info": "🌐 Federation: {name}\n🆔 ID: {id}\n👥 Member groups: {count}",
    "fed_ban_no_target": "Please reply to the target user's message or provide @username/ID.",
    "fed_ban_not_member": "This group isn't part of any federation yet. Run /fnew or /fjoin first.",
    "fed_ban_done": "🚫 {name} was banned across federation «{fed}».\n✅ Success: {success} groups | ❌ Failed: {failed} groups\nReason: {reason}",
    "fed_unban_done": "✅ {name}'s ban was lifted in {success} groups of federation «{fed}».",
    "fed_ban_no_reason": "no reason given",
    "fed_raid_kick_notice": "🚫 {name} was federation-banned and automatically removed.",

    "help_text": (
        "📋 *Admin commands*\n\n"
        "✨ *Fun fact:* you don't have to type the slash! Every command also has a plain-word twin that does the exact same thing — for example, just typing \"report\" works just like /report, and typing \"help\" (or \"guide\") opens this very menu. This works across all 6 languages the bot speaks, each with its own local words, so every member can boss the bot around in their own language without memorizing a single slash command! 🗣️\n\n"
        "👮 *Member management* (reply, @username, or user＿id)\n"
        "/warn [duration] [reason]   /unwarn   /warns — warning history\n"
        "/mute [duration] [reason]   /unmute\n"
        "/ban [duration] [reason]   /unban\n"
        "/kick [reason]\n"
        "Example: /ban 2h heavy spam   or   /mute @user 30m\n"
        "/setmaxwarns number   /setwarnaction mute|ban\n\n"
        "🧹 *Delete messages*\n"
        "/del — delete the replied-to message\n"
        "/purge — delete from the replied message to now (or /purge count)\n\n"
        "⭐️ *Internal roles*\n"
        "/promote /demote — the bot's internal Moderator role (below real admin)\n"
        "/roles — list internal Moderators\n"
        "/logs — recent moderation actions (Audit Log)\n\n"
        "🔒 *Content locks*\n"
        "/lock link|invitelink|channellink|photo|video|sticker|voice|forward|gif|video＿note|document|poll\n"
        "/unlock same options\n"
        "/locks — show active locks\n\n"
        "🌐 *Link Protection*\n"
        "/blockdomain domain   /unblockdomain domain\n"
        "/allowdomain domain   /unallowdomain domain\n"
        "/domains — show lists\n\n"
        "🚫 *Word filters*\n"
        "/filter word\n/stopfilter word\n/filters\n"
        "/setfilteraction delete|warn|mute|ban\n"
        "/allowword word — exception   /disallowword word\n\n"
        "🕵️ *Anti-Spam*\n"
        "/antispam on|off\n/setspamaction delete|warn|mute|ban\n"
        "/dupcross on|off   /setdupcross threshold seconds\n\n"
        "↪️ *Forward Protection*\n"
        "/allowforward source   /blockforward source   /unruleforward source\n"
        "/forwardrules — show rules (source: @username, ID, or name)\n\n"
        "📛 *Mention Protection*\n"
        "/mentionprotection on|off\n/setmentionlimit number\n/setmentionaction delete|warn|mute|ban\n\n"
        "🚨 *Anti-Flood*\n"
        "/setflood count seconds\n/setfloodaction delete|warn|mute|ban\n\n"
        "🛡️ *Anti-Raid*\n"
        "/antiraid on|off\n/setraidthreshold number\n"
        "/lockdown — lock the whole group now   /unlockchat — unlock\n\n"
        "🛡️ *CAPTCHA*\n"
        "/captcha on|off — toggle new-member verification\n\n"
        "📝 *Notes*\n"
        "/save name (reply or text) — save a note\n"
        "/get name or #name — show a note\n"
        "/notes — list notes\n"
        "/clear name — delete a note\n\n"
        "📢 *Channel management (run from the group)*\n"
        "/setchannel @channel＿username — link a channel\n"
        "/post text — post immediately (button with \"text|link\", ; between buttons)\n"
        "/schedulepost minutes | text — scheduled post\n"
        "/editpost message＿id | new text\n"
        "/delpost message＿id\n"
        "/channelstats — channel stats\n\n"
        "🧾 *Admin log*\n"
        "/setlogchannel @channel＿username — log admin actions to a channel\n\n"
        "🌐 *Federation (shared ban list)*\n"
        "/fnew name — create a new federation\n"
        "/fjoin id — join this group to a federation\n"
        "/fleave — leave the federation\n"
        "/finfo — current federation info\n"
        "/fban (reply) reason — ban across all federation groups\n"
        "/funban (reply) — unban across all federation groups\n\n"
        "🆕 *New Members & Automation*\n"
        "/setwelcomedelete seconds|off — auto-delete the welcome message\n"
        "/setgoodbye text   /resetgoodbye   /goodbye on|off\n"
        "/rules   /setrules [lang] text   /clearrules [lang]\n"
        "/addkeyword word response   /delkeyword word   /keywords\n"
        "/addcmd name response   /delcmd name   /cmds\n"
        "/schedulerecurring daily|weekly|monthly ... — recurring channel posts\n"
        "/recurringposts   /delrecurring id\n"
        "/addautoaction condition action   /delautoaction id   /autoactions   /autoactiontoggle on|off\n\n"
        "💬 *Auto-Answer*\n"
        "/setanswer — send in the group, then use the PM button to set keyword/audience/response (up to 20 random text or media responses)\n"
        "/answerlist — show configured keywords\n"
        "/delanswer keyword — remove one keyword\n"
        "/cleananswerlist — clear all auto-answers\n\n"
        "🗂️ *Permission Profiles*\n"
        "/createprofile name cap1,cap2,...   /delprofile name   /profiles\n"
        "/assignprofile [reply|@user|id] profile   /unassignprofile [reply|@user|id]   /myperms\n\n"
        "🚩 *Reports*\n"
        "/report [reason] (reply to a message)   /reports — open reports\n\n"
        "🔔 *Admin Alerts*\n"
        "/setalertchannel channel＿id   /alerts — recent alerts\n\n"
        "📦 *Import / Export Settings*\n"
        "/exportsettings   /importsettings (reply to a .json file)\n\n"
        "🔔 *Daily Notify* (💰 prices + 📰 news + 📅 date/occasion)\n"
        "/dailynotify — settings panel (on/off, assets, test send)\n"
        "/setpricetime HH:MM   /setnewstime HH:MM   /setdailytz timezone\n"
        "/testdailyprice   /testdailynews   /dailyassets\n\n"
        "🌐 /setlang — change the group's language\n"
        "⚙️ /settings — show current group settings"
    ),

    "help_words_text": (
        "📖 *Full list of plain-word command shortcuts*\n"
        "Each line means: type this word = it runs that exact command\n"
        "\n"
        "*👮 Member management*\n"
        "warn = /warn\n"
        "unwarn = /unwarn\n"
        "warns = /warns\n"
        "mute = /mute\n"
        "unmute = /unmute\n"
        "ban = /ban\n"
        "unban = /unban\n"
        "kick = /kick\n"
        "delete = /del\n"
        "purge = /purge\n"
        "\n"
        "*⭐️ Roles & logs*\n"
        "promote = /promote\n"
        "demote = /demote\n"
        "moderators = /roles\n"
        "logs = /logs\n"
        "set language = /setlang\n"
        "\n"
        "*🔒 Locks & filters*\n"
        "lock = /lock\n"
        "unlock = /unlock\n"
        "locks = /locks\n"
        "filter = /filter\n"
        "remove filter = /stopfilter\n"
        "filters = /filters\n"
        "blocked domains = /domains\n"
        "forward rules = /forwardrules\n"
        "\n"
        "*🛡️ Group security*\n"
        "anti raid = /antiraid\n"
        "lockdown = /lockdown\n"
        "open group = /unlockchat\n"
        "captcha = /captcha\n"
        "goodbye = /goodbye\n"
        "\n"
        "*📝 Notes*\n"
        "save = /save\n"
        "get = /get\n"
        "notes = /notes\n"
        "clear note = /clear\n"
        "\n"
        "*📢 Channel*\n"
        "set channel = /setchannel\n"
        "post = /post\n"
        "schedule post = /schedulepost\n"
        "edit post = /editpost\n"
        "delete post = /delpost\n"
        "channel stats = /channelstats\n"
        "set log channel = /setlogchannel\n"
        "\n"
        "*🌐 Federation*\n"
        "new federation = /fnew\n"
        "join federation = /fjoin\n"
        "leave federation = /fleave\n"
        "federation info = /finfo\n"
        "federation ban = /fban\n"
        "federation unban = /funban\n"
        "\n"
        "*🆕 Welcome & automation*\n"
        "rules = /rules\n"
        "set rules = /setrules\n"
        "clear rules = /clearrules\n"
        "add keyword = /addkeyword\n"
        "remove keyword = /delkeyword\n"
        "keywords = /keywords\n"
        "add command = /addcmd\n"
        "remove command = /delcmd\n"
        "commands = /cmds\n"
        "add auto action = /addautoaction\n"
        "remove auto action = /delautoaction\n"
        "auto actions = /autoactions\n"
        "\n"
        "*💬 Auto-Answer*\n"
        "set answer = /setanswer\n"
        "answer list = /answerlist\n"
        "clean answer list = /cleananswerlist\n"
        "remove answer = /delanswer\n"
        "\n"
        "*🗂️ Permissions & reports*\n"
        "profiles = /profiles\n"
        "my permissions = /myperms\n"
        "report = /report\n"
        "reports = /reports\n"
        "alerts = /alerts\n"
        "export settings = /exportsettings\n"
        "\n"
        "*🤖 NEXOR Copilot*\n"
        "admin = /adminpanel\n"
        "assistant = /copilot\n"
        "aicheck = /aicheck\n"
        "ai explain = /aiexplain\n"
        "ai reports = /aireports\n"
        "group health = /aihealth\n"
        "ai rule = /airule\n"
        "optimize rules = /aioptimize\n"
        "analyze incident = /aiincident\n"
        "ai plan = /aiplan\n"
        "\n"
        "*⚙️ General*\n"
        "settings = /settings\n"
        "help = /help\n"
        "\n"
        "💡 For multi-word phrases (like \\\"remove filter\\\"), type them exactly as shown, all together."
    ),

    "channel_set_usage": "Usage: /setchannel @channel＿username or numeric channel ID",
    "channel_set_error": "❌ Couldn't find that channel: {error}",
    "channel_set_done": "📢 Channel «{title}» linked to this group.",
    "channel_no_channel": "First link a channel with /setchannel.",
    "channel_post_empty": "Post text is empty. Usage: /post message text",
    "channel_post_sent": "✅ Post sent. Message ID: {id}",
    "channel_post_failed": "❌ Failed to send post: {error}",
    "channel_schedule_usage": "Usage: /schedulepost minutes, then the post text on the next line",
    "channel_schedule_invalid_minutes": "Invalid number of minutes.",
    "channel_schedule_empty": "Post text is empty.",
    "channel_schedule_done": "⏰ Post scheduled for {minutes} minutes from now.",
    "channel_scheduled_sent": "✅ Scheduled post sent. ID: {id}",
    "channel_scheduled_failed": "❌ Failed to send scheduled post: {error}",
    "channel_editpost_usage": "Usage: /editpost message＿id, then the new text on the next line",
    "channel_editpost_invalid_id": "Invalid message ID.",
    "channel_editpost_empty": "New text is empty.",
    "channel_editpost_done": "✅ Post edited.",
    "channel_editpost_failed": "❌ Edit failed: {error}",
    "channel_delpost_usage": "Usage: /delpost message＿id",
    "channel_delpost_done": "🗑️ Post deleted.",
    "channel_delpost_failed": "❌ Delete failed: {error}",
    "channel_stats_text": "📊 Stats for channel «{title}»\n👥 Members: {count}",
    "channel_stats_failed": "❌ Failed to get stats: {error}",

    "state_on": "enabled",
    "state_off": "disabled",

    "antispam_toggle_usage": "Usage: /antispam on or /antispam off",
    "antispam_toggle_done": "🕵️ Anti-Spam {state}.",
    "adminabuseprotection_toggle_usage": "Usage: /adminabuseprotection on or /adminabuseprotection off (owner only)",
    "adminabuseprotection_toggle_done": "🚷 Admin abuse detection {state}.",
    "setspamaction_usage": "Usage: /setspamaction delete|warn|mute|ban",
    "setspamaction_done": "✅ Anti-Spam action: {action}",
    "spam_reason_duplicate": "sending a duplicate message",
    "spam_reason_newlink": "posting a link right after joining",

    "setflood_usage": "Usage: /setflood count seconds  (e.g. /setflood 5 10)",
    "setflood_done": "✅ Anti-Flood: {limit} messages per {window} seconds",
    "setfloodaction_usage": "Usage: /setfloodaction delete|warn|mute|ban",
    "setfloodaction_done": "✅ Anti-Flood action: {action}",
    "flood_reason": "sending messages too fast",

    "setfilteraction_usage": "Usage: /setfilteraction delete|warn|mute|ban",
    "setfilteraction_done": "✅ Word filter action: {action}",
    "allowword_usage": "Usage: /allowword word",
    "allowword_done": "➕ «{word}» added to the exceptions list.",
    "disallowword_usage": "Usage: /disallowword word",
    "disallowword_done": "➖ «{word}» removed from the exceptions list.",
    "filter_reason": "forbidden word",

    "blockdomain_usage": "Usage: /blockdomain domain (e.g. example.com)",
    "blockdomain_done": "🚫 Domain «{domain}» blocked.",
    "unblockdomain_usage": "Usage: /unblockdomain domain",
    "unblockdomain_done": "✅ Domain «{domain}» unblocked.",
    "allowdomain_usage": "Usage: /allowdomain domain",
    "allowdomain_done": "✅ Domain «{domain}» added to the whitelist.",
    "unallowdomain_usage": "Usage: /unallowdomain domain",
    "unallowdomain_done": "➖ Domain «{domain}» removed from the whitelist.",
    "domains_header_block": "🚫 Blocked domains:",
    "domains_header_allow": "✅ Whitelisted domains:",
    "domains_empty": "No domains registered.",
    "link_reason_blacklisted": "blocked domain link",

    "antiraid_toggle_usage": "Usage: /antiraid on or /antiraid off",
    "antiraid_toggle_done": "🛡️ Anti-Raid {state}.",
    "setraidthreshold_usage": "Usage: /setraidthreshold number (e.g. 8)",
    "setraidthreshold_done": "✅ Raid detection threshold changed to {n} users.",
    "raid_detected_alert": "🚨 *Raid alert!*\nAn unusual number of new members ({count} in {window} seconds) joined the group.\nThe group has been locked for {minutes} minutes (only admins can send messages).",
    "raid_auto_unlock": "🔓 Automatic security lock lifted.",
    "lockdown_done": "🔒 Group locked; only admins can send messages.",
    "unlock_done_manual": "🔓 Group lock lifted.",
    "already_locked": "The group is already locked.",
    "already_unlocked": "The group isn't locked.",
    "btn_unlock_now": "🔓 Unlock now",

    # --- Priority 3: Content Control (Forward Protection / Mention Protection / Cross-user Duplicate) ---
    "allowforward_usage": "Usage: /allowforward @username|ID|name",
    "allowforward_done": "✅ Forwards from «{source}» are now always allowed.",
    "blockforward_usage": "Usage: /blockforward @username|ID|name",
    "blockforward_done": "🚫 Forwards from «{source}» are now always blocked.",
    "unruleforward_usage": "Usage: /unruleforward @username|ID|name",
    "unruleforward_done": "➖ Forward rule for «{source}» removed.",
    "forwardrules_header_block": "🚫 Always-blocked forward sources:",
    "forwardrules_header_allow": "✅ Always-allowed forward sources:",
    "forwardrules_empty": "No forward rules set.",
    "forward_reason_blocked_source": "forward from a blocked source ({source})",
    "mentionprotection_usage": "Usage: /mentionprotection on or /mentionprotection off",
    "mentionprotection_done": "🛡️ Mention Protection {state}.",
    "setmentionlimit_usage": "Usage: /setmentionlimit number (e.g. 5)",
    "setmentionlimit_done": "✅ Mention limit changed to {n}.",
    "setmentionaction_usage": "Usage: /setmentionaction delete|warn|mute|ban",
    "setmentionaction_done": "✅ Mention-abuse action set to: {action}",
    "mention_reason": "mass mention abuse ({count} mentions)",
    "dupcross_usage": "Usage: /dupcross on or /dupcross off",
    "dupcross_done": "🕵️ Cross-user duplicate detection {state}.",
    "setdupcross_usage": "Usage: /setdupcross threshold seconds (e.g. 3 45)",
    "setdupcross_done": "✅ Cross-user duplicate settings: {threshold} users within {window}s.",
    "spam_reason_cross_duplicate": "duplicate message from multiple users (copy/paste raid)",

    # --- Priority 4: New Members & Automation (Welcome auto-delete, Goodbye, Rules, Filters, Custom Commands, Scheduled Messages, Auto Actions) ---
    "setwelcomedelete_usage": "Usage: /setwelcomedelete seconds (e.g. 60) or /setwelcomedelete off",
    "setwelcomedelete_done": "✅ Welcome messages will now be auto-deleted after {seconds} seconds.",
    "setwelcomedelete_off": "✅ Welcome message auto-delete disabled.",
    "setgoodbye_usage": "Usage: /setgoodbye <text>\nAvailable variables: {name} {username} {mention} {chat} {count}",
    "setgoodbye_done": "✅ Custom goodbye message saved.",
    "resetgoodbye_done": "✅ Goodbye message reset to default.",
    "goodbye_toggle_usage": "Usage: /goodbye on or /goodbye off",
    "goodbye_toggle_done": "👋 Goodbye messages {state}.",
    "rules_empty": "No rules have been set for this group yet.",
    "rules_header": "📜 *Group Rules*",
    "setrules_usage": "Usage: /setrules [language code] <rules text>\nExample: /setrules Please be respectful to everyone.\nWith a language code: /setrules en Please be respectful.",
    "setrules_done": "✅ Rules saved ({lang}).",
    "clearrules_done": "🗑️ Rules removed ({lang}).",
    "clearrules_notfound": "No rules were set for that language.",
    "addkeyword_usage": "Usage: /addkeyword <keyword> <response>\nOr reply to a message with: /addkeyword <keyword>",
    "addkeyword_done": "✅ Keyword trigger «{keyword}» added.",
    "addkeyword_updated": "♻️ Keyword trigger «{keyword}» updated.",
    "delkeyword_usage": "Usage: /delkeyword <keyword>",
    "delkeyword_done": "🗑️ Keyword trigger «{keyword}» removed.",
    "delkeyword_notfound": "No such keyword trigger.",
    "keywords_empty": "No keyword triggers set.",
    "keywords_header": "🔑 Keyword triggers:",

    # ==================== Auto-Answer ====================
    "autoanswer_group_only": "This command can only be used inside a group.",
    "autoanswer_pm_button": "🔐 Open PM to set up Auto-Answer",
    "autoanswer_setup_intro": "◄ Auto-Answer\n\nTo set up a new auto-answer for «{title}», tap the button below and continue the steps in a private chat.",
    "autoanswer_invalid_link": "This link is invalid or expired. Send the «SetAnswer» command in the group again.",
    "autoanswer_not_admin": "⛔️ You must be an admin or the owner of that group to set up Auto-Answer.",
    "autoanswer_ask_audience": "⚙️ Setting up Auto-Answer for «{title}»\n\nWho should the bot answer this keyword for?",
    "autoanswer_audience_all": "👥 All users",
    "autoanswer_audience_admins": "🛡 Admins only",
    "autoanswer_audience_owners": "👑 Owner only",
    "autoanswer_ask_keyword": "✏️ Now send the keyword or phrase (e.g. price, rules, admin, ...).",
    "autoanswer_ask_response": "📎 Keyword «{keyword}» saved.\n\nNow send the message or media you want the bot to reply with (text, photo, video, voice, audio, file, GIF, sticker, or video note).\n\nYou can send up to 20 different responses so the bot picks one at random each time. When you're done, tap «Done».",
    "autoanswer_response_added": "✅ Response {count}/{max} saved.\nSend the next one or tap «Done».",
    "autoanswer_max_responses": "⛔️ You've reached the {max}-response limit. Tap «Done» to save.",
    "autoanswer_unsupported_content": "That content type isn't supported. Send text, photo, video, voice, audio, file, GIF, sticker, or video note.",
    "autoanswer_btn_done": "✅ Done",
    "autoanswer_btn_cancel": "❌ Cancel",
    "autoanswer_need_one_response": "You haven't added any response yet; send at least one message or media.",
    "autoanswer_expired": "This step is no longer valid; send the «SetAnswer» command in the group again.",
    "autoanswer_cancelled": "❌ Cancelled; no auto-answer was saved.",
    "autoanswer_saved": "✅ Auto-answer saved for «{title}».\nKeyword: {keyword}\nAudience: {audience}\nResponses: {count}",
    "autoanswer_updated": "♻️ Auto-answer «{keyword}» updated for «{title}».\nAudience: {audience}\nResponses: {count}",
    "autoanswer_list_empty": "No auto-answers set.",
    "autoanswer_list_header": "◄ Auto-Answer list:",
    "autoanswer_list_item": "• «{keyword}» — audience: {audience} — {count} response(s)",
    "autoanswer_cleaned": "🗑️ {count} auto-answer(s) cleared.",
    "delanswer_usage": "Usage: /delanswer <keyword>",
    "delanswer_done": "🗑️ Auto-answer «{keyword}» removed.",
    "delanswer_notfound": "No such auto-answer.",
    "addcmd_usage": "Usage: /addcmd <name> <response>\nOr reply to a message with: /addcmd <name>",
    "addcmd_reserved": "⛔ This name is reserved for a built-in command.",
    "addcmd_done": "✅ Custom command /{name} added.",
    "addcmd_updated": "♻️ Custom command /{name} updated.",
    "delcmd_usage": "Usage: /delcmd <name>",
    "delcmd_done": "🗑️ Custom command /{name} removed.",
    "delcmd_notfound": "No such custom command.",
    "cmds_empty": "No custom commands defined.",
    "cmds_header": "⚙️ Custom commands:",
    "schedulerecurring_usage": "Usage:\n/schedulerecurring daily HH:MM <text>\n/schedulerecurring weekly mon HH:MM <text>\n/schedulerecurring monthly DAY HH:MM <text>\n(weekday: mon tue wed thu fri sat sun — day: 1-28)",
    "schedulerecurring_invalid_time": "Invalid time. Use HH:MM (e.g. 14:30).",
    "schedulerecurring_invalid_day": "Invalid day of month. Use a number between 1 and 28.",
    "schedulerecurring_invalid_weekday": "Invalid weekday. Use one of: mon tue wed thu fri sat sun",
    "schedulerecurring_empty_text": "Message text is required (on the line(s) after the command).",
    "schedulerecurring_done": "✅ Recurring post scheduled (ID {id}).",
    "recurringposts_header": "🔁 Recurring posts:",
    "recurringposts_empty": "No recurring posts scheduled.",
    "recurringposts_item": "#{id} — {schedule} — {preview}",
    "recurring_desc_daily": "Daily at {time}",
    "recurring_desc_weekly": "Weekly on {weekday} at {time}",
    "recurring_desc_monthly": "Monthly on day {day} at {time}",
    "delrecurring_usage": "Usage: /delrecurring <id>",
    "delrecurring_done": "🗑️ Recurring post #{id} removed.",
    "delrecurring_notfound": "No recurring post with that ID.",
    "addautoaction_usage": "Usage: /addautoaction <condition> <action>\nConditions: message＿type:<photo|video|sticker|voice|gif|video＿note|document|poll|forward|link|text>, user＿role:<user|moderator|admin>, warns＿gte:<number>\nActions: delete, warn, mute:<minutes>, ban, kick",
    "addautoaction_invalid_condition": "Invalid condition. Run /addautoaction with no arguments to see the format.",
    "addautoaction_invalid_action": "Invalid action. Run /addautoaction with no arguments to see the format.",
    "addautoaction_done": "✅ Auto Action rule added (ID {id}): {condition} → {action}",
    "delautoaction_usage": "Usage: /delautoaction <id>",
    "delautoaction_done": "🗑️ Auto Action rule #{id} removed.",
    "delautoaction_notfound": "No Auto Action rule with that ID.",
    "autoactions_header": "🤖 Auto Action rules:",
    "autoactions_empty": "No Auto Action rules defined.",
    "autoactiontoggle_usage": "Usage: /autoactiontoggle on or /autoactiontoggle off",
    "autoactiontoggle_done": "🤖 Auto Actions {state}.",
    "autoaction_reason": "Auto Action rule (#{id})",
    "settings_goodbye": "👋 Goodbye messages: {state}",
    "settings_autoaction": "🤖 Auto Actions: {state}",

    # Priority 5, Item 25 — Permission Profiles
    "createprofile_usage": "Usage: /createprofile <name> <cap1,cap2,...>\nAvailable capabilities: {caps}",
    "profile_invalid_caps": "❌ Unknown capability: {invalid}\nAvailable capabilities: {caps}",
    "createprofile_done": "✅ Profile «{name}» created with capabilities: {caps}",
    "createprofile_updated": "♻️ Profile «{name}» updated with capabilities: {caps}",
    "delprofile_usage": "Usage: /delprofile <name>",
    "delprofile_notfound": "No such profile.",
    "delprofile_done": "🗑️ Profile «{name}» deleted.",
    "profiles_empty": "No custom permission profiles defined yet.",
    "profiles_header": "🗂️ Permission profiles:",
    "profile_item": "• «{name}» — {caps}\n   Members: {members}",
    "assignprofile_usage": "Usage: /assignprofile [reply|@user|id] <profile>",
    "assignprofile_notfound_profile": "No profile named «{name}». Create it first with /createprofile.",
    "assignprofile_done": "✅ Profile «{profile}» assigned to {name}.",
    "unassignprofile_usage": "Usage: /unassignprofile [reply|@user|id]",
    "unassignprofile_notfound": "This user has no profile assigned.",
    "unassignprofile_done": "➖ Profile removed from {name}.",
    "myperms_with_profile": "Your rank: {rank}\nAssigned profile: «{profile}»\nCapabilities: {caps}",
    "myperms_no_profile": "Your rank: {rank}\nNo custom profile assigned.",

    # Priority 5, Item 26 — Reports
    "report_need_reply": "Please reply to the message you want to report.",
    "report_self": "You can't report yourself! 😅",
    "report_already": "You've already reported this message recently.",
    "report_done": "✅ Your report was sent to the admins. Thank you!",
    "report_alert_header": "🚩 New report #{id}\nReporter: {reporter}\nReported: {target}\nReason: {reason}",
    "alert_multi_reports_text": "{target} has received {count} separate reports in the last {window}s.",
    "reports_empty": "No open reports.",
    "reports_header": "🚩 Open reports:",
    "report_item": "• #{id} [{when}] {reporter} → {target} ({reason})",
    "btn_report_mute": "🔇 Mute",
    "btn_report_ban": "🚫 Ban",
    "btn_report_delete": "🗑️ Delete message",
    "btn_report_dismiss": "✖️ Dismiss",
    "report_not_found": "This report no longer exists or was already handled.",
    "report_action_done_dismiss": "✖️ Report #{id} on {target} dismissed.",
    "report_action_done_mute": "🔇 {target} was muted ({minutes}m) from the report.",
    "report_action_done_ban": "🚫 {target} was banned from the report.",
    "report_action_done_delete": "🗑️ The reported message from {target} was deleted.",

    # Priority 5, Item 27 — Admin Alerts
    "setalertchannel_usage": "Usage: /setalertchannel <channel＿id> (send with no arguments to clear)",
    "setalertchannel_done": "✅ Alert destination set to {channel}.",
    "setalertchannel_cleared": "✅ Alert destination cleared (alerts will be sent in this group / log channel).",
    "alerts_empty": "No alerts recorded yet.",
    "alerts_header": "🔔 Recent alerts:",
    "alert_type_multi_reports": "Multiple Reports",
    "alert_type_suspicious": "Suspicious Activity",
    "alert_type_security": "Security Event",
    "alert_type_abnormal": "Abnormal Behavior",
    "alert_type_admin_abuse": "Possible Admin Abuse",
    "admin_abuse_alert_detail": "🧑‍💼 {name} performed {count} destructive actions (ban/mute/kick/warn) in the last {minutes} minutes — their account may be compromised, or this may be intentional abuse. Please review.",
    "alert_type_raid": "Raid Detected",
    "alert_type_generic": "Alert",

    # Priority 5, Item 28 — Import / Export Settings
    "exportsettings_caption": "📦 Group settings export.\n{summary}",
    "importsettings_usage": "Reply to a .json settings file with /importsettings.",
    "importsettings_invalid_json": "❌ Couldn't read this file as valid JSON.",
    "importsettings_invalid_schema": "❌ Invalid settings file (problem: {detail}).",
    "importsettings_confirm_prompt": "⚠️ This will *replace* this group's current settings with:\n{summary}\nAre you sure?",
    "importsettings_cancelled": "❌ Import cancelled.",
    "importsettings_done": "✅ Settings imported successfully.\n{summary}",
    "btn_import_confirm": "✅ Confirm import",
    "btn_import_cancel": "❌ Cancel",

    # Personal admin panel
    "panel_header": "🛠 {name}'s admin panel\n\nChoose a section:",
    "panel_btn_settings": "⚙️ Settings",
    "panel_btn_locks": "🔒 Locks",
    "panel_btn_filters": "🚫 Filters",
    "panel_btn_rules": "📜 Rules",
    "panel_btn_reports": "🚩 Open reports",
    "panel_btn_logs": "🗒 Logs",
    "panel_btn_roles": "👮 Moderators",
    "panel_btn_daily": "🔔 Daily Notify",
    "panel_daily_hint": "To change settings: /dailynotify",
    "panel_btn_back": "🔙 Back",
    "panel_btn_close": "❌ Close",
    "panel_not_yours": "This panel belongs only to whoever opened it.",
    "panel_closed": "Panel closed.",

    # ==================== NEXOR Copilot (AI Module) ====================
    "ai_panel_header": "🤖 NEXOR Copilot\nYour admins' AI assistant — choose a section:",
    "ai_btn_analyze": "🔍 Analyze Message",
    "ai_btn_explain": "❓ Explain Action",
    "ai_btn_health": "📊 Group Health",
    "ai_btn_reports": "🗂 Review Reports",
    "ai_btn_optimize": "🛠 Optimize Rules",
    "ai_btn_incident": "🚨 Analyze Incident",
    "ai_btn_rule": "➕ Rule Advisor",
    "ai_btn_close": "❌ Close",
    "ai_working": "⏳ Analyzing with AI...",

    "ai_guide_analyze": "🔍 Analyze Message\nReply to the message you want checked and send:\n/aicheck",
    "ai_guide_explain": "❓ Explain Action\nExample:\n/aiexplain @username why was this user warned?\n(or reply to the user's message and send /aiexplain)",
    "ai_guide_rule": "➕ Rule Advisor\nDescribe your problem, e.g.:\n/airule we're getting a lot of advertisement spam",

    "ai_need_reply": "Reply to a message to run Analyze Message.",
    "ai_explain_usage": "No target user found. Reply to their message or send:\n/aiexplain @username [question]",
    "ai_explain_default_question": "Why was a recent moderation action taken on {name}?",
    "ai_rule_usage": "Describe the problem, e.g.:\n/airule we're getting a lot of advertisement spam",
    "ai_reports_empty_for_ai": "There are no open reports to analyze.",
    "ai_optimize_empty": "There are no Auto Action Rules to review.",
    "ai_incident_empty": "No notable recent activity found to analyze.",
    "ai_rule_not_applicable": "⚠️ This isn't something NEXOR's current rule engine can cover; try a more specific description, or add a rule manually with /addautoaction.",
    "ai_rule_cancelled": "Cancelled; no rule was created.",
    "ai_rule_created": "✅ Rule #{id} created.\nTrigger: {condition}\nAction: {action}",
    "ai_dismissed": "Dismissed; no action was taken on the group.",
    "ai_reason_copilot": "NEXOR Copilot suggestion (admin-approved)",
    "ai_action_done_delwarn": "🗑️ Message deleted and {name} was warned.",

    "ai_plan_status": "This group's current AI plan: {plan}",
    "ai_plan_set_done": "✅ This group's AI plan set to \"{plan}\".",
    "ai_plan_set_invalid": "Invalid plan. Use one of: free, pro, premium",

    "ai_err_plan_not_allowed": "⛔️ This feature isn't available on this group's current plan.",
    "ai_err_rate_limited": "⏳ Your daily AI request limit is used up; try again tomorrow.",
    "ai_err_not_configured": "⚙️ AI isn't configured for this group's plan yet (tell the bot's admin).",
    "ai_err_provider_error": "⚠️ Couldn't reach the AI service; try again in a moment.",
    "ai_err_bad_response": "⚠️ The AI's response wasn't understandable; try again.",
    "ai_err_unknown": "⚠️ Unexpected NEXOR Copilot error; it has been logged.",
    "ai_err_action_failed": "⚠️ Running the action failed.",

    "ai_risk_low": "Low", "ai_risk_medium": "Medium", "ai_risk_high": "High",
    "ai_priority_high": "High Priority", "ai_priority_suspicious": "Suspicious",
    "ai_priority_low": "Low Priority", "ai_priority_false": "Likely False Report",
    "ai_action_none": "No action", "ai_action_delete": "Delete message",
    "ai_action_warn": "Warn", "ai_action_delete_warn": "Delete + Warn",
    "ai_action_mute": "Mute", "ai_action_ban": "Ban",
    "ai_trend_up": "Rising 📈", "ai_trend_down": "Falling 📉", "ai_trend_stable": "Stable ➖",

    "ai_btn_apply_delwarn": "🗑️+⚠️ Delete & Warn",
    "ai_btn_apply_mute": "🔇 Mute",
    "ai_btn_apply_ban": "🚫 Ban",
    "ai_btn_dismiss": "Dismiss",
    "ai_btn_confirm": "✅ Confirm & create",
    "ai_btn_cancel": "❌ Cancel",

    "ai_analyze_message_result": (
        "🤖 NEXOR Copilot analysis\n\n"
        "Risk: {risk}\n"
        "Spam: {spam}%\n"
        "Advertisement: {ad}%\n"
        "Suspicious: {suspicious}%\n"
        "Toxic: {toxic}%\n\n"
        "Summary: {summary}\n\n"
        "💡 Recommendation: {action}\n"
        "Reason: {reason}\n\n"
        "The final call is yours:"
    ),
    "ai_explain_result": "🤖 NEXOR Copilot explanation\n\n{explanation}\n\nKey factors:\n{factors}",
    "ai_reports_header": "🗂 Open reports, categorized:",
    "ai_reports_item": "• #{id} — {priority}: {reason}",
    "ai_reports_summary": "\nSummary: {summary}",
    "ai_health_result": (
        "📊 Group health\n\n"
        "Spam level: {spam_level}\n"
        "Violation trend: {trend}\n\n"
        "Risks:\n{risks}\n\n"
        "💡 Recommendation: {recommendation}"
    ),
    "ai_rule_advisor_result": (
        "➕ Rule Advisor suggestion\n\n"
        "Trigger: {trigger}\n"
        "Action: {action}\n"
        "Scope: {scope}\n"
        "Reason: {reason}\n"
        "Confidence: {confidence}%\n\n"
        "Confirm to create this rule:"
    ),
    "ai_optimize_result": (
        "🛠 Rule Optimization result\n\n"
        "Duplicates: {duplicates}\n"
        "Conflicts: {conflicts}\n"
        "Firing too often: {too_frequent}\n"
        "Dangerous configs: {dangerous}\n\n"
        "Suggestions:\n{suggestions}"
    ),
    "ai_incident_result": (
        "🚨 Incident summary\n\n"
        "{summary}\n\n"
        "Severity: {severity}\n\n"
        "Timeline:\n{timeline}\n\n"
        "💡 Recommendation: {recommendation}"
    ),
    "ai_local_summary_safe": "Short message with no risk signals; classified low-risk locally.",
    "ai_local_reason_no_ai_needed": "AI review wasn't necessary.",

    # ==================== Guide Panel ====================
    "guide_intro": "📖 NEXOR Guide\nTap a section to see what it does — and tap any keyword below it to see the word you'd actually type in chat instead of a command.",
    "guide_btn_locks": "🔒 Locks & Filters",
    "guide_btn_moderation": "🛡 Moderation & Punishments",
    "guide_btn_roles": "👮 Promote / Demote",
    "guide_btn_settings": "⚙️ Group Settings",
    "guide_btn_security": "🚨 Anti-Raid & Lockdown",
    "guide_btn_rules": "📜 Group Rules",
    "guide_btn_autoreply": "💬 Keywords & Custom Cmds",
    "guide_btn_channel": "📢 Channel & Posts",
    "guide_btn_autoactions": "🤖 Automatic Actions",
    "guide_btn_notes": "📝 Notes",
    "guide_btn_reports_logs": "🚩 Reports & Logs",
    "guide_btn_federation": "🌐 Federation",
    "guide_btn_ai_copilot": "🧠 NEXOR Copilot (AI)",
    "guide_title_locks": "🔒 Locks & Filters",
    "guide_title_moderation": "🛡 Moderation & Punishments",
    "guide_title_roles": "👮 Promote / Demote",
    "guide_title_settings": "⚙️ Group Settings",
    "guide_title_security": "🚨 Anti-Raid & Lockdown",
    "guide_title_rules": "📜 Group Rules",
    "guide_title_autoreply": "💬 Keywords & Custom Cmds",
    "guide_title_channel": "📢 Channel & Posts",
    "guide_title_autoactions": "🤖 Automatic Actions",
    "guide_title_notes": "📝 Notes",
    "guide_title_reports_logs": "🚩 Reports & Logs",
    "guide_title_federation": "🌐 Federation",
    "guide_title_ai_copilot": "🧠 NEXOR Copilot (AI)",
    "guide_desc_locks": "Lock risky content — links, photos, stickers, forwards and more — so it's deleted the instant it's sent. Add word or domain filters for anything else you want gone automatically.",
    "guide_desc_moderation": "Warn, mute, kick or ban troublemakers, wipe a single message or purge a whole range at once. The full toolbox for keeping the chat clean.",
    "guide_desc_roles": "Promote trusted members to internal moderator, demote them later, and check who holds which role or permission at a glance.",
    "guide_desc_settings": "One screen with everything about this group — locks, filters, captcha, warnings, language — plus quick access to the admin panel.",
    "guide_desc_security": "Automatic raid detection catches sudden join floods; lockdown seals the whole group in one tap when things get out of hand.",
    "guide_desc_rules": "Write your group's rules once, show them to anyone who asks, or wipe them clean and start over.",
    "guide_desc_autoreply": "Teach the bot to answer certain words on its own, or build entirely new text commands of your own.",
    "guide_desc_channel": "Link a channel to your group, publish or schedule posts, edit or remove them later, and track how the channel is doing.",
    "guide_desc_autoactions": "Simple if-this-then-that rules — the bot reacts to a message type or a warning count without you lifting a finger.",
    "guide_desc_notes": "Save a chunk of text or media once, then recall it instantly with a short tag whenever you need it again.",
    "guide_desc_reports_logs": "Members flag trouble with one tap; you get a running audit trail of every action any admin has taken.",
    "guide_desc_federation": "Share a single ban list across many groups — ban someone once, and they're banned everywhere in the federation.",
    "guide_desc_ai_copilot": "An AI assistant built for admins: analyzes messages, explains past actions, reviews your rules and suggests new ones.",
    "guide_kw_lock": "Lock a content type (e.g. links, photos) so it's auto-deleted.",
    "guide_kw_unlock": "Remove an active lock.",
    "guide_kw_locks": "Show every lock currently active in this group.",
    "guide_kw_filter": "Add a banned word or phrase that's auto-deleted.",
    "guide_kw_stopfilter": "Remove a word filter.",
    "guide_kw_filters": "List every active word filter.",
    "guide_kw_domains": "Show or manage the list of blocked domains.",
    "guide_kw_forwardrules": "Show the allow/block rules for forwarded messages.",
    "guide_kw_warn": "Give a member a warning.",
    "guide_kw_unwarn": "Remove one warning from a member.",
    "guide_kw_warns": "Show how many warnings a member has.",
    "guide_kw_mute": "Silence a member for a set time.",
    "guide_kw_unmute": "Lift a member's mute.",
    "guide_kw_ban": "Remove a member from the group permanently.",
    "guide_kw_unban": "Let a banned member back in.",
    "guide_kw_kick": "Remove a member (they can rejoin).",
    "guide_kw_del": "Delete a message — reply to it first.",
    "guide_kw_purge": "Bulk-delete a whole range of messages at once.",
    "guide_kw_promote": "Promote a member to internal moderator.",
    "guide_kw_demote": "Remove a member's moderator role.",
    "guide_kw_roles": "List everyone with an internal moderator role.",
    "guide_kw_profiles": "Manage custom permission profiles.",
    "guide_kw_myperms": "Show your own current permissions.",
    "guide_kw_settings": "Overview of every setting in this group.",
    "guide_kw_setlang": "Change the group's language.",
    "guide_kw_captcha": "Turn the new-member captcha on or off.",
    "guide_kw_goodbye": "Turn the farewell message on or off.",
    "guide_kw_adminpanel": "Open the quick admin shortcuts panel.",
    "guide_kw_antiraid": "Turn automatic raid detection on or off.",
    "guide_kw_lockdown": "Instantly lock the entire group.",
    "guide_kw_unlockchat": "Lift an active lockdown.",
    "guide_kw_rules": "Show the group's rules.",
    "guide_kw_setrules": "Write or update the group's rules.",
    "guide_kw_clearrules": "Delete the group's rules.",
    "guide_kw_addkeyword": "Add a word that triggers an automatic reply.",
    "guide_kw_delkeyword": "Remove an auto-reply keyword.",
    "guide_kw_keywords": "List every auto-reply keyword.",
    "guide_kw_addcmd": "Create your own custom text command.",
    "guide_kw_delcmd": "Delete a custom command.",
    "guide_kw_cmds": "List every custom command.",
    "guide_kw_setanswer": "Set up an auto-answer (text/media, up to 20 random replies) for a keyword.",
    "guide_kw_answerlist": "Show the list of configured auto-answer keywords.",
    "guide_kw_delanswer": "Remove one auto-answer by its keyword.",
    "guide_kw_cleananswerlist": "Clear all auto-answers in this group.",
    "guide_kw_setchannel": "Link a channel to this group.",
    "guide_kw_post": "Publish a post to the linked channel.",
    "guide_kw_schedulepost": "Schedule a post for later.",
    "guide_kw_editpost": "Edit an already-published post.",
    "guide_kw_delpost": "Delete a published post.",
    "guide_kw_channelstats": "Show stats for the linked channel.",
    "guide_kw_addautoaction": "Create an automatic if-this-then-that rule.",
    "guide_kw_delautoaction": "Remove an automatic rule.",
    "guide_kw_autoactions": "List every automatic rule.",
    "guide_kw_save": "Save a reusable note or snippet.",
    "guide_kw_get": "Fetch a saved note by its name.",
    "guide_kw_notes": "List every saved note.",
    "guide_kw_clear": "Delete a saved note.",
    "guide_kw_report": "Report a message to the admins.",
    "guide_kw_reports": "Show open, unresolved reports.",
    "guide_kw_alerts": "Manage where admin alerts are sent.",
    "guide_kw_adminabuseprotection": "Alerts you if an admin suddenly performs a burst of destructive actions.",
    "guide_kw_logs": "Show the most recent admin actions.",
    "guide_kw_exportsettings": "Export this group's settings as a backup.",
    "guide_kw_setlogchannel": "Set the channel that receives the audit log.",
    "guide_kw_fnew": "Create a new federation (shared ban list).",
    "guide_kw_fjoin": "Join this group to an existing federation.",
    "guide_kw_fleave": "Leave the current federation.",
    "guide_kw_finfo": "Show info about the current federation.",
    "guide_kw_fban": "Ban a user across the whole federation.",
    "guide_kw_funban": "Unban a user across the whole federation.",
    "guide_kw_copilot": "Open the NEXOR Copilot AI assistant menu.",
    "guide_kw_aicheck": "Ask the AI to analyze a message — reply to it first.",
    "guide_kw_aiexplain": "Ask the AI why an action was taken on someone.",
    "guide_kw_aireports": "Let the AI triage open reports by priority.",
    "guide_kw_aihealth": "Get an AI summary of the group's health.",
    "guide_kw_airule": "Describe a problem, get an AI-suggested rule.",
    "guide_kw_aioptimize": "Ask the AI to review your automatic rules.",
    "guide_kw_aiincident": "Get an AI summary of a recent incident.",
    "guide_kw_aiplan": "Show or set this group's AI plan.",

    # --- Natural Language intent layer (nlu/) ---
    "nlu_confirm_mute": "Mute {name} for {duration}?",
    "nlu_btn_confirm": "✅ Confirm",
    "nlu_btn_cancel": "❌ Cancel",
    "nlu_ask_duration": "For how long should I mute {name}? (e.g. 30m, 2h, 1d)",
    "nlu_context_expired": "⌛️ This request has expired. Please try again.",
    "nlu_not_your_confirmation": "This button isn't for your request.",
    "nlu_need_reply_target": "❗️Reply to that user's message so I know who you mean.",
    "nlu_fallback_intro": "🤔 I didn't quite get that. Try /help, or say it more directly.",
    "nlu_confirm_unmute": "Unmute {name}?",
    "nlu_confirm_ban": "Ban {name} ({duration})?",
    "nlu_confirm_unban": "Unban {name}?",
    "nlu_confirm_kick": "Kick {name} from the group?",
    "nlu_action_cancelled": "❌ Cancelled; nothing was done.",
    "nlu_confirm_delete": "Delete this message?",
    "nlu_delete_done": "🗑 Message deleted.",
    "nlu_confirm_setrules": "Replace the group rules with:\n\n{text}",
    "nlu_setrules_format_hint": "To set rules this way, use the format:\n«set rules: your rule text» (everything after the colon is saved exactly as written).",

    # --- Onboarding (handlers/onboarding.py + onboarding_logic.py) ---
    "onboarding_welcome": "👋 Hey! I'm NEXOR — I help keep this group safe and organized: moderation, anti-spam, welcome/rules, auto-answers, and more.",
    "onboarding_needs_admin": "⚠️ I'm not an admin here yet, so most of that won't work. Make me an admin (at least: delete messages, restrict members, invite users, pin messages) and I'll pick up from there.",
    "onboarding_missing_perms": "⚠️ I'm an admin, but I'm missing: {perms}. A few features need those — you can grant them anytime from group settings.",
    "onboarding_all_set": "✅ I've got the permissions I need. Let's set up the basics.",
    "onboarding_btn_security": "🛡 Set up security",
    "onboarding_btn_help": "❓ What can you do?",
    "perm_restrict": "restrict members (mute/kick/ban)",
    "perm_delete": "delete messages",
    "perm_invite": "invite users",
    "perm_pin": "pin messages",
    "err_unexpected": "⚠️ Something went wrong while doing that. Please try again — if it keeps happening, let a group admin know.",
    "nlu_delanswer_format_hint": "To delete an auto-answer this way, use the format:\n«remove answer: keyword» (the exact keyword to delete).",
    "nlu_confirm_delanswer": "Delete the auto-answer for keyword «{keyword}»?",

    # --- Payments / /buyplan (handlers/payments.py) ---
    "buyplan_header": "👑 Upgrade NEXOR Copilot plan\nChoose a plan:",
    "buyplan_use_pv": "🔒 Buying a subscription only works in the bot's private chat. Open a PV with the bot and run /buyplan there.",
    "buyplan_choose_method": "{plan} plan — choose a payment method:",
    "buyplan_stars_sent": "⭐ A Stars invoice was sent to your private chat with the bot. Complete the payment there.",
    "buyplan_ton_sent": "💎 TON payment instructions (wallet address + memo code) were sent to your private chat with the bot.",
    "buyplan_ton_unavailable": "⚠️ TON payment isn't available for this plan right now.",
    "buyplan_dm_failed": "⚠️ I couldn't send you a private message. Start a private chat with the bot with /start first, then try /buyplan again.",
    "buyplan_closed": "Closed.",
    # ---- Ads system (added) ----
    'ads_btn_cancel': '❌ Cancel',
    'ads_btn_free': '🆓 Post a free ad (once a day)',
    'ads_btn_paid': '💳 Buy ads (1 to 5 times a day)',
    'ads_intro': '📢 NEXOR Ads System\n\nAds only show up in groups on the free plan (Pro/Premium groups never see ads).\nA free ad runs once a day; a paid ad can run 1 to 5 times a day (price scales accordingly).\n\nWhich one would you like?',
    'ads_ask_banner': "🖼 First, send a banner (photo) for the ad.\nIf you don't want a banner, type: skip",
    'ads_banner_invalid': 'Send a photo, or type «skip» to continue without a banner.',
    'ads_ask_text': '✍️ Now send the ad text (what will be shown inside groups).',
    'ads_text_empty': "The ad text can't be empty. Send it again.",
    'ads_times_btn': '{n}×/day',
    'ads_ask_times': '📅 How many times a day should your ad run? (more = pricier)',
    'ads_free_submitted': "✅ Free ad #{id} was submitted for admin review.\nOnce approved, it'll show up once a day in free groups connected to the bot.",
    'ads_duration_btn': '{days} days — ⭐{stars}',
    'ads_ask_duration': 'Choose how long the ad should run (selected frequency: {times}×/day):',
    'ads_btn_pay_stars': '⭐ Pay with Stars ({stars})',
    'ads_btn_pay_ton': '💎 Pay with TON ({ton})',
    'ads_order_summary': 'Order summary #{id}:\n• Frequency: {times}×/day\n• Duration: {days} days\n• Price: ⭐{stars}',
    'ads_order_summary_ton_suffix': ' / 💎{ton} TON',
    'ads_order_summary_footer': '\n\nChoose a payment method:',
    'ads_order_invalid': '⚠️ This order is no longer valid.',
    'ads_sending_invoice': '⭐ Sending the Telegram Stars invoice...',
    'ads_invoice_title': '📢 Ad purchase — order #{id}',
    'ads_invoice_desc': 'Buying ad slots inside groups connected to NEXOR (free plan only).',
    'ads_invoice_label': 'NEXOR Ads',
    'ads_ton_disabled': "⚠️ TON payment isn't enabled right now, or this order isn't valid.",
    'ads_ton_payment_info': "💎 Pay with TON — order #{id}\n\nAmount: {amount} TON\nWallet address: {address}\n⚠️ Make sure to enter this exact code in the transfer's Comment/Memo:\n{memo}\n\nDirect link: {link}\n\nOnce the transfer is received, it's checked automatically and the ad moves into the admin review queue.",
    'ads_cancelled': 'Cancelled.',
    'ads_ton_confirmed': '✅ TON payment confirmed! Ad order #{id} was sent for admin review.',
    'ads_admin_none_pending': 'No ads waiting for review.',
    'ads_btn_approve': '✅ Approve',
    'ads_btn_reject': '❌ Reject',
    'ads_kind_free': '🆓 Free',
    'ads_kind_paid': '💳 Paid',
    'ads_admin_caption': '#{id} — {kind}\nFrequency/day: {times} — Duration: {days} days\n\n{text}',
    'ads_approved_toast': 'Approved ✅',
    'ads_approved_notify': '✅ Ad #{id} was approved and will show up in free groups on schedule.',
    'ads_rejected_toast': 'Rejected ❌',
    'ads_none_yet': "You haven't posted any ads yet. Start with /ads.",
    'ads_status_draft': 'Draft',
    'ads_status_pending_payment': 'Awaiting payment',
    'ads_status_pending_review': 'In review',
    'ads_status_active': 'Active',
    'ads_status_rejected': 'Rejected',
    'ads_status_expired': 'Expired',
    'ads_status_active2': '✅ Active',
    'ads_status_rejected2': '❌ Rejected',
    'ads_status_expired2': '⌛ Expired',
    'ads_myads_header': '📋 Your ads:\n',
    'ads_myads_line': '#{id} — {status} — {times}×/day — {days} days',
    'ads_myads_footer': '\nTo see stats for an ad: /adstats <ad number> — e.g. /adstats {id}',
    'ads_stats_usage': 'Please include the ad number too, e.g.:\n/adstats 3\n\nYou can see your ad numbers with /myads.',
    'ads_stats_not_found': "Couldn't find that ad, or it's not yours.",
    'ads_stats_title': '📊 Stats for ad #{id}',
    'ads_stats_status': 'Status: {status}',
    'ads_stats_quota': 'Daily quota: {quota}×/day',
    'ads_stats_today': 'Sent today: {today} of {quota}',
    'ads_stats_total': 'Total views so far: {total}',
    'ads_stats_unique': 'Unique groups this ad has been shown in: {n}',
    'ads_stats_perday_header': '\nDaily breakdown (recent days):',
    'ads_stats_perday_line': '  {day}: {count} times',
    'ads_stats_no_views': "\nNo views recorded for this ad yet (or it isn't approved/active yet).",
    'ads_stars_confirmed': '✅ Payment confirmed! Ad order #{id} was sent for admin review.',
    'err_invalid_language': 'Invalid language.',
    # ---- Buyplan payments (added) ----
    'buyplan_invoice_title': '👑 {plan} subscription ({months} mo.)',
    'buyplan_invoice_desc': 'Upgrade the group to the {plan} plan for {months} month(s).',
    'buyplan_invoice_price_label': '{plan} — {months} mo.',
    'err_order_invalid': 'This order is no longer valid.',
    'buyplan_stars_confirmed': '✅ Payment confirmed!\n👑 The group was upgraded to {plan}.',
    'buyplan_stars_confirmed_groups': '✅ Payment confirmed!\n👑 {plan} was activated on {count} group(s) you own.',
    'buyplan_stars_confirmed_no_groups': '✅ Payment confirmed and {plan} was purchased, but no group was found where the bot is active and you own it.',
    'buyplan_card_order_not_found': '⚠️ Order not found, or it was already processed.',
    'buyplan_card_confirmed_dm': '✅ Card payment confirmed!\n👑 The group was upgraded to {plan}.',
    'buyplan_card_admin_confirmed': '✅ Order #{id} confirmed and {plan} activated.',
    'buyplan_card_admin_rejected': '❌ Order #{id} rejected.',
    'buyplan_card_none_pending': 'No card orders waiting for review.',
    'buyplan_card_pending_header': '💳 Card orders awaiting confirmation:\n',
    'buyplan_card_pending_line': '#{id} — {plan} × {months} mo. — code: {code}',
    'buyplan_ton_instructions': "💎 Buy {plan} subscription with TON\n\nAmount: {amount} TON\nWallet address: {address}\n⚠️ Make sure to enter this exact code in the transfer's Comment/Memo:\n{memo}\n\nOr use this link in your wallet:\n{link}\n\nOnce received, the transaction is checked automatically and the subscription is activated (may take a few minutes).",
    'buyplan_ton_confirmed': '✅ TON payment confirmed!\n👑 The group was upgraded to {plan}.',
    'buyplan_ton_confirmed_groups': '✅ TON payment confirmed!\n👑 {plan} was activated on {count} group(s) you own.',
    'buyplan_ton_confirmed_no_groups': '✅ TON payment confirmed and {plan} was purchased, but no group was found where the bot is active and you own it.',
    'buyplan_card_header': '💳 Buy {plan} subscription by card transfer\n',
    'buyplan_card_amount': 'Amount: {amount} Toman',
    'buyplan_card_number': 'Card number: {number}',
    'buyplan_card_holder': 'Account holder: {holder}',
    'buyplan_card_reference': '\nOrder reference code: {ref}',
    'buyplan_card_instructions': 'After transferring, send a photo of the receipt along with the reference code above to the bot admin so your subscription can be confirmed and activated manually.',
    # ---- Command menu descriptions (added) ----
    'cmd_desc_start': 'Start using the bot',
    'cmd_desc_help': 'Command help',
    'cmd_desc_settings': 'Group settings',
    'cmd_desc_setlang': 'Change group language (admin)',
    'cmd_desc_rules': 'Group rules',
    'cmd_desc_warn': 'Warn a user',
    'cmd_desc_unwarn': 'Remove one warning',
    'cmd_desc_warns': "View a user's warnings",
    'cmd_desc_mute': 'Mute a user',
    'cmd_desc_unmute': 'Unmute a user',
    'cmd_desc_ban': 'Ban a user',
    'cmd_desc_unban': 'Unban a user',
    'cmd_desc_kick': 'Kick a user',
    'cmd_desc_del': 'Delete a message (reply)',
    'cmd_desc_purge': 'Bulk-delete messages',
    'cmd_desc_lock': 'Lock a content type',
    'cmd_desc_unlock': 'Unlock a content type',
    'cmd_desc_locks': 'Show active locks',
    'cmd_desc_promote': 'Promote to internal admin',
    'cmd_desc_demote': 'Demote from internal admin',
    'cmd_desc_roles': 'List internal admins',
    'cmd_desc_logs': 'Recent admin actions',
    'cmd_desc_copilot': '🤖 NEXOR Copilot (admin AI assistant)',
    'cmd_desc_buyplan': '👑 Upgrade plan (Stars / TON) — no ads',
    'cmd_desc_ads': '📢 Post a free ad or buy advertising',
    'cmd_desc_myads': '📋 My ads',
    'cmd_desc_adstats': '📊 Stats for an ad',
    'cmd_desc_adadmin': '🛠 Ad review queue (admin)',

    # ==================== Daily Notify ====================
    "day_mon": "Monday", "day_tue": "Tuesday", "day_wed": "Wednesday", "day_thu": "Thursday",
    "day_fri": "Friday", "day_sat": "Saturday", "day_sun": "Sunday",
    "month_g_1": "January", "month_g_2": "February", "month_g_3": "March", "month_g_4": "April",
    "month_g_5": "May", "month_g_6": "June", "month_g_7": "July", "month_g_8": "August",
    "month_g_9": "September", "month_g_10": "October", "month_g_11": "November", "month_g_12": "December",
    "month_j_1": "Farvardin", "month_j_2": "Ordibehesht", "month_j_3": "Khordad", "month_j_4": "Tir",
    "month_j_5": "Mordad", "month_j_6": "Shahrivar", "month_j_7": "Mehr", "month_j_8": "Aban",
    "month_j_9": "Azar", "month_j_10": "Dey", "month_j_11": "Bahman", "month_j_12": "Esfand",
    "date_format_gregorian": "{weekday}, {day} {month} {year}",
    "date_format_jalali": "{weekday}, {day} {month} {year}",

    "daily_date_line": "📅 Today: {date}",
    "daily_occasion_line": "🎉 Occasion: {occasion}",

    "daily_price_header": "💰 Today's Prices",
    "daily_price_line": "• {asset}: {value} {unit}",
    "daily_price_footer": "Source: {sources}",

    "daily_news_header": "📰 Today's News",
    "daily_news_item": "{n}. {title}",
    "daily_news_summary": "   {summary}",
    "daily_news_source": "   🔗 Source: {source}",

    "asset_gold18": "18K Gold", "asset_usd": "US Dollar (USD)", "asset_eur": "Euro (EUR)",
    "asset_usdt": "Tether (USDT)", "asset_ton": "Toncoin (TON)", "asset_stars": "Telegram Stars",
    "asset_btc": "Bitcoin (BTC)", "asset_eth": "Ethereum (ETH)",
    "unit_toman": "Toman", "unit_usd": "USD",

    "panel_not_owner": "This panel only responds to the person who opened it.",

    "dn_menu_header": "🔔 *Daily Notify*",
    "dn_menu_prices": "💰 Prices: {state} — at {time}",
    "dn_menu_assets_line": "   Active assets: {assets}",
    "dn_menu_news": "📰 News: {state} — at {time}",
    "dn_menu_timezone": "🌍 Timezone: {tz}",
    "dn_menu_date_flags": "📅 Date/Occasion — Prices: {dp}/{op}   News: {dn}/{on}",

    "dn_btn_toggle_prices": "💰 Toggle prices",
    "dn_btn_toggle_news": "📰 Toggle news",
    "dn_btn_assets": "🪙 Choose assets",
    "dn_btn_flags": "📅 Date/occasion settings",
    "dn_btn_test_price": "🧪 Test price",
    "dn_btn_test_news": "🧪 Test news",
    "dn_btn_help": "❓ Help",
    "dn_btn_close": "❌ Close",

    "dn_assets_header": "🪙 Tap an asset to enable/disable it:",
    "dn_flags_header": "📅 Set date/occasion display separately for prices and news:",
    "dn_flag_date_price": "Date in price message",
    "dn_flag_occasion_price": "Occasion in price message",
    "dn_flag_date_news": "Date in news message",
    "dn_flag_occasion_news": "Occasion in news message",

    "dn_help_text": (
        "📖 *Daily Notify Help*\n\n"
        "💰 Prices and 📰 News are sent to this group every day at the times you set.\n\n"
        "/setpricetime HH:MM — price send time\n"
        "/setnewstime HH:MM — news send time\n"
        "/setdailytz timezone — e.g. Asia/Tehran (defaults based on group language)\n"
        "/testdailyprice   /testdailynews — send a test message now\n"
        "/dailyassets — choose which assets are shown\n"
        "Everything else (on/off, date/occasion) can be changed with the buttons above."
    ),
    "dn_toast_saved": "✅ Saved.",
    "dn_toast_sending": "⏳ Sending...",
    "dn_test_no_data": "⚠️ No valid data available right now (provider unavailable, or nothing new yet).",

    "dn_log_toggle_prices": "Daily price notify: {state}",
    "dn_log_toggle_news": "Daily news notify: {state}",
    "dn_log_settime": "{what} send time: {time}",
    "dn_log_settz": "Daily notify timezone: {tz}",

    "dn_settime_usage": "Usage: {cmd} HH:MM (e.g. 09:00)",
    "dn_settime_invalid": "⛔️ Invalid time format. Use HH:MM (e.g. 09:00).",
    "dn_settime_done": "✅ Send time set to {time}.",
    "dn_settz_usage": "Usage: /setdailytz timezone (e.g. Asia/Tehran)",
    "dn_settz_invalid": "⛔️ Invalid timezone. Enter a valid IANA timezone like Asia/Tehran.",
    "dn_settz_done": "✅ Group timezone: {tz}",

    "cmd_desc_dailynotify": "🔔 Daily notify settings (prices/news)",
}


# ---------------------------------------------------------------------------
# TEXT_TRIGGERS (English) — کلمه/عبارتی که کاربر به‌جای دستور "/" تایپ می‌کند
# تا با همون تابع handlers/text_commands.py وصل بشه. هر شناسه (کلید) دقیقاً
# با همون نامی که در handlers/text_commands.py::COMMANDS استفاده شده باید یکی باشه.
# ---------------------------------------------------------------------------
TEXT_TRIGGERS = {
    "help": ["help", "guide"],
    "settings": ["settings"],
    "warn": ["warn"],
    "unwarn": ["unwarn"],
    "warns": ["warns"],
    "mute": ["mute"],
    "unmute": ["unmute"],
    "ban": ["ban"],
    "unban": ["unban"],
    "kick": ["kick"],
    "del": ["delete"],
    "purge": ["purge"],
    "promote": ["promote"],
    "demote": ["demote"],
    "roles": ["moderators"],
    "logs": ["logs"],
    "setlang": ["set language"],
    "lock": ["lock"],
    "unlock": ["unlock"],
    "locks": ["locks"],
    "filter": ["filter"],
    "stopfilter": ["remove filter"],
    "filters": ["filters"],
    "domains": ["blocked domains"],
    "forwardrules": ["forward rules"],
    "antiraid": ["anti raid"],
    "lockdown": ["lockdown"],
    "unlockchat": ["open group"],
    "captcha": ["captcha"],
    "goodbye": ["goodbye"],
    "rules": ["rules"],
    "setrules": ["set rules"],
    "clearrules": ["clear rules"],
    "addkeyword": ["add keyword"],
    "delkeyword": ["remove keyword"],
    "keywords": ["keywords"],
    "setanswer": ["setanswer", "set answer"],
    "answerlist": ["answerlist", "answer list"],
    "cleananswerlist": ["clean answerlist", "clean answer list"],
    "delanswer": ["delanswer", "remove answer"],
    "addcmd": ["add command"],
    "delcmd": ["remove command"],
    "cmds": ["commands"],
    "setchannel": ["set channel"],
    "post": ["post"],
    "schedulepost": ["schedule post"],
    "editpost": ["edit post"],
    "delpost": ["delete post"],
    "channelstats": ["channel stats"],
    "addautoaction": ["add auto action"],
    "delautoaction": ["remove auto action"],
    "autoactions": ["auto actions"],
    "profiles": ["profiles"],
    "myperms": ["my permissions"],
    "report": ["report"],
    "reports": ["reports"],
    "alerts": ["alerts"],
    "exportsettings": ["export settings"],
    "save": ["save"],
    "get": ["get"],
    "notes": ["notes"],
    "clear": ["clear note"],
    "setlogchannel": ["set log channel"],
    "fnew": ["new federation"],
    "fjoin": ["join federation"],
    "fleave": ["leave federation"],
    "finfo": ["federation info"],
    "adminpanel": ["admin", "panel"],
    "copilot": ["assistant", "ai assistant", "copilot"],
    "aicheck": ["aicheck", "ai check"],
    "aiexplain": ["ai explain", "explain action"],
    "aireports": ["ai reports", "analyze reports"],
    "aihealth": ["group health"],
    "airule": ["ai rule", "rule advisor"],
    "aioptimize": ["optimize rules"],
    "aiincident": ["analyze incident"],
    "aiplan": ["ai plan"],
    "fban": ["federation ban"],
    "funban": ["federation unban"],
    # ==================== Phase 3 migration additions ====================
    "allowword": ["allow word"],
    "disallowword": ["disallow word"],
    "blockdomain": ["block domain"],
    "unblockdomain": ["unblock domain"],
    "allowdomain": ["allow domain"],
    "unallowdomain": ["unallow domain"],
    "allowforward": ["allow forward"],
    "blockforward": ["block forward"],
    "unruleforward": ["remove forward rule"],
    "setfilteraction": ["set filter action"],
    "mentionprotection": ["mention protection"],
    "setmentionlimit": ["set mention limit"],
    "setmentionaction": ["set mention action"],
    "antispam": ["antispam"],
    "setspamaction": ["set spam action"],
    "dupcross": ["cross duplicate"],
    "setdupcross": ["set cross duplicate"],
    "setflood": ["set flood"],
    "setfloodaction": ["set flood action"],
    "setraidthreshold": ["set raid threshold"],
    "setmaxwarns": ["set max warns"],
    "setwarnaction": ["set warn action"],
    "setwelcomedelete": ["set welcome delete"],
    "setgoodbye": ["set goodbye"],
    "resetgoodbye": ["reset goodbye"],
    "createprofile": ["create profile"],
    "delprofile": ["delete profile"],
    "assignprofile": ["assign profile"],
    "unassignprofile": ["unassign profile"],
    "setalertchannel": ["set alert channel"],
    "importsettings": ["import settings"],
    "schedulerecurring": ["schedule recurring post"],
    "recurringposts": ["recurring posts"],
    "delrecurring": ["delete recurring post"],
    "autoactiontoggle": ["toggle auto action"],
    "dailynotify": ["daily notify"],
    "setpricetime": ["set price time"],
    "setnewstime": ["set news time"],
    "setdailytz": ["set daily timezone"],
    "testdailyprice": ["test daily price"],
    "testdailynews": ["test daily news"],
    "dailyassets": ["daily assets"],
    "ads": ["ads"],
    "myads": ["my ads"],
    "adadmin": ["ad admin"],
    "adstats": ["ad stats"],
    "buyplan": ["buy plan"],
}
