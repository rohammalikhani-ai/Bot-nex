# -*- coding: utf-8 -*-
STRINGS = {
    "rank_user": "Kullanıcı",
    "rank_moderator": "Moderatör",
    "rank_admin": "Yönetici",
    "rank_owner": "Sahip",

    "err_need_rank": "⛔️ Bu komut «{rank}» veya üzeri yetki gerektirir.",
    "err_self_action": "Bunu kendinize yapamazsınız! 😅",
    "err_rank_too_low": "⛔️ Bu kullanıcı üzerinde işlem yapmak için yeterli yetkiniz yok (hedef sizinle eşit veya daha üst rütbede).",
    "err_user_not_found_username": "❌ Bu kullanıcı bulunamadı (botun tanıyabilmesi için bu grupta en az bir mesaj göndermiş olmalı).",
    "err_need_target": "❗️Hedef kullanıcı bulunamadı.\nKullanım: {usage}",

    "warn_given": "⚠️ {name} bir uyarı aldı. ({count}/{max})",
    "warn_reason_line": "\nSebep: {reason}",
    "warn_removed": "➖ {name} kullanıcısının uyarısı kaldırıldı. ({count}/{max})",
    "warn_escalate_mute": "🔇 {name}, {max} uyarıya ulaştığı için {duration} susturuldu.",
    "warn_escalate_ban": "🚫 {name}, {max} uyarıya ulaştığı için yasaklandı.",
    "warns_header": "⚠️ {name} kullanıcısının uyarıları: {count}/{max}",
    "warns_history_line": "• {when} — {reason} ({actor} tarafından)",
    "warns_no_reason": "sebep belirtilmedi",
    "setwarnaction_usage": "Kullanım: /setwarnaction mute ya da /setwarnaction ban",
    "setwarnaction_done": "✅ Maksimum uyarıya ulaşıldığında yapılacak işlem: {action}",
    "setmaxwarns_usage": "Kullanım: /setmaxwarns sayı (örn. 3)",
    "setmaxwarns_done": "✅ Maksimum uyarı sayısı {n} olarak değiştirildi.",

    "mute_done": "🔇 {name} susturuldu (süre: {duration}).",
    "unmute_done": "🔊 {name} kullanıcısının susturması kaldırıldı.",

    "ban_done": "🚫 {name} yasaklandı (süre: {duration}).",
    "unban_done": "✅ {name} kullanıcısının yasağı kaldırıldı.",
    "duration_permanent": "kalıcı",

    "kick_done": "👢 {name} gruptan atıldı.",

    "del_usage": "Lütfen silmek istediğiniz mesajı yanıtlayın.",
    "purge_usage": "Kullanım: bir mesajı /purge ile yanıtlayın, ya da /purge <sayı>",
    "purge_done": "🧹 {count} mesaj silindi.",

    "promote_usage": "Lütfen hedef kullanıcıyı yanıtlayın ya da @kullaniciadi/ID verin.",
    "promote_already_admin": "Bu kullanıcı zaten gerçek bir Telegram yöneticisi; dahili role gerek yok.",
    "promote_done": "⭐️ {name} dahili Moderatör olarak atandı.",
    "demote_done": "⬇️ {name} kullanıcısının Moderatör rolü kaldırıldı.",
    "roles_empty": "Kayıtlı dahili Moderatör yok. (Gerçek yöneticileri görmek için Telegram'ın kendi grup panelini kullanın.)",
    "roles_header": "⭐️ Bu gruptaki dahili Moderatörler:",
    "logs_empty": "Henüz hiçbir işlem kaydedilmedi.",
    "logs_header": "🧾 Son moderasyon işlemleri:",

    "btn_remove_warn": "➖ Uyarıyı kaldır",
    "btn_mute": "🔇 Sustur",
    "btn_ban": "🚫 Yasakla",
    "modact_invalid_data": "Geçersiz veri.",
    "modact_wrong_chat": "Bu buton bu grup için değil.",
    "modact_no_permission": "⛔️ Bu işlem için yetkiniz yok.",
    "modact_done": "Tamamlandı ✅",
    "modact_unwarn_result": "➖ {name} — bir uyarı kaldırıldı. ({count})",
    "modact_mute_result": "🔇 {name}, {minutes} dakika susturuldu.",
    "modact_ban_result": "🚫 {name} yasaklandı.",

    "start_msg": (
        "Merhaba {mention} 🌹\n\n"
        "🔰 *NEXOR* ile tanış — en profesyonel grup yönetim botu\n"
        "🔰 Telegram gruplarında düzen, güvenlik ve tam kontrol için güçlü bir asistan\n\n"
        "✨ *Öne çıkan özellikler:*\n"
        "✅ Tam üye yönetimi (uyarı, susturma, yasaklama, atma)\n"
        "✅ Akıllı içerik kilitleri (bağlantı, iletme, medya vb.)\n"
        "✅ Yasaklı kelime ve ifadeler için gelişmiş filtreleme\n"
        "✅ İstenmeyen botları engellemek için katılım captcha'sı\n"
        "✅ Gelişmiş spam ve flood koruması\n"
        "✅ Grup baskınlarına karşı koruma (Anti-Raid)\n"
        "✅ Bağlı kanal yönetimi (gönderi, zamanlama, düzenleme, silme)\n"
        "✅ Birden fazla grup arasında federasyon sistemi\n"
        "✅ Dahili roller, kayıt ve tam raporlama\n"
        "✅ Çok dilli (Farsça, İngilizce, Arapça, Türkçe, Rusça, İspanyolca)\n\n"
        "🤖 *NEXOR Copilot — grubunun yapay zeka asistanı:*\n"
        "✅ Şüpheli bir mesajı yanıtla, riskini saniyeler içinde analiz etsin\n"
        "✅ \"Neden?\" diye sor, bir uyarı/susturma/yasaklamanın tam sebebini açıklasın\n"
        "✅ Sana grubun tam bir sağlık raporunu versin: nerede gerginlik var, nerede kuralları sıkılaştırmalısın\n"
        "✅ Sorununu kendi cümlenle anlat (\"son zamanlarda spam çok arttı\"), sana otomatik bir kural önerip oluştursun\n"
        "✅ Karar vermeden önce kullanıcı raporlarını ve son olayları analiz edip önceliklendirsin\n"
        "/copilot yazarak dene! ✨\n"
        "\n"
        "🚀 *Kurulum:*\n"
        "1. Botu aşağıdaki düğmeyle grubuna ekle\n"
        "2. Düzgün çalışması için tam yönetici yetkisi ver\n\n"
        "📌 *Önemli notlar:*\n"
        "• Grup bir süper grup olmalı\n"
        "• En iyi performans için tam yönetici erişimi önerilir\n\n"
        "Tüm komutları görmek için /help kullan."
    ),
    "add_to_group_button": "➕ Gruba ekle",
    "settings_header": "⚙️ *Grubun mevcut ayarları*",
    "settings_locks": "🔒 Kilitler: {locks}",
    "settings_filters": "🚫 Filtreler: {filters}",
    "settings_captcha": "🛡️ CAPTCHA: {state}",
    "settings_warns": "⚠️ Maksimum uyarı: {max} → işlem: {action}",
    "settings_channel": "📢 Bağlı kanal: {channel}",
    "settings_logchannel": "🧾 Log kanalı: {log}",
    "settings_lang": "🌐 Dil: {lang}",
    "none": "yok",
    "not_set": "—",

    "setlang_prompt": "🌐 Grup dilini seçin:",
    "setlang_done": "✅ Grup dili {lang_name} olarak değiştirildi.",

    "welcome_simple": "{chat} grubuna hoş geldin {mention}! 🌹",
    "welcome_captcha": "{chat} grubuna hoş geldin {mention}! 🌹\nRobot olmadığını doğrulamak için lütfen aşağıdaki butona bas.",
    "welcome_simple_multi": "{chat} grubuna hoş geldiniz: {mentions} 🌹",
    "welcome_captcha_multi": "{chat} grubuna hoş geldiniz: {mentions} 🌹\nHerkes doğrulamak için kendi adının yanındaki butona bassın.",
    "captcha_btn": "✅ Robot değilim",
    "captcha_not_yours": "Bu buton size ait değil.",
    "captcha_expired": "Bu doğrulamanın süresi doldu.",
    "captcha_verified_alert": "✅ Doğrulandın, hoş geldin!",
    "captcha_verified_msg": "✅ {name} doğrulandı ve artık mesaj yazabilir.",
    "captcha_timeout_msg": "⛔️ Doğrulama süresi doldu; kullanıcı gruptan çıkarıldı.",
    "captcha_toggle_usage": "Kullanım: /captcha on ya da /captcha off",
    "captcha_toggle_done": "🛡️ CAPTCHA {state}.",
    "captcha_on": "etkinleştirildi",
    "captcha_off": "devre dışı bırakıldı",
    "goodbye_msg": "{name} gruptan ayrıldı. 👋",

    "lock_usage": "Kullanım: /lock {options}",
    "lock_done": "🔒 {kind} kilitlendi.",
    "unlock_usage": "Kullanım: /unlock {options}",
    "unlock_done": "🔓 {kind} kilidi açıldı.",
    "locks_active": "🔒 Aktif kilitler: {locks}",
    "filter_usage": "Kullanım: /filter kelime",
    "filter_added": "➕ «{word}» kelimesi filtreye eklendi.",
    "stopfilter_usage": "Kullanım: /stopfilter kelime",
    "filter_removed": "➖ «{word}» kelimesi filtreden kaldırıldı.",
    "filters_active": "🚫 Aktif filtreler: {filters}",
    "flood_muted": "🚨 {name}, kısa sürede çok fazla mesaj gönderdiği için {minutes} dakika susturuldu.",

    "save_usage": "Kullanım: /save isim metin (ya da bir mesajı yanıtlayarak: /save isim)",
    "save_empty": "Kaydedilecek metin bulunamadı.",
    "save_done": "📝 «{name}» notu kaydedildi. /get {name} ya da #{name} ile görüntülenebilir.",
    "get_usage": "Kullanım: /get isim",
    "get_not_found": "Bu isimde bir not bulunamadı.",
    "notes_empty": "Henüz kaydedilmiş not yok.",
    "notes_list_header": "📝 Mevcut notlar:",
    "clear_usage": "Kullanım: /clear isim",
    "clear_done": "🗑️ «{name}» notu silindi.",

    "setlogchannel_usage": "Kullanım: /setlogchannel @kanaladi ya da kanalın sayısal ID'si",
    "setlogchannel_error": "❌ O kanal bulunamadı: {error}",
    "setlogchannel_done": "🧾 Yönetici işlemleri artık «{title}» kanalında kaydedilecek.",
    "setlogchannel_channel_confirm": "✅ Bu kanal, grup yönetimi log kanalı olarak ayarlandı.",

    "fed_new_usage": "Kullanım: /fnew federasyon＿adı",
    "fed_new_done": "🌐 «{name}» federasyonu oluşturuldu (ID: {id}).\nBu grup ilk üye olarak eklendi.\nBaşka grup eklemek için oradan şunu çalıştırın:\n/fjoin {id}",
    "fed_join_usage": "Kullanım: /fjoin federasyon＿id",
    "fed_join_invalid_id": "Geçersiz federasyon ID'si.",
    "fed_not_found": "Bu ID'de bir federasyon bulunamadı.",
    "fed_join_done": "✅ Bu grup «{name}» federasyonuna katıldı.",
    "fed_not_member": "Bu grup hiçbir federasyonun üyesi değil.",
    "fed_left": "👋 Bu grup «{name}» federasyonundan ayrıldı.",
    "fed_info": "🌐 Federasyon: {name}\n🆔 ID: {id}\n👥 Üye grup sayısı: {count}",
    "fed_ban_no_target": "Lütfen hedef kullanıcının mesajını yanıtlayın ya da @kullaniciadi/ID verin.",
    "fed_ban_not_member": "Bu grup henüz bir federasyona ait değil. Önce /fnew veya /fjoin çalıştırın.",
    "fed_ban_done": "🚫 {name}, «{fed}» federasyonunda yasaklandı.\n✅ Başarılı: {success} grup | ❌ Başarısız: {failed} grup\nSebep: {reason}",
    "fed_unban_done": "✅ {name} kullanıcısının yasağı «{fed}» federasyonunda {success} grupta kaldırıldı.",
    "fed_ban_no_reason": "sebep belirtilmedi",
    "fed_raid_kick_notice": "🚫 {name} federasyonda yasaklıydı ve otomatik olarak çıkarıldı.",

    "help_text": (
        "📋 *Yönetim komutları*\n\n"
        "✨ *Eğlenceli bilgi:* komutları hep eğik çizgiyle yazmak zorunda değilsin! Her komutun tıpatıp aynı işi yapan düz bir kelime karşılığı da var — mesela sadece \"şikayet\" yazmak /report ile aynı işi görür, \"yardım\" yazmak da bu aynı menüyü açar. Bu özellik botun konuştuğu 6 dilin hepsinde, her dilin kendi kelimeleriyle çalışır; yani her üye, tek bir eğik çizgili komut ezberlemeden botu kendi dilinde yönetebilir! 🗣️\n\n"
        "👮 *Üye yönetimi* (yanıt, @username veya user＿id ile)\n"
        "/warn [süre] [sebep]   /unwarn   /warns — uyarı geçmişi\n"
        "/mute [süre] [sebep]   /unmute\n"
        "/ban [süre] [sebep]   /unban\n"
        "/kick [sebep]\n"
        "Örnek: /ban 2h aşırı spam   ya da   /mute @user 30m\n"
        "/setmaxwarns sayı   /setwarnaction mute|ban\n\n"
        "🧹 *Mesaj silme*\n"
        "/del — yanıtlanan mesajı sil\n"
        "/purge — yanıtlanan mesajdan şu ana kadar sil (ya da /purge sayı)\n\n"
        "⭐️ *Dahili roller*\n"
        "/promote /demote — botun dahili Moderatör rolü (gerçek yöneticinin altında)\n"
        "/roles — dahili Moderatörleri listele\n"
        "/logs — son moderasyon işlemleri (Denetim Kaydı)\n\n"
        "🔒 *İçerik kilitleri*\n"
        "/lock link|invitelink|channellink|photo|video|sticker|voice|forward|gif|video＿note|document|poll\n"
        "/unlock aynı seçenekler\n"
        "/locks — aktif kilitleri göster\n\n"
        "🌐 *Link Koruması*\n"
        "/blockdomain alan＿adı   /unblockdomain alan＿adı\n"
        "/allowdomain alan＿adı   /unallowdomain alan＿adı\n"
        "/domains — listeleri göster\n\n"
        "🚫 *Kelime filtreleri*\n"
        "/filter kelime\n/stopfilter kelime\n/filters\n"
        "/setfilteraction delete|warn|mute|ban\n"
        "/allowword kelime — istisna   /disallowword kelime\n\n"
        "🕵️ *Anti-Spam*\n"
        "/antispam on|off\n/setspamaction delete|warn|mute|ban\n"
        "/dupcross on|off   /setdupcross eşik saniye\n\n"
        "↪️ *Yönlendirme Koruması*\n"
        "/allowforward kaynak   /blockforward kaynak   /unruleforward kaynak\n"
        "/forwardrules — kuralları göster (kaynak: @kullaniciadi, ID veya isim)\n\n"
        "📛 *Etiket Koruması*\n"
        "/mentionprotection on|off\n/setmentionlimit sayı\n/setmentionaction delete|warn|mute|ban\n\n"
        "🚨 *Anti-Flood*\n"
        "/setflood sayı saniye\n/setfloodaction delete|warn|mute|ban\n\n"
        "🛡️ *Anti-Raid*\n"
        "/antiraid on|off\n/setraidthreshold sayı\n"
        "/lockdown — tüm grubu hemen kilitle   /unlockchat — kilidi aç\n\n"
        "🛡️ *CAPTCHA*\n"
        "/captcha on|off — yeni üye doğrulamasını aç/kapat\n\n"
        "📝 *Notlar*\n"
        "/save isim (yanıt ya da metinle) — not kaydet\n"
        "/get isim ya da #isim — not göster\n"
        "/notes — notları listele\n"
        "/clear isim — not sil\n\n"
        "📢 *Kanal yönetimi (gruptan çalıştırılır)*\n"
        "/setchannel @channel＿username — kanal bağla\n"
        "/post metin — anında paylaş (\"metin|link\" biçiminde buton, butonlar arasında ;)\n"
        "/schedulepost dakika | metin — zamanlanmış paylaşım\n"
        "/editpost mesaj＿id | yeni metin\n"
        "/delpost mesaj＿id\n"
        "/channelstats — kanal istatistikleri\n\n"
        "🧾 *Yönetici günlüğü*\n"
        "/setlogchannel @channel＿username — yönetici işlemlerini bir kanala kaydet\n\n"
        "🌐 *Federasyon (ortak yasaklama listesi)*\n"
        "/fnew isim — yeni federasyon oluştur\n"
        "/fjoin id — bu grubu bir federasyona ekle\n"
        "/fleave — federasyondan ayrıl\n"
        "/finfo — mevcut federasyon bilgisi\n"
        "/fban (yanıt) sebep — tüm federasyon gruplarında yasakla\n"
        "/funban (yanıt) — tüm federasyon gruplarında yasağı kaldır\n\n"
        "🆕 *Yeni Üyeler ve Otomasyon*\n"
        "/setwelcomedelete saniye|off — karşılama mesajını otomatik sil\n"
        "/setgoodbye metin   /resetgoodbye   /goodbye on|off\n"
        "/rules   /setrules [dil] metin   /clearrules [dil]\n"
        "/addkeyword kelime yanıt   /delkeyword kelime   /keywords\n"
        "/addcmd ad yanıt   /delcmd ad   /cmds\n"
        "/schedulerecurring daily|weekly|monthly ... — tekrarlayan kanal gönderileri\n"
        "/recurringposts   /delrecurring id\n"
        "/addautoaction koşul eylem   /delautoaction id   /autoactions   /autoactiontoggle on|off\n\n"
        "🗂️ *Yetki Profilleri*\n"
        "/createprofile ad yetki1,yetki2,...   /delprofile ad   /profiles\n"
        "/assignprofile [yanıt|@user|id] profil   /unassignprofile [yanıt|@user|id]   /myperms\n\n"
        "🚩 *Şikayetler*\n"
        "/report [sebep] (bir mesaja yanıt vererek)   /reports — açık şikayetler\n\n"
        "🔔 *Yönetici Uyarıları*\n"
        "/setalertchannel chat＿id   /alerts — son uyarılar\n\n"
        "📦 *Ayarları İçe/Dışa Aktarma*\n"
        "/exportsettings   /importsettings (.json dosyasına yanıt vererek)\n\n"
        "🔔 *Günlük Bildirim* (💰 fiyat + 📰 haber + 📅 tarih/özel gün)\n"
        "/dailynotify — ayar paneli (aç/kapat, varlıklar, test gönderimi)\n"
        "/setpricetime HH:MM   /setnewstime HH:MM   /setdailytz saat_dilimi\n"
        "/testdailyprice   /testdailynews   /dailyassets\n\n"
        "🌐 /setlang — grup dilini değiştir\n"
        "⚙️ /settings — grubun mevcut ayarlarını göster"
    ),

    "help_words_text": (
        "📖 *Düz kelime komut kısayollarının tam listesi*\n"
        "Her satır şu anlama gelir: bu kelimeyi yaz = tam olarak o komut çalışır\n"
        "\n"
        "*👮 Üye yönetimi*\n"
        "uyar = /warn\n"
        "uyarı kaldır = /unwarn\n"
        "uyarılar = /warns\n"
        "sustur = /mute\n"
        "susturmayı kaldır = /unmute\n"
        "yasakla = /ban\n"
        "yasağı kaldır = /unban\n"
        "at = /kick\n"
        "sil = /del\n"
        "temizle = /purge\n"
        "\n"
        "*⭐️ Roller ve kayıtlar*\n"
        "yükselt = /promote\n"
        "indir = /demote\n"
        "moderatörler = /roles\n"
        "kayıtlar = /logs\n"
        "dil değiştir = /setlang\n"
        "\n"
        "*🔒 Kilitler ve filtreler*\n"
        "kilitle = /lock\n"
        "kilidi aç = /unlock\n"
        "kilitler = /locks\n"
        "filtre = /filter\n"
        "filtreyi kaldır = /stopfilter\n"
        "filtreler = /filters\n"
        "engelli siteler = /domains\n"
        "yönlendirme kuralları = /forwardrules\n"
        "\n"
        "*🛡️ Grup güvenliği*\n"
        "baskın koruması = /antiraid\n"
        "tam kilit = /lockdown\n"
        "grubu aç = /unlockchat\n"
        "captcha = /captcha\n"
        "hoşçakal = /goodbye\n"
        "\n"
        "*📝 Notlar*\n"
        "kaydet = /save\n"
        "getir = /get\n"
        "notlar = /notes\n"
        "notu temizle = /clear\n"
        "\n"
        "*📢 Kanal*\n"
        "kanal ayarla = /setchannel\n"
        "gönderi = /post\n"
        "gönderi zamanla = /schedulepost\n"
        "gönderiyi düzenle = /editpost\n"
        "gönderiyi sil = /delpost\n"
        "kanal istatistikleri = /channelstats\n"
        "kayıt kanalı ayarla = /setlogchannel\n"
        "\n"
        "*🌐 Federasyon*\n"
        "yeni federasyon = /fnew\n"
        "federasyona katıl = /fjoin\n"
        "federasyondan ayrıl = /fleave\n"
        "federasyon bilgisi = /finfo\n"
        "federasyon yasağı = /fban\n"
        "federasyon yasağını kaldır = /funban\n"
        "\n"
        "*🆕 Karşılama ve otomasyon*\n"
        "kurallar = /rules\n"
        "kuralları ayarla = /setrules\n"
        "kuralları temizle = /clearrules\n"
        "anahtar kelime ekle = /addkeyword\n"
        "anahtar kelime sil = /delkeyword\n"
        "anahtar kelimeler = /keywords\n"
        "komut ekle = /addcmd\n"
        "komut sil = /delcmd\n"
        "komutlar = /cmds\n"
        "otomatik eylem ekle = /addautoaction\n"
        "otomatik eylemi sil = /delautoaction\n"
        "otomatik eylemler = /autoactions\n"
        "\n"
        "*🗂️ Yetkiler ve şikayetler*\n"
        "profiller = /profiles\n"
        "yetkilerim = /myperms\n"
        "şikayet = /report\n"
        "şikayetler = /reports\n"
        "bildirimler = /alerts\n"
        "ayarları dışa aktar = /exportsettings\n"
        "\n"
        "*🤖 NEXOR Copilot*\n"
        "yönetici = /adminpanel\n"
        "asistan = /copilot\n"
        "yapay zeka kontrolü = /aicheck\n"
        "işlemi açıkla = /aiexplain\n"
        "raporları analiz et = /aireports\n"
        "grup sağlığı = /aihealth\n"
        "kural danışmanı = /airule\n"
        "kuralları optimize et = /aioptimize\n"
        "olayı analiz et = /aiincident\n"
        "yapay zeka planı = /aiplan\n"
        "\n"
        "*⚙️ Genel*\n"
        "ayarlar = /settings\n"
        "yardım = /help\n"
        "\n"
        "💡 Birden çok kelimeli ifadeleri (örn. \\\"filtreyi kaldır\\\") tam olarak yazıldığı gibi, art arda yaz."
    ),

    "channel_set_usage": "Kullanım: /setchannel @kanaladi ya da kanalın sayısal ID'si",
    "channel_set_error": "❌ O kanal bulunamadı: {error}",
    "channel_set_done": "📢 «{title}» kanalı bu gruba bağlandı.",
    "channel_no_channel": "Önce /setchannel ile bir kanal bağlayın.",
    "channel_post_empty": "Gönderi metni boş. Kullanım: /post mesaj metni",
    "channel_post_sent": "✅ Gönderi paylaşıldı. Mesaj ID: {id}",
    "channel_post_failed": "❌ Gönderi paylaşılamadı: {error}",
    "channel_schedule_usage": "Kullanım: /schedulepost dakika, ardından bir sonraki satırda gönderi metni",
    "channel_schedule_invalid_minutes": "Geçersiz dakika sayısı.",
    "channel_schedule_empty": "Gönderi metni boş.",
    "channel_schedule_done": "⏰ Gönderi {minutes} dakika sonrasına zamanlandı.",
    "channel_scheduled_sent": "✅ Zamanlanmış gönderi paylaşıldı. ID: {id}",
    "channel_scheduled_failed": "❌ Zamanlanmış gönderi paylaşılamadı: {error}",
    "channel_editpost_usage": "Kullanım: /editpost mesaj＿id, ardından bir sonraki satırda yeni metin",
    "channel_editpost_invalid_id": "Geçersiz mesaj ID'si.",
    "channel_editpost_empty": "Yeni metin boş.",
    "channel_editpost_done": "✅ Gönderi düzenlendi.",
    "channel_editpost_failed": "❌ Düzenleme başarısız: {error}",
    "channel_delpost_usage": "Kullanım: /delpost mesaj＿id",
    "channel_delpost_done": "🗑️ Gönderi silindi.",
    "channel_delpost_failed": "❌ Silme başarısız: {error}",
    "channel_stats_text": "📊 «{title}» kanalı istatistikleri\n👥 Üye sayısı: {count}",
    "channel_stats_failed": "❌ İstatistikler alınamadı: {error}",

    "state_on": "etkin",
    "state_off": "devre dışı",

    "antispam_toggle_usage": "Kullanım: /antispam on ya da /antispam off",
    "antispam_toggle_done": "🕵️ Anti-Spam {state}.",
    "adminabuseprotection_toggle_usage": "Kullanım: /adminabuseprotection on veya /adminabuseprotection off (yalnızca grup sahibi)",
    "adminabuseprotection_toggle_done": "🚷 Yönetici suistimali tespiti {state}.",
    "setspamaction_usage": "Kullanım: /setspamaction delete|warn|mute|ban",
    "setspamaction_done": "✅ Anti-Spam eylemi: {action}",
    "spam_reason_duplicate": "tekrarlanan mesaj gönderme",
    "spam_reason_newlink": "katıldıktan hemen sonra link paylaşma",

    "setflood_usage": "Kullanım: /setflood sayı saniye  (örn. /setflood 5 10)",
    "setflood_done": "✅ Anti-Flood: {window} saniyede {limit} mesaj",
    "setfloodaction_usage": "Kullanım: /setfloodaction delete|warn|mute|ban",
    "setfloodaction_done": "✅ Anti-Flood eylemi: {action}",
    "flood_reason": "çok hızlı mesaj gönderme",

    "setfilteraction_usage": "Kullanım: /setfilteraction delete|warn|mute|ban",
    "setfilteraction_done": "✅ Kelime filtresi eylemi: {action}",
    "allowword_usage": "Kullanım: /allowword kelime",
    "allowword_done": "➕ «{word}» istisna listesine eklendi.",
    "disallowword_usage": "Kullanım: /disallowword kelime",
    "disallowword_done": "➖ «{word}» istisna listesinden kaldırıldı.",
    "filter_reason": "yasaklı kelime",

    "blockdomain_usage": "Kullanım: /blockdomain alan＿adı (örn. example.com)",
    "blockdomain_done": "🚫 «{domain}» alan adı engellendi.",
    "unblockdomain_usage": "Kullanım: /unblockdomain alan＿adı",
    "unblockdomain_done": "✅ «{domain}» alan adının engeli kaldırıldı.",
    "allowdomain_usage": "Kullanım: /allowdomain alan＿adı",
    "allowdomain_done": "✅ «{domain}» alan adı beyaz listeye eklendi.",
    "unallowdomain_usage": "Kullanım: /unallowdomain alan＿adı",
    "unallowdomain_done": "➖ «{domain}» alan adı beyaz listeden kaldırıldı.",
    "domains_header_block": "🚫 Engellenen alan adları:",
    "domains_header_allow": "✅ Beyaz listedeki alan adları:",
    "domains_empty": "Kayıtlı alan adı yok.",
    "link_reason_blacklisted": "engellenmiş alan adı linki",

    "antiraid_toggle_usage": "Kullanım: /antiraid on ya da /antiraid off",
    "antiraid_toggle_done": "🛡️ Anti-Raid {state}.",
    "setraidthreshold_usage": "Kullanım: /setraidthreshold sayı (örn. 8)",
    "setraidthreshold_done": "✅ Raid algılama eşiği {n} kullanıcı olarak değiştirildi.",
    "raid_detected_alert": "🚨 *Raid uyarısı!*\nOlağandışı sayıda yeni üye ({count} kişi, {window} saniyede) gruba katıldı.\nGrup {minutes} dakika kilitlendi (sadece yöneticiler mesaj gönderebilir).",
    "raid_auto_unlock": "🔓 Otomatik güvenlik kilidi kaldırıldı.",
    "lockdown_done": "🔒 Grup kilitlendi; sadece yöneticiler mesaj gönderebilir.",
    "unlock_done_manual": "🔓 Grup kilidi kaldırıldı.",
    "already_locked": "Grup zaten kilitli.",
    "already_unlocked": "Grup kilitli değil.",
    "btn_unlock_now": "🔓 Şimdi kilidi aç",

    # --- Priority 3: Content Control (Forward Protection / Mention Protection / Cross-user Duplicate) ---
    "allowforward_usage": "Kullanım: /allowforward @kullaniciadi|ID|isim",
    "allowforward_done": "✅ «{source}» kaynağından yönlendirmelere artık her zaman izin veriliyor.",
    "blockforward_usage": "Kullanım: /blockforward @kullaniciadi|ID|isim",
    "blockforward_done": "🚫 «{source}» kaynağından yönlendirmeler artık her zaman engelleniyor.",
    "unruleforward_usage": "Kullanım: /unruleforward @kullaniciadi|ID|isim",
    "unruleforward_done": "➖ «{source}» için yönlendirme kuralı kaldırıldı.",
    "forwardrules_header_block": "🚫 Her zaman engellenen kaynaklar:",
    "forwardrules_header_allow": "✅ Her zaman izin verilen kaynaklar:",
    "forwardrules_empty": "Yönlendirme kuralı yok.",
    "forward_reason_blocked_source": "engellenen kaynaktan yönlendirme ({source})",
    "mentionprotection_usage": "Kullanım: /mentionprotection on veya /mentionprotection off",
    "mentionprotection_done": "🛡️ Etiket Koruması {state}.",
    "setmentionlimit_usage": "Kullanım: /setmentionlimit sayı (örn. 5)",
    "setmentionlimit_done": "✅ Etiket sınırı {n} olarak değiştirildi.",
    "setmentionaction_usage": "Kullanım: /setmentionaction delete|warn|mute|ban",
    "setmentionaction_done": "✅ Etiket kötüye kullanım eylemi: {action}",
    "mention_reason": "toplu etiket kötüye kullanımı ({count} etiket)",
    "dupcross_usage": "Kullanım: /dupcross on veya /dupcross off",
    "dupcross_done": "🕵️ Kullanıcılar arası yinelenen mesaj tespiti {state}.",
    "setdupcross_usage": "Kullanım: /setdupcross eşik saniye (örn. 3 45)",
    "setdupcross_done": "✅ Kullanıcılar arası tekrar ayarları: {window} saniyede {threshold} kullanıcı.",
    "spam_reason_cross_duplicate": "birden fazla kullanıcıdan yinelenen mesaj (kopyala/yapıştır saldırısı)",

    # --- Priority 4: New Members & Automation (Welcome auto-delete, Goodbye, Rules, Filters, Custom Commands, Scheduled Messages, Auto Actions) ---
    "setwelcomedelete_usage": "Kullanım: /setwelcomedelete saniye (örn. 60) veya /setwelcomedelete off",
    "setwelcomedelete_done": "✅ Karşılama mesajları artık {seconds} saniye sonra otomatik silinecek.",
    "setwelcomedelete_off": "✅ Karşılama mesajı otomatik silme devre dışı bırakıldı.",
    "setgoodbye_usage": "Kullanım: /setgoodbye <metin>\nKullanılabilir değişkenler: {name} {username} {mention} {chat} {count}",
    "setgoodbye_done": "✅ Özel veda mesajı kaydedildi.",
    "resetgoodbye_done": "✅ Veda mesajı varsayılana sıfırlandı.",
    "goodbye_toggle_usage": "Kullanım: /goodbye on veya /goodbye off",
    "goodbye_toggle_done": "👋 Veda mesajları {state}.",
    "rules_empty": "Bu grup için henüz kural belirlenmedi.",
    "rules_header": "📜 *Grup Kuralları*",
    "setrules_usage": "Kullanım: /setrules [dil kodu] <kurallar metni>\nÖrnek: /setrules Lütfen herkese saygılı olun.\nDil koduyla: /setrules en Please be respectful.",
    "setrules_done": "✅ Kurallar kaydedildi ({lang}).",
    "clearrules_done": "🗑️ Kurallar kaldırıldı ({lang}).",
    "clearrules_notfound": "Bu dil için kural ayarlanmamış.",
    "addkeyword_usage": "Kullanım: /addkeyword <anahtar kelime> <yanıt>\nYa da bir mesaja yanıtla: /addkeyword <anahtar kelime>",
    "addkeyword_done": "✅ «{keyword}» anahtar kelime tetikleyicisi eklendi.",
    "addkeyword_updated": "♻️ «{keyword}» anahtar kelime tetikleyicisi güncellendi.",
    "delkeyword_usage": "Kullanım: /delkeyword <anahtar kelime>",
    "delkeyword_done": "🗑️ «{keyword}» anahtar kelime tetikleyicisi kaldırıldı.",
    "delkeyword_notfound": "Böyle bir tetikleyici yok.",
    "keywords_empty": "Tanımlı anahtar kelime tetikleyicisi yok.",
    "keywords_header": "🔑 Anahtar kelime tetikleyicileri:",
    "autoanswer_ask_audience": "⚙️ «{title}» için Otomatik Yanıt ayarlanıyor\n\nBot bu anahtar kelimeyi kimlere yanıtlasın?",
    "autoanswer_ask_keyword": "✏️ Şimdi anahtar kelimeyi veya cümleyi gönder (örneğin: fiyat, kurallar, admin...).",
    "autoanswer_ask_response": "📎 «{keyword}» anahtar kelimesi kaydedildi.\n\nŞimdi botun yanıt olarak göndermesini istediğin mesajı veya medyayı gönder (metin, fotoğraf, video, sesli mesaj, ses, dosya, GIF, çıkartma veya yuvarlak video).\n\nBotun her seferinde rastgele birini seçmesi için en fazla 20 farklı yanıt gönderebilirsin. Bitirdiğinde «Bitti» düğmesine bas.",
    "autoanswer_audience_admins": "🛡 Sadece yöneticiler",
    "autoanswer_audience_all": "👥 Tüm kullanıcılar",
    "autoanswer_audience_owners": "👑 Sadece sahip",
    "autoanswer_btn_cancel": "❌ Vazgeç",
    "autoanswer_btn_done": "✅ Bitti",
    "autoanswer_cancelled": "❌ İptal edildi; hiçbir otomatik yanıt kaydedilmedi.",
    "autoanswer_cleaned": "🗑️ {count} otomatik yanıt temizlendi.",
    "autoanswer_expired": "Bu adım artık geçerli değil; grubun içinden «otomatik yanıt ayarla» komutunu tekrar gönder.",
    "autoanswer_group_only": "Bu komut yalnızca grup içinde kullanılabilir.",
    "autoanswer_invalid_link": "Bu bağlantı geçersiz veya süresi dolmuş. Grubun içinden «otomatik yanıt ayarla» komutunu tekrar gönder.",
    "autoanswer_list_empty": "Ayarlanmış otomatik yanıt yok.",
    "autoanswer_list_header": "◄ Otomatik yanıt listesi:",
    "autoanswer_list_item": "• «{keyword}» — hedef kitle: {audience} — {count} yanıt",
    "autoanswer_max_responses": "⛔️ {max} yanıt sınırına ulaştın. Kaydetmek için «Bitti»ye bas.",
    "autoanswer_need_one_response": "Henüz hiç yanıt eklemedin; en az bir mesaj veya medya gönder.",
    "autoanswer_not_admin": "⛔️ Otomatik yanıt ayarlamak için o grubun yöneticisi veya sahibi olmalısın.",
    "autoanswer_pm_button": "🔐 Otomatik yanıt ayarlamak için özelden gir",
    "autoanswer_response_added": "✅ {count}/{max} yanıt kaydedildi.\nSonrakini gönder ya da «Bitti»ye bas.",
    "autoanswer_saved": "✅ «{title}» için otomatik yanıt kaydedildi.\nAnahtar kelime: {keyword}\nHedef kitle: {audience}\nYanıt sayısı: {count}",
    "autoanswer_setup_intro": "◄ Otomatik Yanıt (Auto-Answer)\n\n«{title}» için yeni bir otomatik yanıt ayarlamak için aşağıdaki düğmeye bas ve adımlara özel mesajda devam et.",
    "autoanswer_unsupported_content": "Bu içerik türü desteklenmiyor. Metin, fotoğraf, video, sesli mesaj, ses, dosya, GIF, çıkartma veya yuvarlak video gönder.",
    "autoanswer_updated": "♻️ «{title}» için «{keyword}» otomatik yanıtı güncellendi.\nHedef kitle: {audience}\nYanıt sayısı: {count}",
    "delanswer_done": "🗑️ «{keyword}» otomatik yanıtı silindi.",
    "delanswer_notfound": "Böyle bir otomatik yanıt yok.",
    "delanswer_usage": "Kullanım: /delanswer <anahtar kelime>",
    "addcmd_usage": "Kullanım: /addcmd <ad> <yanıt>\nYa da bir mesaja yanıtla: /addcmd <ad>",
    "addcmd_reserved": "⛔ Bu ad yerleşik bir komut için ayrılmış.",
    "addcmd_done": "✅ Özel komut /{name} eklendi.",
    "addcmd_updated": "♻️ Özel komut /{name} güncellendi.",
    "delcmd_usage": "Kullanım: /delcmd <ad>",
    "delcmd_done": "🗑️ Özel komut /{name} kaldırıldı.",
    "delcmd_notfound": "Böyle bir özel komut yok.",
    "cmds_empty": "Tanımlı özel komut yok.",
    "cmds_header": "⚙️ Özel komutlar:",
    "schedulerecurring_usage": "Kullanım:\n/schedulerecurring daily HH:MM <metin>\n/schedulerecurring weekly mon HH:MM <metin>\n/schedulerecurring monthly GÜN HH:MM <metin>\n(haftanın günü: mon tue wed thu fri sat sun — gün: 1-28)",
    "schedulerecurring_invalid_time": "Geçersiz saat. HH:MM biçimini kullanın (örn. 14:30).",
    "schedulerecurring_invalid_day": "Geçersiz ayın günü. 1 ile 28 arasında bir sayı kullanın.",
    "schedulerecurring_invalid_weekday": "Geçersiz gün. Şunlardan birini kullanın: mon tue wed thu fri sat sun",
    "schedulerecurring_empty_text": "Mesaj metni gerekli (komuttan sonraki satır(lar)da).",
    "schedulerecurring_done": "✅ Tekrarlayan gönderi zamanlandı (ID {id}).",
    "recurringposts_header": "🔁 Tekrarlayan gönderiler:",
    "recurringposts_empty": "Zamanlanmış tekrarlayan gönderi yok.",
    "recurringposts_item": "#{id} — {schedule} — {preview}",
    "recurring_desc_daily": "Her gün saat {time}",
    "recurring_desc_weekly": "Her hafta {weekday} günü saat {time}",
    "recurring_desc_monthly": "Her ay {day}. günü saat {time}",
    "delrecurring_usage": "Kullanım: /delrecurring <id>",
    "delrecurring_done": "🗑️ Tekrarlayan gönderi #{id} kaldırıldı.",
    "delrecurring_notfound": "Bu ID'ye sahip tekrarlayan gönderi yok.",
    "addautoaction_usage": "Kullanım: /addautoaction <koşul> <eylem>\nKoşullar: message＿type:<photo|video|sticker|voice|gif|video＿note|document|poll|forward|link|text>, user＿role:<user|moderator|admin>, warns＿gte:<sayı>\nEylemler: delete, warn, mute:<dakika>, ban, kick",
    "addautoaction_invalid_condition": "Geçersiz koşul. Biçimi görmek için /addautoaction komutunu argümansız çalıştırın.",
    "addautoaction_invalid_action": "Geçersiz eylem. Biçimi görmek için /addautoaction komutunu argümansız çalıştırın.",
    "addautoaction_done": "✅ Auto Action kuralı eklendi (ID {id}): {condition} → {action}",
    "delautoaction_usage": "Kullanım: /delautoaction <id>",
    "delautoaction_done": "🗑️ Auto Action kuralı #{id} kaldırıldı.",
    "delautoaction_notfound": "Bu ID'ye sahip Auto Action kuralı yok.",
    "autoactions_header": "🤖 Auto Action kuralları:",
    "autoactions_empty": "Tanımlı Auto Action kuralı yok.",
    "autoactiontoggle_usage": "Kullanım: /autoactiontoggle on veya /autoactiontoggle off",
    "autoactiontoggle_done": "🤖 Auto Actions {state}.",
    "autoaction_reason": "Auto Action kuralı (#{id})",
    "settings_goodbye": "👋 Veda mesajları: {state}",
    "settings_autoaction": "🤖 Auto Actions: {state}",

    # Priority 5, Item 25 — Permission Profiles
    "createprofile_usage": "Kullanım: /createprofile <ad> <yetki1,yetki2,...>\nMevcut yetkiler: {caps}",
    "profile_invalid_caps": "❌ Bilinmeyen yetki: {invalid}\nMevcut yetkiler: {caps}",
    "createprofile_done": "✅ «{name}» profili şu yetkilerle oluşturuldu: {caps}",
    "createprofile_updated": "♻️ «{name}» profili şu yetkilerle güncellendi: {caps}",
    "delprofile_usage": "Kullanım: /delprofile <ad>",
    "delprofile_notfound": "Böyle bir profil yok.",
    "delprofile_done": "🗑️ «{name}» profili silindi.",
    "profiles_empty": "Henüz özel bir yetki profili tanımlanmamış.",
    "profiles_header": "🗂️ Yetki profilleri:",
    "profile_item": "• «{name}» — {caps}\n   Üyeler: {members}",
    "assignprofile_usage": "Kullanım: /assignprofile [yanıt|@user|id] <profil>",
    "assignprofile_notfound_profile": "«{name}» adında bir profil yok. Önce /createprofile ile oluşturun.",
    "assignprofile_done": "✅ «{profile}» profili {name} kullanıcısına atandı.",
    "unassignprofile_usage": "Kullanım: /unassignprofile [yanıt|@user|id]",
    "unassignprofile_notfound": "Bu kullanıcıya atanmış bir profil yok.",
    "unassignprofile_done": "➖ {name} kullanıcısından profil kaldırıldı.",
    "myperms_with_profile": "Rütbeniz: {rank}\nAtanmış profil: «{profile}»\nYetkiler: {caps}",
    "myperms_no_profile": "Rütbeniz: {rank}\nAtanmış özel bir profiliniz yok.",

    # Priority 5, Item 26 — Reports
    "report_need_reply": "Lütfen şikayet etmek istediğiniz mesaja yanıt verin.",
    "report_self": "Kendinizi şikayet edemezsiniz! 😅",
    "report_already": "Bu mesajı zaten yakın zamanda şikayet ettiniz.",
    "report_done": "✅ Şikayetiniz yöneticilere iletildi. Teşekkürler!",
    "report_alert_header": "🚩 Yeni şikayet #{id}\nŞikayet eden: {reporter}\nŞikayet edilen: {target}\nSebep: {reason}",
    "alert_multi_reports_text": "{target} son {window} saniyede {count} ayrı şikayet aldı.",
    "reports_empty": "Açık şikayet yok.",
    "reports_header": "🚩 Açık şikayetler:",
    "report_item": "• #{id} [{when}] {reporter} ← {target} ({reason})",
    "btn_report_mute": "🔇 Sustur",
    "btn_report_ban": "🚫 Yasakla",
    "btn_report_delete": "🗑️ Mesajı sil",
    "btn_report_dismiss": "✖️ Reddet",
    "report_not_found": "Bu şikayet artık yok ya da zaten işlendi.",
    "report_action_done_dismiss": "✖️ {target} hakkındaki #{id} numaralı şikayet reddedildi.",
    "report_action_done_mute": "🔇 {target}, şikayet üzerine {minutes} dakika susturuldu.",
    "report_action_done_ban": "🚫 {target}, şikayet üzerine yasaklandı.",
    "report_action_done_delete": "🗑️ {target} tarafından şikayet edilen mesaj silindi.",

    # Priority 5, Item 27 — Admin Alerts
    "setalertchannel_usage": "Kullanım: /setalertchannel <chat＿id> (argümansız = temizle)",
    "setalertchannel_done": "✅ Uyarı hedefi {channel} olarak ayarlandı.",
    "setalertchannel_cleared": "✅ Özel uyarı hedefi temizlendi (uyarılar bu grupta/log kanalında gönderilecek).",
    "alerts_empty": "Henüz kayıtlı bir uyarı yok.",
    "alerts_header": "🔔 Son uyarılar:",
    "alert_type_multi_reports": "Çoklu Şikayet",
    "alert_type_suspicious": "Şüpheli Aktivite",
    "alert_type_security": "Güvenlik Olayı",
    "alert_type_abnormal": "Anormal Davranış",
    "alert_type_admin_abuse": "Olası Yönetici Suistimali",
    "admin_abuse_alert_detail": "🧑‍💼 {name}, son {minutes} dakikada {count} yıkıcı işlem (ban/susturma/atma/uyarı) yaptı — hesabı ele geçirilmiş olabilir ya da kasıtlı bir suistimal olabilir. Lütfen kontrol edin.",
    "alert_type_raid": "Raid Tespit Edildi",
    "alert_type_generic": "Uyarı",

    # Priority 5, Item 28 — Import / Export Settings
    "exportsettings_caption": "📦 Grup ayarları dışa aktarımı.\n{summary}",
    "importsettings_usage": "Bir .json ayar dosyasına yanıt vererek /importsettings gönderin.",
    "importsettings_invalid_json": "❌ Bu dosya geçerli bir JSON olarak okunamadı.",
    "importsettings_invalid_schema": "❌ Geçersiz ayar dosyası (sorun: {detail}).",
    "importsettings_confirm_prompt": "⚠️ Bu işlem grubun mevcut ayarlarını şunlarla *değiştirecek*:\n{summary}\nEmin misiniz?",
    "importsettings_cancelled": "❌ İçe aktarma iptal edildi.",
    "importsettings_done": "✅ Ayarlar başarıyla içe aktarıldı.\n{summary}",
    "btn_import_confirm": "✅ İçe aktarmayı onayla",
    "btn_import_cancel": "❌ İptal",

    # Kişisel yönetici paneli
    "panel_header": "🛠 {name} yönetim paneli\n\nBir bölüm seç:",
    "panel_btn_settings": "⚙️ Ayarlar",
    "panel_btn_locks": "🔒 Kilitler",
    "panel_btn_filters": "🚫 Filtreler",
    "panel_btn_rules": "📜 Kurallar",
    "panel_btn_reports": "🚩 Açık şikayetler",
    "panel_btn_logs": "🗒 Kayıtlar",
    "panel_btn_roles": "👮 Moderatörler",
    "panel_btn_daily": "🔔 Günlük Bildirim",
    "panel_daily_hint": "Ayarları değiştirmek için: /dailynotify",
    "panel_btn_back": "🔙 Geri",
    "panel_btn_close": "❌ Kapat",
    "panel_not_yours": "Bu panel yalnızca açan kişiye aittir.",
    "panel_closed": "Panel kapatıldı.",

    "ai_panel_header": "🤖 NEXOR Copilot\nYöneticilerin yapay zekâ asistanı — bir bölüm seçin:",
    "ai_btn_analyze": "🔍 Mesajı Analiz Et",
    "ai_btn_explain": "❓ İşlemi Açıkla",
    "ai_btn_health": "📊 Grup Sağlığı",
    "ai_btn_reports": "🗂 Raporları İncele",
    "ai_btn_optimize": "🛠 Kuralları Optimize Et",
    "ai_btn_incident": "🚨 Olayı Analiz Et",
    "ai_btn_rule": "➕ Kural Danışmanı",
    "ai_btn_close": "❌ Kapat",
    "ai_working": "⏳ Yapay zekâ ile analiz ediliyor...",
    "ai_guide_analyze": "🔍 Mesajı Analiz Et\nKontrol edilmesini istediğiniz mesaja yanıt verip şunu gönderin:\naicheck",
    "ai_guide_explain": "❓ İşlemi Açıkla\nÖrnek:\naiexplain @kullaniciadi bu kullanıcı neden uyarıldı?\n(veya kullanıcının mesajına yanıt verip aiexplain gönderin)",
    "ai_guide_rule": "➕ Kural Danışmanı\nSorununuzu açıklayın, örn.:\nairule çok fazla reklam spam'i alıyoruz",
    "ai_need_reply": "Mesajı Analiz Et'i çalıştırmak için bir mesaja yanıt verin.",
    "ai_explain_usage": "Hedef kullanıcı bulunamadı. Mesajına yanıt verin veya şunu gönderin:\naiexplain @kullaniciadi [soru]",
    "ai_explain_default_question": "{name} kullanıcısına yakın zamanda neden bir moderasyon işlemi uygulandı?",
    "ai_rule_usage": "Sorunu açıklayın, örn.:\nairule çok fazla reklam spam'i alıyoruz",
    "ai_reports_empty_for_ai": "Analiz edilecek açık rapor yok.",
    "ai_optimize_empty": "İncelenecek Otomatik İşlem Kuralı yok.",
    "ai_incident_empty": "Analiz edilecek dikkate değer bir yakın zamanlı etkinlik bulunamadı.",
    "ai_rule_not_applicable": "⚠️ Bu, NEXOR'un mevcut kural motorunun kapsayabileceği bir şey değil; daha spesifik bir açıklama deneyin veya addautoaction ile manuel olarak bir kural ekleyin.",
    "ai_rule_cancelled": "İptal edildi; herhangi bir kural oluşturulmadı.",
    "ai_rule_created": "✅ #{id} numaralı kural oluşturuldu.\nTetikleyici: {condition}\nİşlem: {action}",
    "ai_dismissed": "Yoksayıldı; grupta herhangi bir işlem yapılmadı.",
    "ai_reason_copilot": "NEXOR Copilot önerisi (yönetici onaylı)",
    "ai_action_done_delwarn": "🗑️ Mesaj silindi ve {name} uyarıldı.",
    "ai_plan_status": "Bu grubun mevcut yapay zekâ planı: {plan}",
    "ai_plan_set_done": "✅ Bu grubun yapay zekâ planı \"{plan}\" olarak ayarlandı.",
    "ai_plan_set_invalid": "Geçersiz plan. Şunlardan birini kullanın: free, pro, premium",
    "ai_err_plan_not_allowed": "⛔️ Bu özellik, bu grubun mevcut planında kullanılamıyor.",
    "ai_err_rate_limited": "⏳ Günlük yapay zekâ istek limitiniz doldu; yarın tekrar deneyin.",
    "ai_err_not_configured": "⚙️ Bu grubun planı için yapay zekâ henüz yapılandırılmadı (botun yöneticisine bildirin).",
    "ai_err_provider_error": "⚠️ Yapay zekâ servisine ulaşılamadı; birazdan tekrar deneyin.",
    "ai_err_bad_response": "⚠️ Yapay zekânın yanıtı anlaşılamadı; tekrar deneyin.",
    "ai_err_unknown": "⚠️ Beklenmeyen bir NEXOR Copilot hatası oluştu; kaydedildi.",
    "ai_err_action_failed": "⚠️ İşlemin çalıştırılması başarısız oldu.",
    "ai_risk_low": "Düşük",
    "ai_risk_medium": "Orta",
    "ai_risk_high": "Yüksek",
    "ai_priority_high": "Yüksek Öncelik",
    "ai_priority_suspicious": "Şüpheli",
    "ai_priority_low": "Düşük Öncelik",
    "ai_priority_false": "Muhtemelen Yanlış Rapor",
    "ai_action_none": "İşlem yok",
    "ai_action_delete": "Mesajı sil",
    "ai_action_warn": "Uyar",
    "ai_action_delete_warn": "Sil + Uyar",
    "ai_action_mute": "Sustur",
    "ai_action_ban": "Yasakla",
    "ai_trend_up": "Yükseliyor 📈",
    "ai_trend_down": "Düşüyor 📉",
    "ai_trend_stable": "Sabit ➖",
    "ai_btn_apply_delwarn": "🗑️+⚠️ Sil ve Uyar",
    "ai_btn_apply_mute": "🔇 Sustur",
    "ai_btn_apply_ban": "🚫 Yasakla",
    "ai_btn_dismiss": "Yoksay",
    "ai_btn_confirm": "✅ Onayla ve oluştur",
    "ai_btn_cancel": "❌ İptal",
    "ai_analyze_message_result": "🤖 NEXOR Copilot analizi\n\nRisk: {risk}\nSpam: %{spam}\nReklam: %{ad}\nŞüpheli: %{suspicious}\nSaldırgan: %{toxic}\n\nÖzet: {summary}\n\n💡 Öneri: {action}\nGerekçe: {reason}\n\nSon karar sizin:",
    "ai_explain_result": "🤖 NEXOR Copilot açıklaması\n\n{explanation}\n\nAnahtar faktörler:\n{factors}",
    "ai_reports_header": "🗂 Açık raporlar, kategorilere ayrılmış:",
    "ai_reports_item": "• #{id} — {priority}: {reason}",
    "ai_reports_summary": "\nÖzet: {summary}",
    "ai_health_result": "📊 Grup sağlığı\n\nSpam seviyesi: {spam_level}\nİhlal eğilimi: {trend}\n\nRiskler:\n{risks}\n\n💡 Öneri: {recommendation}",
    "ai_rule_advisor_result": "➕ Kural Danışmanı önerisi\n\nTetikleyici: {trigger}\nİşlem: {action}\nKapsam: {scope}\nGerekçe: {reason}\nGüven: %{confidence}\n\nBu kuralı oluşturmak için onaylayın:",
    "ai_optimize_result": "🛠 Kural Optimizasyonu sonucu\n\nYinelenenler: {duplicates}\nÇakışmalar: {conflicts}\nÇok sık tetiklenenler: {too_frequent}\nTehlikeli yapılandırmalar: {dangerous}\n\nÖneriler:\n{suggestions}",
    "ai_incident_result": "🚨 Olay özeti\n\n{summary}\n\nCiddiyet: {severity}\n\nZaman çizelgesi:\n{timeline}\n\n💡 Öneri: {recommendation}",
    "ai_local_summary_safe": "Kısa ve risk belirtisi olmayan bir mesaj; yerel olarak düşük riskli sınıflandırıldı.",
    "ai_local_reason_no_ai_needed": "Yapay zekâ incelemesine gerek yoktu.",

    # ==================== Guide Panel ====================
    "guide_intro": "📖 NEXOR Rehberi\nBir bölüme dokun, ne işe yaradığını gör — altındaki herhangi bir kelimeye dokununca da komut yerine sohbete gerçekten yazacağın kelimeyi görürsün.",
    "guide_btn_locks": "🔒 Kilitler ve Filtreler",
    "guide_btn_moderation": "🛡 Moderasyon ve Cezalar",
    "guide_btn_roles": "👮 Terfi / Rütbe Düşürme",
    "guide_btn_settings": "⚙️ Grup Ayarları",
    "guide_btn_security": "🚨 Anti-Raid ve Tam Kilit",
    "guide_btn_rules": "📜 Grup Kuralları",
    "guide_btn_autoreply": "💬 Anahtar Kelime ve Özel Komut",
    "guide_btn_channel": "📢 Kanal ve Gönderiler",
    "guide_btn_autoactions": "🤖 Otomatik Eylemler",
    "guide_btn_notes": "📝 Notlar",
    "guide_btn_reports_logs": "🚩 Raporlar ve Kayıtlar",
    "guide_btn_federation": "🌐 Federasyon",
    "guide_btn_ai_copilot": "🧠 NEXOR Copilot (Yapay Zekâ)",
    "guide_title_locks": "🔒 Kilitler ve Filtreler",
    "guide_title_moderation": "🛡 Moderasyon ve Cezalar",
    "guide_title_roles": "👮 Terfi / Rütbe Düşürme",
    "guide_title_settings": "⚙️ Grup Ayarları",
    "guide_title_security": "🚨 Anti-Raid ve Tam Kilit",
    "guide_title_rules": "📜 Grup Kuralları",
    "guide_title_autoreply": "💬 Anahtar Kelime ve Özel Komut",
    "guide_title_channel": "📢 Kanal ve Gönderiler",
    "guide_title_autoactions": "🤖 Otomatik Eylemler",
    "guide_title_notes": "📝 Notlar",
    "guide_title_reports_logs": "🚩 Raporlar ve Kayıtlar",
    "guide_title_federation": "🌐 Federasyon",
    "guide_title_ai_copilot": "🧠 NEXOR Copilot (Yapay Zekâ)",
    "guide_desc_locks": "Riskli içerikleri — bağlantı, fotoğraf, çıkartma, yönlendirme ve daha fazlasını — kilitle, gönderilir gönderilmez silinsin. Otomatik silinmesini istediğin başka şeyler için kelime veya alan adı filtresi ekle.",
    "guide_desc_moderation": "Kural bozanları uyar, sustur, at ya da yasakla; tek bir mesajı sil ya da koca bir aralığı tek seferde temizle — sohbeti düzenli tutmak için eksiksiz araç kutusu.",
    "guide_desc_roles": "Güvendiğin üyeleri iç moderatörlüğe terfi ettir, sonra rütbelerini düşür ve kimin hangi rol veya yetkiye sahip olduğunu tek bakışta gör.",
    "guide_desc_settings": "Bu grupla ilgili her şeyin tek ekranda toplandığı yer — kilitler, filtreler, captcha, uyarılar, dil — ayrıca admin paneline hızlı erişim.",
    "guide_desc_security": "Otomatik raid tespiti ani üye akınlarını yakalar; tam kilit ise işler kötüye gittiğinde tek dokunuşla tüm grubu kapatır.",
    "guide_desc_rules": "Grup kurallarını bir kez yaz, isteyen olduğunda göster ya da tamamen silip yeniden başla.",
    "guide_desc_autoreply": "Bota belirli kelimelere kendiliğinden cevap vermeyi öğret ya da tamamen kendi özel metin komutlarını oluştur.",
    "guide_desc_channel": "Gruba bir kanal bağla, gönderi paylaş ya da zamanla, sonradan düzenle veya sil ve kanal istatistiklerini takip et.",
    "guide_desc_autoactions": "Basit \"şu olursa şunu yap\" kuralları — bot mesaj türüne veya uyarı sayısına göre kendiliğinden tepki verir.",
    "guide_desc_notes": "Bir metni ya da dosyayı bir kez kaydet, ihtiyacın olduğunda kısa bir etiketle anında geri getir.",
    "guide_desc_reports_logs": "Üyeler tek dokunuşla sorun bildirir; sen de her adminin her işleminin tam kaydını görürsün.",
    "guide_desc_federation": "Birden çok grup arasında tek bir yasaklı listesi — birini bir kez yasakla, tüm federasyonda yasaklansın.",
    "guide_desc_ai_copilot": "Adminler için yapay zekâ asistanı: mesajları analiz eder, geçmiş işlemleri açıklar ve yeni kurallar önerir.",
    "guide_kw_lock": "Otomatik silinmesi için bir içerik türünü (örn. link, fotoğraf) kilitle.",
    "guide_kw_unlock": "Aktif bir kilidi kaldır.",
    "guide_kw_locks": "Bu gruptaki tüm aktif kilitleri göster.",
    "guide_kw_filter": "Otomatik silinecek yasaklı bir kelime/ifade ekle.",
    "guide_kw_stopfilter": "Bir kelime filtresini kaldır.",
    "guide_kw_filters": "Tüm aktif kelime filtrelerini listele.",
    "guide_kw_domains": "Engellenen alan adları listesini göster veya yönet.",
    "guide_kw_forwardrules": "Yönlendirilen mesajlar için izin/engel kurallarını göster.",
    "guide_kw_warn": "Bir üyeye uyarı ver.",
    "guide_kw_unwarn": "Bir üyeden bir uyarı kaldır.",
    "guide_kw_warns": "Bir üyenin kaç uyarısı olduğunu göster.",
    "guide_kw_mute": "Bir üyeyi belirli bir süre sustur.",
    "guide_kw_unmute": "Bir üyenin susturmasını kaldır.",
    "guide_kw_ban": "Bir üyeyi gruptan kalıcı olarak çıkar.",
    "guide_kw_unban": "Yasaklı bir üyenin geri dönmesine izin ver.",
    "guide_kw_kick": "Bir üyeyi at (tekrar katılabilir).",
    "guide_kw_del": "Bir mesajı sil — önce ona yanıt ver.",
    "guide_kw_purge": "Bir mesaj aralığını toplu olarak sil.",
    "guide_kw_promote": "Bir üyeyi iç moderatörlüğe terfi ettir.",
    "guide_kw_demote": "Bir üyenin moderatör rütbesini kaldır.",
    "guide_kw_roles": "İç moderatör rütbesine sahip herkesi listele.",
    "guide_kw_profiles": "Özel yetki profillerini yönet.",
    "guide_kw_myperms": "Kendi mevcut yetkilerini göster.",
    "guide_kw_settings": "Bu gruptaki tüm ayarların genel görünümü.",
    "guide_kw_setlang": "Grubun dilini değiştir.",
    "guide_kw_captcha": "Yeni üye captcha'sını aç/kapat.",
    "guide_kw_goodbye": "Veda mesajını aç/kapat.",
    "guide_kw_adminpanel": "Hızlı admin kısayolları panelini aç.",
    "guide_kw_antiraid": "Otomatik raid tespitini aç/kapat.",
    "guide_kw_lockdown": "Tüm grubu anında kilitle.",
    "guide_kw_unlockchat": "Tam kilidi kaldır.",
    "guide_kw_rules": "Grup kurallarını göster.",
    "guide_kw_setrules": "Grup kurallarını yaz veya güncelle.",
    "guide_kw_clearrules": "Grup kurallarını sil.",
    "guide_kw_addkeyword": "Otomatik yanıt tetikleyen bir kelime ekle.",
    "guide_kw_delkeyword": "Bir otomatik yanıt anahtar kelimesini kaldır.",
    "guide_kw_keywords": "Tüm otomatik yanıt anahtar kelimelerini listele.",
    "guide_kw_addcmd": "Kendi özel metin komutunu oluştur.",
    "guide_kw_delcmd": "Özel bir komutu sil.",
    "guide_kw_cmds": "Tüm özel komutları listele.",
    "guide_kw_setanswer": "Bir anahtar kelime için otomatik yanıt kur (metin/medya, 20'ye kadar rastgele yanıt).",
    "guide_kw_answerlist": "Ayarlanmış otomatik yanıt anahtar kelimelerini listele.",
    "guide_kw_delanswer": "Anahtar kelimesiyle bir otomatik yanıtı kaldır.",
    "guide_kw_cleananswerlist": "Bu gruptaki tüm otomatik yanıtları temizle.",
    "guide_kw_setchannel": "Bu gruba bir kanal bağla.",
    "guide_kw_post": "Bağlı kanala bir gönderi paylaş.",
    "guide_kw_schedulepost": "Bir gönderiyi daha sonrası için zamanla.",
    "guide_kw_editpost": "Zaten yayınlanmış bir gönderiyi düzenle.",
    "guide_kw_delpost": "Yayınlanmış bir gönderiyi sil.",
    "guide_kw_channelstats": "Bağlı kanalın istatistiklerini göster.",
    "guide_kw_addautoaction": "Otomatik bir \"şu olursa şunu yap\" kuralı oluştur.",
    "guide_kw_delautoaction": "Otomatik bir kuralı kaldır.",
    "guide_kw_autoactions": "Tüm otomatik kuralları listele.",
    "guide_kw_save": "Tekrar kullanılabilir bir not/parça kaydet.",
    "guide_kw_get": "Kaydedilmiş bir notu adıyla getir.",
    "guide_kw_notes": "Kaydedilmiş tüm notları listele.",
    "guide_kw_clear": "Kaydedilmiş bir notu sil.",
    "guide_kw_report": "Bir mesajı adminlere bildir.",
    "guide_kw_reports": "Açık, çözülmemiş raporları göster.",
    "guide_kw_alerts": "Admin uyarılarının nereye gideceğini yönet.",
    "guide_kw_adminabuseprotection": "Bir yönetici aniden çok sayıda yıkıcı işlem yaparsa seni uyarır.",
    "guide_kw_logs": "En son admin işlemlerini göster.",
    "guide_kw_exportsettings": "Bu grubun ayarlarını yedek olarak dışa aktar.",
    "guide_kw_setlogchannel": "Denetim kaydını alacak kanalı ayarla.",
    "guide_kw_fnew": "Yeni bir federasyon oluştur (ortak yasaklı listesi).",
    "guide_kw_fjoin": "Bu grubu mevcut bir federasyona katıl.",
    "guide_kw_fleave": "Mevcut federasyondan ayrıl.",
    "guide_kw_finfo": "Mevcut federasyon hakkında bilgi göster.",
    "guide_kw_fban": "Bir kullanıcıyı tüm federasyonda yasakla.",
    "guide_kw_funban": "Bir kullanıcının tüm federasyondaki yasağını kaldır.",
    "guide_kw_copilot": "NEXOR Copilot yapay zekâ asistanı menüsünü aç.",
    "guide_kw_aicheck": "Yapay zekâdan bir mesajı analiz etmesini iste — önce yanıtla.",
    "guide_kw_aiexplain": "Yapay zekâya birine neden işlem yapıldığını sor.",
    "guide_kw_aireports": "Yapay zekânın açık raporları önceliğe göre sıralamasını sağla.",
    "guide_kw_aihealth": "Grubun durumu hakkında yapay zekâ özeti al.",
    "guide_kw_airule": "Bir sorunu tarif et, yapay zekânın önerdiği kuralı al.",
    "guide_kw_aioptimize": "Yapay zekâdan otomatik kurallarını incelemesini iste.",
    "guide_kw_aiincident": "Yakın zamandaki bir olay hakkında yapay zekâ özeti al.",
    "guide_kw_aiplan": "Bu grubun yapay zekâ planını göster veya ayarla.",

    # --- Doğal Dil (niyet tabanlı) katmanı — nlu/ ---
    "nlu_confirm_mute": "{name} kullanıcısını {duration} susturayım mı?",
    "nlu_btn_confirm": "✅ Onayla",
    "nlu_btn_cancel": "❌ İptal",
    "nlu_ask_duration": "{name} kullanıcısını ne kadar süre susturayım? (örn: 30m, 2h, 1d)",
    "nlu_context_expired": "⌛️ Bu isteğin süresi doldu. Lütfen tekrar dene.",
    "nlu_not_your_confirmation": "Bu buton senin isteğin için değil.",
    "nlu_need_reply_target": "❗️Kimi kastettiğimi anlamam için o kullanıcının mesajını yanıtla.",
    "nlu_fallback_intro": "🤔 Tam anlayamadım. /help yazabilir ya da daha açık söyleyebilirsin.",
    "nlu_confirm_unmute": "{name} kullanıcısının susturması kaldırılsın mı?",
    "nlu_confirm_ban": "{name} kullanıcısı {duration} yasaklansın mı?",
    "nlu_confirm_unban": "{name} kullanıcısının yasağı kaldırılsın mı?",
    "nlu_confirm_kick": "{name} kullanıcısı gruptan atılsın mı?",
    "nlu_action_cancelled": "❌ İptal edildi; hiçbir şey yapılmadı.",
    "nlu_confirm_delete": "Bu mesaj silinsin mi?",
    "nlu_delete_done": "🗑 Mesaj silindi.",
    "nlu_confirm_setrules": "Grup kuralları bu metinle değiştirilsin mi?\n\n{text}",
    "nlu_setrules_format_hint": "Kuralları bu şekilde ayarlamak için şu formatı kullan:\n«kuralları ayarla: kural metni» (iki noktadan sonraki her şey aynen kaydedilir).",

    # --- Onboarding (handlers/onboarding.py + onboarding_logic.py) ---
    "onboarding_welcome": "👋 Merhaba! Ben NEXOR — bu grubu güvenli ve düzenli tutmana yardımcı oluyorum: moderasyon, anti-spam, karşılama/kurallar, otomatik yanıtlar ve daha fazlası.",
    "onboarding_needs_admin": "⚠️ Henüz burada yönetici değilim, bu yüzden çoğu özellik çalışmaz. Beni yönetici yap (en azından: mesaj silme, üyeleri kısıtlama, kullanıcı davet etme, mesaj sabitleme), ben de oradan devam edeyim.",
    "onboarding_missing_perms": "⚠️ Yöneticiyim ama şunlar eksik: {perms}. Bazı özellikler bunlara ihtiyaç duyar — istediğin zaman grup ayarlarından verebilirsin.",
    "onboarding_all_set": "✅ İhtiyacım olan izinlere sahibim. Hadi temel ayarları yapalım.",
    "onboarding_btn_security": "🛡 Güvenliği ayarla",
    "onboarding_btn_help": "❓ Neler yapabilirsin?",
    "perm_restrict": "üyeleri kısıtlama (sustur/at/yasakla)",
    "perm_delete": "mesajları silme",
    "perm_invite": "kullanıcı davet etme",
    "perm_pin": "mesaj sabitleme",
    "err_unexpected": "⚠️ Bunu yaparken bir şeyler ters gitti. Lütfen tekrar dene — devam ederse bir grup yöneticisine haber ver.",
    "nlu_delanswer_format_hint": "Bir otomatik yanıtı bu şekilde silmek için şu formatı kullan:\n«otomatik yanıt sil: anahtar kelime» (silinecek anahtar kelimenin tam hali).",
    "nlu_confirm_delanswer": "«{keyword}» anahtar kelimesi için otomatik yanıt silinsin mi?",
    # ---- Ads system (added) ----
    'ads_btn_cancel': '❌ Vazgeç',
    'ads_btn_free': '🆓 Ücretsiz ilan ver (günde 1 kez)',
    'ads_btn_paid': '💳 Reklam satın al (günde 1-5 kez)',
    'ads_intro': '📢 NEXOR Reklam Sistemi\n\nReklamlar sadece ücretsiz plandaki gruplarda gösterilir (Pro/Premium gruplar reklam görmez).\nÜcretsiz ilan günde sadece bir kez gösterilir; satın alınan reklam günde 1 ile 5 kez arasında yayınlanabilir (fiyat buna göre artar).\n\nHangisini istersin?',
    'ads_ask_banner': '🖼 Önce reklam için bir banner (görsel) gönder.\nBanner istemiyorsan: geç yaz',
    'ads_banner_invalid': 'Ya bir görsel gönder ya da bannersız devam etmek için «geç» yaz.',
    'ads_ask_text': '✍️ Şimdi ilan metnini gönder (gruplarda görünecek olan).',
    'ads_text_empty': 'İlan metni boş olamaz. Tekrar gönder.',
    'ads_times_btn': '{n}×/gün',
    'ads_ask_times': '📅 İlanın günde kaç kez yayınlansın? (ne kadar çok, o kadar pahalı)',
    'ads_free_submitted': '✅ Ücretsiz ilan #{id} yönetici incelemesine gönderildi.\nOnaylandıktan sonra, botun bağlı olduğu ücretsiz gruplarda günde bir kez gösterilecek.',
    'ads_duration_btn': '{days} gün — ⭐{stars}',
    'ads_ask_duration': 'İlanın ne kadar süre yayınlanacağını seç (seçilen sıklık: {times}×/gün):',
    'ads_btn_pay_stars': '⭐ Stars ile öde ({stars})',
    'ads_btn_pay_ton': '💎 TON ile öde ({ton})',
    'ads_order_summary': 'Sipariş özeti #{id}:\n• Sıklık: {times}×/gün\n• Süre: {days} gün\n• Fiyat: ⭐{stars}',
    'ads_order_summary_ton_suffix': ' / 💎{ton} TON',
    'ads_order_summary_footer': '\n\nÖdeme yöntemini seç:',
    'ads_order_invalid': '⚠️ Bu sipariş artık geçerli değil.',
    'ads_sending_invoice': '⭐ Telegram Stars faturası gönderiliyor...',
    'ads_invoice_title': '📢 Reklam satın alma — sipariş #{id}',
    'ads_invoice_desc': "NEXOR'a bağlı gruplar içinde reklam gösterimi satın alma (sadece ücretsiz plan).",
    'ads_invoice_label': 'NEXOR Reklamları',
    'ads_ton_disabled': '⚠️ TON ile ödeme şu an aktif değil ya da bu sipariş geçerli değil.',
    'ads_ton_payment_info': '💎 TON ile ödeme — sipariş #{id}\n\nTutar: {amount} TON\nCüzdan adresi: {address}\n⚠️ Transferin Comment/Memo alanına mutlaka şu kodu gir:\n{memo}\n\nDoğrudan link: {link}\n\nTransfer sonrası işlem otomatik kontrol edilir ve ilan yönetici inceleme sırasına girer.',
    'ads_cancelled': 'Vazgeçildi.',
    'ads_ton_confirmed': '✅ TON ödemesi onaylandı! Reklam siparişi #{id} yönetici incelemesine gönderildi.',
    'ads_admin_none_pending': 'İncelemede bekleyen ilan yok.',
    'ads_btn_approve': '✅ Onayla',
    'ads_btn_reject': '❌ Reddet',
    'ads_kind_free': '🆓 Ücretsiz',
    'ads_kind_paid': '💳 Satın alınmış',
    'ads_admin_caption': '#{id} — {kind}\nSıklık/gün: {times} — Süre: {days} gün\n\n{text}',
    'ads_approved_toast': 'Onaylandı ✅',
    'ads_approved_notify': '✅ İlan #{id} onaylandı ve programa göre ücretsiz gruplarda gösterilecek.',
    'ads_rejected_toast': 'Reddedildi ❌',
    'ads_none_yet': 'Henüz hiç ilan vermedin. /ads ile başla.',
    'ads_status_draft': 'Taslak',
    'ads_status_pending_payment': 'Ödeme bekliyor',
    'ads_status_pending_review': 'İncelemede',
    'ads_status_active': 'Aktif',
    'ads_status_rejected': 'Reddedildi',
    'ads_status_expired': 'Süresi doldu',
    'ads_status_active2': '✅ Aktif',
    'ads_status_rejected2': '❌ Reddedildi',
    'ads_status_expired2': '⌛ Süresi doldu',
    'ads_myads_header': '📋 İlanların:\n',
    'ads_myads_line': '#{id} — {status} — {times}×/gün — {days} gün',
    'ads_myads_footer': '\nBir ilanın istatistiklerini görmek için: /adstats <ilan no> — örneğin /adstats {id}',
    'ads_stats_usage': 'İlan numarasını da yaz, örneğin:\n/adstats 3\n\nİlan numaralarını /myads ile görebilirsin.',
    'ads_stats_not_found': 'Böyle bir ilan bulunamadı ya da sana ait değil.',
    'ads_stats_title': '📊 İlan #{id} istatistikleri',
    'ads_stats_status': 'Durum: {status}',
    'ads_stats_quota': 'Günlük kota: {quota}×/gün',
    'ads_stats_today': 'Bugün gönderilen: {today} / {quota}',
    'ads_stats_total': 'Toplam gösterim (başından beri): {total}',
    'ads_stats_unique': 'Bu ilanın gösterildiği benzersiz grup sayısı: {n}',
    'ads_stats_perday_header': '\nGünlük döküm (son günler):',
    'ads_stats_perday_line': '  {day}: {count} kez',
    'ads_stats_no_views': '\nBu ilan için henüz gösterim kaydı yok (ya da henüz onaylanmadı/aktif değil).',
    'ads_stars_confirmed': '✅ Ödeme onaylandı! Reklam siparişi #{id} yönetici incelemesine gönderildi.',
    'err_invalid_language': 'Geçersiz dil.',
    # ---- Buyplan payments (added) ----
    'buyplan_invoice_title': '👑 {plan} aboneliği ({months} ay)',
    'buyplan_invoice_desc': 'Grubu {months} ay boyunca {plan} planına yükselt.',
    'buyplan_invoice_price_label': '{plan} — {months} ay',
    'err_order_invalid': 'Bu sipariş artık geçerli değil.',
    'buyplan_stars_confirmed': '✅ Ödeme onaylandı!\n👑 Grup {plan} planına yükseltildi.',
    'buyplan_card_order_not_found': '⚠️ Sipariş bulunamadı ya da zaten işlendi.',
    'buyplan_card_confirmed_dm': '✅ Kart ödemesi onaylandı!\n👑 Grup {plan} planına yükseltildi.',
    'buyplan_card_admin_confirmed': '✅ Sipariş #{id} onaylandı ve {plan} planı etkinleştirildi.',
    'buyplan_card_admin_rejected': '❌ Sipariş #{id} reddedildi.',
    'buyplan_card_none_pending': 'İncelemede bekleyen kart siparişi yok.',
    'buyplan_card_pending_header': '💳 Onay bekleyen kart siparişleri:\n',
    'buyplan_card_pending_line': '#{id} — {plan} × {months} ay — kod: {code}',
    'buyplan_ton_instructions': '💎 TON ile {plan} aboneliği satın al\n\nTutar: {amount} TON\nCüzdan adresi: {address}\n⚠️ Transferin Comment/Memo alanına mutlaka şu kodu gir:\n{memo}\n\nYa da cüzdanında şu linki kullan:\n{link}\n\nTransfer alındıktan sonra işlem otomatik kontrol edilir ve abonelik etkinleştirilir (birkaç dakika sürebilir).',
    'buyplan_ton_confirmed': '✅ TON ödemesi onaylandı!\n👑 Grup {plan} planına yükseltildi.',
    'buyplan_card_header': '💳 Havale/EFT ile {plan} aboneliği satın al\n',
    'buyplan_card_amount': 'Tutar: {amount} Tümen',
    'buyplan_card_number': 'Kart numarası: {number}',
    'buyplan_card_holder': 'Hesap sahibi: {holder}',
    'buyplan_card_reference': '\nSipariş takip kodu: {ref}',
    'buyplan_card_instructions': 'Transferden sonra, yukarıdaki takip koduyla birlikte dekont fotoğrafını bot yöneticisine gönder; aboneliğin elle onaylanıp etkinleştirilsin.',
    'buyplan_header': '👑 NEXOR Copilot planını yükselt\nİstediğin planı seç:',
    'buyplan_choose_method': '{plan} planı — ödeme yöntemini seç:',
    'buyplan_closed': 'Kapatıldı.',
    'buyplan_dm_failed': '⚠️ Sana özel mesaj gönderemedim. Önce botla özel sohbette /start yaz, sonra tekrar /buyplan dene.',
    'buyplan_stars_sent': '⭐ Stars ile ödeme faturası botla özel sohbetine gönderildi. Ödemeyi orada tamamla.',
    'buyplan_ton_sent': '💎 TON ödeme talimatları (cüzdan adresi + memo kodu) botla özel sohbetine gönderildi.',
    'buyplan_ton_unavailable': '⚠️ Bu plan için TON ile ödeme şu anda kullanılamıyor.',
    # ---- Command menu descriptions (added) ----
    'cmd_desc_start': 'Botu kullanmaya başla',
    'cmd_desc_help': 'Komut rehberi',
    'cmd_desc_settings': 'Grup ayarları',
    'cmd_desc_setlang': 'Grup dilini değiştir (yönetici)',
    'cmd_desc_rules': 'Grup kuralları',
    'cmd_desc_warn': 'Kullanıcıyı uyar',
    'cmd_desc_unwarn': 'Bir uyarıyı kaldır',
    'cmd_desc_warns': 'Kullanıcının uyarılarını gör',
    'cmd_desc_mute': 'Kullanıcıyı sustur',
    'cmd_desc_unmute': 'Susturmayı kaldır',
    'cmd_desc_ban': 'Kullanıcıyı yasakla',
    'cmd_desc_unban': 'Yasağı kaldır',
    'cmd_desc_kick': 'Kullanıcıyı at',
    'cmd_desc_del': 'Mesajı sil (yanıtla)',
    'cmd_desc_purge': 'Toplu mesaj silme',
    'cmd_desc_lock': 'Bir içerik türünü kilitle',
    'cmd_desc_unlock': 'Kilidi aç',
    'cmd_desc_locks': 'Aktif kilitleri göster',
    'cmd_desc_promote': 'Dahili yönetici yap',
    'cmd_desc_demote': 'Dahili yöneticilikten al',
    'cmd_desc_roles': 'Dahili yöneticileri listele',
    'cmd_desc_logs': 'Son yönetici işlemleri',
    'cmd_desc_copilot': '🤖 NEXOR Copilot (yönetici AI asistanı)',
    'cmd_desc_buyplan': '👑 Planı yükselt (Stars / TON) — reklamsız',
    'cmd_desc_ads': '📢 Ücretsiz ilan ver veya reklam satın al',
    'cmd_desc_myads': '📋 İlanlarım',
    'cmd_desc_adstats': '📊 Bir ilanın istatistikleri',
    'cmd_desc_adadmin': '🛠 İlan inceleme kuyruğu (yönetici)',

    # ==================== Günlük Bildirim (Daily Notify) ====================
    "day_mon": "Pazartesi", "day_tue": "Salı", "day_wed": "Çarşamba", "day_thu": "Perşembe",
    "day_fri": "Cuma", "day_sat": "Cumartesi", "day_sun": "Pazar",
    "month_g_1": "Ocak", "month_g_2": "Şubat", "month_g_3": "Mart", "month_g_4": "Nisan",
    "month_g_5": "Mayıs", "month_g_6": "Haziran", "month_g_7": "Temmuz", "month_g_8": "Ağustos",
    "month_g_9": "Eylül", "month_g_10": "Ekim", "month_g_11": "Kasım", "month_g_12": "Aralık",
    "month_j_1": "Farvardin", "month_j_2": "Ordibehesht", "month_j_3": "Khordad", "month_j_4": "Tir",
    "month_j_5": "Mordad", "month_j_6": "Shahrivar", "month_j_7": "Mehr", "month_j_8": "Aban",
    "month_j_9": "Azar", "month_j_10": "Dey", "month_j_11": "Bahman", "month_j_12": "Esfand",
    "date_format_gregorian": "{weekday}, {day} {month} {year}",
    "date_format_jalali": "{weekday}, {day} {month} {year}",

    "daily_date_line": "📅 Bugün: {date}",
    "daily_occasion_line": "🎉 Özel gün: {occasion}",

    "daily_price_header": "💰 Bugünün Fiyatları",
    "daily_price_line": "• {asset}: {value} {unit}",
    "daily_price_footer": "Kaynak: {sources}",

    "daily_news_header": "📰 Bugünün Haberleri",
    "daily_news_item": "{n}. {title}",
    "daily_news_summary": "   {summary}",
    "daily_news_source": "   🔗 Kaynak: {source}",

    "asset_gold18": "18 Ayar Altın", "asset_usd": "Amerikan Doları (USD)", "asset_eur": "Euro (EUR)",
    "asset_usdt": "Tether (USDT)", "asset_ton": "Toncoin (TON)", "asset_stars": "Telegram Stars",
    "asset_btc": "Bitcoin (BTC)", "asset_eth": "Ethereum (ETH)",
    "unit_toman": "Tümen", "unit_usd": "Dolar",

    "panel_not_owner": "Bu panel sadece açan kişiye yanıt verir.",

    "dn_menu_header": "🔔 *Günlük Bildirim*",
    "dn_menu_prices": "💰 Fiyatlar: {state} — saat {time}",
    "dn_menu_assets_line": "   Aktif varlıklar: {assets}",
    "dn_menu_news": "📰 Haberler: {state} — saat {time}",
    "dn_menu_timezone": "🌍 Saat dilimi: {tz}",
    "dn_menu_date_flags": "📅 Tarih/Özel gün — Fiyat: {dp}/{op}   Haber: {dn}/{on}",

    "dn_btn_toggle_prices": "💰 Fiyatları aç/kapat",
    "dn_btn_toggle_news": "📰 Haberleri aç/kapat",
    "dn_btn_assets": "🪙 Varlık seç",
    "dn_btn_flags": "📅 Tarih/özel gün ayarları",
    "dn_btn_test_price": "🧪 Fiyat testi",
    "dn_btn_test_news": "🧪 Haber testi",
    "dn_btn_help": "❓ Yardım",
    "dn_btn_close": "❌ Kapat",

    "dn_assets_header": "🪙 Açmak/kapatmak için bir varlığa dokun:",
    "dn_flags_header": "📅 Tarih/özel gün gösterimini fiyat ve haber için ayrı ayarla:",
    "dn_flag_date_price": "Fiyat mesajında tarih",
    "dn_flag_occasion_price": "Fiyat mesajında özel gün",
    "dn_flag_date_news": "Haber mesajında tarih",
    "dn_flag_occasion_news": "Haber mesajında özel gün",

    "dn_help_text": (
        "📖 *Günlük Bildirim Yardımı*\n\n"
        "💰 Fiyatlar ve 📰 Haberler her gün belirlediğiniz saatte bu gruba gönderilir.\n\n"
        "/setpricetime HH:MM — fiyat gönderim saati\n"
        "/setnewstime HH:MM — haber gönderim saati\n"
        "/setdailytz saat_dilimi — örn. Asia/Tehran (varsayılan grup diline göre)\n"
        "/testdailyprice   /testdailynews — hemen test gönderimi\n"
        "/dailyassets — gösterilecek varlıkları seç\n"
        "Diğer her şey (açık/kapalı, tarih/özel gün) yukarıdaki butonlarla değiştirilebilir."
    ),
    "dn_toast_saved": "✅ Kaydedildi.",
    "dn_toast_sending": "⏳ Gönderiliyor...",
    "dn_test_no_data": "⚠️ Şu anda geçerli veri yok (sağlayıcı erişilemiyor ya da henüz yeni içerik yok).",

    "dn_log_toggle_prices": "Günlük fiyat bildirimi: {state}",
    "dn_log_toggle_news": "Günlük haber bildirimi: {state}",
    "dn_log_settime": "{what} gönderim saati: {time}",
    "dn_log_settz": "Günlük bildirim saat dilimi: {tz}",

    "dn_settime_usage": "Kullanım: {cmd} HH:MM (örn. 09:00)",
    "dn_settime_invalid": "⛔️ Geçersiz saat biçimi. HH:MM kullanın (örn. 09:00).",
    "dn_settime_done": "✅ Gönderim saati {time} olarak ayarlandı.",
    "dn_settz_usage": "Kullanım: /setdailytz saat_dilimi (örn. Asia/Tehran)",
    "dn_settz_invalid": "⛔️ Geçersiz saat dilimi. Asia/Tehran gibi geçerli bir IANA saat dilimi girin.",
    "dn_settz_done": "✅ Grup saat dilimi: {tz}",

    "cmd_desc_dailynotify": "🔔 Günlük bildirim ayarları (fiyat/haber)",
}


# ---------------------------------------------------------------------------
# TEXT_TRIGGERS (Türkçe) — کلمه/عبارتی که کاربر به‌جای دستور "/" تایپ می‌کند
# تا با همون تابع handlers/text_commands.py وصل بشه. هر شناسه (کلید) دقیقاً
# با همون نامی که در handlers/text_commands.py::COMMANDS استفاده شده باید یکی باشه.
# ---------------------------------------------------------------------------
TEXT_TRIGGERS = {
    "help": ["yardım"],
    "settings": ["ayarlar"],
    "warn": ["uyar"],
    "unwarn": ["uyarı kaldır"],
    "warns": ["uyarılar"],
    "mute": ["sustur"],
    "unmute": ["susturmayı kaldır"],
    "ban": ["yasakla"],
    "unban": ["yasağı kaldır"],
    "kick": ["at"],
    "del": ["sil"],
    "purge": ["temizle"],
    "promote": ["yükselt"],
    "demote": ["indir"],
    "roles": ["moderatörler"],
    "logs": ["kayıtlar"],
    "setlang": ["dil değiştir"],
    "lock": ["kilitle"],
    "unlock": ["kilidi aç"],
    "locks": ["kilitler"],
    "filter": ["filtre"],
    "stopfilter": ["filtreyi kaldır"],
    "filters": ["filtreler"],
    "domains": ["engelli siteler"],
    "forwardrules": ["yönlendirme kuralları"],
    "antiraid": ["baskın koruması"],
    "lockdown": ["tam kilit"],
    "unlockchat": ["grubu aç"],
    "captcha": ["captcha"],
    "goodbye": ["hoşçakal"],
    "rules": ["kurallar"],
    "setrules": ["kuralları ayarla"],
    "clearrules": ["kuralları temizle"],
    "addkeyword": ["anahtar kelime ekle"],
    "delkeyword": ["anahtar kelime sil"],
    "keywords": ["anahtar kelimeler"],
    "setanswer": ["otomatik yanıt ayarla"],
    "answerlist": ["otomatik yanıt listesi"],
    "cleananswerlist": ["otomatik yanıt listesini temizle"],
    "delanswer": ["otomatik yanıt sil"],
    "addcmd": ["komut ekle"],
    "delcmd": ["komut sil"],
    "cmds": ["komutlar"],
    "setchannel": ["kanal ayarla"],
    "post": ["gönderi"],
    "schedulepost": ["gönderi zamanla"],
    "editpost": ["gönderiyi düzenle"],
    "delpost": ["gönderiyi sil"],
    "channelstats": ["kanal istatistikleri"],
    "addautoaction": ["otomatik eylem ekle"],
    "delautoaction": ["otomatik eylemi sil"],
    "autoactions": ["otomatik eylemler"],
    "profiles": ["profiller"],
    "myperms": ["yetkilerim"],
    "report": ["şikayet"],
    "reports": ["şikayetler"],
    "alerts": ["bildirimler"],
    "exportsettings": ["ayarları dışa aktar"],
    "save": ["kaydet"],
    "get": ["getir"],
    "notes": ["notlar"],
    "clear": ["notu temizle"],
    "setlogchannel": ["kayıt kanalı ayarla"],
    "fnew": ["yeni federasyon"],
    "fjoin": ["federasyona katıl"],
    "fleave": ["federasyondan ayrıl"],
    "finfo": ["federasyon bilgisi"],
    "adminpanel": ["yönetici", "panel"],
    "fban": ["federasyon yasağı"],
    "funban": ["federasyon yasağını kaldır"],
    "copilot": ["asistan", "yapay zeka asistanı", "kopilot"],
    "aicheck": ["yapay zeka kontrolü"],
    "aiexplain": ["işlemi açıkla"],
    "aireports": ["raporları analiz et"],
    "aihealth": ["grup sağlığı"],
    "airule": ["kural danışmanı"],
    "aioptimize": ["kuralları optimize et"],
    "aiincident": ["olayı analiz et"],
    "aiplan": ["yapay zeka planı"],
    # ==================== Phase 3 migration additions ====================
    "allowword": ["kelimeye izin ver"],
    "disallowword": ["kelime iznini kaldır"],
    "blockdomain": ["alan adını engelle"],
    "unblockdomain": ["alan adı engelini kaldır"],
    "allowdomain": ["alan adına izin ver"],
    "unallowdomain": ["alan adı iznini kaldır"],
    "allowforward": ["yönlendirmeye izin ver"],
    "blockforward": ["yönlendirmeyi engelle"],
    "unruleforward": ["yönlendirme kuralını kaldır"],
    "setfilteraction": ["filtre eylemini ayarla"],
    "mentionprotection": ["etiketleme koruması"],
    "setmentionlimit": ["etiketleme sınırını ayarla"],
    "setmentionaction": ["etiketleme eylemini ayarla"],
    "antispam": ["spam engelleme"],
    "setspamaction": ["spam eylemini ayarla"],
    "dupcross": ["gruplar arası tekrar"],
    "setdupcross": ["gruplar arası tekrarı ayarla"],
    "setflood": ["flood ayarla"],
    "setfloodaction": ["flood eylemini ayarla"],
    "setraidthreshold": ["baskın eşiğini ayarla"],
    "setmaxwarns": ["maksimum uyarıyı ayarla"],
    "setwarnaction": ["uyarı eylemini ayarla"],
    "setwelcomedelete": ["karşılama silmeyi ayarla"],
    "setgoodbye": ["veda mesajını ayarla"],
    "resetgoodbye": ["veda mesajını sıfırla"],
    "createprofile": ["profil oluştur"],
    "delprofile": ["profili sil"],
    "assignprofile": ["profil ata"],
    "unassignprofile": ["profil atamasını kaldır"],
    "setalertchannel": ["uyarı kanalını ayarla"],
    "importsettings": ["ayarları içe aktar"],
    "schedulerecurring": ["tekrarlayan gönderi zamanla"],
    "recurringposts": ["tekrarlayan gönderiler"],
    "delrecurring": ["tekrarlayan gönderiyi sil"],
    "autoactiontoggle": ["otomatik eylemi aç/kapat"],
    "dailynotify": ["günlük bildirim"],
    "setpricetime": ["fiyat saatini ayarla"],
    "setnewstime": ["haber saatini ayarla"],
    "setdailytz": ["günlük saat dilimini ayarla"],
    "testdailyprice": ["günlük fiyatı test et"],
    "testdailynews": ["günlük haberi test et"],
    "dailyassets": ["günlük varlıklar"],
    "ads": ["reklamlar"],
    "myads": ["reklamlarım"],
    "adadmin": ["reklam yönetimi"],
    "adstats": ["reklam istatistikleri"],
    "buyplan": ["plan satın al"],
}
