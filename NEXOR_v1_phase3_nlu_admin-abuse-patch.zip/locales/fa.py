# -*- coding: utf-8 -*-
STRINGS = {
    # رتبه‌ها
    "rank_user": "کاربر",
    "rank_moderator": "مدیر (Moderator)",
    "rank_admin": "ادمین",
    "rank_owner": "مالک",

    # خطاهای عمومی
    "err_need_rank": "⛔️ این دستور نیاز به سطح دسترسی «{rank}» یا بالاتر دارد.",
    "err_self_action": "روی خودتون که نمی‌شه این اکشن رو زد! 😅",
    "err_rank_too_low": "⛔️ شما سطح دسترسی کافی برای اقدام روی این کاربر را ندارید (کاربر مقصد هم‌رتبه یا بالاتر از شماست).",
    "err_user_not_found_username": "❌ این کاربر رو نتونستم پیدا کنم (باید قبلاً حداقل یک پیام تو این گروه فرستاده باشه تا ربات بشناسدش).",
    "err_need_target": "❗️کاربر مقصد پیدا نشد.\nاستفاده: {usage}",

    # Warn
    "warn_given": "⚠️ {name} یک اخطار گرفت. ({count}/{max})",
    "warn_reason_line": "\nدلیل: {reason}",
    "warn_removed": "➖ اخطار {name} کم شد. ({count}/{max})",
    "warn_escalate_mute": "🔇 {name} به دلیل رسیدن به {max} اخطار، {duration} سکوت شد.",
    "warn_escalate_ban": "🚫 {name} به دلیل رسیدن به {max} اخطار، بن شد.",
    "warns_header": "⚠️ اخطارهای {name}: {count}/{max}",
    "warns_history_line": "• {when} — {reason} (توسط {actor})",
    "warns_no_reason": "بدون دلیل",
    "setwarnaction_usage": "استفاده: /setwarnaction mute یا /setwarnaction ban",
    "setwarnaction_done": "✅ اکشن بعد از رسیدن به سقف اخطار: {action}",
    "setmaxwarns_usage": "استفاده: /setmaxwarns عدد (مثلا 3)",
    "setmaxwarns_done": "✅ سقف اخطار به {n} تغییر کرد.",

    # Mute
    "mute_done": "🔇 {name} سکوت شد (مدت: {duration}).",
    "unmute_done": "🔊 سکوت {name} برداشته شد.",

    # Ban
    "ban_done": "🚫 {name} بن شد (مدت: {duration}).",
    "unban_done": "✅ بن {name} برداشته شد.",
    "duration_permanent": "دائم/همیشگی",

    # Kick
    "kick_done": "👢 {name} از گروه اخراج شد.",

    # Delete/Purge
    "del_usage": "لطفاً روی پیامی که می‌خواهید حذف شود ریپلای کنید.",
    "purge_usage": "استفاده: با ریپلای روی یک پیام /purge بزنید، یا /purge تعداد",
    "purge_done": "🧹 {count} پیام پاک شد.",

    # Roles
    "promote_usage": "لطفاً روی کاربر مورد نظر ریپلای کنید یا @username/ID بدهید.",
    "promote_already_admin": "این کاربر از قبل ادمین واقعی تلگرام است؛ نیازی به نقش داخلی نیست.",
    "promote_done": "⭐️ {name} به عنوان Moderator داخلی ربات منصوب شد.",
    "demote_done": "⬇️ نقش Moderator از {name} گرفته شد.",
    "roles_empty": "هیچ Moderator داخلی‌ای ثبت نشده. (برای دیدن ادمین‌های واقعی از پنل تلگرام گروه استفاده کنید.)",
    "roles_header": "⭐️ Moderatorهای داخلی این گروه:",
    "logs_empty": "هنوز هیچ اقدامی ثبت نشده.",
    "logs_header": "🧾 آخرین اقدامات ادمین/مدیریت:",

    # دکمه‌های سریع
    "btn_remove_warn": "➖ حذف اخطار",
    "btn_mute": "🔇 سکوت",
    "btn_ban": "🚫 بن",
    "modact_invalid_data": "داده نامعتبر.",
    "modact_wrong_chat": "این دکمه برای این گروه نیست.",
    "modact_no_permission": "⛔️ شما دسترسی لازم برای این اکشن را ندارید.",
    "modact_done": "انجام شد ✅",
    "modact_unwarn_result": "➖ {name} — یک اخطار کم شد. ({count})",
    "modact_mute_result": "🔇 {name} برای {minutes} دقیقه سکوت شد.",
    "modact_ban_result": "🚫 {name} بن شد.",

    # پایه/راهنما/تنظیمات
    "start_msg": (
        "سلام {mention} عزیز 🌹\n\n"
        "🔰 با *NEXOR* آشنا شو — حرفه‌ای‌ترین ربات مدیریت گروه\n"
        "🔰 دستیار قدرتمند برای نظم، امنیت و کنترل کامل گروه‌های تلگرامی\n\n"
        "✨ *ویژگی‌های کلیدی:*\n"
        "✅ مدیریت کامل اعضا (اخطار، سکوت، بن، اخراج)\n"
        "✅ قفل هوشمند محتوا (لینک، فوروارد، مدیا و ...)\n"
        "✅ فیلتر پیشرفته کلمات و عبارات ممنوعه\n"
        "✅ کپچای عضویت برای جلوگیری از ربات‌های مزاحم\n"
        "✅ ضد اسپم و ضد فلود پیشرفته\n"
        "✅ محافظت در برابر ریدهای گروهی (Anti-Raid)\n"
        "✅ مدیریت کانال متصل (پست، زمان‌بندی، ویرایش، حذف)\n"
        "✅ سیستم فدراسیون بین چند گروه\n"
        "✅ نقش‌های داخلی، لاگ و گزارش‌گیری کامل\n"
        "✅ چندزبانه (فارسی، انگلیسی، عربی، ترکی، روسی، اسپانیایی)\n\n"
        "🤖 *NEXOR Copilot — دستیار هوش مصنوعی گروهت:*\n"
        "✅ فقط با یک Reply، پیام مشکوک رو در چند ثانیه تحلیل می‌کنه و ریسکش رو می‌سنجه\n"
        "✅ می‌پرسی «چرا؟» و برات دقیق توضیح می‌ده پشت هر اخطار/بن/سکوت چه دلیلی بوده\n"
        "✅ یه گزارش سلامت از کل گروه می‌ده: کجاها شلوغه، کجا باید سخت‌گیر بشی\n"
        "✅ کافیه مشکلت رو به زبون خودت بگی («تبلیغات زیاد شده») تا خودش یه قانون خودکار پیشنهاد و بسازه\n"
        "✅ گزارش‌های کاربرا و رخدادهای اخیر رو قبل از تصمیم، برات اولویت‌بندی و تحلیل می‌کنه\n"
        "با /copilot یه سر بهش بزن! ✨\n"
        "\n"
        "🚀 *نصب و راه‌اندازی:*\n"
        "۱. با دکمه‌ی زیر ربات رو به گروهت اضافه کن\n"
        "۲. بهش دسترسی کامل ادمین بده تا فعال بشه\n\n"
        "📌 *نکات مهم:*\n"
        "• گروه باید سوپرگروه باشه\n"
        "• برای بهترین عملکرد، دسترسی کامل ادمین پیشنهاد می‌شه\n\n"
        "برای دیدن لیست کامل دستورات از /help استفاده کن."
    ),
    "add_to_group_button": "➕ افزودن به گروه",
    "settings_header": "⚙️ *تنظیمات فعلی گروه*",
    "settings_locks": "🔒 قفل‌ها: {locks}",
    "settings_filters": "🚫 فیلترها: {filters}",
    "settings_captcha": "🛡️ کپچا: {state}",
    "settings_warns": "⚠️ سقف اخطار: {max} → اکشن: {action}",
    "settings_channel": "📢 کانال متصل: {channel}",
    "settings_logchannel": "🧾 لاگ‌چنل: {log}",
    "settings_lang": "🌐 زبان: {lang}",
    "none": "هیچ‌کدام",
    "not_set": "—",

    # زبان
    "setlang_prompt": "🌐 زبان گروه را انتخاب کنید:",
    "setlang_done": "✅ زبان گروه به {lang_name} تغییر کرد.",

    # کپچا/خوش‌آمد
    "welcome_simple": "سلام {mention} عزیز، به {chat} خوش اومدی! 🌹",
    "welcome_captcha": "سلام {mention} عزیز، به {chat} خوش اومدی! 🌹\nبرای شروع، لطفاً روی دکمه زیر بزن تا تایید بشی.",
    "welcome_simple_multi": "به {chat} خوش اومدید: {mentions} 🌹",
    "welcome_captcha_multi": "به {chat} خوش اومدید: {mentions} 🌹\nهرکس برای تایید، روی دکمه‌ی کنار اسم خودش بزنه.",
    "captcha_btn": "✅ من ربات نیستم",
    "captcha_not_yours": "این دکمه برای شما نیست.",
    "captcha_expired": "این تایید منقضی شده.",
    "captcha_verified_alert": "✅ تایید شدی، خوش اومدی!",
    "captcha_verified_msg": "✅ {name} تایید شد و می‌تونه پیام بده.",
    "captcha_timeout_msg": "⛔️ زمان تایید کپچا تموم شد و کاربر از گروه خارج شد.",
    "captcha_toggle_usage": "استفاده: /captcha on یا /captcha off",
    "captcha_toggle_done": "🛡️ کپچا {state} شد.",
    "captcha_on": "فعال",
    "captcha_off": "غیرفعال",
    "goodbye_msg": "{name} از گروه خارج شد. 👋",

    # قفل/فیلتر
    "lock_usage": "استفاده: /lock {options}",
    "lock_done": "🔒 {kind} قفل شد.",
    "unlock_usage": "استفاده: /unlock {options}",
    "unlock_done": "🔓 {kind} آزاد شد.",
    "locks_active": "🔒 قفل‌های فعال: {locks}",
    "filter_usage": "استفاده: /filter کلمه",
    "filter_added": "➕ کلمه‌ی «{word}» به فیلتر اضافه شد.",
    "stopfilter_usage": "استفاده: /stopfilter کلمه",
    "filter_removed": "➖ کلمه‌ی «{word}» از فیلتر حذف شد.",
    "filters_active": "🚫 فیلترهای فعال: {filters}",
    "flood_muted": "🚨 {name} به دلیل ارسال پیام زیاد در زمان کوتاه، برای {minutes} دقیقه سکوت شد.",

    # یادداشت‌ها
    "save_usage": "استفاده: /save نام متن  (یا با ریپلای روی یک پیام: /save نام)",
    "save_empty": "متنی برای ذخیره پیدا نشد.",
    "save_done": "📝 یادداشت «{name}» ذخیره شد. با /get {name} یا #{name} قابل مشاهده‌ست.",
    "get_usage": "استفاده: /get نام",
    "get_not_found": "یادداشتی با این نام پیدا نشد.",
    "notes_empty": "هنوز یادداشتی ذخیره نشده.",
    "notes_list_header": "📝 یادداشت‌های موجود:",
    "clear_usage": "استفاده: /clear نام",
    "clear_done": "🗑️ یادداشت «{name}» حذف شد.",

    # لاگ‌چنل
    "setlogchannel_usage": "استفاده: /setlogchannel @channel＿username یا شناسه عددی کانال",
    "setlogchannel_error": "❌ نتونستم کانال رو پیدا کنم: {error}",
    "setlogchannel_done": "🧾 اقدامات ادمین از این پس در «{title}» ثبت می‌شن.",
    "setlogchannel_channel_confirm": "✅ این کانال به عنوان لاگ‌چنل مدیریت گروه تنظیم شد.",

    # Federation
    "fed_new_usage": "استفاده: /fnew نام＿فدراسیون",
    "fed_new_done": "🌐 فدراسیون «{name}» ساخته شد (شناسه: {id}).\nاین گروه به‌عنوان اولین عضو اضافه شد.\nبرای اضافه کردن گروه‌های دیگه، تو اون گروه‌ها دستور زیر رو بزن:\n/fjoin {id}",
    "fed_join_usage": "استفاده: /fjoin شناسه＿فدراسیون",
    "fed_join_invalid_id": "شناسه فدراسیون نامعتبره.",
    "fed_not_found": "فدراسیونی با این شناسه پیدا نشد.",
    "fed_join_done": "✅ این گروه به فدراسیون «{name}» پیوست.",
    "fed_not_member": "این گروه عضو هیچ فدراسیونی نیست.",
    "fed_left": "👋 این گروه از فدراسیون «{name}» خارج شد.",
    "fed_info": "🌐 فدراسیون: {name}\n🆔 شناسه: {id}\n👥 تعداد گروه‌های عضو: {count}",
    "fed_ban_no_target": "لطفاً روی پیام کاربر مورد نظر ریپلای کنید یا @username/ID بدید.",
    "fed_ban_not_member": "این گروه عضو هیچ فدراسیونی نیست. اول /fnew یا /fjoin بزن.",
    "fed_ban_done": "🚫 {name} در فدراسیون «{fed}» بن شد.\n✅ موفق: {success} گروه | ❌ ناموفق: {failed} گروه\nدلیل: {reason}",
    "fed_unban_done": "✅ بن {name} در {success} گروه فدراسیون «{fed}» برداشته شد.",
    "fed_ban_no_reason": "بدون دلیل ذکرشده",
    "fed_raid_kick_notice": "🚫 {name} در فدراسیون بن بود و خودکار اخراج شد.",

    "help_text": (
        "📋 *دستورات مدیریتی*\n\n"
        "✨ *یه نکته‌ی باحال:* لازم نیست همیشه با «/» بنویسی! هر دستور یک هم‌معنیِ کلمه‌ای هم داره که با تایپ ساده‌ی همون کلمه، دقیقاً همون اتفاق می‌افته — مثلاً تایپ‌کردن «گزارش» عیناً کار /report رو انجام می‌ده، یا نوشتن «راهنما» همین صفحه رو براتون باز می‌کنه. این ویژگی توی هر ۶ زبانی که ربات پشتیبانی می‌کنه با کلمات همون زبون کار می‌کنه؛ یعنی هر عضو گروه، با زبون خودش و بدون حفظ‌کردن هیچ اسلش‌کامندی، می‌تونه ربات رو به حرف بیاره! 🗣️\n\n"
        "👮 *مدیریت اعضا* (با ریپلای یا @username یا user＿id)\n"
        "/warn [مدت] [دلیل]   /unwarn   /warns — تاریخچه اخطار\n"
        "/mute [مدت] [دلیل]   /unmute\n"
        "/ban [مدت] [دلیل]   /unban\n"
        "/kick [دلیل]\n"
        "مثال: /ban 2h اسپم زیاد   یا   /mute @user 30m\n"
        "/setmaxwarns عدد   /setwarnaction mute|ban\n\n"
        "🧹 *حذف پیام*\n"
        "/del — حذف پیام ریپلای‌شده\n"
        "/purge — حذف از پیام ریپلای‌شده تا الان (یا /purge تعداد)\n\n"
        "⭐️ *نقش‌های داخلی*\n"
        "/promote /demote — نقش Moderator داخلی ربات (پایین‌تر از ادمین واقعی)\n"
        "/roles — لیست Moderatorهای داخلی\n"
        "/logs — آخرین اقدامات مدیریتی (Audit Log)\n\n"
        "🔒 *قفل محتوا*\n"
        "/lock link|invitelink|channellink|photo|video|sticker|voice|forward|gif|video＿note|document|poll\n"
        "/unlock همان\n"
        "/locks — نمایش قفل‌های فعال\n\n"
        "🌐 *Link Protection*\n"
        "/blockdomain دامنه   /unblockdomain دامنه\n"
        "/allowdomain دامنه   /unallowdomain دامنه\n"
        "/domains — نمایش لیست‌ها\n\n"
        "🚫 *فیلتر کلمات*\n"
        "/filter کلمه\n/stopfilter کلمه\n/filters\n"
        "/setfilteraction delete|warn|mute|ban\n"
        "/allowword کلمه — استثنا از فیلتر   /disallowword کلمه\n\n"
        "🕵️ *آنتی‌اسپم*\n"
        "/antispam on|off\n/setspamaction delete|warn|mute|ban\n"
        "/dupcross on|off   /setdupcross آستانه ثانیه\n\n"
        "↪️ *محافظت از فوروارد*\n"
        "/allowforward منبع   /blockforward منبع   /unruleforward منبع\n"
        "/forwardrules — نمایش قوانین (منبع: @username، ID یا نام)\n\n"
        "📛 *محافظت از Mention*\n"
        "/mentionprotection on|off\n/setmentionlimit عدد\n/setmentionaction delete|warn|mute|ban\n\n"
        "🚨 *آنتی‌فلاد*\n"
        "/setflood تعداد ثانیه\n/setfloodaction delete|warn|mute|ban\n\n"
        "🛡️ *آنتی‌رید*\n"
        "/antiraid on|off\n/setraidthreshold عدد\n"
        "/lockdown — قفل فوری کل گروه   /unlockchat — باز کردن\n\n"
        "🛡️ *کپچا*\n"
        "/captcha on|off — روشن/خاموش کردن تایید عضو جدید\n\n"
        "📝 *یادداشت‌ها*\n"
        "/save نام (با ریپلای یا متن) — ذخیره یادداشت\n"
        "/get نام یا #نام — نمایش یادداشت\n"
        "/notes — لیست یادداشت‌ها\n"
        "/clear نام — حذف یادداشت\n\n"
        "📢 *مدیریت کانال (در گروه اجرا می‌شود)*\n"
        "/setchannel @channel＿username — اتصال کانال\n"
        "/post متن — ارسال فوری پست (دکمه با «متن|لینک» و ; بین دکمه‌ها)\n"
        "/schedulepost دقیقه | متن — پست زمان‌بندی‌شده\n"
        "/editpost شناسه＿پیام | متن جدید\n"
        "/delpost شناسه＿پیام\n"
        "/channelstats — آمار کانال\n\n"
        "🧾 *لاگ ادمین*\n"
        "/setlogchannel @channel＿username — ثبت اقدامات ادمین در یک کانال\n\n"
        "🌐 *Federation (لیست بن مشترک)*\n"
        "/fnew نام — ساخت فدراسیون جدید\n"
        "/fjoin شناسه — پیوستن این گروه به فدراسیون\n"
        "/fleave — خروج از فدراسیون\n"
        "/finfo — اطلاعات فدراسیون فعلی\n"
        "/fban (ریپلای) دلیل — بن در همه گروه‌های فدراسیون\n"
        "/funban (ریپلای) — رفع بن در همه گروه‌های فدراسیون\n\n"
        "🆕 *اعضای جدید و اتوماسیون*\n"
        "/setwelcomedelete ثانیه|off — حذف خودکار پیام خوش‌آمد\n"
        "/setgoodbye متن   /resetgoodbye   /goodbye on|off\n"
        "/rules   /setrules [زبان] متن   /clearrules [زبان]\n"
        "/addkeyword کلمه پاسخ   /delkeyword کلمه   /keywords\n"
        "/addcmd نام پاسخ   /delcmd نام   /cmds\n"
        "/schedulerecurring daily|weekly|monthly ... — پست تکرارشونده در کانال\n"
        "/recurringposts   /delrecurring شناسه\n"
        "/addautoaction شرط اکشن   /delautoaction شناسه   /autoactions   /autoactiontoggle on|off\n\n"
        "💬 *پاسخ خودکار (Auto-Answer)*\n"
        "/setanswer — در گروه بفرست و از دکمه‌ی پیوی، کلیدواژه/مخاطب/پاسخ (تا ۲۰ پاسخ رندوم، متن یا رسانه) رو تنظیم کن\n"
        "/answerlist — نمایش کلیدواژه‌های تنظیم‌شده\n"
        "/delanswer کلمه — حذف یک کلیدواژه\n"
        "/cleananswerlist — پاک‌کردن همه‌ی پاسخ‌های خودکار\n\n"
        "🗂️ *پروفایل‌های دسترسی*\n"
        "/createprofile نام قابلیت1,قابلیت2,...   /delprofile نام   /profiles\n"
        "/assignprofile [ریپلای|@user|id] نام‌پروفایل   /unassignprofile [ریپلای|@user|id]   /myperms\n\n"
        "🚩 *گزارش‌ها (Reports)*\n"
        "/report [دلیل] (ریپلای روی پیام)   /reports — گزارش‌های باز\n\n"
        "🔔 *هشدارهای ادمین (Alerts)*\n"
        "/setalertchannel chat＿id   /alerts — Alertهای اخیر\n\n"
        "📦 *Import / Export تنظیمات*\n"
        "/exportsettings   /importsettings (ریپلای روی فایل .json)\n\n"
        "🔔 *اطلاع‌رسانی روزانه* (💰 قیمت + 📰 اخبار + 📅 تاریخ/مناسبت)\n"
        "/dailynotify — پنل تنظیمات (روشن/خاموش، دارایی‌ها، تست ارسال)\n"
        "/setpricetime HH:MM   /setnewstime HH:MM   /setdailytz منطقه‌زمانی\n"
        "/testdailyprice   /testdailynews   /dailyassets\n\n"
        "🌐 /setlang — تغییر زبان گروه\n"
        "⚙️ /settings — نمایش تنظیمات فعلی گروه"
    ),

    "help_words_text": (
        "📖 *لیست کامل کلمات جایگزین دستورها*\n"
        "هر خط یعنی: این کلمه رو تایپ کن = دقیقاً همون دستور اجرا می‌شه\n"
        "\n"
        "*👮 مدیریت اعضا*\n"
        "اخطار = /warn\n"
        "حذف اخطار = /unwarn\n"
        "اخطارها = /warns\n"
        "سکوت = /mute\n"
        "لغو سکوت = /unmute\n"
        "بن = /ban\n"
        "لغو بن = /unban\n"
        "اخراج = /kick\n"
        "حذف پیام = /del\n"
        "پاکسازی = /purge\n"
        "\n"
        "*⭐️ نقش و لاگ*\n"
        "ارتقا = /promote\n"
        "تنزل = /demote\n"
        "مدیران = /roles\n"
        "لاگ = /logs\n"
        "تغییر زبان = /setlang\n"
        "\n"
        "*🔒 قفل و فیلتر*\n"
        "قفل = /lock\n"
        "باز کردن قفل = /unlock\n"
        "قفل‌ها = /locks\n"
        "فیلتر = /filter\n"
        "حذف فیلتر = /stopfilter\n"
        "فیلترها = /filters\n"
        "دامنه‌های مسدود = /domains\n"
        "قوانین فوروارد = /forwardrules\n"
        "\n"
        "*🛡️ امنیت گروه*\n"
        "آنتی رید = /antiraid\n"
        "قفل کامل گروه = /lockdown\n"
        "باز کردن گروه = /unlockchat\n"
        "کپچا = /captcha\n"
        "خداحافظی = /goodbye\n"
        "\n"
        "*📝 یادداشت‌ها*\n"
        "ذخیره = /save\n"
        "دریافت = /get\n"
        "یادداشت‌ها = /notes\n"
        "پاک کردن یادداشت = /clear\n"
        "\n"
        "*📢 کانال*\n"
        "تنظیم کانال = /setchannel\n"
        "پست = /post\n"
        "زمان‌بندی پست = /schedulepost\n"
        "ویرایش پست = /editpost\n"
        "حذف پست = /delpost\n"
        "آمار کانال = /channelstats\n"
        "تنظیم لاگ = /setlogchannel\n"
        "\n"
        "*🌐 فدراسیون*\n"
        "فدراسیون جدید = /fnew\n"
        "عضویت فدراسیون = /fjoin\n"
        "ترک فدراسیون = /fleave\n"
        "اطلاعات فدراسیون = /finfo\n"
        "بن فدراسیون = /fban\n"
        "لغو بن فدراسیون = /funban\n"
        "\n"
        "*🆕 خوش‌آمد و اتوماسیون*\n"
        "قوانین = /rules\n"
        "تنظیم قوانین = /setrules\n"
        "پاک کردن قوانین = /clearrules\n"
        "افزودن کلیدواژه = /addkeyword\n"
        "حذف کلیدواژه = /delkeyword\n"
        "کلیدواژه‌ها = /keywords\n"
        "افزودن دستور = /addcmd\n"
        "حذف دستور = /delcmd\n"
        "دستورها = /cmds\n"
        "افزودن اکشن خودکار = /addautoaction\n"
        "حذف اکشن خودکار = /delautoaction\n"
        "اکشن‌های خودکار = /autoactions\n"
        "\n"
        "*💬 پاسخ خودکار*\n"
        "تنظیم پاسخ = /setanswer\n"
        "لیست پاسخ = /answerlist\n"
        "پاکسازی لیست پاسخ = /cleananswerlist\n"
        "حذف پاسخ = /delanswer\n"
        "\n"
        "*🗂️ دسترسی و گزارش*\n"
        "پروفایل‌ها = /profiles\n"
        "دسترسی من = /myperms\n"
        "گزارش = /report\n"
        "گزارش‌ها = /reports\n"
        "هشدارها = /alerts\n"
        "خروجی تنظیمات = /exportsettings\n"
        "\n"
        "*🤖 NEXOR Copilot*\n"
        "ادمین = /adminpanel\n"
        "دستیار = /copilot\n"
        "بررسی هوش مصنوعی = /aicheck\n"
        "توضیح اقدام = /aiexplain\n"
        "تحلیل گزارش‌ها = /aireports\n"
        "سلامت گروه = /aihealth\n"
        "پیشنهاد قانون = /airule\n"
        "بهینه‌سازی قوانین = /aioptimize\n"
        "تحلیل حادثه = /aiincident\n"
        "پلن هوش مصنوعی = /aiplan\n"
        "\n"
        "*⚙️ عمومی*\n"
        "تنظیمات = /settings\n"
        "راهنما = /help\n"
        "\n"
        "💡 عبارت‌های چندکلمه‌ای (مثل «حذف پیام») رو دقیقاً همون‌جوری، پشت‌سرهم بنویس."
    ),

    # مدیریت کانال
    "channel_set_usage": "استفاده: /setchannel @channel＿username یا شناسه عددی کانال",
    "channel_set_error": "❌ نتونستم کانال رو پیدا کنم: {error}",
    "channel_set_done": "📢 کانال «{title}» با این گروه متصل شد.",
    "channel_no_channel": "اول با /setchannel یک کانال متصل کن.",
    "channel_post_empty": "متن پست خالیه. استفاده: /post متن پیام",
    "channel_post_sent": "✅ پست ارسال شد. شناسه پیام: {id}",
    "channel_post_failed": "❌ ارسال پست ناموفق بود: {error}",
    "channel_schedule_usage": "استفاده: /schedulepost دقیقه سپس در خط بعد متن پست",
    "channel_schedule_invalid_minutes": "عدد دقیقه نامعتبره.",
    "channel_schedule_empty": "متن پست خالیه.",
    "channel_schedule_done": "⏰ پست برای {minutes} دقیقه‌ی دیگر زمان‌بندی شد.",
    "channel_scheduled_sent": "✅ پست زمان‌بندی‌شده ارسال شد. شناسه: {id}",
    "channel_scheduled_failed": "❌ ارسال پست زمان‌بندی‌شده ناموفق بود: {error}",
    "channel_editpost_usage": "استفاده: /editpost شناسه＿پیام سپس در خط بعد متن جدید",
    "channel_editpost_invalid_id": "شناسه پیام نامعتبره.",
    "channel_editpost_empty": "متن جدید خالیه.",
    "channel_editpost_done": "✅ پست ویرایش شد.",
    "channel_editpost_failed": "❌ ویرایش ناموفق بود: {error}",
    "channel_delpost_usage": "استفاده: /delpost شناسه＿پیام",
    "channel_delpost_done": "🗑️ پست حذف شد.",
    "channel_delpost_failed": "❌ حذف ناموفق بود: {error}",
    "channel_stats_text": "📊 آمار کانال «{title}»\n👥 تعداد اعضا: {count}",
    "channel_stats_failed": "❌ گرفتن آمار ناموفق بود: {error}",

    # عمومی روشن/خاموش
    "state_on": "فعال",
    "state_off": "غیرفعال",

    # Anti-Spam
    "antispam_toggle_usage": "استفاده: /antispam on یا /antispam off",
    "antispam_toggle_done": "🕵️ آنتی‌اسپم {state} شد.",
    "adminabuseprotection_toggle_usage": "استفاده: /adminabuseprotection on یا /adminabuseprotection off (فقط مالک گروه)",
    "adminabuseprotection_toggle_done": "🚷 تشخیص سوءاستفاده‌ی ادمین {state} شد.",
    "setspamaction_usage": "استفاده: /setspamaction delete|warn|mute|ban",
    "setspamaction_done": "✅ اکشن آنتی‌اسپم: {action}",
    "spam_reason_duplicate": "ارسال پیام تکراری",
    "spam_reason_newlink": "ارسال لینک توسط عضو تازه‌وارد",

    # Anti-Flood
    "setflood_usage": "استفاده: /setflood تعداد ثانیه  (مثلا /setflood 5 10)",
    "setflood_done": "✅ آنتی‌فلاد: {limit} پیام در {window} ثانیه",
    "setfloodaction_usage": "استفاده: /setfloodaction delete|warn|mute|ban",
    "setfloodaction_done": "✅ اکشن آنتی‌فلاد: {action}",
    "flood_reason": "ارسال پیام بیش‌ازحد سریع",

    # Forbidden Words
    "setfilteraction_usage": "استفاده: /setfilteraction delete|warn|mute|ban",
    "setfilteraction_done": "✅ اکشن فیلتر کلمات: {action}",
    "allowword_usage": "استفاده: /allowword کلمه",
    "allowword_done": "➕ «{word}» به لیست استثناها اضافه شد.",
    "disallowword_usage": "استفاده: /disallowword کلمه",
    "disallowword_done": "➖ «{word}» از لیست استثناها حذف شد.",
    "filter_reason": "کلمه ممنوعه",

    # Link Protection / Domains
    "blockdomain_usage": "استفاده: /blockdomain دامنه (مثل example.com)",
    "blockdomain_done": "🚫 دامنه‌ی «{domain}» بلاک شد.",
    "unblockdomain_usage": "استفاده: /unblockdomain دامنه",
    "unblockdomain_done": "✅ دامنه‌ی «{domain}» از بلاک خارج شد.",
    "allowdomain_usage": "استفاده: /allowdomain دامنه",
    "allowdomain_done": "✅ دامنه‌ی «{domain}» به وایت‌لیست اضافه شد.",
    "unallowdomain_usage": "استفاده: /unallowdomain دامنه",
    "unallowdomain_done": "➖ دامنه‌ی «{domain}» از وایت‌لیست حذف شد.",
    "domains_header_block": "🚫 دامنه‌های بلاک‌شده:",
    "domains_header_allow": "✅ دامنه‌های وایت‌لیست:",
    "domains_empty": "هیچ دامنه‌ای ثبت نشده.",
    "link_reason_blacklisted": "لینک دامنه‌ی بلاک‌شده",

    # Anti-Raid
    "antiraid_toggle_usage": "استفاده: /antiraid on یا /antiraid off",
    "antiraid_toggle_done": "🛡️ آنتی‌رید {state} شد.",
    "setraidthreshold_usage": "استفاده: /setraidthreshold عدد (مثلا 8)",
    "setraidthreshold_done": "✅ آستانه‌ی تشخیص رید به {n} کاربر تغییر کرد.",
    "raid_detected_alert": "🚨 *هشدار رید!*\nتعداد غیرعادی کاربر جدید ({count} نفر در {window} ثانیه) وارد گروه شدن.\nگروه به مدت {minutes} دقیقه قفل شد (فقط ادمین‌ها می‌تونن پیام بدن).",
    "raid_auto_unlock": "🔓 قفل امنیتی خودکار برداشته شد.",
    "lockdown_done": "🔒 گروه قفل شد؛ فقط ادمین‌ها می‌تونن پیام بدن.",
    "unlock_done_manual": "🔓 قفل گروه برداشته شد.",
    "already_locked": "گروه از قبل قفله.",
    "already_unlocked": "گروه قفل نیست.",
    "btn_unlock_now": "🔓 باز کردن قفل الان",

    # --- Priority 3: Content Control (Forward Protection / Mention Protection / Cross-user Duplicate) ---
    "allowforward_usage": "استفاده: /allowforward @username|ID|نام",
    "allowforward_done": "✅ فوروارد از «{source}» همیشه مجاز شد.",
    "blockforward_usage": "استفاده: /blockforward @username|ID|نام",
    "blockforward_done": "🚫 فوروارد از «{source}» همیشه مسدود شد.",
    "unruleforward_usage": "استفاده: /unruleforward @username|ID|نام",
    "unruleforward_done": "➖ قانون فوروارد برای «{source}» حذف شد.",
    "forwardrules_header_block": "🚫 منابع همیشه مسدود:",
    "forwardrules_header_allow": "✅ منابع همیشه مجاز:",
    "forwardrules_empty": "هیچ قانونی برای فوروارد ثبت نشده.",
    "forward_reason_blocked_source": "فوروارد از منبع مسدودشده ({source})",
    "mentionprotection_usage": "استفاده: /mentionprotection on یا /mentionprotection off",
    "mentionprotection_done": "🛡️ محافظت از Mention {state}.",
    "setmentionlimit_usage": "استفاده: /setmentionlimit عدد (مثلا 5)",
    "setmentionlimit_done": "✅ سقف Mention به {n} تغییر کرد.",
    "setmentionaction_usage": "استفاده: /setmentionaction delete|warn|mute|ban",
    "setmentionaction_done": "✅ اکشن سوءاستفاده از Mention: {action}",
    "mention_reason": "سوءاستفاده از Mention دسته‌جمعی ({count} منشن)",
    "dupcross_usage": "استفاده: /dupcross on یا /dupcross off",
    "dupcross_done": "🕵️ تشخیص پیام تکراری بین چند کاربر {state}.",
    "setdupcross_usage": "استفاده: /setdupcross آستانه ثانیه (مثلا 3 45)",
    "setdupcross_done": "✅ تنظیمات تکراری بین‌کاربری: {threshold} کاربر در {window} ثانیه.",
    "spam_reason_cross_duplicate": "پیام تکراری از چند کاربر مختلف (Copy/Paste Raid)",

    # --- Priority 4: New Members & Automation (Welcome auto-delete, Goodbye, Rules, Filters, Custom Commands, Scheduled Messages, Auto Actions) ---
    "setwelcomedelete_usage": "استفاده: /setwelcomedelete ثانیه (مثلا 60) یا /setwelcomedelete off",
    "setwelcomedelete_done": "✅ پیام خوش‌آمد از این به بعد بعد از {seconds} ثانیه خودکار حذف می‌شه.",
    "setwelcomedelete_off": "✅ حذف خودکار پیام خوش‌آمد غیرفعال شد.",
    "setgoodbye_usage": "استفاده: /setgoodbye <متن>\nمتغیرهای قابل استفاده: {name} {username} {mention} {chat} {count}",
    "setgoodbye_done": "✅ پیام خداحافظی سفارشی ذخیره شد.",
    "resetgoodbye_done": "✅ پیام خداحافظی به حالت پیش‌فرض برگشت.",
    "goodbye_toggle_usage": "استفاده: /goodbye on یا /goodbye off",
    "goodbye_toggle_done": "👋 پیام خداحافظی {state} شد.",
    "rules_empty": "هنوز قانونی برای این گروه ثبت نشده.",
    "rules_header": "📜 *قوانین گروه*",
    "setrules_usage": "استفاده: /setrules [کد زبان] <متن قوانین>\nمثال: /setrules لطفاً به همه احترام بگذارید.\nبا کد زبان: /setrules en Please be respectful.",
    "setrules_done": "✅ قوانین ذخیره شد ({lang}).",
    "clearrules_done": "🗑️ قوانین حذف شد ({lang}).",
    "clearrules_notfound": "برای این زبان قانونی ثبت نشده بود.",
    "addkeyword_usage": "استفاده: /addkeyword <کلمه کلیدی> <پاسخ>\nیا با ریپلای: /addkeyword <کلمه کلیدی>",
    "addkeyword_done": "✅ تریگر کلمه‌کلیدی «{keyword}» اضافه شد.",
    "addkeyword_updated": "♻️ تریگر کلمه‌کلیدی «{keyword}» به‌روزرسانی شد.",
    "delkeyword_usage": "استفاده: /delkeyword <کلمه کلیدی>",
    "delkeyword_done": "🗑️ تریگر کلمه‌کلیدی «{keyword}» حذف شد.",
    "delkeyword_notfound": "چنین تریگری وجود نداشت.",
    "keywords_empty": "هیچ تریگر کلمه‌کلیدی‌ای ثبت نشده.",
    "keywords_header": "🔑 تریگرهای کلمه‌کلیدی:",

    # ==================== Auto-Answer (پاسخ خودکار) ====================
    "autoanswer_group_only": "این دستور فقط داخل گروه قابل استفاده است.",
    "autoanswer_pm_button": "🔐 ورود به پیوی برای تنظیم پاسخ خودکار",
    "autoanswer_setup_intro": "◄ پاسخ خودکار ( Auto-Answer )\n\nبرای تنظیم یک پاسخ خودکار جدید برای «{title}»، روی دکمه‌ی زیر بزن و مراحل رو داخل پیوی ادامه بده.",
    "autoanswer_invalid_link": "این لینک نامعتبر یا منقضی شده. دوباره از داخل گروه دستور «تنظیم پاسخ» را بفرست.",
    "autoanswer_not_admin": "⛔️ برای تنظیم پاسخ خودکار باید ادمین یا مالک همان گروه باشی.",
    "autoanswer_ask_audience": "⚙️ تنظیم پاسخ خودکار برای «{title}»\n\nربات به پاسخ این کلیدواژه به چه کسانی پاسخ بدهد؟",
    "autoanswer_audience_all": "👥 همه کاربران",
    "autoanswer_audience_admins": "🛡 فقط مقام‌داران",
    "autoanswer_audience_owners": "👑 فقط مالکین",
    "autoanswer_ask_keyword": "✏️ حالا کلمه یا جمله‌ی کلیدی را بفرست (مثلاً: قیمت، قوانین، ادمین و...).",
    "autoanswer_ask_response": "📎 کلیدواژه‌ی «{keyword}» ثبت شد.\n\nحالا پیام یا رسانه‌ای که می‌خواهی ربات در جواب بفرستد را ارسال کن (متن، عکس، ویدیو، وویس، آهنگ، فایل، گیف، استیکر یا ویدیوی سلفی).\n\nمی‌تونی تا ۲۰ پاسخ مختلف بفرستی تا ربات هر بار یکی رو تصادفی انتخاب کنه. وقتی تموم شد، دکمه‌ی «پایان» رو بزن.",
    "autoanswer_response_added": "✅ پاسخ {count} از {max} ثبت شد.\nپاسخ بعدی رو بفرست یا «پایان» را بزن.",
    "autoanswer_max_responses": "⛔️ به سقف {max} پاسخ رسیدی. برای ذخیره «پایان» را بزن.",
    "autoanswer_unsupported_content": "این نوع پیام پشتیبانی نمی‌شود. متن، عکس، ویدیو، وویس، آهنگ، فایل، گیف، استیکر یا ویدیوی سلفی بفرست.",
    "autoanswer_btn_done": "✅ پایان",
    "autoanswer_btn_cancel": "❌ انصراف",
    "autoanswer_need_one_response": "هنوز هیچ پاسخی ثبت نکرده‌ای؛ حداقل یک پیام یا رسانه بفرست.",
    "autoanswer_expired": "این مرحله دیگر معتبر نیست؛ دوباره از داخل گروه دستور «تنظیم پاسخ» را بفرست.",
    "autoanswer_cancelled": "❌ لغو شد؛ هیچ پاسخ خودکاری ثبت نشد.",
    "autoanswer_saved": "✅ پاسخ خودکار برای «{title}» ثبت شد.\nکلیدواژه: {keyword}\nمخاطب: {audience}\nتعداد پاسخ: {count}",
    "autoanswer_updated": "♻️ پاسخ خودکار «{keyword}» برای «{title}» به‌روزرسانی شد.\nمخاطب: {audience}\nتعداد پاسخ: {count}",
    "autoanswer_list_empty": "هیچ پاسخ خودکاری ثبت نشده.",
    "autoanswer_list_header": "◄ لیست پاسخ‌های خودکار:",
    "autoanswer_list_item": "• «{keyword}» — مخاطب: {audience} — {count} پاسخ",
    "autoanswer_cleaned": "🗑️ {count} پاسخ خودکار پاک شد.",
    "delanswer_usage": "استفاده: /delanswer <کلمه کلیدی>",
    "delanswer_done": "🗑️ پاسخ خودکار «{keyword}» حذف شد.",
    "delanswer_notfound": "چنین پاسخ خودکاری وجود نداشت.",
    "addcmd_usage": "استفاده: /addcmd <نام> <پاسخ>\nیا با ریپلای: /addcmd <نام>",
    "addcmd_reserved": "⛔ این نام برای یک دستور داخلی رزرو شده.",
    "addcmd_done": "✅ دستور سفارشی /{name} اضافه شد.",
    "addcmd_updated": "♻️ دستور سفارشی /{name} به‌روزرسانی شد.",
    "delcmd_usage": "استفاده: /delcmd <نام>",
    "delcmd_done": "🗑️ دستور سفارشی /{name} حذف شد.",
    "delcmd_notfound": "چنین دستور سفارشی‌ای وجود نداشت.",
    "cmds_empty": "هیچ دستور سفارشی‌ای تعریف نشده.",
    "cmds_header": "⚙️ دستورهای سفارشی:",
    "schedulerecurring_usage": "استفاده:\n/schedulerecurring daily HH:MM <متن>\n/schedulerecurring weekly mon HH:MM <متن>\n/schedulerecurring monthly DAY HH:MM <متن>\n(روز هفته: mon tue wed thu fri sat sun — روز ماه: 1 تا 28)",
    "schedulerecurring_invalid_time": "زمان نامعتبر. از فرمت HH:MM استفاده کنید (مثلا 14:30).",
    "schedulerecurring_invalid_day": "روز ماه نامعتبر. عددی بین 1 تا 28 وارد کنید.",
    "schedulerecurring_invalid_weekday": "روز هفته نامعتبر. یکی از این‌ها: mon tue wed thu fri sat sun",
    "schedulerecurring_empty_text": "متن پیام لازمه (در خط(های) بعد از دستور).",
    "schedulerecurring_done": "✅ پست تکرارشونده زمان‌بندی شد (شناسه {id}).",
    "recurringposts_header": "🔁 پست‌های تکرارشونده:",
    "recurringposts_empty": "هیچ پست تکرارشونده‌ای زمان‌بندی نشده.",
    "recurringposts_item": "#{id} — {schedule} — {preview}",
    "recurring_desc_daily": "روزانه ساعت {time}",
    "recurring_desc_weekly": "هفتگی، روز {weekday} ساعت {time}",
    "recurring_desc_monthly": "ماهانه، روز {day} ساعت {time}",
    "delrecurring_usage": "استفاده: /delrecurring <شناسه>",
    "delrecurring_done": "🗑️ پست تکرارشونده #{id} حذف شد.",
    "delrecurring_notfound": "پست تکرارشونده‌ای با این شناسه پیدا نشد.",
    "addautoaction_usage": "استفاده: /addautoaction <شرط> <اکشن>\nشرط‌ها: message＿type:<photo|video|sticker|voice|gif|video＿note|document|poll|forward|link|text>، user＿role:<user|moderator|admin>، warns＿gte:<عدد>\nاکشن‌ها: delete, warn, mute:<دقیقه>, ban, kick",
    "addautoaction_invalid_condition": "شرط نامعتبره. برای دیدن فرمت، /addautoaction را بدون آرگومان اجرا کنید.",
    "addautoaction_invalid_action": "اکشن نامعتبره. برای دیدن فرمت، /addautoaction را بدون آرگومان اجرا کنید.",
    "addautoaction_done": "✅ قانون Auto Action اضافه شد (شناسه {id}): {condition} → {action}",
    "delautoaction_usage": "استفاده: /delautoaction <شناسه>",
    "delautoaction_done": "🗑️ قانون Auto Action #{id} حذف شد.",
    "delautoaction_notfound": "قانون Auto Action‌ای با این شناسه پیدا نشد.",
    "autoactions_header": "🤖 قوانین Auto Action:",
    "autoactions_empty": "هیچ قانون Auto Action‌ای تعریف نشده.",
    "autoactiontoggle_usage": "استفاده: /autoactiontoggle on یا /autoactiontoggle off",
    "autoactiontoggle_done": "🤖 Auto Actions {state} شد.",
    "autoaction_reason": "قانون Auto Action (#{id})",
    "settings_goodbye": "👋 پیام خداحافظی: {state}",
    "settings_autoaction": "🤖 Auto Actions: {state}",

    # Priority 5, Item 25 — Permission Profiles
    "createprofile_usage": "استفاده: /createprofile <نام> <قابلیت1,قابلیت2,...>\nقابلیت‌های موجود: {caps}",
    "profile_invalid_caps": "❌ قابلیت نامعتبر: {invalid}\nقابلیت‌های موجود: {caps}",
    "createprofile_done": "✅ پروفایل «{name}» با قابلیت‌های زیر ساخته شد: {caps}",
    "createprofile_updated": "♻️ پروفایل «{name}» با قابلیت‌های زیر به‌روزرسانی شد: {caps}",
    "delprofile_usage": "استفاده: /delprofile <نام>",
    "delprofile_notfound": "چنین پروفایلی وجود ندارد.",
    "delprofile_done": "🗑️ پروفایل «{name}» حذف شد.",
    "profiles_empty": "هنوز هیچ Permission Profile سفارشی‌ای تعریف نشده.",
    "profiles_header": "🗂️ پروفایل‌های دسترسی:",
    "profile_item": "• «{name}» — {caps}\n   اعضا: {members}",
    "assignprofile_usage": "استفاده: /assignprofile [ریپلای|@user|id] <نام پروفایل>",
    "assignprofile_notfound_profile": "پروفایلی با نام «{name}» وجود ندارد. اول با /createprofile بسازید.",
    "assignprofile_done": "✅ پروفایل «{profile}» به {name} اختصاص داده شد.",
    "unassignprofile_usage": "استفاده: /unassignprofile [ریپلای|@user|id]",
    "unassignprofile_notfound": "این کاربر هیچ پروفایلی ندارد.",
    "unassignprofile_done": "➖ پروفایل از {name} برداشته شد.",
    "myperms_with_profile": "رتبه‌ی شما: {rank}\nپروفایل اختصاص‌یافته: «{profile}»\nقابلیت‌ها: {caps}",
    "myperms_no_profile": "رتبه‌ی شما: {rank}\nهیچ پروفایل سفارشی‌ای ندارید.",

    # Priority 5, Item 26 — Reports
    "report_need_reply": "لطفاً روی پیامی که می‌خواهید Report کنید ریپلای بزنید.",
    "report_self": "نمی‌تونی خودتو Report کنی! 😅",
    "report_already": "شما اخیراً همین پیام رو Report کرده‌اید.",
    "report_done": "✅ گزارش شما برای ادمین‌ها ارسال شد. ممنون!",
    "report_alert_header": "🚩 گزارش جدید #{id}\nگزارش‌دهنده: {reporter}\nگزارش‌شده: {target}\nدلیل: {reason}",
    "alert_multi_reports_text": "روی {target} در {window} ثانیه‌ی اخیر {count} گزارش مجزا ثبت شده.",
    "reports_empty": "هیچ گزارش بازی وجود ندارد.",
    "reports_header": "🚩 گزارش‌های باز:",
    "report_item": "• #{id} [{when}] {reporter} ← {target} ({reason})",
    "btn_report_mute": "🔇 سکوت",
    "btn_report_ban": "🚫 بن",
    "btn_report_delete": "🗑️ حذف پیام",
    "btn_report_dismiss": "✖️ رد گزارش",
    "report_not_found": "این گزارش دیگر وجود ندارد یا قبلاً رسیدگی شده.",
    "report_action_done_dismiss": "✖️ گزارش #{id} روی {target} رد شد.",
    "report_action_done_mute": "🔇 {target} از طریق گزارش به مدت {minutes} دقیقه سکوت شد.",
    "report_action_done_ban": "🚫 {target} از طریق گزارش بن شد.",
    "report_action_done_delete": "🗑️ پیام گزارش‌شده از {target} حذف شد.",

    # Priority 5, Item 27 — Admin Alerts
    "setalertchannel_usage": "استفاده: /setalertchannel <chat＿id> (بدون آرگومان = پاک کردن)",
    "setalertchannel_done": "✅ مقصد Alertها روی {channel} تنظیم شد.",
    "setalertchannel_cleared": "✅ مقصد اختصاصی Alert پاک شد (Alertها در همین گروه/لاگ‌چنل ارسال می‌شوند).",
    "alerts_empty": "هنوز هیچ Alertی ثبت نشده.",
    "alerts_header": "🔔 Alertهای اخیر:",
    "alert_type_multi_reports": "چند گزارش پیاپی",
    "alert_type_suspicious": "فعالیت مشکوک",
    "alert_type_security": "رویداد امنیتی",
    "alert_type_abnormal": "رفتار غیرعادی",
    "alert_type_admin_abuse": "سوءاستفاده‌ی احتمالی ادمین",
    "admin_abuse_alert_detail": "🧑‍💼 {name} در {minutes} دقیقه‌ی اخیر {count} اکشن مخرب (بن/سکوت/اخراج/اخطار) زده — ممکنه اکانتش هک شده باشه یا داره سوءاستفاده می‌کنه. بررسی کن.",
    "alert_type_raid": "تشخیص Raid",
    "alert_type_generic": "هشدار",

    # Priority 5, Item 28 — Import / Export Settings
    "exportsettings_caption": "📦 خروجی تنظیمات گروه.\n{summary}",
    "importsettings_usage": "روی یک فایل .json تنظیمات ریپلای بزنید و /importsettings را بفرستید.",
    "importsettings_invalid_json": "❌ این فایل به‌عنوان JSON معتبر خوانده نشد.",
    "importsettings_invalid_schema": "❌ فایل تنظیمات نامعتبر است (مشکل: {detail}).",
    "importsettings_confirm_prompt": "⚠️ این کار تنظیمات فعلی گروه را با موارد زیر *جایگزین* می‌کند:\n{summary}\nمطمئنید؟",
    "importsettings_cancelled": "❌ Import لغو شد.",
    "importsettings_done": "✅ تنظیمات با موفقیت Import شد.\n{summary}",
    "btn_import_confirm": "✅ تأیید Import",
    "btn_import_cancel": "❌ لغو",

    # پنل شخصی ادمین
    "panel_header": "🛠 پنل مدیریت {name}\n\nیک بخش رو انتخاب کن:",
    "panel_btn_settings": "⚙️ تنظیمات",
    "panel_btn_locks": "🔒 قفل‌ها",
    "panel_btn_filters": "🚫 فیلترها",
    "panel_btn_rules": "📜 قوانین",
    "panel_btn_reports": "🚩 گزارش‌های باز",
    "panel_btn_logs": "🗒 لاگ",
    "panel_btn_roles": "👮 مدیران",
    "panel_btn_daily": "🔔 اطلاع‌رسانی روزانه",
    "panel_daily_hint": "برای تغییر تنظیمات: /dailynotify",
    "panel_btn_back": "🔙 بازگشت",
    "panel_btn_close": "❌ بستن",
    "panel_not_yours": "این پنل مخصوص همون کسیه که بازش کرده.",
    "panel_closed": "پنل بسته شد.",

    # ---------------------------------------------------------------------------
    # TEXT_TRIGGERS (فارسی) — کلمه/عبارتی که کاربر به‌جای دستور "/" تایپ می‌کند
# تا با همون تابع handlers/text_commands.py وصل بشه. هر شناسه (کلید) دقیقاً
# با همون نامی که در handlers/text_commands.py::COMMANDS استفاده شده باید یکی باشه.
# ---------------------------------------------------------------------------
    # ==================== NEXOR Copilot (AI Module) ====================
    "ai_panel_header": "🤖 NEXOR Copilot\nدستیار هوش مصنوعی ادمین‌ها — یک بخش رو انتخاب کن:",
    "ai_btn_analyze": "🔍 Analyze Message",
    "ai_btn_explain": "❓ Explain Action",
    "ai_btn_health": "📊 Group Health",
    "ai_btn_reports": "🗂 Review Reports",
    "ai_btn_optimize": "🛠 Optimize Rules",
    "ai_btn_incident": "🚨 Analyze Incident",
    "ai_btn_rule": "➕ Rule Advisor",
    "ai_btn_close": "❌ بستن",
    "ai_working": "⏳ در حال تحلیل با AI...",

    "ai_guide_analyze": "🔍 Analyze Message\nروی پیام موردنظر Reply کن و بنویس:\n/aicheck",
    "ai_guide_explain": "❓ Explain Action\nمثال:\n/aiexplain @username چرا این کاربر اخطار گرفت؟\n(یا روی پیام کاربر Reply کن و /aiexplain بزن)",
    "ai_guide_rule": "➕ Rule Advisor\nمشکلت رو توضیح بده، مثلاً:\n/airule تبلیغات زیادی در گروه داریم",

    "ai_need_reply": "برای Analyze Message باید روی یک پیام Reply کنی.",
    "ai_explain_usage": "کاربر هدف مشخص نیست. یا روی پیامش Reply کن یا بنویس:\n/aiexplain @username [سؤال]",
    "ai_explain_default_question": "چرا اخیراً روی {name} اقدام مدیریتی انجام شده؟",
    "ai_rule_usage": "مشکل رو توضیح بده، مثلاً:\n/airule تبلیغات زیادی در گروه داریم",
    "ai_reports_empty_for_ai": "گزارش بازی برای تحلیل وجود ندارد.",
    "ai_optimize_empty": "هیچ Auto Action Rule‌ای برای بررسی وجود ندارد.",
    "ai_incident_empty": "رخداد اخیر قابل‌توجهی برای تحلیل پیدا نشد.",
    "ai_rule_not_applicable": "⚠️ این مورد با نوع قانون‌های پشتیبانی‌شده‌ی فعلی NEXOR قابل پوشش نیست؛ توضیح دقیق‌تری بده یا خودت با /addautoaction دستی اضافه کن.",
    "ai_rule_cancelled": "لغو شد؛ هیچ قانونی ساخته نشد.",
    "ai_rule_created": "✅ قانون #{id} ساخته شد.\nTrigger: {condition}\nAction: {action}",
    "ai_dismissed": "نادیده گرفته شد؛ هیچ اقدامی روی گروه انجام نشد.",
    "ai_reason_copilot": "پیشنهاد NEXOR Copilot (تأیید ادمین)",
    "ai_action_done_delwarn": "🗑️ پیام حذف و به {name} اخطار داده شد.",

    "ai_plan_status": "پلن فعلی AI این گروه: {plan}",
    "ai_plan_set_done": "✅ پلن AI این گروه روی «{plan}» تنظیم شد.",
    "ai_plan_set_invalid": "پلن نامعتبر است. یکی از این‌ها را وارد کن: free, pro, premium",

    "ai_err_plan_not_allowed": "⛔️ این قابلیت در پلن فعلی این گروه در دسترس نیست.",
    "ai_err_rate_limited": "⏳ سقف روزانه‌ی درخواست AI برای شما پر شده؛ فردا دوباره امتحان کن.",
    "ai_err_not_configured": "⚙️ AI برای پلن این گروه هنوز پیکربندی نشده (به مدیر فنی ربات اطلاع بده).",
    "ai_err_provider_error": "⚠️ ارتباط با سرویس AI برقرار نشد؛ چند لحظه‌ی دیگر دوباره امتحان کن.",
    "ai_err_bad_response": "⚠️ پاسخ AI قابل‌فهم نبود؛ دوباره امتحان کن.",
    "ai_err_unknown": "⚠️ خطای غیرمنتظره در NEXOR Copilot؛ گزارش خطا ثبت شد.",
    "ai_err_action_failed": "⚠️ اجرای اکشن با خطا مواجه شد.",

    "ai_risk_low": "Low", "ai_risk_medium": "Medium", "ai_risk_high": "High",
    "ai_priority_high": "High Priority", "ai_priority_suspicious": "Suspicious",
    "ai_priority_low": "Low Priority", "ai_priority_false": "Likely False Report",
    "ai_action_none": "بدون اقدام", "ai_action_delete": "حذف پیام",
    "ai_action_warn": "اخطار", "ai_action_delete_warn": "حذف + اخطار",
    "ai_action_mute": "سکوت", "ai_action_ban": "بن",
    "ai_trend_up": "افزایشی 📈", "ai_trend_down": "کاهشی 📉", "ai_trend_stable": "ثابت ➖",

    "ai_btn_apply_delwarn": "🗑️+⚠️ حذف و اخطار",
    "ai_btn_apply_mute": "🔇 سکوت",
    "ai_btn_apply_ban": "🚫 بن",
    "ai_btn_dismiss": "نادیده بگیر",
    "ai_btn_confirm": "✅ تأیید و ایجاد",
    "ai_btn_cancel": "❌ لغو",

    "ai_analyze_message_result": (
        "🤖 نتیجه‌ی تحلیل NEXOR Copilot\n\n"
        "Risk: {risk}\n"
        "Spam: {spam}%\n"
        "Advertisement: {ad}%\n"
        "Suspicious: {suspicious}%\n"
        "Toxic: {toxic}%\n\n"
        "خلاصه: {summary}\n\n"
        "💡 پیشنهاد: {action}\n"
        "دلیل: {reason}\n\n"
        "تصمیم نهایی با شماست:"
    ),
    "ai_explain_result": "🤖 توضیح NEXOR Copilot\n\n{explanation}\n\nعوامل مؤثر:\n{factors}",
    "ai_reports_header": "🗂 دسته‌بندی گزارش‌های باز:",
    "ai_reports_item": "• #{id} — {priority}: {reason}",
    "ai_reports_summary": "\nخلاصه: {summary}",
    "ai_health_result": (
        "📊 وضعیت سلامت گروه\n\n"
        "سطح Spam: {spam_level}\n"
        "روند تخلفات: {trend}\n\n"
        "ریسک‌ها:\n{risks}\n\n"
        "💡 پیشنهاد: {recommendation}"
    ),
    "ai_rule_advisor_result": (
        "➕ پیشنهاد Rule Advisor\n\n"
        "Trigger: {trigger}\n"
        "Action: {action}\n"
        "Scope: {scope}\n"
        "Reason: {reason}\n"
        "Confidence: {confidence}%\n\n"
        "برای ساخت این قانون تأیید کن:"
    ),
    "ai_optimize_result": (
        "🛠 نتیجه‌ی بررسی Rule Optimization\n\n"
        "تکراری: {duplicates}\n"
        "متناقض: {conflicts}\n"
        "بیش‌ازحد فعال: {too_frequent}\n"
        "پیکربندی خطرناک: {dangerous}\n\n"
        "پیشنهادها:\n{suggestions}"
    ),
    "ai_incident_result": (
        "🚨 خلاصه‌ی Incident\n\n"
        "{summary}\n\n"
        "شدت: {severity}\n\n"
        "Timeline:\n{timeline}\n\n"
        "💡 پیشنهاد: {recommendation}"
    ),
    "ai_local_summary_safe": "پیام کوتاه و بدون نشانه‌ی خطر است؛ به‌صورت محلی low-risk تشخیص داده شد.",
    "ai_local_reason_no_ai_needed": "نیازی به بررسی AI نبود.",

    # ==================== راهنمای شیشه‌ای (Guide Panel) ====================
    "guide_intro": "📖 راهنمای NEXOR\nروی هر بخش بزن تا ببینی چیکار می‌کنه — بعد روی هر کلمه‌ی زیرش بزن تا همون کلمه‌ای رو ببینی که به‌جای دستور، توی چت تایپ می‌کنی.",
    "guide_btn_locks": "🔒 قفل‌ها و فیلترها",
    "guide_btn_moderation": "🛡 مدیریت و مجازات‌ها",
    "guide_btn_roles": "👮 ارتقا / عزل کاربران",
    "guide_btn_settings": "⚙️ تنظیمات گروه",
    "guide_btn_security": "🚨 آنتی‌رید و قفل کامل",
    "guide_btn_rules": "📜 قوانین گروه",
    "guide_btn_autoreply": "💬 کلیدواژه و دستور سفارشی",
    "guide_btn_channel": "📢 کانال و پست‌ها",
    "guide_btn_autoactions": "🤖 اکشن‌های خودکار",
    "guide_btn_notes": "📝 یادداشت‌ها",
    "guide_btn_reports_logs": "🚩 گزارش‌ها و لاگ",
    "guide_btn_federation": "🌐 فدراسیون",
    "guide_btn_ai_copilot": "🧠 دستیار هوشمند NEXOR",
    "guide_title_locks": "🔒 قفل‌ها و فیلترها",
    "guide_title_moderation": "🛡 مدیریت و مجازات‌ها",
    "guide_title_roles": "👮 ارتقا / عزل کاربران",
    "guide_title_settings": "⚙️ تنظیمات گروه",
    "guide_title_security": "🚨 آنتی‌رید و قفل کامل",
    "guide_title_rules": "📜 قوانین گروه",
    "guide_title_autoreply": "💬 کلیدواژه و دستور سفارشی",
    "guide_title_channel": "📢 کانال و پست‌ها",
    "guide_title_autoactions": "🤖 اکشن‌های خودکار",
    "guide_title_notes": "📝 یادداشت‌ها",
    "guide_title_reports_logs": "🚩 گزارش‌ها و لاگ",
    "guide_title_federation": "🌐 فدراسیون",
    "guide_title_ai_copilot": "🧠 دستیار هوشمند NEXOR",
    "guide_desc_locks": "هر نوع محتوای پرخطر — لینک، عکس، استیکر، فوروارد و... — رو قفل کن تا همون لحظه‌ی ارسال حذف بشه. برای هرچیز دیگه هم می‌تونی فیلتر کلمه یا دامنه اضافه کنی.",
    "guide_desc_moderation": "به مزاحم‌ها اخطار بده، سکوتشون کن، اخراج یا بنشون کن، یک پیام رو حذف کن یا یک بازه کامل رو یک‌جا پاکسازی کن؛ جعبه‌ابزار کامل نظم‌دهی گروه.",
    "guide_desc_roles": "کاربرهای مورد اعتماد رو مدیر داخلی کن، هروقت خواستی عزلشون کن و یک‌نگاه ببین چه کسی چه نقش یا دسترسی‌ای داره.",
    "guide_desc_settings": "یک صفحه با همه چیز درباره‌ی این گروه — قفل‌ها، فیلترها، کپچا، اخطارها، زبان — به‌علاوه‌ی دسترسی سریع به پنل ادمین.",
    "guide_desc_security": "تشخیص خودکار رید، هجوم ناگهانی عضوها رو می‌گیره؛ قفل کامل هم با یک دستور کل گروه رو می‌بنده وقتی اوضاع خراب شد.",
    "guide_desc_rules": "قوانین گروهت رو یک‌بار بنویس، هروقت کسی خواست نشونش بده، یا کامل پاکش کن و از نو بنویس.",
    "guide_desc_autoreply": "به ربات یاد بده به بعضی کلمه‌ها خودش جواب بده، یا کلاً یک دستور متنی سفارشی تازه بساز.",
    "guide_desc_channel": "یک کانال رو به گروهت وصل کن، پست بذار یا زمان‌بندی کن، بعداً ویرایش یا حذفش کن و آمار کانال رو ببین.",
    "guide_desc_autoactions": "قانون‌های ساده‌ی «اگر این شد، اون کار رو بکن» بساز — ربات خودش بر اساس نوع پیام یا تعداد اخطار واکنش نشون می‌ده.",
    "guide_desc_notes": "یک متن یا فایل رو یک‌بار ذخیره کن، بعد هروقت خواستی با یک تگ کوتاه سریع پسش بگیر.",
    "guide_desc_reports_logs": "کاربرها با یک لمس مشکل رو گزارش می‌دن؛ تو هم یک ردِ کامل از هر اقدام هر ادمین داری.",
    "guide_desc_federation": "یک لیست بن مشترک بین چند گروه — یک نفر رو یک‌بار بن کن، توی کل فدراسیون بن می‌شه.",
    "guide_desc_ai_copilot": "یک دستیار هوش مصنوعی مخصوص ادمین‌ها: پیام‌ها رو تحلیل می‌کنه، دلیل اقدام‌های قبلی رو توضیح می‌ده و قانون‌های تازه پیشنهاد می‌ده.",
    "guide_kw_lock": "یک نوع محتوا (مثلاً لینک، عکس) رو قفل کن تا خودکار حذف بشه.",
    "guide_kw_unlock": "یک قفل فعال رو باز کن.",
    "guide_kw_locks": "همه‌ی قفل‌های فعال این گروه رو نشون بده.",
    "guide_kw_filter": "یک کلمه/عبارت ممنوعه اضافه کن که خودکار حذف بشه.",
    "guide_kw_stopfilter": "یک فیلتر کلمه رو حذف کن.",
    "guide_kw_filters": "همه‌ی فیلترهای فعال رو لیست کن.",
    "guide_kw_domains": "لیست دامنه‌های مسدودشده رو نشون بده یا مدیریت کن.",
    "guide_kw_forwardrules": "قوانین اجازه/بلاک برای پیام‌های فوروارد رو نشون بده.",
    "guide_kw_warn": "به یک کاربر اخطار بده.",
    "guide_kw_unwarn": "یک اخطار از یک کاربر کم کن.",
    "guide_kw_warns": "تعداد اخطارهای یک کاربر رو نشون بده.",
    "guide_kw_mute": "یک کاربر رو برای مدت مشخص ساکت کن.",
    "guide_kw_unmute": "سکوت یک کاربر رو بردار.",
    "guide_kw_ban": "یک کاربر رو برای همیشه از گروه بیرون کن.",
    "guide_kw_unban": "اجازه بده یک کاربر بن‌شده برگرده.",
    "guide_kw_kick": "یک کاربر رو اخراج کن (می‌تونه دوباره جوین بشه).",
    "guide_kw_del": "یک پیام رو حذف کن (اول روش ریپلای کن).",
    "guide_kw_purge": "یک بازه از پیام‌ها رو یک‌جا پاک کن.",
    "guide_kw_promote": "یک کاربر رو مدیر داخلی کن.",
    "guide_kw_demote": "نقش مدیر داخلیِ یک کاربر رو بردار.",
    "guide_kw_roles": "همه‌ی کسایی که مدیر داخلی‌ان رو لیست کن.",
    "guide_kw_profiles": "پروفایل‌های دسترسی سفارشی رو مدیریت کن.",
    "guide_kw_myperms": "دسترسی‌های فعلی خودت رو نشون بده.",
    "guide_kw_settings": "یک نمای کلی از همه‌ی تنظیمات این گروه.",
    "guide_kw_setlang": "زبان گروه رو عوض کن.",
    "guide_kw_captcha": "کپچای عضو جدید رو روشن/خاموش کن.",
    "guide_kw_goodbye": "پیام خداحافظی رو روشن/خاموش کن.",
    "guide_kw_adminpanel": "پنل میان‌بر سریع ادمین رو باز کن.",
    "guide_kw_antiraid": "تشخیص خودکار رید رو روشن/خاموش کن.",
    "guide_kw_lockdown": "کل گروه رو فوراً قفل کن.",
    "guide_kw_unlockchat": "قفل کامل گروه رو بردار.",
    "guide_kw_rules": "قوانین گروه رو نشون بده.",
    "guide_kw_setrules": "قوانین گروه رو بنویس یا آپدیت کن.",
    "guide_kw_clearrules": "قوانین گروه رو پاک کن.",
    "guide_kw_addkeyword": "یک کلمه اضافه کن که پاسخ خودکار داشته باشه.",
    "guide_kw_delkeyword": "یک کلیدواژه‌ی پاسخ خودکار رو حذف کن.",
    "guide_kw_keywords": "همه‌ی کلیدواژه‌های پاسخ خودکار رو لیست کن.",
    "guide_kw_addcmd": "یک دستور متنی سفارشی خودت بساز.",
    "guide_kw_delcmd": "یک دستور سفارشی رو حذف کن.",
    "guide_kw_cmds": "همه‌ی دستورهای سفارشی رو لیست کن.",
    "guide_kw_setanswer": "تنظیم پاسخ خودکار (متن/رسانه، تا ۲۰ پاسخ رندوم) برای یک کلیدواژه.",
    "guide_kw_answerlist": "لیست کلیدواژه‌های پاسخ خودکار ثبت‌شده رو نشون بده.",
    "guide_kw_delanswer": "یک پاسخ خودکار رو با کلیدواژه‌اش حذف کن.",
    "guide_kw_cleananswerlist": "همه‌ی پاسخ‌های خودکار این گروه رو پاک کن.",
    "guide_kw_setchannel": "یک کانال رو به این گروه وصل کن.",
    "guide_kw_post": "یک پست توی کانال وصل‌شده منتشر کن.",
    "guide_kw_schedulepost": "یک پست رو برای بعداً زمان‌بندی کن.",
    "guide_kw_editpost": "یک پست منتشرشده رو ویرایش کن.",
    "guide_kw_delpost": "یک پست منتشرشده رو حذف کن.",
    "guide_kw_channelstats": "آمار کانال وصل‌شده رو نشون بده.",
    "guide_kw_addautoaction": "یک قانون خودکار «اگر... پس...» بساز.",
    "guide_kw_delautoaction": "یک قانون خودکار رو حذف کن.",
    "guide_kw_autoactions": "همه‌ی قانون‌های خودکار رو لیست کن.",
    "guide_kw_save": "یک یادداشت/متن قابل استفاده‌ی مجدد ذخیره کن.",
    "guide_kw_get": "یک یادداشت ذخیره‌شده رو با اسمش بگیر.",
    "guide_kw_notes": "همه‌ی یادداشت‌های ذخیره‌شده رو لیست کن.",
    "guide_kw_clear": "یک یادداشت ذخیره‌شده رو پاک کن.",
    "guide_kw_report": "یک پیام رو به ادمین‌ها گزارش بده.",
    "guide_kw_reports": "گزارش‌های بازِ حل‌نشده رو نشون بده.",
    "guide_kw_alerts": "محل ارسال هشدارهای ادمین رو مدیریت کن.",
    "guide_kw_adminabuseprotection": "اگر یک ادمین ناگهان اکشن مخرب زیادی بزنه، بهت هشدار می‌ده.",
    "guide_kw_logs": "آخرین اقدام‌های ادمین‌ها رو نشون بده.",
    "guide_kw_exportsettings": "تنظیمات این گروه رو به‌عنوان بکاپ خروجی بگیر.",
    "guide_kw_setlogchannel": "کانالی که لاگ‌ها رو دریافت می‌کنه تنظیم کن.",
    "guide_kw_fnew": "یک فدراسیون جدید (لیست بن مشترک) بساز.",
    "guide_kw_fjoin": "این گروه رو به یک فدراسیون موجود ملحق کن.",
    "guide_kw_fleave": "از فدراسیون فعلی خارج شو.",
    "guide_kw_finfo": "اطلاعات فدراسیون فعلی رو نشون بده.",
    "guide_kw_fban": "یک کاربر رو توی کل فدراسیون بن کن.",
    "guide_kw_funban": "بن یک کاربر رو توی کل فدراسیون بردار.",
    "guide_kw_copilot": "منوی دستیار هوش مصنوعی NEXOR Copilot رو باز کن.",
    "guide_kw_aicheck": "از AI بخواه یک پیام رو تحلیل کنه (اول ریپلای کن).",
    "guide_kw_aiexplain": "از AI بپرس چرا روی یک کاربر اقدامی انجام شده.",
    "guide_kw_aireports": "بذار AI گزارش‌های باز رو بر اساس اولویت دسته‌بندی کنه.",
    "guide_kw_aihealth": "یک خلاصه‌ی AI از سلامت گروه بگیر.",
    "guide_kw_airule": "مشکلت رو توضیح بده، AI یک قانون پیشنهاد می‌ده.",
    "guide_kw_aioptimize": "از AI بخواه قانون‌های خودکارت رو بررسی کنه.",
    "guide_kw_aiincident": "یک خلاصه‌ی AI از یک رخداد اخیر بگیر.",
    "guide_kw_aiplan": "پلن هوش مصنوعی این گروه رو نشون بده یا تنظیم کن.",

    # --- لایه‌ی Natural Language (نیت‌محور) — nlu/ ---
    "nlu_confirm_mute": "می‌خوای {name} رو برای {duration} mute کنم؟",
    "nlu_btn_confirm": "✅ تأیید",
    "nlu_btn_cancel": "❌ لغو",
    "nlu_ask_duration": "برای چه مدتی {name} رو mute کنم؟ (مثلاً: 30m، 2h، 1d)",
    "nlu_context_expired": "⌛️ این درخواست منقضی شده. دوباره امتحان کن.",
    "nlu_not_your_confirmation": "این دکمه برای درخواست شخص دیگه‌ایه.",
    "nlu_need_reply_target": "❗️باید روی پیام همون کاربر ریپلای کنی تا مشخص بشه منظورت کیه.",
    "nlu_fallback_intro": "🤔 دقیق متوجه نشدم. می‌تونی /help رو بزنی یا واضح‌تر بگی چی می‌خوای.",
    "nlu_confirm_unmute": "سکوت {name} برداشته بشه؟",
    "nlu_confirm_ban": "{name} برای {duration} بن بشه؟",
    "nlu_confirm_unban": "بن {name} لغو بشه؟",
    "nlu_confirm_kick": "{name} از گروه اخراج بشه؟",
    "nlu_action_cancelled": "❌ لغو شد؛ کاری انجام نشد.",
    "nlu_confirm_delete": "این پیام پاک بشه؟",
    "nlu_delete_done": "🗑 پیام حذف شد.",
    "nlu_confirm_setrules": "قوانین گروه با این متن جایگزین بشه؟\n\n{text}",
    "nlu_setrules_format_hint": "برای تنظیم قوانین به این روش، از این فرمت استفاده کن:\n«تنظیم قوانین: متن قانون» (هر چی بعد از «:» بیاد، دقیقاً همون ذخیره می‌شه).",

    # --- Onboarding (handlers/onboarding.py + onboarding_logic.py) ---
    "onboarding_welcome": "👋 سلام! من NEXORم — کمک می‌کنم این گروه امن و منظم بمونه: مدیریت، ضداسپم، خوش‌آمد/قوانین، پاسخ خودکار و بیشتر.",
    "onboarding_needs_admin": "⚠️ من هنوز ادمین این گروه نیستم، پس بیشتر امکاناتم کار نمی‌کنه. من رو ادمین کن (حداقل: حذف پیام، محدودکردن اعضا، دعوت کاربر، پین پیام) تا از همون‌جا شروع کنم.",
    "onboarding_missing_perms": "⚠️ ادمین هستم ولی این دسترسی‌ها رو ندارم: {perms}. بعضی قابلیت‌ها بهشون نیاز دارن — هروقت خواستی از تنظیمات گروه بهم بده.",
    "onboarding_all_set": "✅ همه‌ی دسترسی‌های لازم رو دارم. بیا اول تنظیمات پایه رو انجام بدیم.",
    "onboarding_btn_security": "🛡 تنظیم امنیت",
    "onboarding_btn_help": "❓ چیکار می‌تونی بکنی؟",
    "perm_restrict": "محدودکردن اعضا (میوت/کیک/بن)",
    "perm_delete": "حذف پیام‌ها",
    "perm_invite": "دعوت کاربر",
    "perm_pin": "پین کردن پیام",
    "err_unexpected": "⚠️ یه مشکلی پیش اومد و این کار انجام نشد. دوباره امتحان کن — اگه تکرار شد، به یکی از ادمین‌های گروه بگو.",
    "nlu_delanswer_format_hint": "برای حذف پاسخ خودکار به این روش، از این فرمت استفاده کن:\n«حذف پاسخ: کلیدواژه» (دقیقاً همون کلیدواژه‌ای که می‌خوای حذف بشه).",
    "nlu_confirm_delanswer": "پاسخ خودکار برای کلیدواژه‌ی «{keyword}» حذف بشه؟",

    # --- Payments / /buyplan (handlers/payments.py) ---
    "buyplan_header": "👑 ارتقای پلن NEXOR Copilot\nپلن موردنظر رو انتخاب کن:",
    "buyplan_use_pv": "🔒 خرید اشتراک فقط توی پیام خصوصی ربات ممکنه. برو به PV ربات و از همونجا /buyplan رو بزن.",
    "buyplan_choose_method": "پلن {plan} — روش پرداخت رو انتخاب کن:",
    "buyplan_stars_sent": "⭐ فاکتور پرداخت با Stars برات توی پیام خصوصی ربات فرستاده شد. همونجا پرداخت رو کامل کن.",
    "buyplan_ton_sent": "💎 راهنمای پرداخت TON (آدرس کیف‌پول + کد Memo) برات توی پیام خصوصی ربات فرستاده شد.",
    "buyplan_ton_unavailable": "⚠️ پرداخت TON فعلاً برای این پلن در دسترس نیست.",
    "buyplan_dm_failed": "⚠️ نتونستم برات پیام خصوصی بفرستم. اول یک‌بار با ربات در چت خصوصی /start بزن، بعد دوباره از /buyplan امتحان کن.",
    "buyplan_closed": "بسته شد.",
    # ---- Ads system (added) ----
    'ads_btn_cancel': '❌ انصراف',
    'ads_btn_free': '🆓 ثبت آگهی رایگان (۱ بار در روز)',
    'ads_btn_paid': '💳 خرید تبلیغات (۱ تا ۵ بار در روز)',
    'ads_intro': '📢 سیستم تبلیغات NEXOR\n\nتبلیغ فقط داخل گروه\u200cهایی که پلن\u200cشون رایگانه نمایش داده می\u200cشه (گروه\u200cهای Pro/Premium تبلیغ نمی\u200cبینن).\nآگهی رایگان روزی فقط یک\u200cبار ارسال می\u200cشه؛ آگهی خریداری\u200cشده می\u200cتونه بین ۱ تا ۵ بار در روز پخش بشه (قیمت به همون نسبت زیاد می\u200cشه).\n\nکدوم رو می\u200cخوای؟',
    'ads_ask_banner': '🖼 اول بنر (عکس) تبلیغ رو بفرست.\nاگه بنر نمی\u200cخوای، بنویس: رد',
    'ads_banner_invalid': 'یا عکس بفرست یا بنویس «رد» تا بدون بنر ادامه بدیم.',
    'ads_ask_text': '✍️ حالا متن آگهی رو بفرست (چیزی که داخل گروه\u200cها دیده می\u200cشه).',
    'ads_text_empty': 'متن آگهی نمی\u200cتونه خالی باشه. دوباره بفرست.',
    'ads_times_btn': '{n}×/روز',
    'ads_ask_times': '📅 چند بار در روز آگهی\u200cت پخش بشه؟ (هرچه بیشتر، گران\u200cتر)',
    'ads_free_submitted': '✅ آگهی رایگان #{id} ثبت شد و برای بررسی ادمین ارسال شد.\nبعد از تایید، روزی یک\u200cبار داخل گروه\u200cهای رایگان متصل به ربات نمایش داده می\u200cشه.',
    'ads_duration_btn': '{days} روز — ⭐{stars}',
    'ads_ask_duration': 'مدت نمایش آگهی رو انتخاب کن (تعداد دفعات انتخابی: {times}×/روز):',
    'ads_btn_pay_stars': '⭐ پرداخت با Stars ({stars})',
    'ads_btn_pay_ton': '💎 پرداخت با TON ({ton})',
    'ads_order_summary': 'خلاصه سفارش #{id}:\n• تعداد ارسال: {times}×/روز\n• مدت: {days} روز\n• قیمت: ⭐{stars}',
    'ads_order_summary_ton_suffix': ' / 💎{ton} TON',
    'ads_order_summary_footer': '\n\nروش پرداخت رو انتخاب کن:',
    'ads_order_invalid': '⚠️ این سفارش دیگه معتبر نیست.',
    'ads_sending_invoice': '⭐ در حال ارسال فاکتور پرداخت با Telegram Stars...',
    'ads_invoice_title': '📢 خرید تبلیغات — سفارش #{id}',
    'ads_invoice_desc': 'خرید نمایش تبلیغ داخل گروه\u200cهای متصل به NEXOR (فقط پلن رایگان).',
    'ads_invoice_label': 'تبلیغات NEXOR',
    'ads_ton_disabled': '⚠️ پرداخت TON فعلاً فعال نیست یا این سفارش معتبر نیست.',
    'ads_ton_payment_info': '💎 پرداخت با TON — سفارش #{id}\n\nمبلغ: {amount} TON\nآدرس کیف\u200cپول: {address}\n⚠️ حتماً این کد رو دقیقاً در Comment/Memo واریز وارد کن:\n{memo}\n\nلینک مستقیم: {link}\n\nبعد از واریز، تراکنش خودکار بررسی می\u200cشه و آگهی وارد صف بررسی ادمین می\u200cشه.',
    'ads_cancelled': 'لغو شد.',
    'ads_ton_confirmed': '✅ پرداخت TON تایید شد! سفارش تبلیغ #{id} برای بررسی ادمین ارسال شد.',
    'ads_admin_none_pending': 'آگهی\u200cای در صف بررسی نیست.',
    'ads_btn_approve': '✅ تایید',
    'ads_btn_reject': '❌ رد',
    'ads_kind_free': '🆓 رایگان',
    'ads_kind_paid': '💳 خریداری\u200cشده',
    'ads_admin_caption': '#{id} — {kind}\nدفعات/روز: {times} — مدت: {days} روز\n\n{text}',
    'ads_approved_toast': 'تایید شد ✅',
    'ads_approved_notify': '✅ آگهی #{id} تایید شد و طبق زمان\u200cبندی داخل گروه\u200cهای رایگان نمایش داده می\u200cشه.',
    'ads_rejected_toast': 'رد شد ❌',
    'ads_none_yet': 'هنوز آگهی\u200cای ثبت نکردی. از /ads شروع کن.',
    'ads_status_draft': 'پیش\u200cنویس',
    'ads_status_pending_payment': 'در انتظار پرداخت',
    'ads_status_pending_review': 'در صف بررسی',
    'ads_status_active': 'فعال',
    'ads_status_rejected': 'رد شده',
    'ads_status_expired': 'منقضی',
    'ads_status_active2': '✅ فعال',
    'ads_status_rejected2': '❌ رد شده',
    'ads_status_expired2': '⌛ منقضی',
    'ads_myads_header': '📋 آگهی\u200cهای شما:\n',
    'ads_myads_line': '#{id} — {status} — {times}×/روز — {days} روز',
    'ads_myads_footer': '\nبرای دیدن آمار نمایش هر آگهی: /adstats <شماره آگهی> — مثلاً /adstats {id}',
    'ads_stats_usage': 'شماره\u200cی آگهی رو هم بنویس، مثلاً:\n/adstats 3\n\nشماره\u200cی آگهی\u200cهات رو از /myads می\u200cتونی ببینی.',
    'ads_stats_not_found': 'همچین آگهی\u200cای پیدا نشد یا مال شما نیست.',
    'ads_stats_title': '📊 آمار آگهی #{id}',
    'ads_stats_status': 'وضعیت: {status}',
    'ads_stats_quota': 'سهمیه\u200cی روزانه: {quota}×/روز',
    'ads_stats_today': 'امروز ارسال\u200cشده: {today} از {quota}',
    'ads_stats_total': 'مجموع کل نمایش\u200cها (از اول تا الان): {total}',
    'ads_stats_unique': 'تعداد گروه\u200cهای یکتایی که این آگهی توشون دیده شده: {n}',
    'ads_stats_perday_header': '\nریز روزانه (آخرین روزها):',
    'ads_stats_perday_line': '  {day}: {count} بار',
    'ads_stats_no_views': '\nهنوز هیچ نمایشی برای این آگهی ثبت نشده (یا هنوز تایید/فعال نشده).',
    'ads_stars_confirmed': '✅ پرداخت تایید شد! سفارش تبلیغ #{id} برای بررسی ادمین ارسال شد.',
    'err_invalid_language': 'زبان نامعتبر است.',
    # ---- Buyplan payments (added) ----
    'buyplan_invoice_title': '👑 اشتراک {plan} ({months} ماهه)',
    'buyplan_invoice_desc': 'ارتقای گروه به پلن {plan} برای {months} ماه.',
    'buyplan_invoice_price_label': '{plan} {months} ماهه',
    'err_order_invalid': 'این سفارش دیگه معتبر نیست.',
    'buyplan_stars_confirmed': '✅ پرداخت تایید شد!\n👑 گروه به پلن {plan} ارتقا پیدا کرد.',
    'buyplan_stars_confirmed_groups': '✅ پرداخت تایید شد!\n👑 پلن {plan} روی {count} گروهی که مالکشونی فعال شد.',
    'buyplan_stars_confirmed_no_groups': '✅ پرداخت تایید شد و پلن {plan} خریداری شد، ولی هیچ گروهی که ربات توش فعال باشه و مالکش تو باشی پیدا نشد. اگه فکر می‌کنی اشتباهه، مطمئن شو ربات توی گروهت هست و تو owner واقعی اون گروهی.',
    'buyplan_card_order_not_found': '⚠️ این سفارش پیدا نشد یا قبلاً پردازش شده.',
    'buyplan_card_confirmed_dm': '✅ پرداخت کارتی تایید شد!\n👑 گروه به پلن {plan} ارتقا پیدا کرد.',
    'buyplan_card_admin_confirmed': '✅ سفارش #{id} تایید و پلن {plan} فعال شد.',
    'buyplan_card_admin_rejected': '❌ سفارش #{id} رد شد.',
    'buyplan_card_none_pending': 'سفارش کارتی در انتظاری وجود نداره.',
    'buyplan_card_pending_header': '💳 سفارش\u200cهای کارتی در انتظار تایید:\n',
    'buyplan_card_pending_line': '#{id} — {plan} × {months} ماه — کد: {code}',
    'buyplan_ton_instructions': '💎 خرید اشتراک {plan} با TON\n\nمبلغ: {amount} TON\nآدرس کیف\u200cپول: {address}\n⚠️ حتماً این کد رو دقیقاً در قسمت Comment/Memo واریز وارد کن:\n{memo}\n\nیا از لینک زیر تو کیف\u200cپولت استفاده کن:\n{link}\n\nبعد از واریز، تراکنش خودکار بررسی و اشتراک فعال می\u200cشه (چند دقیقه طول می\u200cکشه).',
    'buyplan_ton_confirmed': '✅ پرداخت TON تایید شد!\n👑 گروه به پلن {plan} ارتقا پیدا کرد.',
    'buyplan_ton_confirmed_groups': '✅ پرداخت TON تایید شد!\n👑 پلن {plan} روی {count} گروهی که مالکشونی فعال شد.',
    'buyplan_ton_confirmed_no_groups': '✅ پرداخت TON تایید شد و پلن {plan} خریداری شد، ولی هیچ گروهی که ربات توش فعال باشه و مالکش تو باشی پیدا نشد.',
    'buyplan_card_header': '💳 خرید اشتراک {plan} با کارت\u200cبه\u200cکارت\n',
    'buyplan_card_amount': 'مبلغ: {amount} تومان',
    'buyplan_card_number': 'شماره کارت: {number}',
    'buyplan_card_holder': 'به نام: {holder}',
    'buyplan_card_reference': '\nکد پیگیری سفارش: {ref}',
    'buyplan_card_instructions': 'بعد از واریز، عکس رسید رو همراه با کد پیگیری بالا برای ادمین ربات بفرست تا اشتراکت دستی تایید و فعال بشه.',
    # ---- Command menu descriptions (added) ----
    'cmd_desc_start': 'شروع کار با ربات',
    'cmd_desc_help': 'راهنمای دستورات',
    'cmd_desc_settings': 'تنظیمات گروه',
    'cmd_desc_setlang': 'تغییر زبان گروه (ادمین)',
    'cmd_desc_rules': 'قوانین گروه',
    'cmd_desc_warn': 'اخطار دادن به کاربر',
    'cmd_desc_unwarn': 'کم کردن یک اخطار',
    'cmd_desc_warns': 'مشاهده اخطارهای کاربر',
    'cmd_desc_mute': 'سکوت کاربر',
    'cmd_desc_unmute': 'لغو سکوت',
    'cmd_desc_ban': 'بن کردن کاربر',
    'cmd_desc_unban': 'لغو بن',
    'cmd_desc_kick': 'اخراج کاربر',
    'cmd_desc_del': 'حذف پیام (با ریپلای)',
    'cmd_desc_purge': 'حذف دسته\u200cجمعی پیام',
    'cmd_desc_lock': 'قفل کردن یک نوع محتوا',
    'cmd_desc_unlock': 'باز کردن قفل',
    'cmd_desc_locks': 'نمایش قفل\u200cهای فعال',
    'cmd_desc_promote': 'ارتقا به مدیر داخلی',
    'cmd_desc_demote': 'عزل از مدیر داخلی',
    'cmd_desc_roles': 'لیست مدیران داخلی',
    'cmd_desc_logs': 'آخرین اقدامات مدیریتی',
    'cmd_desc_copilot': '🤖 NEXOR Copilot (دستیار AI ادمین\u200cها)',
    'cmd_desc_buyplan': '👑 ارتقای پلن (Stars / TON) — بدون تبلیغات',
    'cmd_desc_ads': '📢 ثبت آگهی رایگان یا خرید تبلیغات',
    'cmd_desc_myads': '📋 آگهی\u200cهای من',
    'cmd_desc_adstats': '📊 آمار نمایش یک آگهی',
    'cmd_desc_adadmin': '🛠 صف بررسی آگهی\u200cها (ادمین)',

    # ==================== سیستم اطلاع‌رسانی روزانه (Daily Notify) ====================
    # DateService: روزهای هفته و نام ماه‌ها (میلادی/شمسی) — از اینجا خونده می‌شن،
    # هیچ‌جای services/date_service.py متن Hardcode نشده.
    "day_mon": "دوشنبه", "day_tue": "سه‌شنبه", "day_wed": "چهارشنبه", "day_thu": "پنجشنبه",
    "day_fri": "جمعه", "day_sat": "شنبه", "day_sun": "یکشنبه",
    "month_g_1": "ژانویه", "month_g_2": "فوریه", "month_g_3": "مارس", "month_g_4": "آوریل",
    "month_g_5": "مه", "month_g_6": "ژوئن", "month_g_7": "ژوئیه", "month_g_8": "اوت",
    "month_g_9": "سپتامبر", "month_g_10": "اکتبر", "month_g_11": "نوامبر", "month_g_12": "دسامبر",
    "month_j_1": "فروردین", "month_j_2": "اردیبهشت", "month_j_3": "خرداد", "month_j_4": "تیر",
    "month_j_5": "مرداد", "month_j_6": "شهریور", "month_j_7": "مهر", "month_j_8": "آبان",
    "month_j_9": "آذر", "month_j_10": "دی", "month_j_11": "بهمن", "month_j_12": "اسفند",
    "date_format_gregorian": "{weekday} {day} {month} {year}",
    "date_format_jalali": "{weekday} {day} {month} {year}",

    "daily_date_line": "📅 امروز: {date}",
    "daily_occasion_line": "🎉 مناسبت: {occasion}",

    "daily_price_header": "💰 قیمت‌های امروز",
    "daily_price_line": "• {asset}: {value} {unit}",
    "daily_price_footer": "منبع: {sources}",

    "daily_news_header": "📰 اخبار امروز",
    "daily_news_item": "{n}. {title}",
    "daily_news_summary": "   {summary}",
    "daily_news_source": "   🔗 منبع: {source}",

    "asset_gold18": "طلای ۱۸ عیار", "asset_usd": "دلار آمریکا (USD)", "asset_eur": "یورو (EUR)",
    "asset_usdt": "تتر (USDT)", "asset_ton": "تون‌کوین (TON)", "asset_stars": "استارز تلگرام (Stars)",
    "asset_btc": "بیت‌کوین (BTC)", "asset_eth": "اتریوم (ETH)",
    "unit_toman": "تومان", "unit_usd": "دلار",

    "panel_not_owner": "این پنل مخصوص همون کسیه که بازش کرده.",

    "dn_menu_header": "🔔 *اطلاع‌رسانی روزانه*",
    "dn_menu_prices": "💰 قیمت‌ها: {state} — ساعت {time}",
    "dn_menu_assets_line": "   دارایی‌های فعال: {assets}",
    "dn_menu_news": "📰 اخبار: {state} — ساعت {time}",
    "dn_menu_timezone": "🌍 Timezone: {tz}",
    "dn_menu_date_flags": "📅 تاریخ/مناسبت — قیمت: {dp}/{op}   اخبار: {dn}/{on}",

    "dn_btn_toggle_prices": "💰 روشن/خاموش قیمت‌ها",
    "dn_btn_toggle_news": "📰 روشن/خاموش اخبار",
    "dn_btn_assets": "🪙 انتخاب دارایی‌ها",
    "dn_btn_flags": "📅 تنظیم تاریخ/مناسبت",
    "dn_btn_test_price": "🧪 تست قیمت",
    "dn_btn_test_news": "🧪 تست اخبار",
    "dn_btn_help": "❓ راهنما",
    "dn_btn_close": "❌ بستن",

    "dn_assets_header": "🪙 روی هر دارایی بزن تا فعال/غیرفعال بشه:",
    "dn_flags_header": "📅 نمایش تاریخ/مناسبت را جدا برای قیمت و اخبار تنظیم کن:",
    "dn_flag_date_price": "تاریخ در پیام قیمت",
    "dn_flag_occasion_price": "مناسبت در پیام قیمت",
    "dn_flag_date_news": "تاریخ در پیام اخبار",
    "dn_flag_occasion_news": "مناسبت در پیام اخبار",

    "dn_help_text": (
        "📖 *راهنمای اطلاع‌رسانی روزانه*\n\n"
        "💰 قیمت‌ها و 📰 اخبار هر روز، سر ساعتی که تعیین می‌کنی، برای این گروه ارسال می‌شن.\n\n"
        "/setpricetime HH:MM — ساعت ارسال قیمت‌ها\n"
        "/setnewstime HH:MM — ساعت ارسال اخبار\n"
        "/setdailytz منطقه‌زمانی — مثلاً Asia/Tehran (پیش‌فرض بر اساس زبان گروه)\n"
        "/testdailyprice   /testdailynews — ارسال آزمایشی فوری\n"
        "/dailyassets — انتخاب دارایی‌های نمایشی\n"
        "بقیه‌ی تنظیمات (روشن/خاموش، تاریخ/مناسبت) از همین دکمه‌ها قابل تغییرن."
    ),
    "dn_toast_saved": "✅ ذخیره شد.",
    "dn_toast_sending": "⏳ در حال ارسال...",
    "dn_test_no_data": "⚠️ در حال حاضر داده‌ی معتبری برای ارسال وجود نداره (Provider در دسترس نیست یا هنوز چیز جدیدی نیومده).",

    "dn_log_toggle_prices": "اطلاع‌رسانی قیمت: {state}",
    "dn_log_toggle_news": "اطلاع‌رسانی اخبار: {state}",
    "dn_log_settime": "ساعت ارسال {what}: {time}",
    "dn_log_settz": "Timezone اطلاع‌رسانی روزانه: {tz}",

    "dn_settime_usage": "استفاده: {cmd} HH:MM (مثلا 09:00)",
    "dn_settime_invalid": "⛔️ فرمت ساعت نامعتبره. از HH:MM استفاده کن (مثلا 09:00).",
    "dn_settime_done": "✅ ساعت ارسال روی {time} تنظیم شد.",
    "dn_settz_usage": "استفاده: /setdailytz منطقه‌زمانی (مثلا Asia/Tehran)",
    "dn_settz_invalid": "⛔️ این Timezone معتبر نیست. یک IANA Timezone معتبر مثل Asia/Tehran وارد کن.",
    "dn_settz_done": "✅ Timezone گروه: {tz}",

    "cmd_desc_dailynotify": "🔔 تنظیمات اطلاع‌رسانی روزانه (قیمت/اخبار)",
}


TEXT_TRIGGERS = {
    "help": ["راهنما", "کمک"],
    "settings": ["تنظیمات"],
    "warn": ["اخطار"],
    "unwarn": ["حذف اخطار"],
    "warns": ["اخطارها"],
    "mute": ["سکوت"],
    "unmute": ["لغو سکوت"],
    "ban": ["بن"],
    "unban": ["لغو بن"],
    "kick": ["اخراج"],
    "del": ["حذف پیام"],
    "purge": ["پاکسازی"],
    "promote": ["ارتقا"],
    "demote": ["تنزل"],
    "roles": ["مدیران"],
    "logs": ["لاگ"],
    "setlang": ["تغییر زبان"],
    "lock": ["قفل"],
    "unlock": ["باز کردن قفل"],
    "locks": ["قفل‌ها"],
    "filter": ["فیلتر"],
    "stopfilter": ["حذف فیلتر"],
    "filters": ["فیلترها"],
    "domains": ["دامنه‌های مسدود"],
    "forwardrules": ["قوانین فوروارد"],
    "antiraid": ["آنتی رید"],
    "lockdown": ["قفل کامل گروه"],
    "unlockchat": ["باز کردن گروه"],
    "captcha": ["کپچا"],
    "goodbye": ["خداحافظی"],
    "rules": ["قوانین"],
    "setrules": ["تنظیم قوانین"],
    "clearrules": ["پاک کردن قوانین"],
    "addkeyword": ["افزودن کلیدواژه"],
    "delkeyword": ["حذف کلیدواژه"],
    "keywords": ["کلیدواژه‌ها"],
    "setanswer": ["تنظیم پاسخ"],
    "answerlist": ["لیست پاسخ"],
    "cleananswerlist": ["پاکسازی لیست پاسخ"],
    "delanswer": ["حذف پاسخ"],
    "addcmd": ["افزودن دستور"],
    "delcmd": ["حذف دستور"],
    "cmds": ["دستورها"],
    "setchannel": ["تنظیم کانال"],
    "post": ["پست"],
    "schedulepost": ["زمان‌بندی پست"],
    "editpost": ["ویرایش پست"],
    "delpost": ["حذف پست"],
    "channelstats": ["آمار کانال"],
    "addautoaction": ["افزودن اکشن خودکار"],
    "delautoaction": ["حذف اکشن خودکار"],
    "autoactions": ["اکشن‌های خودکار"],
    "profiles": ["پروفایل‌ها"],
    "myperms": ["دسترسی من"],
    "report": ["گزارش"],
    "reports": ["گزارش‌ها"],
    "alerts": ["هشدارها"],
    "exportsettings": ["خروجی تنظیمات"],
    "save": ["ذخیره"],
    "get": ["دریافت"],
    "notes": ["یادداشت‌ها"],
    "clear": ["پاک کردن یادداشت"],
    "setlogchannel": ["تنظیم لاگ"],
    "fnew": ["فدراسیون جدید"],
    "fjoin": ["عضویت فدراسیون"],
    "fleave": ["ترک فدراسیون"],
    "finfo": ["اطلاعات فدراسیون"],
    "adminpanel": ["ادمین", "پنل"],
    "copilot": ["دستیار", "دستیار هوشمند", "کوپایلوت"],
    "aicheck": ["بررسی هوش مصنوعی", "چک هوش مصنوعی"],
    "aiexplain": ["توضیح اقدام"],
    "aireports": ["تحلیل گزارش‌ها"],
    "aihealth": ["سلامت گروه"],
    "airule": ["پیشنهاد قانون"],
    "aioptimize": ["بهینه‌سازی قوانین"],
    "aiincident": ["تحلیل حادثه"],
    "aiplan": ["پلن هوش مصنوعی"],
    "fban": ["بن فدراسیون"],
    "funban": ["لغو بن فدراسیون"],
    # ==================== Phase 3 migration additions ====================
    "allowword": ["اجازه کلمه"],
    "disallowword": ["لغو اجازه کلمه"],
    "blockdomain": ["مسدود کردن دامنه"],
    "unblockdomain": ["رفع مسدودی دامنه"],
    "allowdomain": ["اجازه دامنه"],
    "unallowdomain": ["لغو اجازه دامنه"],
    "allowforward": ["اجازه فوروارد"],
    "blockforward": ["مسدود کردن فوروارد"],
    "unruleforward": ["حذف قانون فوروارد"],
    "setfilteraction": ["تنظیم اکشن فیلتر"],
    "mentionprotection": ["محافظت از منشن"],
    "setmentionlimit": ["تنظیم محدودیت منشن"],
    "setmentionaction": ["تنظیم اکشن منشن"],
    "antispam": ["ضد اسپم"],
    "setspamaction": ["تنظیم اکشن اسپم"],
    "dupcross": ["پیام تکراری بین گروه‌ها"],
    "setdupcross": ["تنظیم تکراری بین گروه‌ها"],
    "setflood": ["تنظیم فلود"],
    "setfloodaction": ["تنظیم اکشن فلود"],
    "setraidthreshold": ["تنظیم آستانه رید"],
    "setmaxwarns": ["تنظیم حداکثر اخطار"],
    "setwarnaction": ["تنظیم اکشن اخطار"],
    "setwelcomedelete": ["حذف خودکار خوش‌آمد"],
    "setgoodbye": ["تنظیم خداحافظی"],
    "resetgoodbye": ["بازنشانی خداحافظی"],
    "createprofile": ["ساخت پروفایل"],
    "delprofile": ["حذف پروفایل"],
    "assignprofile": ["اختصاص پروفایل"],
    "unassignprofile": ["لغو اختصاص پروفایل"],
    "setalertchannel": ["تنظیم کانال هشدار"],
    "importsettings": ["وارد کردن تنظیمات"],
    "schedulerecurring": ["زمان‌بندی پست تکراری"],
    "recurringposts": ["پست‌های تکراری"],
    "delrecurring": ["حذف پست تکراری"],
    "autoactiontoggle": ["فعال‌سازی اکشن خودکار"],
    "dailynotify": ["اطلاع رسانی روزانه"],
    "setpricetime": ["تنظیم زمان قیمت"],
    "setnewstime": ["تنظیم زمان اخبار"],
    "setdailytz": ["تنظیم منطقه زمانی روزانه"],
    "testdailyprice": ["تست قیمت روزانه"],
    "testdailynews": ["تست اخبار روزانه"],
    "dailyassets": ["دارایی‌های روزانه"],
    "ads": ["تبلیغات"],
    "myads": ["تبلیغات من"],
    "adadmin": ["مدیریت تبلیغات"],
    "adstats": ["آمار تبلیغات"],
    "buyplan": ["خرید پلن"],
}
