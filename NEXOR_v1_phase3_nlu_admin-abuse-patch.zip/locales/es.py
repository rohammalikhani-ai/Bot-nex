# -*- coding: utf-8 -*-
STRINGS = {
    "rank_user": "Usuario",
    "rank_moderator": "Moderador",
    "rank_admin": "Admin",
    "rank_owner": "Propietario",

    "err_need_rank": "⛔️ Este comando requiere el nivel de acceso «{rank}» o superior.",
    "err_self_action": "¡No puedes hacerte eso a ti mismo! 😅",
    "err_rank_too_low": "⛔️ No tienes rango suficiente para actuar sobre este usuario (tiene un rango igual o superior al tuyo).",
    "err_user_not_found_username": "❌ No pude encontrar a este usuario (debe haber enviado al menos un mensaje en este grupo para que el bot lo reconozca).",
    "err_need_target": "❗️No se encontró el usuario objetivo.\nUso: {usage}",

    "warn_given": "⚠️ {name} recibió una advertencia. ({count}/{max})",
    "warn_reason_line": "\nMotivo: {reason}",
    "warn_removed": "➖ Se quitó una advertencia a {name}. ({count}/{max})",
    "warn_escalate_mute": "🔇 {name} fue silenciado por {duration} al alcanzar {max} advertencias.",
    "warn_escalate_ban": "🚫 {name} fue baneado al alcanzar {max} advertencias.",
    "warns_header": "⚠️ Advertencias de {name}: {count}/{max}",
    "warns_history_line": "• {when} — {reason} (por {actor})",
    "warns_no_reason": "sin motivo",
    "setwarnaction_usage": "Uso: /setwarnaction mute o /setwarnaction ban",
    "setwarnaction_done": "✅ Acción al alcanzar el máximo de advertencias: {action}",
    "setmaxwarns_usage": "Uso: /setmaxwarns número (p. ej. 3)",
    "setmaxwarns_done": "✅ Máximo de advertencias cambiado a {n}.",

    "mute_done": "🔇 {name} fue silenciado (duración: {duration}).",
    "unmute_done": "🔊 Se quitó el silencio a {name}.",

    "ban_done": "🚫 {name} fue baneado (duración: {duration}).",
    "unban_done": "✅ Se levantó el baneo de {name}.",
    "duration_permanent": "permanente",

    "kick_done": "👢 {name} fue expulsado del grupo.",

    "del_usage": "Por favor responde al mensaje que quieres eliminar.",
    "purge_usage": "Uso: responde a un mensaje con /purge, o /purge <cantidad>",
    "purge_done": "🧹 Se eliminaron {count} mensajes.",

    "promote_usage": "Por favor responde al usuario objetivo o da @usuario/ID.",
    "promote_already_admin": "Este usuario ya es administrador real de Telegram; no necesita rol interno.",
    "promote_done": "⭐️ {name} fue nombrado Moderador interno del bot.",
    "demote_done": "⬇️ Se quitó el rol de Moderador a {name}.",
    "roles_empty": "No hay Moderadores internos registrados. (Usa el panel del grupo de Telegram para ver a los administradores reales.)",
    "roles_header": "⭐️ Moderadores internos de este grupo:",
    "logs_empty": "Aún no se ha registrado ninguna acción.",
    "logs_header": "🧾 Últimas acciones de moderación:",

    "btn_remove_warn": "➖ Quitar advertencia",
    "btn_mute": "🔇 Silenciar",
    "btn_ban": "🚫 Banear",
    "modact_invalid_data": "Datos inválidos.",
    "modact_wrong_chat": "Este botón no es para este chat.",
    "modact_no_permission": "⛔️ No tienes permiso para esta acción.",
    "modact_done": "Hecho ✅",
    "modact_unwarn_result": "➖ {name} — se quitó una advertencia. ({count})",
    "modact_mute_result": "🔇 {name} fue silenciado por {minutes} minutos.",
    "modact_ban_result": "🚫 {name} fue baneado.",

    "start_msg": (
        "¡Hola {mention}! 🌹\n\n"
        "🔰 Conoce a *NEXOR* — el bot de administración de grupos más profesional\n"
        "🔰 Un asistente potente para el orden, la seguridad y el control total de tus grupos de Telegram\n\n"
        "✨ *Características principales:*\n"
        "✅ Gestión completa de miembros (advertencia, silencio, baneo, expulsión)\n"
        "✅ Bloqueos inteligentes de contenido (enlaces, reenvíos, multimedia y más)\n"
        "✅ Filtrado avanzado de palabras y frases prohibidas\n"
        "✅ Captcha de ingreso para bloquear bots no deseados\n"
        "✅ Protección avanzada contra spam y flood\n"
        "✅ Protección contra invasiones masivas (Anti-Raid)\n"
        "✅ Gestión de canal conectado (publicar, programar, editar, eliminar)\n"
        "✅ Sistema de federación entre varios grupos\n"
        "✅ Roles internos, registro y reportes completos\n"
        "✅ Multilingüe (persa, inglés, árabe, turco, ruso, español)\n\n"
        "🤖 *NEXOR Copilot — el asistente de IA de tu grupo:*\n"
        "✅ Responde a cualquier mensaje sospechoso y analiza el riesgo en segundos\n"
        "✅ Pregúntale «¿por qué?» y te explica exactamente el motivo de una advertencia/silencio/baneo\n"
        "✅ Te da un informe completo de salud del grupo: dónde hay tensión y dónde endurecer las reglas\n"
        "✅ Solo describe tu problema con tus palabras («hay mucho spam») y te propone y crea una regla automática\n"
        "✅ Analiza y prioriza los reportes de usuarios e incidentes recientes antes de que decidas\n"
        "¡Pruébalo con /copilot! ✨\n"
        "\n"
        "🚀 *Instalación:*\n"
        "1. Agrega el bot a tu grupo con el botón de abajo\n"
        "2. Dale permisos completos de administrador para que funcione correctamente\n\n"
        "📌 *Notas importantes:*\n"
        "• El grupo debe ser un supergrupo\n"
        "• Para un mejor rendimiento, se recomienda otorgar acceso completo de administrador\n\n"
        "Usa /help para ver la lista completa de comandos."
    ),
    "add_to_group_button": "➕ Agregar al grupo",
    "settings_header": "⚙️ *Configuración actual del grupo*",
    "settings_locks": "🔒 Bloqueos: {locks}",
    "settings_filters": "🚫 Filtros: {filters}",
    "settings_captcha": "🛡️ CAPTCHA: {state}",
    "settings_warns": "⚠️ Máximo de advertencias: {max} → acción: {action}",
    "settings_channel": "📢 Canal vinculado: {channel}",
    "settings_logchannel": "🧾 Canal de logs: {log}",
    "settings_lang": "🌐 Idioma: {lang}",
    "none": "ninguno",
    "not_set": "—",

    "setlang_prompt": "🌐 Elige el idioma del grupo:",
    "setlang_done": "✅ Idioma del grupo cambiado a {lang_name}.",

    "welcome_simple": "¡Bienvenido {mention} a {chat}! 🌹",
    "welcome_captcha": "¡Bienvenido {mention} a {chat}! 🌹\nPor favor pulsa el botón de abajo para verificar que no eres un robot.",
    "welcome_simple_multi": "¡Bienvenidos a {chat}: {mentions} 🌹",
    "welcome_captcha_multi": "¡Bienvenidos a {chat}: {mentions} 🌹\nCada persona debe pulsar el botón junto a su nombre para verificar.",
    "captcha_btn": "✅ No soy un robot",
    "captcha_not_yours": "Este botón no es para ti.",
    "captcha_expired": "Esta verificación ha expirado.",
    "captcha_verified_alert": "✅ ¡Verificado, bienvenido!",
    "captcha_verified_msg": "✅ {name} fue verificado y ya puede escribir.",
    "captcha_timeout_msg": "⛔️ El tiempo de verificación expiró; el usuario fue eliminado.",
    "captcha_toggle_usage": "Uso: /captcha on o /captcha off",
    "captcha_toggle_done": "🛡️ CAPTCHA {state}.",
    "captcha_on": "activado",
    "captcha_off": "desactivado",
    "goodbye_msg": "{name} dejó el grupo. 👋",

    "lock_usage": "Uso: /lock {options}",
    "lock_done": "🔒 {kind} bloqueado.",
    "unlock_usage": "Uso: /unlock {options}",
    "unlock_done": "🔓 {kind} desbloqueado.",
    "locks_active": "🔒 Bloqueos activos: {locks}",
    "filter_usage": "Uso: /filter palabra",
    "filter_added": "➕ Palabra «{word}» añadida al filtro.",
    "stopfilter_usage": "Uso: /stopfilter palabra",
    "filter_removed": "➖ Palabra «{word}» eliminada del filtro.",
    "filters_active": "🚫 Filtros activos: {filters}",
    "flood_muted": "🚨 {name} fue silenciado por {minutes} minutos por enviar demasiados mensajes muy rápido.",

    "save_usage": "Uso: /save nombre texto (o respondiendo a un mensaje: /save nombre)",
    "save_empty": "No se encontró texto para guardar.",
    "save_done": "📝 Nota «{name}» guardada. Consúltala con /get {name} o #{name}.",
    "get_usage": "Uso: /get nombre",
    "get_not_found": "No se encontró ninguna nota con ese nombre.",
    "notes_empty": "Aún no hay notas guardadas.",
    "notes_list_header": "📝 Notas disponibles:",
    "clear_usage": "Uso: /clear nombre",
    "clear_done": "🗑️ Nota «{name}» eliminada.",

    "setlogchannel_usage": "Uso: /setlogchannel @canal＿username o ID numérico del canal",
    "setlogchannel_error": "❌ No pude encontrar ese canal: {error}",
    "setlogchannel_done": "🧾 Las acciones de administración se registrarán ahora en «{title}».",
    "setlogchannel_channel_confirm": "✅ Este canal fue configurado como canal de logs de administración del grupo.",

    "fed_new_usage": "Uso: /fnew nombre＿federación",
    "fed_new_done": "🌐 Federación «{name}» creada (ID: {id}).\nEste grupo fue añadido como primer miembro.\nPara añadir otros grupos, ejecuta esto allí:\n/fjoin {id}",
    "fed_join_usage": "Uso: /fjoin id＿federación",
    "fed_join_invalid_id": "ID de federación inválido.",
    "fed_not_found": "No se encontró ninguna federación con ese ID.",
    "fed_join_done": "✅ Este grupo se unió a la federación «{name}».",
    "fed_not_member": "Este grupo no es miembro de ninguna federación.",
    "fed_left": "👋 Este grupo dejó la federación «{name}».",
    "fed_info": "🌐 Federación: {name}\n🆔 ID: {id}\n👥 Grupos miembros: {count}",
    "fed_ban_no_target": "Por favor responde al mensaje del usuario objetivo o da @usuario/ID.",
    "fed_ban_not_member": "Este grupo aún no pertenece a ninguna federación. Ejecuta /fnew o /fjoin primero.",
    "fed_ban_done": "🚫 {name} fue baneado en toda la federación «{fed}».\n✅ Éxito: {success} grupos | ❌ Fallido: {failed} grupos\nMotivo: {reason}",
    "fed_unban_done": "✅ Se levantó el baneo de {name} en {success} grupos de la federación «{fed}».",
    "fed_ban_no_reason": "sin motivo indicado",
    "fed_raid_kick_notice": "🚫 {name} estaba baneado en la federación y fue eliminado automáticamente.",

    "help_text": (
        "📋 *Comandos de administración*\n\n"
        "✨ *Dato genial:* ¡no siempre hace falta escribir la barra! Cada comando tiene también una palabra gemela que hace exactamente lo mismo — por ejemplo, escribir «reportar» funciona igual que /report, y escribir «ayuda» abre este mismo menú. Esto funciona en los 6 idiomas que soporta el bot, cada uno con sus propias palabras, así que cualquier miembro puede mandar al bot en su propio idioma sin memorizar ni un solo comando con barra! 🗣️\n\n"
        "👮 *Gestión de miembros* (respondiendo, con @usuario o user＿id)\n"
        "/warn [duración] [motivo]   /unwarn   /warns — historial de advertencias\n"
        "/mute [duración] [motivo]   /unmute\n"
        "/ban [duración] [motivo]   /unban\n"
        "/kick [motivo]\n"
        "Ejemplo: /ban 2h mucho spam   o   /mute @user 30m\n"
        "/setmaxwarns número   /setwarnaction mute|ban\n\n"
        "🧹 *Eliminar mensajes*\n"
        "/del — elimina el mensaje respondido\n"
        "/purge — elimina desde el mensaje respondido hasta ahora (o /purge cantidad)\n\n"
        "⭐️ *Roles internos*\n"
        "/promote /demote — rol interno de Moderador del bot (por debajo de admin real)\n"
        "/roles — lista de Moderadores internos\n"
        "/logs — acciones de moderación recientes (registro de auditoría)\n\n"
        "🔒 *Bloqueos de contenido*\n"
        "/lock link|invitelink|channellink|photo|video|sticker|voice|forward|gif|video＿note|document|poll\n"
        "/unlock las mismas opciones\n"
        "/locks — mostrar bloqueos activos\n\n"
        "🌐 *Protección de enlaces*\n"
        "/blockdomain dominio   /unblockdomain dominio\n"
        "/allowdomain dominio   /unallowdomain dominio\n"
        "/domains — mostrar listas\n\n"
        "🚫 *Filtros de palabras*\n"
        "/filter palabra\n/stopfilter palabra\n/filters\n"
        "/setfilteraction delete|warn|mute|ban\n"
        "/allowword palabra — excepción   /disallowword palabra\n\n"
        "🕵️ *Anti-Spam*\n"
        "/antispam on|off\n/setspamaction delete|warn|mute|ban\n"
        "/dupcross on|off   /setdupcross umbral segundos\n\n"
        "↪️ *Protección de Reenvíos*\n"
        "/allowforward origen   /blockforward origen   /unruleforward origen\n"
        "/forwardrules — mostrar reglas (origen: @usuario, ID o nombre)\n\n"
        "📛 *Protección de Menciones*\n"
        "/mentionprotection on|off\n/setmentionlimit número\n/setmentionaction delete|warn|mute|ban\n\n"
        "🚨 *Anti-Flood*\n"
        "/setflood cantidad segundos\n/setfloodaction delete|warn|mute|ban\n\n"
        "🛡️ *Anti-Raid*\n"
        "/antiraid on|off\n/setraidthreshold número\n"
        "/lockdown — bloquear todo el grupo ahora   /unlockchat — desbloquear\n\n"
        "🛡️ *CAPTCHA*\n"
        "/captcha on|off — activar/desactivar verificación de nuevos miembros\n\n"
        "📝 *Notas*\n"
        "/save nombre (respondiendo o con texto) — guardar una nota\n"
        "/get nombre o #nombre — mostrar una nota\n"
        "/notes — listar notas\n"
        "/clear nombre — eliminar una nota\n\n"
        "📢 *Gestión de canal (se ejecuta desde el grupo)*\n"
        "/setchannel @canal＿username — vincular un canal\n"
        "/post texto — publicar de inmediato (botón con \"texto|enlace\", ; entre botones)\n"
        "/schedulepost minutos | texto — publicación programada\n"
        "/editpost id＿mensaje | nuevo texto\n"
        "/delpost id＿mensaje\n"
        "/channelstats — estadísticas del canal\n\n"
        "🧾 *Registro de administración*\n"
        "/setlogchannel @canal＿username — registrar acciones de admin en un canal\n\n"
        "🌐 *Federación (lista de baneos compartida)*\n"
        "/fnew nombre — crear una nueva federación\n"
        "/fjoin id — unir este grupo a una federación\n"
        "/fleave — abandonar la federación\n"
        "/finfo — info de la federación actual\n"
        "/fban (respondiendo) motivo — banear en todos los grupos de la federación\n"
        "/funban (respondiendo) — desbanear en todos los grupos de la federación\n\n"
        "🆕 *Nuevos miembros y automatización*\n"
        "/setwelcomedelete segundos|off — autoeliminar el mensaje de bienvenida\n"
        "/setgoodbye texto   /resetgoodbye   /goodbye on|off\n"
        "/rules   /setrules [idioma] texto   /clearrules [idioma]\n"
        "/addkeyword palabra respuesta   /delkeyword palabra   /keywords\n"
        "/addcmd nombre respuesta   /delcmd nombre   /cmds\n"
        "/schedulerecurring daily|weekly|monthly ... — publicaciones recurrentes en el canal\n"
        "/recurringposts   /delrecurring id\n"
        "/addautoaction condición acción   /delautoaction id   /autoactions   /autoactiontoggle on|off\n\n"
        "🗂️ *Perfiles de permisos*\n"
        "/createprofile nombre permiso1,permiso2,...   /delprofile nombre   /profiles\n"
        "/assignprofile [responder|@user|id] perfil   /unassignprofile [responder|@user|id]   /myperms\n\n"
        "🚩 *Reportes*\n"
        "/report [motivo] (respondiendo a un mensaje)   /reports — reportes abiertos\n\n"
        "🔔 *Alertas de administradores*\n"
        "/setalertchannel chat＿id   /alerts — alertas recientes\n\n"
        "📦 *Importar / Exportar configuración*\n"
        "/exportsettings   /importsettings (respondiendo a un archivo .json)\n\n"
        "🔔 *Notificación diaria* (💰 precios + 📰 noticias + 📅 fecha/ocasión)\n"
        "/dailynotify — panel de ajustes (activar/desactivar, activos, envío de prueba)\n"
        "/setpricetime HH:MM   /setnewstime HH:MM   /setdailytz zona_horaria\n"
        "/testdailyprice   /testdailynews   /dailyassets\n\n"
        "🌐 /setlang — cambiar el idioma del grupo\n"
        "⚙️ /settings — mostrar la configuración actual del grupo"
    ),

    "help_words_text": (
        "📖 *Lista completa de comandos por palabra*\n"
        "Cada línea significa: escribe esta palabra = ejecuta ese comando exacto\n"
        "\n"
        "*👮 Gestión de miembros*\n"
        "advertencia = /warn\n"
        "quitar advertencia = /unwarn\n"
        "advertencias = /warns\n"
        "silenciar = /mute\n"
        "quitar silencio = /unmute\n"
        "banear = /ban\n"
        "desbanear = /unban\n"
        "expulsar = /kick\n"
        "borrar = /del\n"
        "purgar = /purge\n"
        "\n"
        "*⭐️ Roles y registro*\n"
        "ascender = /promote\n"
        "degradar = /demote\n"
        "moderadores = /roles\n"
        "registro = /logs\n"
        "cambiar idioma = /setlang\n"
        "\n"
        "*🔒 Bloqueos y filtros*\n"
        "bloquear = /lock\n"
        "desbloquear = /unlock\n"
        "bloqueos = /locks\n"
        "filtro = /filter\n"
        "quitar filtro = /stopfilter\n"
        "filtros = /filters\n"
        "dominios bloqueados = /domains\n"
        "reglas de reenvío = /forwardrules\n"
        "\n"
        "*🛡️ Seguridad del grupo*\n"
        "antiraid = /antiraid\n"
        "bloqueo total = /lockdown\n"
        "abrir grupo = /unlockchat\n"
        "captcha = /captcha\n"
        "despedida = /goodbye\n"
        "\n"
        "*📝 Notas*\n"
        "guardar = /save\n"
        "obtener = /get\n"
        "notas = /notes\n"
        "borrar nota = /clear\n"
        "\n"
        "*📢 Canal*\n"
        "establecer canal = /setchannel\n"
        "publicar = /post\n"
        "programar publicación = /schedulepost\n"
        "editar publicación = /editpost\n"
        "eliminar publicación = /delpost\n"
        "estadísticas del canal = /channelstats\n"
        "establecer canal de registro = /setlogchannel\n"
        "\n"
        "*🌐 Federación*\n"
        "nueva federación = /fnew\n"
        "unirse a federación = /fjoin\n"
        "salir de federación = /fleave\n"
        "información de federación = /finfo\n"
        "baneo de federación = /fban\n"
        "desbaneo de federación = /funban\n"
        "\n"
        "*🆕 Bienvenida y automatización*\n"
        "reglas = /rules\n"
        "establecer reglas = /setrules\n"
        "borrar reglas = /clearrules\n"
        "agregar palabra clave = /addkeyword\n"
        "quitar palabra clave = /delkeyword\n"
        "palabras clave = /keywords\n"
        "agregar comando = /addcmd\n"
        "quitar comando = /delcmd\n"
        "comandos = /cmds\n"
        "agregar acción automática = /addautoaction\n"
        "quitar acción automática = /delautoaction\n"
        "acciones automáticas = /autoactions\n"
        "\n"
        "*🗂️ Perfiles y reportes*\n"
        "perfiles = /profiles\n"
        "mis permisos = /myperms\n"
        "reportar = /report\n"
        "reportes = /reports\n"
        "alertas = /alerts\n"
        "exportar ajustes = /exportsettings\n"
        "\n"
        "*🤖 NEXOR Copilot*\n"
        "admin = /adminpanel\n"
        "asistente = /copilot\n"
        "revisión ia = /aicheck\n"
        "explicar acción = /aiexplain\n"
        "analizar reportes = /aireports\n"
        "salud del grupo = /aihealth\n"
        "asesor de reglas = /airule\n"
        "optimizar reglas = /aioptimize\n"
        "analizar incidente = /aiincident\n"
        "plan de ia = /aiplan\n"
        "\n"
        "*⚙️ General*\n"
        "ajustes = /settings\n"
        "ayuda = /help\n"
        "\n"
        "💡 Para frases de varias palabras (como «quitar filtro»), escríbelas tal cual, seguidas."
    ),

    "channel_set_usage": "Uso: /setchannel @canal＿username o ID numérico del canal",
    "channel_set_error": "❌ No pude encontrar ese canal: {error}",
    "channel_set_done": "📢 Canal «{title}» vinculado a este grupo.",
    "channel_no_channel": "Primero vincula un canal con /setchannel.",
    "channel_post_empty": "El texto de la publicación está vacío. Uso: /post texto del mensaje",
    "channel_post_sent": "✅ Publicación enviada. ID de mensaje: {id}",
    "channel_post_failed": "❌ Error al enviar la publicación: {error}",
    "channel_schedule_usage": "Uso: /schedulepost minutos, luego el texto de la publicación en la siguiente línea",
    "channel_schedule_invalid_minutes": "Número de minutos inválido.",
    "channel_schedule_empty": "El texto de la publicación está vacío.",
    "channel_schedule_done": "⏰ Publicación programada para dentro de {minutes} minutos.",
    "channel_scheduled_sent": "✅ Publicación programada enviada. ID: {id}",
    "channel_scheduled_failed": "❌ Error al enviar la publicación programada: {error}",
    "channel_editpost_usage": "Uso: /editpost id＿mensaje, luego el nuevo texto en la siguiente línea",
    "channel_editpost_invalid_id": "ID de mensaje inválido.",
    "channel_editpost_empty": "El nuevo texto está vacío.",
    "channel_editpost_done": "✅ Publicación editada.",
    "channel_editpost_failed": "❌ Error al editar: {error}",
    "channel_delpost_usage": "Uso: /delpost id＿mensaje",
    "channel_delpost_done": "🗑️ Publicación eliminada.",
    "channel_delpost_failed": "❌ Error al eliminar: {error}",
    "channel_stats_text": "📊 Estadísticas del canal «{title}»\n👥 Miembros: {count}",
    "channel_stats_failed": "❌ Error al obtener estadísticas: {error}",

    "state_on": "activado",
    "state_off": "desactivado",

    "antispam_toggle_usage": "Uso: /antispam on o /antispam off",
    "antispam_toggle_done": "🕵️ Anti-Spam {state}.",
    "adminabuseprotection_toggle_usage": "Uso: /adminabuseprotection on o /adminabuseprotection off (solo el propietario)",
    "adminabuseprotection_toggle_done": "🚷 Detección de abuso de administrador {state}.",
    "setspamaction_usage": "Uso: /setspamaction delete|warn|mute|ban",
    "setspamaction_done": "✅ Acción de Anti-Spam: {action}",
    "spam_reason_duplicate": "envío de mensaje duplicado",
    "spam_reason_newlink": "publicar un enlace justo después de unirse",

    "setflood_usage": "Uso: /setflood cantidad segundos  (p. ej. /setflood 5 10)",
    "setflood_done": "✅ Anti-Flood: {limit} mensajes cada {window} segundos",
    "setfloodaction_usage": "Uso: /setfloodaction delete|warn|mute|ban",
    "setfloodaction_done": "✅ Acción de Anti-Flood: {action}",
    "flood_reason": "enviar mensajes demasiado rápido",

    "setfilteraction_usage": "Uso: /setfilteraction delete|warn|mute|ban",
    "setfilteraction_done": "✅ Acción del filtro de palabras: {action}",
    "allowword_usage": "Uso: /allowword palabra",
    "allowword_done": "➕ «{word}» añadida a la lista de excepciones.",
    "disallowword_usage": "Uso: /disallowword palabra",
    "disallowword_done": "➖ «{word}» eliminada de la lista de excepciones.",
    "filter_reason": "palabra prohibida",

    "blockdomain_usage": "Uso: /blockdomain dominio (p. ej. example.com)",
    "blockdomain_done": "🚫 Dominio «{domain}» bloqueado.",
    "unblockdomain_usage": "Uso: /unblockdomain dominio",
    "unblockdomain_done": "✅ Dominio «{domain}» desbloqueado.",
    "allowdomain_usage": "Uso: /allowdomain dominio",
    "allowdomain_done": "✅ Dominio «{domain}» añadido a la lista blanca.",
    "unallowdomain_usage": "Uso: /unallowdomain dominio",
    "unallowdomain_done": "➖ Dominio «{domain}» eliminado de la lista blanca.",
    "domains_header_block": "🚫 Dominios bloqueados:",
    "domains_header_allow": "✅ Dominios en la lista blanca:",
    "domains_empty": "No hay dominios registrados.",
    "link_reason_blacklisted": "enlace de dominio bloqueado",

    "antiraid_toggle_usage": "Uso: /antiraid on o /antiraid off",
    "antiraid_toggle_done": "🛡️ Anti-Raid {state}.",
    "setraidthreshold_usage": "Uso: /setraidthreshold número (p. ej. 8)",
    "setraidthreshold_done": "✅ Umbral de detección de raid cambiado a {n} usuarios.",
    "raid_detected_alert": "🚨 *¡Alerta de raid!*\nUn número inusual de nuevos miembros ({count} en {window} segundos) se unió al grupo.\nEl grupo fue bloqueado durante {minutes} minutos (solo los admins pueden escribir).",
    "raid_auto_unlock": "🔓 Bloqueo de seguridad automático levantado.",
    "lockdown_done": "🔒 Grupo bloqueado; solo los admins pueden escribir.",
    "unlock_done_manual": "🔓 Bloqueo del grupo levantado.",
    "already_locked": "El grupo ya está bloqueado.",
    "already_unlocked": "El grupo no está bloqueado.",
    "btn_unlock_now": "🔓 Desbloquear ahora",

    # --- Priority 3: Content Control (Forward Protection / Mention Protection / Cross-user Duplicate) ---
    "allowforward_usage": "Uso: /allowforward @usuario|ID|nombre",
    "allowforward_done": "✅ Los reenvíos de «{source}» ahora siempre están permitidos.",
    "blockforward_usage": "Uso: /blockforward @usuario|ID|nombre",
    "blockforward_done": "🚫 Los reenvíos de «{source}» ahora siempre están bloqueados.",
    "unruleforward_usage": "Uso: /unruleforward @usuario|ID|nombre",
    "unruleforward_done": "➖ Regla de reenvío para «{source}» eliminada.",
    "forwardrules_header_block": "🚫 Fuentes siempre bloqueadas:",
    "forwardrules_header_allow": "✅ Fuentes siempre permitidas:",
    "forwardrules_empty": "No hay reglas de reenvío.",
    "forward_reason_blocked_source": "reenvío desde una fuente bloqueada ({source})",
    "mentionprotection_usage": "Uso: /mentionprotection on o /mentionprotection off",
    "mentionprotection_done": "🛡️ Protección de menciones {state}.",
    "setmentionlimit_usage": "Uso: /setmentionlimit número (ej. 5)",
    "setmentionlimit_done": "✅ Límite de menciones cambiado a {n}.",
    "setmentionaction_usage": "Uso: /setmentionaction delete|warn|mute|ban",
    "setmentionaction_done": "✅ Acción por abuso de menciones: {action}",
    "mention_reason": "abuso de menciones masivas ({count} menciones)",
    "dupcross_usage": "Uso: /dupcross on o /dupcross off",
    "dupcross_done": "🕵️ Detección de duplicados entre usuarios {state}.",
    "setdupcross_usage": "Uso: /setdupcross umbral segundos (ej. 3 45)",
    "setdupcross_done": "✅ Ajustes de duplicados entre usuarios: {threshold} usuarios en {window}s.",
    "spam_reason_cross_duplicate": "mensaje duplicado de varios usuarios (raid de copiar/pegar)",

    # --- Priority 4: New Members & Automation (Welcome auto-delete, Goodbye, Rules, Filters, Custom Commands, Scheduled Messages, Auto Actions) ---
    "setwelcomedelete_usage": "Uso: /setwelcomedelete segundos (ej. 60) o /setwelcomedelete off",
    "setwelcomedelete_done": "✅ Los mensajes de bienvenida ahora se eliminarán automáticamente tras {seconds} segundos.",
    "setwelcomedelete_off": "✅ Autoeliminación del mensaje de bienvenida desactivada.",
    "setgoodbye_usage": "Uso: /setgoodbye <texto>\nVariables disponibles: {name} {username} {mention} {chat} {count}",
    "setgoodbye_done": "✅ Mensaje de despedida personalizado guardado.",
    "resetgoodbye_done": "✅ Mensaje de despedida restablecido al predeterminado.",
    "goodbye_toggle_usage": "Uso: /goodbye on o /goodbye off",
    "goodbye_toggle_done": "👋 Mensajes de despedida {state}.",
    "rules_empty": "Aún no se han establecido reglas para este grupo.",
    "rules_header": "📜 *Reglas del grupo*",
    "setrules_usage": "Uso: /setrules [código de idioma] <texto de las reglas>\nEjemplo: /setrules Por favor respeten a todos.\nCon código de idioma: /setrules en Please be respectful.",
    "setrules_done": "✅ Reglas guardadas ({lang}).",
    "clearrules_done": "🗑️ Reglas eliminadas ({lang}).",
    "clearrules_notfound": "No había reglas establecidas para ese idioma.",
    "addkeyword_usage": "Uso: /addkeyword <palabra clave> <respuesta>\nO respondiendo a un mensaje: /addkeyword <palabra clave>",
    "addkeyword_done": "✅ Disparador de palabra clave «{keyword}» añadido.",
    "addkeyword_updated": "♻️ Disparador de palabra clave «{keyword}» actualizado.",
    "delkeyword_usage": "Uso: /delkeyword <palabra clave>",
    "delkeyword_done": "🗑️ Disparador de palabra clave «{keyword}» eliminado.",
    "delkeyword_notfound": "No existe ese disparador.",
    "keywords_empty": "No hay disparadores de palabras clave configurados.",
    "keywords_header": "🔑 Disparadores de palabras clave:",
    "autoanswer_ask_audience": "⚙️ Configurando respuesta automática para «{title}»\n\n¿A quién debe responder el bot con esta palabra clave?",
    "autoanswer_ask_keyword": "✏️ Ahora envía la palabra o frase clave (por ejemplo: precio, reglas, admin...).",
    "autoanswer_ask_response": "📎 Palabra clave «{keyword}» guardada.\n\nAhora envía el mensaje o el contenido multimedia con el que quieres que el bot responda (texto, foto, video, nota de voz, audio, archivo, GIF, sticker o video circular).\n\nPuedes enviar hasta 20 respuestas diferentes para que el bot elija una al azar cada vez. Cuando termines, pulsa «Finalizar».",
    "autoanswer_audience_admins": "🛡 Solo administradores",
    "autoanswer_audience_all": "👥 Todos los usuarios",
    "autoanswer_audience_owners": "👑 Solo el propietario",
    "autoanswer_btn_cancel": "❌ Cancelar",
    "autoanswer_btn_done": "✅ Finalizar",
    "autoanswer_cancelled": "❌ Cancelado; no se guardó ninguna respuesta automática.",
    "autoanswer_cleaned": "🗑️ Se eliminaron {count} respuesta(s) automática(s).",
    "autoanswer_expired": "Este paso ya no es válido; envía de nuevo el comando «configurar respuesta automática» dentro del grupo.",
    "autoanswer_group_only": "Este comando solo se puede usar dentro de un grupo.",
    "autoanswer_invalid_link": "Este enlace no es válido o ha caducado. Envía de nuevo el comando «configurar respuesta automática» dentro del grupo.",
    "autoanswer_list_empty": "No hay respuestas automáticas configuradas.",
    "autoanswer_list_header": "◄ Lista de respuestas automáticas:",
    "autoanswer_list_item": "• «{keyword}» — destinatarios: {audience} — {count} respuesta(s)",
    "autoanswer_max_responses": "⛔️ Has alcanzado el límite de {max} respuestas. Pulsa «Finalizar» para guardar.",
    "autoanswer_need_one_response": "Todavía no has añadido ninguna respuesta; envía al menos un mensaje o contenido multimedia.",
    "autoanswer_not_admin": "⛔️ Debes ser administrador o propietario de ese grupo para configurar una respuesta automática.",
    "autoanswer_pm_button": "🔐 Abrir el privado para configurar la respuesta automática",
    "autoanswer_response_added": "✅ Respuesta {count}/{max} guardada.\nEnvía la siguiente o pulsa «Finalizar».",
    "autoanswer_saved": "✅ Respuesta automática guardada para «{title}».\nPalabra clave: {keyword}\nDestinatarios: {audience}\nRespuestas: {count}",
    "autoanswer_setup_intro": "◄ Respuesta automática (Auto-Answer)\n\nPara configurar una nueva respuesta automática para «{title}», pulsa el botón de abajo y continúa los pasos en un chat privado.",
    "autoanswer_unsupported_content": "Ese tipo de contenido no es compatible. Envía texto, foto, video, nota de voz, audio, archivo, GIF, sticker o video circular.",
    "autoanswer_updated": "♻️ Respuesta automática «{keyword}» actualizada para «{title}».\nDestinatarios: {audience}\nRespuestas: {count}",
    "delanswer_done": "🗑️ Respuesta automática «{keyword}» eliminada.",
    "delanswer_notfound": "No existe esa respuesta automática.",
    "delanswer_usage": "Uso: /delanswer <palabra clave>",
    "addcmd_usage": "Uso: /addcmd <nombre> <respuesta>\nO respondiendo a un mensaje: /addcmd <nombre>",
    "addcmd_reserved": "⛔ Este nombre está reservado para un comando integrado.",
    "addcmd_done": "✅ Comando personalizado /{name} añadido.",
    "addcmd_updated": "♻️ Comando personalizado /{name} actualizado.",
    "delcmd_usage": "Uso: /delcmd <nombre>",
    "delcmd_done": "🗑️ Comando personalizado /{name} eliminado.",
    "delcmd_notfound": "No existe ese comando personalizado.",
    "cmds_empty": "No hay comandos personalizados definidos.",
    "cmds_header": "⚙️ Comandos personalizados:",
    "schedulerecurring_usage": "Uso:\n/schedulerecurring daily HH:MM <texto>\n/schedulerecurring weekly mon HH:MM <texto>\n/schedulerecurring monthly DÍA HH:MM <texto>\n(día de la semana: mon tue wed thu fri sat sun — día: 1-28)",
    "schedulerecurring_invalid_time": "Hora inválida. Usa el formato HH:MM (ej. 14:30).",
    "schedulerecurring_invalid_day": "Día del mes inválido. Usa un número entre 1 y 28.",
    "schedulerecurring_invalid_weekday": "Día de la semana inválido. Usa uno de: mon tue wed thu fri sat sun",
    "schedulerecurring_empty_text": "Se requiere el texto del mensaje (en la(s) línea(s) tras el comando).",
    "schedulerecurring_done": "✅ Publicación recurrente programada (ID {id}).",
    "recurringposts_header": "🔁 Publicaciones recurrentes:",
    "recurringposts_empty": "No hay publicaciones recurrentes programadas.",
    "recurringposts_item": "#{id} — {schedule} — {preview}",
    "recurring_desc_daily": "Diariamente a las {time}",
    "recurring_desc_weekly": "Semanalmente los {weekday} a las {time}",
    "recurring_desc_monthly": "Mensualmente el día {day} a las {time}",
    "delrecurring_usage": "Uso: /delrecurring <id>",
    "delrecurring_done": "🗑️ Publicación recurrente #{id} eliminada.",
    "delrecurring_notfound": "No hay ninguna publicación recurrente con ese ID.",
    "addautoaction_usage": "Uso: /addautoaction <condición> <acción>\nCondiciones: message＿type:<photo|video|sticker|voice|gif|video＿note|document|poll|forward|link|text>, user＿role:<user|moderator|admin>, warns＿gte:<número>\nAcciones: delete, warn, mute:<minutos>, ban, kick",
    "addautoaction_invalid_condition": "Condición inválida. Ejecuta /addautoaction sin argumentos para ver el formato.",
    "addautoaction_invalid_action": "Acción inválida. Ejecuta /addautoaction sin argumentos para ver el formato.",
    "addautoaction_done": "✅ Regla de Auto Action añadida (ID {id}): {condition} → {action}",
    "delautoaction_usage": "Uso: /delautoaction <id>",
    "delautoaction_done": "🗑️ Regla de Auto Action #{id} eliminada.",
    "delautoaction_notfound": "No hay ninguna regla de Auto Action con ese ID.",
    "autoactions_header": "🤖 Reglas de Auto Action:",
    "autoactions_empty": "No hay reglas de Auto Action definidas.",
    "autoactiontoggle_usage": "Uso: /autoactiontoggle on o /autoactiontoggle off",
    "autoactiontoggle_done": "🤖 Auto Actions {state}.",
    "autoaction_reason": "Regla de Auto Action (#{id})",
    "settings_goodbye": "👋 Mensajes de despedida: {state}",
    "settings_autoaction": "🤖 Auto Actions: {state}",

    # Priority 5, Item 25 — Permission Profiles
    "createprofile_usage": "Uso: /createprofile <nombre> <permiso1,permiso2,...>\nPermisos disponibles: {caps}",
    "profile_invalid_caps": "❌ Permiso desconocido: {invalid}\nPermisos disponibles: {caps}",
    "createprofile_done": "✅ Perfil «{name}» creado con permisos: {caps}",
    "createprofile_updated": "♻️ Perfil «{name}» actualizado con permisos: {caps}",
    "delprofile_usage": "Uso: /delprofile <nombre>",
    "delprofile_notfound": "No existe ese perfil.",
    "delprofile_done": "🗑️ Perfil «{name}» eliminado.",
    "profiles_empty": "Aún no hay perfiles de permisos personalizados.",
    "profiles_header": "🗂️ Perfiles de permisos:",
    "profile_item": "• «{name}» — {caps}\n   Miembros: {members}",
    "assignprofile_usage": "Uso: /assignprofile [responder|@user|id] <perfil>",
    "assignprofile_notfound_profile": "No existe un perfil llamado «{name}». Créalo primero con /createprofile.",
    "assignprofile_done": "✅ Perfil «{profile}» asignado a {name}.",
    "unassignprofile_usage": "Uso: /unassignprofile [responder|@user|id]",
    "unassignprofile_notfound": "Este usuario no tiene ningún perfil asignado.",
    "unassignprofile_done": "➖ Perfil eliminado de {name}.",
    "myperms_with_profile": "Tu rango: {rank}\nPerfil asignado: «{profile}»\nPermisos: {caps}",
    "myperms_no_profile": "Tu rango: {rank}\nNo tienes un perfil personalizado asignado.",

    # Priority 5, Item 26 — Reports
    "report_need_reply": "Por favor responde al mensaje que quieres reportar.",
    "report_self": "¡No puedes reportarte a ti mismo! 😅",
    "report_already": "Ya reportaste este mensaje recientemente.",
    "report_done": "✅ Tu reporte fue enviado a los administradores. ¡Gracias!",
    "report_alert_header": "🚩 Nuevo reporte #{id}\nReportado por: {reporter}\nReportado: {target}\nMotivo: {reason}",
    "alert_multi_reports_text": "{target} ha recibido {count} reportes distintos en los últimos {window}s.",
    "reports_empty": "No hay reportes abiertos.",
    "reports_header": "🚩 Reportes abiertos:",
    "report_item": "• #{id} [{when}] {reporter} → {target} ({reason})",
    "btn_report_mute": "🔇 Silenciar",
    "btn_report_ban": "🚫 Banear",
    "btn_report_delete": "🗑️ Borrar mensaje",
    "btn_report_dismiss": "✖️ Descartar",
    "report_not_found": "Este reporte ya no existe o ya fue gestionado.",
    "report_action_done_dismiss": "✖️ Reporte #{id} sobre {target} descartado.",
    "report_action_done_mute": "🔇 {target} fue silenciado ({minutes} min) por el reporte.",
    "report_action_done_ban": "🚫 {target} fue baneado por el reporte.",
    "report_action_done_delete": "🗑️ Se eliminó el mensaje reportado de {target}.",

    # Priority 5, Item 27 — Admin Alerts
    "setalertchannel_usage": "Uso: /setalertchannel <chat＿id> (sin argumentos = borrar)",
    "setalertchannel_done": "✅ Destino de alertas configurado a {channel}.",
    "setalertchannel_cleared": "✅ Destino de alertas borrado (las alertas se enviarán en este grupo/canal de log).",
    "alerts_empty": "Todavía no hay alertas registradas.",
    "alerts_header": "🔔 Alertas recientes:",
    "alert_type_multi_reports": "Reportes múltiples",
    "alert_type_suspicious": "Actividad sospechosa",
    "alert_type_security": "Evento de seguridad",
    "alert_type_abnormal": "Comportamiento anómalo",
    "alert_type_admin_abuse": "Posible abuso de administrador",
    "admin_abuse_alert_detail": "🧑‍💼 {name} realizó {count} acciones destructivas (ban/mute/kick/advertencia) en los últimos {minutes} minutos — su cuenta podría estar comprometida o podría ser un abuso intencional. Revísalo.",
    "alert_type_raid": "Raid detectado",
    "alert_type_generic": "Alerta",

    # Priority 5, Item 28 — Import / Export Settings
    "exportsettings_caption": "📦 Exportación de la configuración del grupo.\n{summary}",
    "importsettings_usage": "Responde a un archivo .json de configuración con /importsettings.",
    "importsettings_invalid_json": "❌ No se pudo leer este archivo como JSON válido.",
    "importsettings_invalid_schema": "❌ Archivo de configuración inválido (problema: {detail}).",
    "importsettings_confirm_prompt": "⚠️ Esto *reemplazará* la configuración actual del grupo por:\n{summary}\n¿Estás seguro?",
    "importsettings_cancelled": "❌ Importación cancelada.",
    "importsettings_done": "✅ Configuración importada correctamente.\n{summary}",
    "btn_import_confirm": "✅ Confirmar importación",
    "btn_import_cancel": "❌ Cancelar",

    # Panel personal de administración
    "panel_header": "🛠 Panel de administración de {name}\n\nElige una sección:",
    "panel_btn_settings": "⚙️ Ajustes",
    "panel_btn_locks": "🔒 Bloqueos",
    "panel_btn_filters": "🚫 Filtros",
    "panel_btn_rules": "📜 Reglas",
    "panel_btn_reports": "🚩 Reportes abiertos",
    "panel_btn_logs": "🗒 Registro",
    "panel_btn_roles": "👮 Moderadores",
    "panel_btn_daily": "🔔 Notificación diaria",
    "panel_daily_hint": "Para cambiar la configuración: /dailynotify",
    "panel_btn_back": "🔙 Volver",
    "panel_btn_close": "❌ Cerrar",
    "panel_not_yours": "Este panel pertenece solo a quien lo abrió.",
    "panel_closed": "Panel cerrado.",

    "ai_panel_header": "🤖 NEXOR Copilot\nEl asistente de IA de tus administradores — elige una sección:",
    "ai_btn_analyze": "🔍 Analizar mensaje",
    "ai_btn_explain": "❓ Explicar acción",
    "ai_btn_health": "📊 Salud del grupo",
    "ai_btn_reports": "🗂 Revisar reportes",
    "ai_btn_optimize": "🛠 Optimizar reglas",
    "ai_btn_incident": "🚨 Analizar incidente",
    "ai_btn_rule": "➕ Asesor de reglas",
    "ai_btn_close": "❌ Cerrar",
    "ai_working": "⏳ Analizando con IA...",
    "ai_guide_analyze": "🔍 Analizar mensaje\nResponde al mensaje que quieras revisar y envía:\naicheck",
    "ai_guide_explain": "❓ Explicar acción\nEjemplo:\naiexplain @usuario ¿por qué se advirtió a este usuario?\n(o responde al mensaje del usuario y envía aiexplain)",
    "ai_guide_rule": "➕ Asesor de reglas\nDescribe tu problema, por ejemplo:\nairule estamos recibiendo mucho spam publicitario",
    "ai_need_reply": "Responde a un mensaje para ejecutar Analizar mensaje.",
    "ai_explain_usage": "No se encontró al usuario objetivo. Responde a su mensaje o envía:\naiexplain @usuario [pregunta]",
    "ai_explain_default_question": "¿Por qué se tomó recientemente una acción de moderación contra {name}?",
    "ai_rule_usage": "Describe el problema, por ejemplo:\nairule estamos recibiendo mucho spam publicitario",
    "ai_reports_empty_for_ai": "No hay reportes abiertos para analizar.",
    "ai_optimize_empty": "No hay Reglas de Acción Automática para revisar.",
    "ai_incident_empty": "No se encontró actividad reciente notable para analizar.",
    "ai_rule_not_applicable": "⚠️ Esto no es algo que el motor de reglas actual de NEXOR pueda cubrir; intenta una descripción más específica, o añade una regla manualmente con addautoaction.",
    "ai_rule_cancelled": "Cancelado; no se creó ninguna regla.",
    "ai_rule_created": "✅ Regla #{id} creada.\nDisparador: {condition}\nAcción: {action}",
    "ai_dismissed": "Descartado; no se tomó ninguna acción en el grupo.",
    "ai_reason_copilot": "Sugerencia de NEXOR Copilot (aprobado por un admin)",
    "ai_action_done_delwarn": "🗑️ Mensaje eliminado y {name} recibió una advertencia.",
    "ai_plan_status": "Plan de IA actual de este grupo: {plan}",
    "ai_plan_set_done": "✅ El plan de IA de este grupo se estableció en \"{plan}\".",
    "ai_plan_set_invalid": "Plan inválido. Usa uno de: free, pro, premium",
    "ai_err_plan_not_allowed": "⛔️ Esta función no está disponible en el plan actual de este grupo.",
    "ai_err_rate_limited": "⏳ Se agotó tu límite diario de solicitudes de IA; inténtalo mañana.",
    "ai_err_not_configured": "⚙️ La IA aún no está configurada para el plan de este grupo (avisa al administrador del bot).",
    "ai_err_provider_error": "⚠️ No se pudo contactar al servicio de IA; inténtalo de nuevo en un momento.",
    "ai_err_bad_response": "⚠️ No se pudo entender la respuesta de la IA; inténtalo de nuevo.",
    "ai_err_unknown": "⚠️ Error inesperado de NEXOR Copilot; ha sido registrado.",
    "ai_err_action_failed": "⚠️ No se pudo ejecutar la acción.",
    "ai_risk_low": "Bajo",
    "ai_risk_medium": "Medio",
    "ai_risk_high": "Alto",
    "ai_priority_high": "Prioridad alta",
    "ai_priority_suspicious": "Sospechoso",
    "ai_priority_low": "Prioridad baja",
    "ai_priority_false": "Probable reporte falso",
    "ai_action_none": "Sin acción",
    "ai_action_delete": "Eliminar mensaje",
    "ai_action_warn": "Advertir",
    "ai_action_delete_warn": "Eliminar + advertir",
    "ai_action_mute": "Silenciar",
    "ai_action_ban": "Banear",
    "ai_trend_up": "Subiendo 📈",
    "ai_trend_down": "Bajando 📉",
    "ai_trend_stable": "Estable ➖",
    "ai_btn_apply_delwarn": "🗑️+⚠️ Eliminar y advertir",
    "ai_btn_apply_mute": "🔇 Silenciar",
    "ai_btn_apply_ban": "🚫 Banear",
    "ai_btn_dismiss": "Descartar",
    "ai_btn_confirm": "✅ Confirmar y crear",
    "ai_btn_cancel": "❌ Cancelar",
    "ai_analyze_message_result": "🤖 Análisis de NEXOR Copilot\n\nRiesgo: {risk}\nSpam: {spam}%\nPublicidad: {ad}%\nSospechoso: {suspicious}%\nTóxico: {toxic}%\n\nResumen: {summary}\n\n💡 Recomendación: {action}\nMotivo: {reason}\n\nLa decisión final es tuya:",
    "ai_explain_result": "🤖 Explicación de NEXOR Copilot\n\n{explanation}\n\nFactores clave:\n{factors}",
    "ai_reports_header": "🗂 Reportes abiertos, categorizados:",
    "ai_reports_item": "• #{id} — {priority}: {reason}",
    "ai_reports_summary": "\nResumen: {summary}",
    "ai_health_result": "📊 Salud del grupo\n\nNivel de spam: {spam_level}\nTendencia de infracciones: {trend}\n\nRiesgos:\n{risks}\n\n💡 Recomendación: {recommendation}",
    "ai_rule_advisor_result": "➕ Sugerencia del Asesor de reglas\n\nDisparador: {trigger}\nAcción: {action}\nAlcance: {scope}\nMotivo: {reason}\nConfianza: {confidence}%\n\nConfirma para crear esta regla:",
    "ai_optimize_result": "🛠 Resultado de optimización de reglas\n\nDuplicados: {duplicates}\nConflictos: {conflicts}\nSe disparan con demasiada frecuencia: {too_frequent}\nConfiguraciones peligrosas: {dangerous}\n\nSugerencias:\n{suggestions}",
    "ai_incident_result": "🚨 Resumen del incidente\n\n{summary}\n\nGravedad: {severity}\n\nCronología:\n{timeline}\n\n💡 Recomendación: {recommendation}",
    "ai_local_summary_safe": "Mensaje corto sin señales de riesgo; clasificado localmente como riesgo bajo.",
    "ai_local_reason_no_ai_needed": "No fue necesaria una revisión de IA.",

    # ==================== Guide Panel ====================
    "guide_intro": "📖 Guía de NEXOR\nToca una sección para ver qué hace — luego toca cualquier palabra debajo para ver lo que realmente escribirías en el chat en vez de un comando.",
    "guide_btn_locks": "🔒 Bloqueos y Filtros",
    "guide_btn_moderation": "🛡 Moderación y Sanciones",
    "guide_btn_roles": "👮 Ascender / Degradar",
    "guide_btn_settings": "⚙️ Ajustes del Grupo",
    "guide_btn_security": "🚨 Anti-Raid y Bloqueo Total",
    "guide_btn_rules": "📜 Reglas del Grupo",
    "guide_btn_autoreply": "💬 Palabras Clave y Comandos",
    "guide_btn_channel": "📢 Canal y Publicaciones",
    "guide_btn_autoactions": "🤖 Acciones Automáticas",
    "guide_btn_notes": "📝 Notas",
    "guide_btn_reports_logs": "🚩 Reportes y Registro",
    "guide_btn_federation": "🌐 Federación",
    "guide_btn_ai_copilot": "🧠 NEXOR Copilot (IA)",
    "guide_title_locks": "🔒 Bloqueos y Filtros",
    "guide_title_moderation": "🛡 Moderación y Sanciones",
    "guide_title_roles": "👮 Ascender / Degradar",
    "guide_title_settings": "⚙️ Ajustes del Grupo",
    "guide_title_security": "🚨 Anti-Raid y Bloqueo Total",
    "guide_title_rules": "📜 Reglas del Grupo",
    "guide_title_autoreply": "💬 Palabras Clave y Comandos",
    "guide_title_channel": "📢 Canal y Publicaciones",
    "guide_title_autoactions": "🤖 Acciones Automáticas",
    "guide_title_notes": "📝 Notas",
    "guide_title_reports_logs": "🚩 Reportes y Registro",
    "guide_title_federation": "🌐 Federación",
    "guide_title_ai_copilot": "🧠 NEXOR Copilot (IA)",
    "guide_desc_locks": "Bloquea contenido riesgoso —enlaces, fotos, stickers, reenvíos y más— para que se borre al instante. Agrega filtros de palabras o dominios para todo lo demás que quieras eliminar automáticamente.",
    "guide_desc_moderation": "Advierte, silencia, expulsa o banea a quien cause problemas, borra un mensaje o limpia un rango completo de una vez — el kit completo para mantener el chat en orden.",
    "guide_desc_roles": "Asciende a miembros de confianza a moderador interno, degrádalos después y ve de un vistazo quién tiene cada rol o permiso.",
    "guide_desc_settings": "Una sola pantalla con todo sobre este grupo —bloqueos, filtros, captcha, advertencias, idioma— además de acceso rápido al panel de administración.",
    "guide_desc_security": "La detección automática de raids capta oleadas repentinas de ingresos; el bloqueo total cierra todo el grupo con un solo toque cuando la cosa se complica.",
    "guide_desc_rules": "Escribe las reglas del grupo una vez, muéstralas a quien las pida, o bórralas por completo y empieza de nuevo.",
    "guide_desc_autoreply": "Enseña al bot a responder solo ciertas palabras, o crea tus propios comandos de texto totalmente nuevos.",
    "guide_desc_channel": "Vincula un canal a tu grupo, publica o programa posts, edítalos o elimínalos después y sigue las estadísticas del canal.",
    "guide_desc_autoactions": "Reglas simples de \"si pasa esto, haz aquello\" — el bot reacciona solo según el tipo de mensaje o el número de advertencias.",
    "guide_desc_notes": "Guarda un texto o archivo una vez y recupéralo al instante con una etiqueta corta cuando lo necesites.",
    "guide_desc_reports_logs": "Los miembros reportan problemas con un toque; tú obtienes un registro completo de cada acción de cualquier admin.",
    "guide_desc_federation": "Una sola lista de baneados compartida entre varios grupos — banea a alguien una vez y quedará baneado en toda la federación.",
    "guide_desc_ai_copilot": "Un asistente de IA hecho para admins: analiza mensajes, explica acciones pasadas y sugiere nuevas reglas.",
    "guide_kw_lock": "Bloquea un tipo de contenido (p. ej. enlaces, fotos) para que se borre solo.",
    "guide_kw_unlock": "Quita un bloqueo activo.",
    "guide_kw_locks": "Muestra todos los bloqueos activos en este grupo.",
    "guide_kw_filter": "Agrega una palabra o frase prohibida que se borra sola.",
    "guide_kw_stopfilter": "Quita un filtro de palabra.",
    "guide_kw_filters": "Lista todos los filtros de palabras activos.",
    "guide_kw_domains": "Muestra o administra la lista de dominios bloqueados.",
    "guide_kw_forwardrules": "Muestra las reglas de permitir/bloquear reenvíos.",
    "guide_kw_warn": "Da una advertencia a un miembro.",
    "guide_kw_unwarn": "Quita una advertencia a un miembro.",
    "guide_kw_warns": "Muestra cuántas advertencias tiene un miembro.",
    "guide_kw_mute": "Silencia a un miembro por un tiempo determinado.",
    "guide_kw_unmute": "Levanta el silencio de un miembro.",
    "guide_kw_ban": "Elimina a un miembro del grupo de forma permanente.",
    "guide_kw_unban": "Permite que un miembro baneado regrese.",
    "guide_kw_kick": "Expulsa a un miembro (puede volver a entrar).",
    "guide_kw_del": "Borra un mensaje — respóndelo primero.",
    "guide_kw_purge": "Borra en bloque todo un rango de mensajes.",
    "guide_kw_promote": "Asciende a un miembro a moderador interno.",
    "guide_kw_demote": "Quita el rol de moderador interno a un miembro.",
    "guide_kw_roles": "Lista a todos con rol de moderador interno.",
    "guide_kw_profiles": "Administra perfiles de permisos personalizados.",
    "guide_kw_myperms": "Muestra tus permisos actuales.",
    "guide_kw_settings": "Resumen de todos los ajustes de este grupo.",
    "guide_kw_setlang": "Cambia el idioma del grupo.",
    "guide_kw_captcha": "Activa o desactiva el captcha para nuevos miembros.",
    "guide_kw_goodbye": "Activa o desactiva el mensaje de despedida.",
    "guide_kw_adminpanel": "Abre el panel de accesos rápidos de admin.",
    "guide_kw_antiraid": "Activa o desactiva la detección automática de raids.",
    "guide_kw_lockdown": "Bloquea todo el grupo al instante.",
    "guide_kw_unlockchat": "Levanta un bloqueo total activo.",
    "guide_kw_rules": "Muestra las reglas del grupo.",
    "guide_kw_setrules": "Escribe o actualiza las reglas del grupo.",
    "guide_kw_clearrules": "Borra las reglas del grupo.",
    "guide_kw_addkeyword": "Agrega una palabra que dispare una respuesta automática.",
    "guide_kw_delkeyword": "Quita una palabra clave de respuesta automática.",
    "guide_kw_keywords": "Lista todas las palabras clave de respuesta automática.",
    "guide_kw_addcmd": "Crea tu propio comando de texto personalizado.",
    "guide_kw_delcmd": "Borra un comando personalizado.",
    "guide_kw_cmds": "Lista todos los comandos personalizados.",
    "guide_kw_setanswer": "Configura una respuesta automática (texto/medios, hasta 20 respuestas aleatorias) para una palabra clave.",
    "guide_kw_answerlist": "Muestra la lista de respuestas automáticas configuradas.",
    "guide_kw_delanswer": "Quita una respuesta automática por su palabra clave.",
    "guide_kw_cleananswerlist": "Borra todas las respuestas automáticas de este grupo.",
    "guide_kw_setchannel": "Vincula un canal a este grupo.",
    "guide_kw_post": "Publica un post en el canal vinculado.",
    "guide_kw_schedulepost": "Programa un post para más tarde.",
    "guide_kw_editpost": "Edita un post ya publicado.",
    "guide_kw_delpost": "Borra un post publicado.",
    "guide_kw_channelstats": "Muestra las estadísticas del canal vinculado.",
    "guide_kw_addautoaction": "Crea una regla automática de \"si... entonces...\".",
    "guide_kw_delautoaction": "Quita una regla automática.",
    "guide_kw_autoactions": "Lista todas las reglas automáticas.",
    "guide_kw_save": "Guarda una nota o fragmento reutilizable.",
    "guide_kw_get": "Recupera una nota guardada por su nombre.",
    "guide_kw_notes": "Lista todas las notas guardadas.",
    "guide_kw_clear": "Borra una nota guardada.",
    "guide_kw_report": "Reporta un mensaje a los admins.",
    "guide_kw_reports": "Muestra los reportes abiertos sin resolver.",
    "guide_kw_alerts": "Administra a dónde se envían las alertas de admin.",
    "guide_kw_adminabuseprotection": "Te avisa si un administrador realiza de repente muchas acciones destructivas.",
    "guide_kw_logs": "Muestra las acciones más recientes de los admins.",
    "guide_kw_exportsettings": "Exporta los ajustes de este grupo como respaldo.",
    "guide_kw_setlogchannel": "Define el canal que recibirá el registro de auditoría.",
    "guide_kw_fnew": "Crea una nueva federación (lista de baneados compartida).",
    "guide_kw_fjoin": "Une este grupo a una federación existente.",
    "guide_kw_fleave": "Abandona la federación actual.",
    "guide_kw_finfo": "Muestra información sobre la federación actual.",
    "guide_kw_fban": "Banea a un usuario en toda la federación.",
    "guide_kw_funban": "Quita el baneo de un usuario en toda la federación.",
    "guide_kw_copilot": "Abre el menú del asistente de IA NEXOR Copilot.",
    "guide_kw_aicheck": "Pide a la IA analizar un mensaje — respóndelo primero.",
    "guide_kw_aiexplain": "Pregunta a la IA por qué se tomó una acción contra alguien.",
    "guide_kw_aireports": "Deja que la IA clasifique los reportes abiertos por prioridad.",
    "guide_kw_aihealth": "Obtén un resumen de la IA sobre la salud del grupo.",
    "guide_kw_airule": "Describe un problema y obtén una regla sugerida por la IA.",
    "guide_kw_aioptimize": "Pide a la IA que revise tus reglas automáticas.",
    "guide_kw_aiincident": "Obtén un resumen de la IA de un incidente reciente.",
    "guide_kw_aiplan": "Muestra o define el plan de IA de este grupo.",

    # --- Capa de Lenguaje Natural (basada en intención) — nlu/ ---
    "nlu_confirm_mute": "¿Silenciar a {name} durante {duration}?",
    "nlu_btn_confirm": "✅ Confirmar",
    "nlu_btn_cancel": "❌ Cancelar",
    "nlu_ask_duration": "¿Por cuánto tiempo silencio a {name}? (ej: 30m, 2h, 1d)",
    "nlu_context_expired": "⌛️ Esta solicitud caducó. Intenta de nuevo.",
    "nlu_not_your_confirmation": "Este botón no es para tu solicitud.",
    "nlu_need_reply_target": "❗️Responde al mensaje de ese usuario para saber a quién te refieres.",
    "nlu_fallback_intro": "🤔 No entendí bien. Prueba con /help o sé más directo.",
    "nlu_confirm_unmute": "¿Quitar el silencio a {name}?",
    "nlu_confirm_ban": "¿Banear a {name} durante {duration}?",
    "nlu_confirm_unban": "¿Desbanear a {name}?",
    "nlu_confirm_kick": "¿Expulsar a {name} del grupo?",
    "nlu_action_cancelled": "❌ Cancelado; no se hizo nada.",
    "nlu_confirm_delete": "¿Eliminar este mensaje?",
    "nlu_delete_done": "🗑 Mensaje eliminado.",
    "nlu_confirm_setrules": "¿Reemplazar las reglas del grupo con este texto?\n\n{text}",
    "nlu_setrules_format_hint": "Para establecer las reglas así, usa este formato:\n«establecer reglas: texto de la regla» (todo lo que va después de los dos puntos se guarda tal cual).",

    # --- Onboarding (handlers/onboarding.py + onboarding_logic.py) ---
    "onboarding_welcome": "👋 ¡Hola! Soy NEXOR — ayudo a mantener este grupo seguro y organizado: moderación, anti-spam, bienvenida/reglas, respuestas automáticas y más.",
    "onboarding_needs_admin": "⚠️ Todavía no soy administrador aquí, así que la mayoría de las funciones no funcionarán. Hazme administrador (al menos: eliminar mensajes, restringir miembros, invitar usuarios, fijar mensajes) y sigo desde ahí.",
    "onboarding_missing_perms": "⚠️ Soy administrador, pero me faltan: {perms}. Algunas funciones los necesitan — puedes otorgármelos cuando quieras desde la configuración del grupo.",
    "onboarding_all_set": "✅ Tengo los permisos que necesito. Configuremos lo básico.",
    "onboarding_btn_security": "🛡 Configurar seguridad",
    "onboarding_btn_help": "❓ ¿Qué puedes hacer?",
    "perm_restrict": "restringir miembros (silenciar/expulsar/banear)",
    "perm_delete": "eliminar mensajes",
    "perm_invite": "invitar usuarios",
    "perm_pin": "fijar mensajes",
    "err_unexpected": "⚠️ Algo salió mal al hacer eso. Intenta de nuevo — si sigue pasando, avísale a un administrador del grupo.",
    "nlu_delanswer_format_hint": "Para eliminar una respuesta automática así, usa este formato:\n«quitar respuesta automática: palabra clave» (la palabra clave exacta a eliminar).",
    "nlu_confirm_delanswer": "¿Eliminar la respuesta automática para la palabra clave «{keyword}»?",
    # ---- Ads system (added) ----
    'ads_btn_cancel': '❌ Cancelar',
    'ads_btn_free': '🆓 Publicar anuncio gratis (1 vez al día)',
    'ads_btn_paid': '💳 Comprar publicidad (1 a 5 veces al día)',
    'ads_intro': '📢 Sistema de anuncios de NEXOR\n\nLos anuncios solo se muestran en grupos con el plan gratuito (los grupos Pro/Premium no ven anuncios).\nUn anuncio gratis se muestra una vez al día; uno pagado puede mostrarse de 1 a 5 veces al día (el precio sube en la misma proporción).\n\n¿Cuál prefieres?',
    'ads_ask_banner': '🖼 Primero envía un banner (foto) para el anuncio.\nSi no quieres banner, escribe: omitir',
    'ads_banner_invalid': 'Envía una foto o escribe «omitir» para continuar sin banner.',
    'ads_ask_text': '✍️ Ahora envía el texto del anuncio (lo que se verá dentro de los grupos).',
    'ads_text_empty': 'El texto del anuncio no puede estar vacío. Envíalo de nuevo.',
    'ads_times_btn': '{n}×/día',
    'ads_ask_times': '📅 ¿Cuántas veces al día quieres que se muestre tu anuncio? (cuantas más, más caro)',
    'ads_free_submitted': '✅ El anuncio gratis #{id} fue enviado para revisión del administrador.\nUna vez aprobado, se mostrará una vez al día en los grupos gratuitos conectados al bot.',
    'ads_duration_btn': '{days} días — ⭐{stars}',
    'ads_ask_duration': 'Elige por cuánto tiempo se mostrará el anuncio (frecuencia elegida: {times}×/día):',
    'ads_btn_pay_stars': '⭐ Pagar con Stars ({stars})',
    'ads_btn_pay_ton': '💎 Pagar con TON ({ton})',
    'ads_order_summary': 'Resumen del pedido #{id}:\n• Frecuencia: {times}×/día\n• Duración: {days} días\n• Precio: ⭐{stars}',
    'ads_order_summary_ton_suffix': ' / 💎{ton} TON',
    'ads_order_summary_footer': '\n\nElige el método de pago:',
    'ads_order_invalid': '⚠️ Este pedido ya no es válido.',
    'ads_sending_invoice': '⭐ Enviando la factura de pago con Telegram Stars...',
    'ads_invoice_title': '📢 Compra de anuncio — pedido #{id}',
    'ads_invoice_desc': 'Compra de espacio publicitario dentro de grupos conectados a NEXOR (solo plan gratuito).',
    'ads_invoice_label': 'Anuncios NEXOR',
    'ads_ton_disabled': '⚠️ El pago con TON no está activo ahora mismo, o este pedido no es válido.',
    'ads_ton_payment_info': '💎 Pago con TON — pedido #{id}\n\nMonto: {amount} TON\nDirección de la wallet: {address}\n⚠️ Asegúrate de poner este código exacto en el Comentario/Memo de la transferencia:\n{memo}\n\nEnlace directo: {link}\n\nDespués de la transferencia, se verifica automáticamente y el anuncio pasa a la cola de revisión del administrador.',
    'ads_cancelled': 'Cancelado.',
    'ads_ton_confirmed': '✅ ¡Pago con TON confirmado! El pedido de anuncio #{id} fue enviado para revisión del administrador.',
    'ads_admin_none_pending': 'No hay anuncios esperando revisión.',
    'ads_btn_approve': '✅ Aprobar',
    'ads_btn_reject': '❌ Rechazar',
    'ads_kind_free': '🆓 Gratis',
    'ads_kind_paid': '💳 Comprado',
    'ads_admin_caption': '#{id} — {kind}\nFrecuencia/día: {times} — Duración: {days} días\n\n{text}',
    'ads_approved_toast': 'Aprobado ✅',
    'ads_approved_notify': '✅ El anuncio #{id} fue aprobado y se mostrará en los grupos gratuitos según lo programado.',
    'ads_rejected_toast': 'Rechazado ❌',
    'ads_none_yet': 'Todavía no has publicado ningún anuncio. Empieza con /ads.',
    'ads_status_draft': 'Borrador',
    'ads_status_pending_payment': 'Esperando pago',
    'ads_status_pending_review': 'En revisión',
    'ads_status_active': 'Activo',
    'ads_status_rejected': 'Rechazado',
    'ads_status_expired': 'Vencido',
    'ads_status_active2': '✅ Activo',
    'ads_status_rejected2': '❌ Rechazado',
    'ads_status_expired2': '⌛ Vencido',
    'ads_myads_header': '📋 Tus anuncios:\n',
    'ads_myads_line': '#{id} — {status} — {times}×/día — {days} días',
    'ads_myads_footer': '\nPara ver las estadísticas de un anuncio: /adstats <número de anuncio> — por ejemplo /adstats {id}',
    'ads_stats_usage': 'Incluye también el número del anuncio, por ejemplo:\n/adstats 3\n\nPuedes ver los números de tus anuncios con /myads.',
    'ads_stats_not_found': 'No se encontró ese anuncio, o no es tuyo.',
    'ads_stats_title': '📊 Estadísticas del anuncio #{id}',
    'ads_stats_status': 'Estado: {status}',
    'ads_stats_quota': 'Cuota diaria: {quota}×/día',
    'ads_stats_today': 'Enviado hoy: {today} de {quota}',
    'ads_stats_total': 'Total de vistas (desde el inicio): {total}',
    'ads_stats_unique': 'Cantidad de grupos únicos donde se vio este anuncio: {n}',
    'ads_stats_perday_header': '\nDetalle diario (últimos días):',
    'ads_stats_perday_line': '  {day}: {count} veces',
    'ads_stats_no_views': '\nTodavía no hay vistas registradas para este anuncio (o aún no está aprobado/activo).',
    'ads_stars_confirmed': '✅ ¡Pago confirmado! El pedido de anuncio #{id} fue enviado para revisión del administrador.',
    'err_invalid_language': 'Idioma no válido.',
    # ---- Buyplan payments (added) ----
    'buyplan_invoice_title': '👑 Suscripción {plan} ({months} meses)',
    'buyplan_invoice_desc': 'Actualizar el grupo al plan {plan} por {months} mes(es).',
    'buyplan_invoice_price_label': '{plan} — {months} meses',
    'err_order_invalid': 'Este pedido ya no es válido.',
    'buyplan_stars_confirmed': '✅ ¡Pago confirmado!\n👑 El grupo fue actualizado al plan {plan}.',
    'buyplan_card_order_not_found': '⚠️ No se encontró el pedido, o ya fue procesado.',
    'buyplan_card_confirmed_dm': '✅ ¡Pago con tarjeta confirmado!\n👑 El grupo fue actualizado al plan {plan}.',
    'buyplan_card_admin_confirmed': '✅ Pedido #{id} confirmado y plan {plan} activado.',
    'buyplan_card_admin_rejected': '❌ Pedido #{id} rechazado.',
    'buyplan_card_none_pending': 'No hay pedidos con tarjeta esperando revisión.',
    'buyplan_card_pending_header': '💳 Pedidos con tarjeta pendientes de confirmación:\n',
    'buyplan_card_pending_line': '#{id} — {plan} × {months} meses — código: {code}',
    'buyplan_ton_instructions': '💎 Comprar suscripción {plan} con TON\n\nMonto: {amount} TON\nDirección de la wallet: {address}\n⚠️ Asegúrate de poner este código exacto en el Comentario/Memo de la transferencia:\n{memo}\n\nO usa este enlace en tu wallet:\n{link}\n\nUna vez recibida, la transacción se verifica automáticamente y la suscripción se activa (puede tardar unos minutos).',
    'buyplan_ton_confirmed': '✅ ¡Pago con TON confirmado!\n👑 El grupo fue actualizado al plan {plan}.',
    'buyplan_card_header': '💳 Comprar suscripción {plan} por transferencia bancaria\n',
    'buyplan_card_amount': 'Monto: {amount} tomans',
    'buyplan_card_number': 'Número de tarjeta: {number}',
    'buyplan_card_holder': 'A nombre de: {holder}',
    'buyplan_card_reference': '\nCódigo de seguimiento del pedido: {ref}',
    'buyplan_card_instructions': 'Después de transferir, envía una foto del comprobante junto con el código de seguimiento anterior al administrador del bot para que tu suscripción se confirme y active manualmente.',
    'buyplan_header': '👑 Mejora tu plan de NEXOR Copilot\nElige un plan:',
    'buyplan_choose_method': 'Plan {plan} — elige un método de pago:',
    'buyplan_closed': 'Cerrado.',
    'buyplan_dm_failed': '⚠️ No pude enviarte un mensaje privado. Primero inicia un chat privado con el bot usando /start, luego intenta /buyplan de nuevo.',
    'buyplan_stars_sent': '⭐ Se envió una factura de pago con Stars a tu chat privado con el bot. Completa el pago ahí.',
    'buyplan_ton_sent': '💎 Las instrucciones de pago con TON (dirección de wallet + código memo) se enviaron a tu chat privado con el bot.',
    'buyplan_ton_unavailable': '⚠️ El pago con TON no está disponible ahora mismo para este plan.',
    # ---- Command menu descriptions (added) ----
    'cmd_desc_start': 'Empezar a usar el bot',
    'cmd_desc_help': 'Guía de comandos',
    'cmd_desc_settings': 'Configuración del grupo',
    'cmd_desc_setlang': 'Cambiar el idioma del grupo (admin)',
    'cmd_desc_rules': 'Reglas del grupo',
    'cmd_desc_warn': 'Advertir a un usuario',
    'cmd_desc_unwarn': 'Quitar una advertencia',
    'cmd_desc_warns': 'Ver advertencias de un usuario',
    'cmd_desc_mute': 'Silenciar a un usuario',
    'cmd_desc_unmute': 'Quitar el silencio',
    'cmd_desc_ban': 'Banear a un usuario',
    'cmd_desc_unban': 'Quitar el baneo',
    'cmd_desc_kick': 'Expulsar a un usuario',
    'cmd_desc_del': 'Eliminar un mensaje (respondiendo)',
    'cmd_desc_purge': 'Eliminar mensajes en masa',
    'cmd_desc_lock': 'Bloquear un tipo de contenido',
    'cmd_desc_unlock': 'Desbloquear',
    'cmd_desc_locks': 'Ver bloqueos activos',
    'cmd_desc_promote': 'Ascender a admin interno',
    'cmd_desc_demote': 'Quitar de admin interno',
    'cmd_desc_roles': 'Listar admins internos',
    'cmd_desc_logs': 'Acciones recientes de admins',
    'cmd_desc_copilot': '🤖 NEXOR Copilot (asistente de IA para admins)',
    'cmd_desc_buyplan': '👑 Mejorar el plan (Stars / TON) — sin anuncios',
    'cmd_desc_ads': '📢 Publicar un anuncio gratis o comprar publicidad',
    'cmd_desc_myads': '📋 Mis anuncios',
    'cmd_desc_adstats': '📊 Estadísticas de un anuncio',
    'cmd_desc_adadmin': '🛠 Cola de revisión de anuncios (admin)',

    # ==================== Notificación diaria (Daily Notify) ====================
    "day_mon": "Lunes", "day_tue": "Martes", "day_wed": "Miércoles", "day_thu": "Jueves",
    "day_fri": "Viernes", "day_sat": "Sábado", "day_sun": "Domingo",
    "month_g_1": "Enero", "month_g_2": "Febrero", "month_g_3": "Marzo", "month_g_4": "Abril",
    "month_g_5": "Mayo", "month_g_6": "Junio", "month_g_7": "Julio", "month_g_8": "Agosto",
    "month_g_9": "Septiembre", "month_g_10": "Octubre", "month_g_11": "Noviembre", "month_g_12": "Diciembre",
    "month_j_1": "Farvardin", "month_j_2": "Ordibehesht", "month_j_3": "Khordad", "month_j_4": "Tir",
    "month_j_5": "Mordad", "month_j_6": "Shahrivar", "month_j_7": "Mehr", "month_j_8": "Aban",
    "month_j_9": "Azar", "month_j_10": "Dey", "month_j_11": "Bahman", "month_j_12": "Esfand",
    "date_format_gregorian": "{weekday}, {day} de {month} de {year}",
    "date_format_jalali": "{weekday}, {day} de {month} de {year}",

    "daily_date_line": "📅 Hoy: {date}",
    "daily_occasion_line": "🎉 Fecha especial: {occasion}",

    "daily_price_header": "💰 Precios de hoy",
    "daily_price_line": "• {asset}: {value} {unit}",
    "daily_price_footer": "Fuente: {sources}",

    "daily_news_header": "📰 Noticias de hoy",
    "daily_news_item": "{n}. {title}",
    "daily_news_summary": "   {summary}",
    "daily_news_source": "   🔗 Fuente: {source}",

    "asset_gold18": "Oro de 18 quilates", "asset_usd": "Dólar estadounidense (USD)", "asset_eur": "Euro (EUR)",
    "asset_usdt": "Tether (USDT)", "asset_ton": "Toncoin (TON)", "asset_stars": "Telegram Stars",
    "asset_btc": "Bitcoin (BTC)", "asset_eth": "Ethereum (ETH)",
    "unit_toman": "toman", "unit_usd": "USD",

    "panel_not_owner": "Este panel solo responde a quien lo abrió.",

    "dn_menu_header": "🔔 *Notificación diaria*",
    "dn_menu_prices": "💰 Precios: {state} — a las {time}",
    "dn_menu_assets_line": "   Activos activados: {assets}",
    "dn_menu_news": "📰 Noticias: {state} — a las {time}",
    "dn_menu_timezone": "🌍 Zona horaria: {tz}",
    "dn_menu_date_flags": "📅 Fecha/ocasión — Precios: {dp}/{op}   Noticias: {dn}/{on}",

    "dn_btn_toggle_prices": "💰 Act./desact. precios",
    "dn_btn_toggle_news": "📰 Act./desact. noticias",
    "dn_btn_assets": "🪙 Elegir activos",
    "dn_btn_flags": "📅 Ajustes de fecha/ocasión",
    "dn_btn_test_price": "🧪 Probar precios",
    "dn_btn_test_news": "🧪 Probar noticias",
    "dn_btn_help": "❓ Ayuda",
    "dn_btn_close": "❌ Cerrar",

    "dn_assets_header": "🪙 Toca un activo para activarlo/desactivarlo:",
    "dn_flags_header": "📅 Configura la fecha/ocasión de forma independiente para precios y noticias:",
    "dn_flag_date_price": "Fecha en el mensaje de precios",
    "dn_flag_occasion_price": "Ocasión en el mensaje de precios",
    "dn_flag_date_news": "Fecha en el mensaje de noticias",
    "dn_flag_occasion_news": "Ocasión en el mensaje de noticias",

    "dn_help_text": (
        "📖 *Ayuda de notificación diaria*\n\n"
        "💰 Los precios y las 📰 noticias se envían a este grupo cada día a la hora que definas.\n\n"
        "/setpricetime HH:MM — hora de envío de precios\n"
        "/setnewstime HH:MM — hora de envío de noticias\n"
        "/setdailytz zona_horaria — p. ej. Asia/Tehran (por defecto según el idioma del grupo)\n"
        "/testdailyprice   /testdailynews — enviar un mensaje de prueba ahora\n"
        "/dailyassets — elegir qué activos se muestran\n"
        "Todo lo demás (activar/desactivar, fecha/ocasión) se cambia con los botones de arriba."
    ),
    "dn_toast_saved": "✅ Guardado.",
    "dn_toast_sending": "⏳ Enviando...",
    "dn_test_no_data": "⚠️ No hay datos válidos en este momento (proveedor no disponible o aún no hay contenido nuevo).",

    "dn_log_toggle_prices": "Notificación diaria de precios: {state}",
    "dn_log_toggle_news": "Notificación diaria de noticias: {state}",
    "dn_log_settime": "Hora de envío de {what}: {time}",
    "dn_log_settz": "Zona horaria de notificación diaria: {tz}",

    "dn_settime_usage": "Uso: {cmd} HH:MM (p. ej. 09:00)",
    "dn_settime_invalid": "⛔️ Formato de hora inválido. Usa HH:MM (p. ej. 09:00).",
    "dn_settime_done": "✅ Hora de envío establecida en {time}.",
    "dn_settz_usage": "Uso: /setdailytz zona_horaria (p. ej. Asia/Tehran)",
    "dn_settz_invalid": "⛔️ Zona horaria inválida. Ingresa una zona horaria IANA válida como Asia/Tehran.",
    "dn_settz_done": "✅ Zona horaria del grupo: {tz}",

    "cmd_desc_dailynotify": "🔔 Ajustes de notificación diaria (precios/noticias)",
}


# ---------------------------------------------------------------------------
# TEXT_TRIGGERS (Español) — کلمه/عبارتی که کاربر به‌جای دستور "/" تایپ می‌کند
# تا با همون تابع handlers/text_commands.py وصل بشه. هر شناسه (کلید) دقیقاً
# با همون نامی که در handlers/text_commands.py::COMMANDS استفاده شده باید یکی باشه.
# ---------------------------------------------------------------------------
TEXT_TRIGGERS = {
    "help": ["ayuda"],
    "settings": ["ajustes"],
    "warn": ["advertencia"],
    "unwarn": ["quitar advertencia"],
    "warns": ["advertencias"],
    "mute": ["silenciar"],
    "unmute": ["quitar silencio"],
    "ban": ["banear"],
    "unban": ["desbanear"],
    "kick": ["expulsar"],
    "del": ["borrar"],
    "purge": ["purgar"],
    "promote": ["ascender"],
    "demote": ["degradar"],
    "roles": ["moderadores"],
    "logs": ["registro"],
    "setlang": ["cambiar idioma"],
    "lock": ["bloquear"],
    "unlock": ["desbloquear"],
    "locks": ["bloqueos"],
    "filter": ["filtro"],
    "stopfilter": ["quitar filtro"],
    "filters": ["filtros"],
    "domains": ["dominios bloqueados"],
    "forwardrules": ["reglas de reenvío"],
    "antiraid": ["antiraid"],
    "lockdown": ["bloqueo total"],
    "unlockchat": ["abrir grupo"],
    "captcha": ["captcha"],
    "goodbye": ["despedida"],
    "rules": ["reglas"],
    "setrules": ["establecer reglas"],
    "clearrules": ["borrar reglas"],
    "addkeyword": ["agregar palabra clave"],
    "delkeyword": ["quitar palabra clave"],
    "keywords": ["palabras clave"],
    "setanswer": ["configurar respuesta automática"],
    "answerlist": ["lista de respuestas automáticas"],
    "cleananswerlist": ["limpiar lista de respuestas automáticas"],
    "delanswer": ["quitar respuesta automática"],
    "addcmd": ["agregar comando"],
    "delcmd": ["quitar comando"],
    "cmds": ["comandos"],
    "setchannel": ["establecer canal"],
    "post": ["publicar"],
    "schedulepost": ["programar publicación"],
    "editpost": ["editar publicación"],
    "delpost": ["eliminar publicación"],
    "channelstats": ["estadísticas del canal"],
    "addautoaction": ["agregar acción automática"],
    "delautoaction": ["quitar acción automática"],
    "autoactions": ["acciones automáticas"],
    "profiles": ["perfiles"],
    "myperms": ["mis permisos"],
    "report": ["reportar"],
    "reports": ["reportes"],
    "alerts": ["alertas"],
    "exportsettings": ["exportar ajustes"],
    "save": ["guardar"],
    "get": ["obtener"],
    "notes": ["notas"],
    "clear": ["borrar nota"],
    "setlogchannel": ["establecer canal de registro"],
    "fnew": ["nueva federación"],
    "fjoin": ["unirse a federación"],
    "fleave": ["salir de federación"],
    "finfo": ["información de federación"],
    "adminpanel": ["admin", "panel"],
    "fban": ["baneo de federación"],
    "funban": ["desbaneo de federación"],
    "copilot": ["asistente", "asistente ia", "copiloto"],
    "aicheck": ["revisión ia"],
    "aiexplain": ["explicar acción"],
    "aireports": ["analizar reportes"],
    "aihealth": ["salud del grupo"],
    "airule": ["asesor de reglas"],
    "aioptimize": ["optimizar reglas"],
    "aiincident": ["analizar incidente"],
    "aiplan": ["plan de ia"],
    # ==================== Phase 3 migration additions ====================
    "allowword": ["permitir palabra"],
    "disallowword": ["prohibir palabra"],
    "blockdomain": ["bloquear dominio"],
    "unblockdomain": ["desbloquear dominio"],
    "allowdomain": ["permitir dominio"],
    "unallowdomain": ["revocar dominio"],
    "allowforward": ["permitir reenvío"],
    "blockforward": ["bloquear reenvío"],
    "unruleforward": ["quitar regla de reenvío"],
    "setfilteraction": ["configurar acción de filtro"],
    "mentionprotection": ["protección de menciones"],
    "setmentionlimit": ["establecer límite de menciones"],
    "setmentionaction": ["configurar acción de mención"],
    "antispam": ["antispam"],
    "setspamaction": ["configurar acción de spam"],
    "dupcross": ["duplicado entre grupos"],
    "setdupcross": ["configurar duplicado entre grupos"],
    "setflood": ["configurar flood"],
    "setfloodaction": ["configurar acción de flood"],
    "setraidthreshold": ["establecer umbral de raid"],
    "setmaxwarns": ["establecer máx. de avisos"],
    "setwarnaction": ["configurar acción de aviso"],
    "setwelcomedelete": ["configurar borrado de bienvenida"],
    "setgoodbye": ["configurar despedida"],
    "resetgoodbye": ["restablecer despedida"],
    "createprofile": ["crear perfil"],
    "delprofile": ["eliminar perfil"],
    "assignprofile": ["asignar perfil"],
    "unassignprofile": ["desasignar perfil"],
    "setalertchannel": ["configurar canal de alertas"],
    "importsettings": ["importar configuración"],
    "schedulerecurring": ["programar publicación recurrente"],
    "recurringposts": ["publicaciones recurrentes"],
    "delrecurring": ["eliminar publicación recurrente"],
    "autoactiontoggle": ["alternar acción automática"],
    "dailynotify": ["notificación diaria"],
    "setpricetime": ["configurar hora de precio"],
    "setnewstime": ["configurar hora de noticias"],
    "setdailytz": ["configurar zona horaria diaria"],
    "testdailyprice": ["probar precio diario"],
    "testdailynews": ["probar noticias diarias"],
    "dailyassets": ["activos diarios"],
    "ads": ["anuncios"],
    "myads": ["mis anuncios"],
    "adadmin": ["administrar anuncios"],
    "adstats": ["estadísticas de anuncios"],
    "buyplan": ["comprar plan"],
}
