# -*- coding: utf-8 -*-
STRINGS = {
    "rank_user": "Пользователь",
    "rank_moderator": "Модератор",
    "rank_admin": "Админ",
    "rank_owner": "Владелец",

    "err_need_rank": "⛔️ Эта команда требует уровень доступа «{rank}» или выше.",
    "err_self_action": "Нельзя применить это к самому себе! 😅",
    "err_rank_too_low": "⛔️ У вас недостаточно прав для действия над этим пользователем (у него такой же или более высокий ранг).",
    "err_user_not_found_username": "❌ Не удалось найти этого пользователя (он должен был отправить хотя бы одно сообщение в этой группе, чтобы бот его узнал).",
    "err_need_target": "❗️Целевой пользователь не найден.\nИспользование: {usage}",

    "warn_given": "⚠️ {name} получил предупреждение. ({count}/{max})",
    "warn_reason_line": "\nПричина: {reason}",
    "warn_removed": "➖ Предупреждение снято с {name}. ({count}/{max})",
    "warn_escalate_mute": "🔇 {name} заглушён на {duration} за достижение {max} предупреждений.",
    "warn_escalate_ban": "🚫 {name} забанен за достижение {max} предупреждений.",
    "warns_header": "⚠️ Предупреждения {name}: {count}/{max}",
    "warns_history_line": "• {when} — {reason} (от {actor})",
    "warns_no_reason": "без причины",
    "setwarnaction_usage": "Использование: /setwarnaction mute или /setwarnaction ban",
    "setwarnaction_done": "✅ Действие после достижения лимита предупреждений: {action}",
    "setmaxwarns_usage": "Использование: /setmaxwarns число (например, 3)",
    "setmaxwarns_done": "✅ Лимит предупреждений изменён на {n}.",

    "mute_done": "🔇 {name} заглушён (длительность: {duration}).",
    "unmute_done": "🔊 С {name} снята заглушка.",

    "ban_done": "🚫 {name} забанен (длительность: {duration}).",
    "unban_done": "✅ Бан {name} снят.",
    "duration_permanent": "навсегда",

    "kick_done": "👢 {name} исключён из группы.",

    "del_usage": "Пожалуйста, ответьте на сообщение, которое хотите удалить.",
    "purge_usage": "Использование: ответьте на сообщение командой /purge, или /purge <число>",
    "purge_done": "🧹 Удалено сообщений: {count}.",

    "promote_usage": "Пожалуйста, ответьте на нужного пользователя или укажите @username/ID.",
    "promote_already_admin": "Этот пользователь уже настоящий администратор Telegram; внутренняя роль не нужна.",
    "promote_done": "⭐️ {name} назначен внутренним модератором бота.",
    "demote_done": "⬇️ У {name} снята роль модератора.",
    "roles_empty": "Внутренних модераторов не зарегистрировано. (Для просмотра настоящих админов используйте панель группы Telegram.)",
    "roles_header": "⭐️ Внутренние модераторы этой группы:",
    "logs_empty": "Пока не зафиксировано ни одного действия.",
    "logs_header": "🧾 Последние действия модерации:",

    "btn_remove_warn": "➖ Снять предупреждение",
    "btn_mute": "🔇 Заглушить",
    "btn_ban": "🚫 Бан",
    "modact_invalid_data": "Неверные данные.",
    "modact_wrong_chat": "Эта кнопка не для этого чата.",
    "modact_no_permission": "⛔️ У вас нет прав для этого действия.",
    "modact_done": "Готово ✅",
    "modact_unwarn_result": "➖ {name} — снято одно предупреждение. ({count})",
    "modact_mute_result": "🔇 {name} заглушён на {minutes} минут.",
    "modact_ban_result": "🚫 {name} забанен.",

    "start_msg": (
        "Привет, {mention} 🌹\n\n"
        "🔰 Знакомьтесь — *NEXOR*, самый профессиональный бот для управления группами\n"
        "🔰 Мощный помощник для порядка, безопасности и полного контроля над вашими группами в Telegram\n\n"
        "✨ *Основные возможности:*\n"
        "✅ Полное управление участниками (предупреждение, мут, бан, кик)\n"
        "✅ Умные блокировки контента (ссылки, пересылка, медиа и др.)\n"
        "✅ Продвинутая фильтрация запрещённых слов и фраз\n"
        "✅ Капча при вступлении против нежелательных ботов\n"
        "✅ Продвинутая защита от спама и флуда\n"
        "✅ Защита от рейдов (Anti-Raid)\n"
        "✅ Управление подключённым каналом (публикация, расписание, редактирование, удаление)\n"
        "✅ Система федерации между несколькими группами\n"
        "✅ Встроенные роли, журнал и полная отчётность\n"
        "✅ Многоязычность (персидский, английский, арабский, турецкий, русский, испанский)\n\n"
        "🤖 *NEXOR Copilot — ИИ-помощник вашей группы:*\n"
        "✅ Ответьте на любое подозрительное сообщение — он оценит риск за секунды\n"
        "✅ Спросите «почему?» — и он точно объяснит причину предупреждения/мута/бана\n"
        "✅ Даёт полный отчёт о здоровье группы: где напряжённо, где стоит ужесточить правила\n"
        "✅ Просто опишите проблему своими словами («стало много спама») — он предложит и создаст автоправило\n"
        "✅ Анализирует и расставляет приоритеты по жалобам и недавним инцидентам ещё до вашего решения\n"
        "Попробуйте /copilot! ✨\n"
        "\n"
        "🚀 *Установка:*\n"
        "1. Добавьте бота в свою группу с помощью кнопки ниже\n"
        "2. Выдайте ему полные права администратора для корректной работы\n\n"
        "📌 *Важные заметки:*\n"
        "• Группа должна быть супергруппой\n"
        "• Для лучшей работы рекомендуется выдать полные права администратора\n\n"
        "Используйте /help, чтобы увидеть полный список команд."
    ),
    "add_to_group_button": "➕ Добавить в группу",
    "settings_header": "⚙️ *Текущие настройки группы*",
    "settings_locks": "🔒 Блокировки: {locks}",
    "settings_filters": "🚫 Фильтры: {filters}",
    "settings_captcha": "🛡️ Капча: {state}",
    "settings_warns": "⚠️ Лимит предупреждений: {max} → действие: {action}",
    "settings_channel": "📢 Привязанный канал: {channel}",
    "settings_logchannel": "🧾 Канал логов: {log}",
    "settings_lang": "🌐 Язык: {lang}",
    "none": "нет",
    "not_set": "—",

    "setlang_prompt": "🌐 Выберите язык группы:",
    "setlang_done": "✅ Язык группы изменён на {lang_name}.",

    "welcome_simple": "Добро пожаловать, {mention}, в {chat}! 🌹",
    "welcome_captcha": "Добро пожаловать, {mention}, в {chat}! 🌹\nНажмите на кнопку ниже, чтобы подтвердить, что вы не робот.",
    "welcome_simple_multi": "Добро пожаловать в {chat}: {mentions} 🌹",
    "welcome_captcha_multi": "Добро пожаловать в {chat}: {mentions} 🌹\nКаждый должен нажать кнопку рядом со своим именем для подтверждения.",
    "captcha_btn": "✅ Я не робот",
    "captcha_not_yours": "Эта кнопка не для вас.",
    "captcha_expired": "Срок этой проверки истёк.",
    "captcha_verified_alert": "✅ Подтверждено, добро пожаловать!",
    "captcha_verified_msg": "✅ {name} подтверждён и теперь может писать.",
    "captcha_timeout_msg": "⛔️ Время проверки истекло; пользователь удалён из группы.",
    "captcha_toggle_usage": "Использование: /captcha on или /captcha off",
    "captcha_toggle_done": "🛡️ Капча {state}.",
    "captcha_on": "включена",
    "captcha_off": "отключена",
    "goodbye_msg": "{name} покинул(а) группу. 👋",

    "lock_usage": "Использование: /lock {options}",
    "lock_done": "🔒 {kind} заблокировано.",
    "unlock_usage": "Использование: /unlock {options}",
    "unlock_done": "🔓 {kind} разблокировано.",
    "locks_active": "🔒 Активные блокировки: {locks}",
    "filter_usage": "Использование: /filter слово",
    "filter_added": "➕ Слово «{word}» добавлено в фильтр.",
    "stopfilter_usage": "Использование: /stopfilter слово",
    "filter_removed": "➖ Слово «{word}» удалено из фильтра.",
    "filters_active": "🚫 Активные фильтры: {filters}",
    "flood_muted": "🚨 {name} заглушён на {minutes} минут за слишком частую отправку сообщений.",

    "save_usage": "Использование: /save имя текст (или ответом на сообщение: /save имя)",
    "save_empty": "Текст для сохранения не найден.",
    "save_done": "📝 Заметка «{name}» сохранена. Посмотреть: /get {name} или #{name}.",
    "get_usage": "Использование: /get имя",
    "get_not_found": "Заметка с таким именем не найдена.",
    "notes_empty": "Заметок пока нет.",
    "notes_list_header": "📝 Доступные заметки:",
    "clear_usage": "Использование: /clear имя",
    "clear_done": "🗑️ Заметка «{name}» удалена.",

    "setlogchannel_usage": "Использование: /setlogchannel @channel＿username или числовой ID канала",
    "setlogchannel_error": "❌ Не удалось найти этот канал: {error}",
    "setlogchannel_done": "🧾 Действия администраторов теперь будут логироваться в «{title}».",
    "setlogchannel_channel_confirm": "✅ Этот канал установлен как канал логов управления группой.",

    "fed_new_usage": "Использование: /fnew название＿федерации",
    "fed_new_done": "🌐 Федерация «{name}» создана (ID: {id}).\nЭта группа добавлена как первый участник.\nЧтобы добавить другие группы, выполните там:\n/fjoin {id}",
    "fed_join_usage": "Использование: /fjoin id＿федерации",
    "fed_join_invalid_id": "Неверный ID федерации.",
    "fed_not_found": "Федерация с таким ID не найдена.",
    "fed_join_done": "✅ Эта группа присоединилась к федерации «{name}».",
    "fed_not_member": "Эта группа не состоит ни в одной федерации.",
    "fed_left": "👋 Эта группа покинула федерацию «{name}».",
    "fed_info": "🌐 Федерация: {name}\n🆔 ID: {id}\n👥 Групп-участников: {count}",
    "fed_ban_no_target": "Пожалуйста, ответьте на сообщение нужного пользователя или укажите @username/ID.",
    "fed_ban_not_member": "Эта группа пока не состоит ни в одной федерации. Сначала выполните /fnew или /fjoin.",
    "fed_ban_done": "🚫 {name} забанен по всей федерации «{fed}».\n✅ Успешно: {success} групп | ❌ Неудачно: {failed} групп\nПричина: {reason}",
    "fed_unban_done": "✅ Бан {name} снят в {success} группах федерации «{fed}».",
    "fed_ban_no_reason": "причина не указана",
    "fed_raid_kick_notice": "🚫 {name} был в федеративном бане и был автоматически удалён.",

    "help_text": (
        "📋 *Команды администрирования*\n\n"
        "✨ *Приятный бонус:* необязательно всегда писать со слэшем! У каждой команды есть словесный близнец, который делает ровно то же самое — например, слово «жалоба» работает точно как /report, а слово «помощь» открывает то же самое меню. Это работает на всех 6 языках бота, каждый со своими словами, так что любой участник может командовать ботом на родном языке, не запоминая ни одной команды со слэшем! 🗣️\n\n"
        "👮 *Управление участниками* (ответом, @username или user＿id)\n"
        "/warn [срок] [причина]   /unwarn   /warns — история предупреждений\n"
        "/mute [срок] [причина]   /unmute\n"
        "/ban [срок] [причина]   /unban\n"
        "/kick [причина]\n"
        "Пример: /ban 2h много спама   или   /mute @user 30m\n"
        "/setmaxwarns число   /setwarnaction mute|ban\n\n"
        "🧹 *Удаление сообщений*\n"
        "/del — удалить сообщение, на которое ответили\n"
        "/purge — удалить от отвеченного сообщения до текущего момента (или /purge число)\n\n"
        "⭐️ *Внутренние роли*\n"
        "/promote /demote — внутренняя роль модератора бота (ниже настоящего админа)\n"
        "/roles — список внутренних модераторов\n"
        "/logs — последние действия модерации (журнал аудита)\n\n"
        "🔒 *Блокировки контента*\n"
        "/lock link|invitelink|channellink|photo|video|sticker|voice|forward|gif|video＿note|document|poll\n"
        "/unlock те же варианты\n"
        "/locks — показать активные блокировки\n\n"
        "🌐 *Защита от ссылок*\n"
        "/blockdomain домен   /unblockdomain домен\n"
        "/allowdomain домен   /unallowdomain домен\n"
        "/domains — показать списки\n\n"
        "🚫 *Фильтры слов*\n"
        "/filter слово\n/stopfilter слово\n/filters\n"
        "/setfilteraction delete|warn|mute|ban\n"
        "/allowword слово — исключение   /disallowword слово\n\n"
        "🕵️ *Антиспам*\n"
        "/antispam on|off\n/setspamaction delete|warn|mute|ban\n"
        "/dupcross on|off   /setdupcross порог секунды\n\n"
        "↪️ *Защита пересылки*\n"
        "/allowforward источник   /blockforward источник   /unruleforward источник\n"
        "/forwardrules — показать правила (источник: @username, ID или имя)\n\n"
        "📛 *Защита от упоминаний*\n"
        "/mentionprotection on|off\n/setmentionlimit число\n/setmentionaction delete|warn|mute|ban\n\n"
        "🚨 *Антифлуд*\n"
        "/setflood число секунды\n/setfloodaction delete|warn|mute|ban\n\n"
        "🛡️ *Антирейд*\n"
        "/antiraid on|off\n/setraidthreshold число\n"
        "/lockdown — заблокировать всю группу сейчас   /unlockchat — разблокировать\n\n"
        "🛡️ *Капча*\n"
        "/captcha on|off — включить/выключить проверку новых участников\n\n"
        "📝 *Заметки*\n"
        "/save имя (ответом или текстом) — сохранить заметку\n"
        "/get имя или #имя — показать заметку\n"
        "/notes — список заметок\n"
        "/clear имя — удалить заметку\n\n"
        "📢 *Управление каналом (выполняется из группы)*\n"
        "/setchannel @channel＿username — привязать канал\n"
        "/post текст — опубликовать сразу (кнопка вида «текст|ссылка», между кнопками ;)\n"
        "/schedulepost минуты | текст — отложенный пост\n"
        "/editpost id＿сообщения | новый текст\n"
        "/delpost id＿сообщения\n"
        "/channelstats — статистика канала\n\n"
        "🧾 *Журнал администратора*\n"
        "/setlogchannel @channel＿username — логировать действия администраторов в канал\n\n"
        "🌐 *Федерация (общий список банов)*\n"
        "/fnew имя — создать новую федерацию\n"
        "/fjoin id — добавить эту группу в федерацию\n"
        "/fleave — покинуть федерацию\n"
        "/finfo — информация о текущей федерации\n"
        "/fban (ответом) причина — забанить во всех группах федерации\n"
        "/funban (ответом) — разбанить во всех группах федерации\n\n"
        "🆕 *Новые участники и автоматизация*\n"
        "/setwelcomedelete секунды|off — автоудаление приветственного сообщения\n"
        "/setgoodbye текст   /resetgoodbye   /goodbye on|off\n"
        "/rules   /setrules [язык] текст   /clearrules [язык]\n"
        "/addkeyword слово ответ   /delkeyword слово   /keywords\n"
        "/addcmd имя ответ   /delcmd имя   /cmds\n"
        "/schedulerecurring daily|weekly|monthly ... — повторяющиеся посты в канале\n"
        "/recurringposts   /delrecurring id\n"
        "/addautoaction условие действие   /delautoaction id   /autoactions   /autoactiontoggle on|off\n\n"
        "🗂️ *Профили доступа*\n"
        "/createprofile имя право1,право2,...   /delprofile имя   /profiles\n"
        "/assignprofile [ответ|@user|id] профиль   /unassignprofile [ответ|@user|id]   /myperms\n\n"
        "🚩 *Жалобы*\n"
        "/report [причина] (ответом на сообщение)   /reports — открытые жалобы\n\n"
        "🔔 *Оповещения администраторов*\n"
        "/setalertchannel chat＿id   /alerts — последние оповещения\n\n"
        "📦 *Импорт / экспорт настроек*\n"
        "/exportsettings   /importsettings (ответом на файл .json)\n\n"
        "🔔 *Ежедневные уведомления* (💰 курсы + 📰 новости + 📅 дата/праздник)\n"
        "/dailynotify — панель настроек (вкл/выкл, активы, тестовая отправка)\n"
        "/setpricetime HH:MM   /setnewstime HH:MM   /setdailytz часовой_пояс\n"
        "/testdailyprice   /testdailynews   /dailyassets\n\n"
        "🌐 /setlang — изменить язык группы\n"
        "⚙️ /settings — показать текущие настройки группы"
    ),

    "help_words_text": (
        "📖 *Полный список текстовых команд*\n"
        "Каждая строка значит: напишите это слово = выполнится ровно эта команда\n"
        "\n"
        "*👮 Управление участниками*\n"
        "предупреждение = /warn\n"
        "снять предупреждение = /unwarn\n"
        "предупреждения = /warns\n"
        "мут = /mute\n"
        "снять мут = /unmute\n"
        "бан = /ban\n"
        "разбан = /unban\n"
        "кик = /kick\n"
        "удалить = /del\n"
        "очистить = /purge\n"
        "\n"
        "*⭐️ Роли и журнал*\n"
        "повысить = /promote\n"
        "понизить = /demote\n"
        "модераторы = /roles\n"
        "журнал = /logs\n"
        "сменить язык = /setlang\n"
        "\n"
        "*🔒 Блокировки и фильтры*\n"
        "заблокировать = /lock\n"
        "разблокировать = /unlock\n"
        "блокировки = /locks\n"
        "фильтр = /filter\n"
        "удалить фильтр = /stopfilter\n"
        "фильтры = /filters\n"
        "заблокированные домены = /domains\n"
        "правила пересылки = /forwardrules\n"
        "\n"
        "*🛡️ Безопасность группы*\n"
        "антирейд = /antiraid\n"
        "полная блокировка = /lockdown\n"
        "открыть группу = /unlockchat\n"
        "капча = /captcha\n"
        "прощание = /goodbye\n"
        "\n"
        "*📝 Заметки*\n"
        "сохранить = /save\n"
        "получить = /get\n"
        "заметки = /notes\n"
        "очистить заметку = /clear\n"
        "\n"
        "*📢 Канал*\n"
        "установить канал = /setchannel\n"
        "пост = /post\n"
        "запланировать пост = /schedulepost\n"
        "редактировать пост = /editpost\n"
        "удалить пост = /delpost\n"
        "статистика канала = /channelstats\n"
        "установить канал журнала = /setlogchannel\n"
        "\n"
        "*🌐 Федерация*\n"
        "новая федерация = /fnew\n"
        "вступить в федерацию = /fjoin\n"
        "покинуть федерацию = /fleave\n"
        "информация о федерации = /finfo\n"
        "бан по федерации = /fban\n"
        "разбан по федерации = /funban\n"
        "\n"
        "*🆕 Приветствие и автоматизация*\n"
        "правила = /rules\n"
        "установить правила = /setrules\n"
        "очистить правила = /clearrules\n"
        "добавить ключевое слово = /addkeyword\n"
        "удалить ключевое слово = /delkeyword\n"
        "ключевые слова = /keywords\n"
        "добавить команду = /addcmd\n"
        "удалить команду = /delcmd\n"
        "команды = /cmds\n"
        "добавить автодействие = /addautoaction\n"
        "удалить автодействие = /delautoaction\n"
        "автодействия = /autoactions\n"
        "\n"
        "*🗂️ Профили и жалобы*\n"
        "профили = /profiles\n"
        "мои права = /myperms\n"
        "жалоба = /report\n"
        "жалобы = /reports\n"
        "уведомления = /alerts\n"
        "экспорт настроек = /exportsettings\n"
        "\n"
        "*🤖 NEXOR Copilot*\n"
        "админ = /adminpanel\n"
        "помощник = /copilot\n"
        "проверка ии = /aicheck\n"
        "объяснить действие = /aiexplain\n"
        "анализ жалоб = /aireports\n"
        "здоровье группы = /aihealth\n"
        "советник по правилам = /airule\n"
        "оптимизация правил = /aioptimize\n"
        "анализ инцидента = /aiincident\n"
        "ии тариф = /aiplan\n"
        "\n"
        "*⚙️ Общее*\n"
        "настройки = /settings\n"
        "помощь = /help\n"
        "\n"
        "💡 Фразы из нескольких слов (например «снять предупреждение») пишите точно так же, подряд."
    ),

    "channel_set_usage": "Использование: /setchannel @channel＿username или числовой ID канала",
    "channel_set_error": "❌ Не удалось найти этот канал: {error}",
    "channel_set_done": "📢 Канал «{title}» привязан к этой группе.",
    "channel_no_channel": "Сначала привяжите канал через /setchannel.",
    "channel_post_empty": "Текст поста пустой. Использование: /post текст сообщения",
    "channel_post_sent": "✅ Пост отправлен. ID сообщения: {id}",
    "channel_post_failed": "❌ Не удалось отправить пост: {error}",
    "channel_schedule_usage": "Использование: /schedulepost минуты, затем текст поста на следующей строке",
    "channel_schedule_invalid_minutes": "Неверное число минут.",
    "channel_schedule_empty": "Текст поста пустой.",
    "channel_schedule_done": "⏰ Пост запланирован через {minutes} минут.",
    "channel_scheduled_sent": "✅ Запланированный пост отправлен. ID: {id}",
    "channel_scheduled_failed": "❌ Не удалось отправить запланированный пост: {error}",
    "channel_editpost_usage": "Использование: /editpost id＿сообщения, затем новый текст на следующей строке",
    "channel_editpost_invalid_id": "Неверный ID сообщения.",
    "channel_editpost_empty": "Новый текст пустой.",
    "channel_editpost_done": "✅ Пост отредактирован.",
    "channel_editpost_failed": "❌ Ошибка редактирования: {error}",
    "channel_delpost_usage": "Использование: /delpost id＿сообщения",
    "channel_delpost_done": "🗑️ Пост удалён.",
    "channel_delpost_failed": "❌ Ошибка удаления: {error}",
    "channel_stats_text": "📊 Статистика канала «{title}»\n👥 Участников: {count}",
    "channel_stats_failed": "❌ Не удалось получить статистику: {error}",

    "state_on": "включено",
    "state_off": "отключено",

    "antispam_toggle_usage": "Использование: /antispam on или /antispam off",
    "antispam_toggle_done": "🕵️ Антиспам {state}.",
    "adminabuseprotection_toggle_usage": "Использование: /adminabuseprotection on или /adminabuseprotection off (только владелец)",
    "adminabuseprotection_toggle_done": "🚷 Обнаружение злоупотреблений администратора {state}.",
    "setspamaction_usage": "Использование: /setspamaction delete|warn|mute|ban",
    "setspamaction_done": "✅ Действие антиспама: {action}",
    "spam_reason_duplicate": "отправка повторяющегося сообщения",
    "spam_reason_newlink": "публикация ссылки сразу после вступления",

    "setflood_usage": "Использование: /setflood число секунды  (напр. /setflood 5 10)",
    "setflood_done": "✅ Антифлуд: {limit} сообщений за {window} секунд",
    "setfloodaction_usage": "Использование: /setfloodaction delete|warn|mute|ban",
    "setfloodaction_done": "✅ Действие антифлуда: {action}",
    "flood_reason": "слишком быстрая отправка сообщений",

    "setfilteraction_usage": "Использование: /setfilteraction delete|warn|mute|ban",
    "setfilteraction_done": "✅ Действие фильтра слов: {action}",
    "allowword_usage": "Использование: /allowword слово",
    "allowword_done": "➕ «{word}» добавлено в список исключений.",
    "disallowword_usage": "Использование: /disallowword слово",
    "disallowword_done": "➖ «{word}» удалено из списка исключений.",
    "filter_reason": "запрещённое слово",

    "blockdomain_usage": "Использование: /blockdomain домен (напр. example.com)",
    "blockdomain_done": "🚫 Домен «{domain}» заблокирован.",
    "unblockdomain_usage": "Использование: /unblockdomain домен",
    "unblockdomain_done": "✅ Домен «{domain}» разблокирован.",
    "allowdomain_usage": "Использование: /allowdomain домен",
    "allowdomain_done": "✅ Домен «{domain}» добавлен в белый список.",
    "unallowdomain_usage": "Использование: /unallowdomain домен",
    "unallowdomain_done": "➖ Домен «{domain}» удалён из белого списка.",
    "domains_header_block": "🚫 Заблокированные домены:",
    "domains_header_allow": "✅ Домены в белом списке:",
    "domains_empty": "Домены не зарегистрированы.",
    "link_reason_blacklisted": "ссылка на заблокированный домен",

    "antiraid_toggle_usage": "Использование: /antiraid on или /antiraid off",
    "antiraid_toggle_done": "🛡️ Антирейд {state}.",
    "setraidthreshold_usage": "Использование: /setraidthreshold число (напр. 8)",
    "setraidthreshold_done": "✅ Порог обнаружения рейда изменён на {n} пользователей.",
    "raid_detected_alert": "🚨 *Внимание, рейд!*\nНеобычное количество новых участников ({count} за {window} секунд) вступило в группу.\nГруппа заблокирована на {minutes} минут (писать могут только админы).",
    "raid_auto_unlock": "🔓 Автоматическая блокировка снята.",
    "lockdown_done": "🔒 Группа заблокирована; писать могут только админы.",
    "unlock_done_manual": "🔓 Блокировка группы снята.",
    "already_locked": "Группа уже заблокирована.",
    "already_unlocked": "Группа не заблокирована.",
    "btn_unlock_now": "🔓 Разблокировать сейчас",

    # --- Priority 3: Content Control (Forward Protection / Mention Protection / Cross-user Duplicate) ---
    "allowforward_usage": "Использование: /allowforward @username|ID|имя",
    "allowforward_done": "✅ Пересылка от «{source}» теперь всегда разрешена.",
    "blockforward_usage": "Использование: /blockforward @username|ID|имя",
    "blockforward_done": "🚫 Пересылка от «{source}» теперь всегда заблокирована.",
    "unruleforward_usage": "Использование: /unruleforward @username|ID|имя",
    "unruleforward_done": "➖ Правило пересылки для «{source}» удалено.",
    "forwardrules_header_block": "🚫 Всегда заблокированные источники:",
    "forwardrules_header_allow": "✅ Всегда разрешённые источники:",
    "forwardrules_empty": "Правила пересылки не заданы.",
    "forward_reason_blocked_source": "пересылка из заблокированного источника ({source})",
    "mentionprotection_usage": "Использование: /mentionprotection on или /mentionprotection off",
    "mentionprotection_done": "🛡️ Защита от упоминаний {state}.",
    "setmentionlimit_usage": "Использование: /setmentionlimit число (напр. 5)",
    "setmentionlimit_done": "✅ Лимит упоминаний изменён на {n}.",
    "setmentionaction_usage": "Использование: /setmentionaction delete|warn|mute|ban",
    "setmentionaction_done": "✅ Действие за злоупотребление упоминаниями: {action}",
    "mention_reason": "массовые упоминания ({count} шт.)",
    "dupcross_usage": "Использование: /dupcross on или /dupcross off",
    "dupcross_done": "🕵️ Обнаружение дублей от разных пользователей {state}.",
    "setdupcross_usage": "Использование: /setdupcross порог секунды (напр. 3 45)",
    "setdupcross_done": "✅ Настройки межпользовательских дублей: {threshold} польз. за {window} сек.",
    "spam_reason_cross_duplicate": "повторяющееся сообщение от нескольких пользователей (копипаст-рейд)",

    # --- Priority 4: New Members & Automation (Welcome auto-delete, Goodbye, Rules, Filters, Custom Commands, Scheduled Messages, Auto Actions) ---
    "setwelcomedelete_usage": "Использование: /setwelcomedelete секунды (напр. 60) или /setwelcomedelete off",
    "setwelcomedelete_done": "✅ Приветственные сообщения теперь будут удаляться автоматически через {seconds} сек.",
    "setwelcomedelete_off": "✅ Автоудаление приветственного сообщения отключено.",
    "setgoodbye_usage": "Использование: /setgoodbye <текст>\nДоступные переменные: {name} {username} {mention} {chat} {count}",
    "setgoodbye_done": "✅ Пользовательское прощальное сообщение сохранено.",
    "resetgoodbye_done": "✅ Прощальное сообщение сброшено на стандартное.",
    "goodbye_toggle_usage": "Использование: /goodbye on или /goodbye off",
    "goodbye_toggle_done": "👋 Прощальные сообщения {state}.",
    "rules_empty": "Правила для этой группы ещё не заданы.",
    "rules_header": "📜 *Правила группы*",
    "setrules_usage": "Использование: /setrules [код языка] <текст правил>\nПример: /setrules Пожалуйста, уважайте друг друга.\nС кодом языка: /setrules en Please be respectful.",
    "setrules_done": "✅ Правила сохранены ({lang}).",
    "clearrules_done": "🗑️ Правила удалены ({lang}).",
    "clearrules_notfound": "Для этого языка правила не были заданы.",
    "addkeyword_usage": "Использование: /addkeyword <ключевое слово> <ответ>\nИли ответом на сообщение: /addkeyword <ключевое слово>",
    "addkeyword_done": "✅ Триггер по ключевому слову «{keyword}» добавлен.",
    "addkeyword_updated": "♻️ Триггер по ключевому слову «{keyword}» обновлён.",
    "delkeyword_usage": "Использование: /delkeyword <ключевое слово>",
    "delkeyword_done": "🗑️ Триггер по ключевому слову «{keyword}» удалён.",
    "delkeyword_notfound": "Такого триггера нет.",
    "keywords_empty": "Триггеры по ключевым словам не заданы.",
    "keywords_header": "🔑 Триггеры по ключевым словам:",
    "autoanswer_ask_audience": "⚙️ Настройка автоответа для «{title}»\n\nКому бот должен отвечать на это ключевое слово?",
    "autoanswer_ask_keyword": "✏️ Теперь отправьте ключевое слово или фразу (например: цена, правила, админ...).",
    "autoanswer_ask_response": "📎 Ключевое слово «{keyword}» сохранено.\n\nТеперь отправьте сообщение или медиа, которым бот должен отвечать (текст, фото, видео, голосовое, аудио, файл, GIF, стикер или видеосообщение).\n\nВы можете отправить до 20 разных ответов, чтобы бот каждый раз выбирал один случайным образом. Когда закончите, нажмите «Готово».",
    "autoanswer_audience_admins": "🛡 Только администраторы",
    "autoanswer_audience_all": "👥 Все пользователи",
    "autoanswer_audience_owners": "👑 Только владелец",
    "autoanswer_btn_cancel": "❌ Отмена",
    "autoanswer_btn_done": "✅ Готово",
    "autoanswer_cancelled": "❌ Отменено; автоответ не сохранён.",
    "autoanswer_cleaned": "🗑️ Удалено автоответов: {count}.",
    "autoanswer_expired": "Этот шаг больше не действителен; отправьте команду «настроить автоответ» снова внутри группы.",
    "autoanswer_group_only": "Эта команда используется только внутри группы.",
    "autoanswer_invalid_link": "Эта ссылка недействительна или устарела. Отправьте команду «настроить автоответ» снова внутри группы.",
    "autoanswer_list_empty": "Автоответы не настроены.",
    "autoanswer_list_header": "◄ Список автоответов:",
    "autoanswer_list_item": "• «{keyword}» — аудитория: {audience} — ответов: {count}",
    "autoanswer_max_responses": "⛔️ Вы достигли лимита в {max} ответов. Нажмите «Готово», чтобы сохранить.",
    "autoanswer_need_one_response": "Вы ещё не добавили ни одного ответа; отправьте хотя бы одно сообщение или медиа.",
    "autoanswer_not_admin": "⛔️ Чтобы настроить автоответ, вы должны быть администратором или владельцем этой группы.",
    "autoanswer_pm_button": "🔐 Перейти в личку для настройки автоответа",
    "autoanswer_response_added": "✅ Ответ {count} из {max} сохранён.\nОтправьте следующий или нажмите «Готово».",
    "autoanswer_saved": "✅ Автоответ для «{title}» сохранён.\nКлючевое слово: {keyword}\nАудитория: {audience}\nЧисло ответов: {count}",
    "autoanswer_setup_intro": "◄ Автоответ (Auto-Answer)\n\nЧтобы настроить новый автоответ для «{title}», нажмите кнопку ниже и продолжите шаги в личных сообщениях.",
    "autoanswer_unsupported_content": "Этот тип контента не поддерживается. Отправьте текст, фото, видео, голосовое, аудио, файл, GIF, стикер или видеосообщение.",
    "autoanswer_updated": "♻️ Автоответ «{keyword}» для «{title}» обновлён.\nАудитория: {audience}\nЧисло ответов: {count}",
    "delanswer_done": "🗑️ Автоответ «{keyword}» удалён.",
    "delanswer_notfound": "Такого автоответа не существует.",
    "delanswer_usage": "Использование: /delanswer <ключевое слово>",
    "addcmd_usage": "Использование: /addcmd <имя> <ответ>\nИли ответом на сообщение: /addcmd <имя>",
    "addcmd_reserved": "⛔ Это имя зарезервировано для встроенной команды.",
    "addcmd_done": "✅ Пользовательская команда /{name} добавлена.",
    "addcmd_updated": "♻️ Пользовательская команда /{name} обновлена.",
    "delcmd_usage": "Использование: /delcmd <имя>",
    "delcmd_done": "🗑️ Пользовательская команда /{name} удалена.",
    "delcmd_notfound": "Такой пользовательской команды нет.",
    "cmds_empty": "Пользовательские команды не заданы.",
    "cmds_header": "⚙️ Пользовательские команды:",
    "schedulerecurring_usage": "Использование:\n/schedulerecurring daily HH:MM <текст>\n/schedulerecurring weekly mon HH:MM <текст>\n/schedulerecurring monthly ДЕНЬ HH:MM <текст>\n(день недели: mon tue wed thu fri sat sun — день месяца: 1-28)",
    "schedulerecurring_invalid_time": "Неверное время. Используйте формат HH:MM (напр. 14:30).",
    "schedulerecurring_invalid_day": "Неверный день месяца. Используйте число от 1 до 28.",
    "schedulerecurring_invalid_weekday": "Неверный день недели. Используйте один из: mon tue wed thu fri sat sun",
    "schedulerecurring_empty_text": "Требуется текст сообщения (в строке(ах) после команды).",
    "schedulerecurring_done": "✅ Повторяющийся пост запланирован (ID {id}).",
    "recurringposts_header": "🔁 Повторяющиеся посты:",
    "recurringposts_empty": "Нет запланированных повторяющихся постов.",
    "recurringposts_item": "#{id} — {schedule} — {preview}",
    "recurring_desc_daily": "Ежедневно в {time}",
    "recurring_desc_weekly": "Еженедельно по {weekday} в {time}",
    "recurring_desc_monthly": "Ежемесячно {day}-го числа в {time}",
    "delrecurring_usage": "Использование: /delrecurring <id>",
    "delrecurring_done": "🗑️ Повторяющийся пост #{id} удалён.",
    "delrecurring_notfound": "Повторяющийся пост с таким ID не найден.",
    "addautoaction_usage": "Использование: /addautoaction <условие> <действие>\nУсловия: message＿type:<photo|video|sticker|voice|gif|video＿note|document|poll|forward|link|text>, user＿role:<user|moderator|admin>, warns＿gte:<число>\nДействия: delete, warn, mute:<минуты>, ban, kick",
    "addautoaction_invalid_condition": "Неверное условие. Запустите /addautoaction без аргументов, чтобы увидеть формат.",
    "addautoaction_invalid_action": "Неверное действие. Запустите /addautoaction без аргументов, чтобы увидеть формат.",
    "addautoaction_done": "✅ Правило Auto Action добавлено (ID {id}): {condition} → {action}",
    "delautoaction_usage": "Использование: /delautoaction <id>",
    "delautoaction_done": "🗑️ Правило Auto Action #{id} удалено.",
    "delautoaction_notfound": "Правило Auto Action с таким ID не найдено.",
    "autoactions_header": "🤖 Правила Auto Action:",
    "autoactions_empty": "Правила Auto Action не заданы.",
    "autoactiontoggle_usage": "Использование: /autoactiontoggle on или /autoactiontoggle off",
    "autoactiontoggle_done": "🤖 Auto Actions {state}.",
    "autoaction_reason": "Правило Auto Action (#{id})",
    "settings_goodbye": "👋 Прощальные сообщения: {state}",
    "settings_autoaction": "🤖 Auto Actions: {state}",

    # Priority 5, Item 25 — Permission Profiles
    "createprofile_usage": "Использование: /createprofile <имя> <право1,право2,...>\nДоступные права: {caps}",
    "profile_invalid_caps": "❌ Неизвестное право: {invalid}\nДоступные права: {caps}",
    "createprofile_done": "✅ Профиль «{name}» создан с правами: {caps}",
    "createprofile_updated": "♻️ Профиль «{name}» обновлён, права: {caps}",
    "delprofile_usage": "Использование: /delprofile <имя>",
    "delprofile_notfound": "Такого профиля нет.",
    "delprofile_done": "🗑️ Профиль «{name}» удалён.",
    "profiles_empty": "Пользовательские профили доступа ещё не созданы.",
    "profiles_header": "🗂️ Профили доступа:",
    "profile_item": "• «{name}» — {caps}\n   Участники: {members}",
    "assignprofile_usage": "Использование: /assignprofile [ответ|@user|id] <профиль>",
    "assignprofile_notfound_profile": "Профиля «{name}» не существует. Сначала создайте его через /createprofile.",
    "assignprofile_done": "✅ Профиль «{profile}» назначен {name}.",
    "unassignprofile_usage": "Использование: /unassignprofile [ответ|@user|id]",
    "unassignprofile_notfound": "У этого пользователя нет назначенного профиля.",
    "unassignprofile_done": "➖ Профиль снят с {name}.",
    "myperms_with_profile": "Ваш ранг: {rank}\nНазначенный профиль: «{profile}»\nПрава: {caps}",
    "myperms_no_profile": "Ваш ранг: {rank}\nПользовательский профиль не назначен.",

    # Priority 5, Item 26 — Reports
    "report_need_reply": "Пожалуйста, ответьте на сообщение, которое хотите пожаловаться.",
    "report_self": "Нельзя пожаловаться на самого себя! 😅",
    "report_already": "Вы уже недавно жаловались на это сообщение.",
    "report_done": "✅ Ваша жалоба отправлена администраторам. Спасибо!",
    "report_alert_header": "🚩 Новая жалоба #{id}\nОт: {reporter}\nНа: {target}\nПричина: {reason}",
    "alert_multi_reports_text": "На {target} поступило {count} отдельных жалоб за последние {window} сек.",
    "reports_empty": "Открытых жалоб нет.",
    "reports_header": "🚩 Открытые жалобы:",
    "report_item": "• #{id} [{when}] {reporter} ← {target} ({reason})",
    "btn_report_mute": "🔇 Мут",
    "btn_report_ban": "🚫 Бан",
    "btn_report_delete": "🗑️ Удалить сообщение",
    "btn_report_dismiss": "✖️ Отклонить",
    "report_not_found": "Этой жалобы больше нет или она уже обработана.",
    "report_action_done_dismiss": "✖️ Жалоба #{id} на {target} отклонена.",
    "report_action_done_mute": "🔇 {target} получил мут на {minutes} мин. по жалобе.",
    "report_action_done_ban": "🚫 {target} забанен по жалобе.",
    "report_action_done_delete": "🗑️ Сообщение {target}, на которое пожаловались, удалено.",

    # Priority 5, Item 27 — Admin Alerts
    "setalertchannel_usage": "Использование: /setalertchannel <chat＿id> (без аргументов — очистить)",
    "setalertchannel_done": "✅ Место для оповещений установлено: {channel}.",
    "setalertchannel_cleared": "✅ Место для оповещений очищено (оповещения будут идти в этот чат/лог-канал).",
    "alerts_empty": "Оповещений пока нет.",
    "alerts_header": "🔔 Последние оповещения:",
    "alert_type_multi_reports": "Множественные жалобы",
    "alert_type_suspicious": "Подозрительная активность",
    "alert_type_security": "Событие безопасности",
    "alert_type_abnormal": "Аномальное поведение",
    "alert_type_admin_abuse": "Возможное злоупотребление администратора",
    "admin_abuse_alert_detail": "🧑‍💼 {name} выполнил {count} деструктивных действий (бан/мут/кик/предупреждение) за последние {minutes} мин. — возможно, аккаунт взломан или это намеренное злоупотребление. Проверьте.",
    "alert_type_raid": "Обнаружен рейд",
    "alert_type_generic": "Оповещение",

    # Priority 5, Item 28 — Import / Export Settings
    "exportsettings_caption": "📦 Экспорт настроек группы.\n{summary}",
    "importsettings_usage": "Ответьте на файл .json с настройками командой /importsettings.",
    "importsettings_invalid_json": "❌ Не удалось прочитать файл как корректный JSON.",
    "importsettings_invalid_schema": "❌ Некорректный файл настроек (проблема: {detail}).",
    "importsettings_confirm_prompt": "⚠️ Это *заменит* текущие настройки группы на:\n{summary}\nВы уверены?",
    "importsettings_cancelled": "❌ Импорт отменён.",
    "importsettings_done": "✅ Настройки успешно импортированы.\n{summary}",
    "btn_import_confirm": "✅ Подтвердить импорт",
    "btn_import_cancel": "❌ Отмена",

    # Личная панель администратора
    "panel_header": "🛠 Панель управления {name}\n\nВыберите раздел:",
    "panel_btn_settings": "⚙️ Настройки",
    "panel_btn_locks": "🔒 Блокировки",
    "panel_btn_filters": "🚫 Фильтры",
    "panel_btn_rules": "📜 Правила",
    "panel_btn_reports": "🚩 Открытые жалобы",
    "panel_btn_logs": "🗒 Журнал",
    "panel_btn_roles": "👮 Модераторы",
    "panel_btn_daily": "🔔 Ежедневные уведомления",
    "panel_daily_hint": "Чтобы изменить настройки: /dailynotify",
    "panel_btn_back": "🔙 Назад",
    "panel_btn_close": "❌ Закрыть",
    "panel_not_yours": "Эта панель доступна только тому, кто её открыл.",
    "panel_closed": "Панель закрыта.",

    "ai_panel_header": "🤖 NEXOR Copilot\nИИ-помощник для админов — выберите раздел:",
    "ai_btn_analyze": "🔍 Анализ сообщения",
    "ai_btn_explain": "❓ Объяснить действие",
    "ai_btn_health": "📊 Здоровье группы",
    "ai_btn_reports": "🗂 Просмотр жалоб",
    "ai_btn_optimize": "🛠 Оптимизация правил",
    "ai_btn_incident": "🚨 Анализ инцидента",
    "ai_btn_rule": "➕ Советник по правилам",
    "ai_btn_close": "❌ Закрыть",
    "ai_working": "⏳ Анализ с помощью ИИ...",
    "ai_guide_analyze": "🔍 Анализ сообщения\nОтветьте на сообщение, которое нужно проверить, и отправьте:\naicheck",
    "ai_guide_explain": "❓ Объяснить действие\nПример:\naiexplain @username почему этот пользователь получил предупреждение?\n(или ответьте на сообщение пользователя и отправьте aiexplain)",
    "ai_guide_rule": "➕ Советник по правилам\nОпишите проблему, например:\nairule у нас много рекламного спама",
    "ai_need_reply": "Ответьте на сообщение, чтобы запустить анализ сообщения.",
    "ai_explain_usage": "Целевой пользователь не найден. Ответьте на его сообщение или отправьте:\naiexplain @username [вопрос]",
    "ai_explain_default_question": "Почему недавно было применено модераторское действие к {name}?",
    "ai_rule_usage": "Опишите проблему, например:\nairule у нас много рекламного спама",
    "ai_reports_empty_for_ai": "Нет открытых жалоб для анализа.",
    "ai_optimize_empty": "Нет правил автодействий для проверки.",
    "ai_incident_empty": "Не найдено значимой недавней активности для анализа.",
    "ai_rule_not_applicable": "⚠️ Текущий движок правил NEXOR не может это покрыть; попробуйте более точное описание или добавьте правило вручную через addautoaction.",
    "ai_rule_cancelled": "Отменено; правило не было создано.",
    "ai_rule_created": "✅ Правило #{id} создано.\nУсловие: {condition}\nДействие: {action}",
    "ai_dismissed": "Отклонено; действие в группе не выполнено.",
    "ai_reason_copilot": "Предложение NEXOR Copilot (одобрено админом)",
    "ai_action_done_delwarn": "🗑️ Сообщение удалено, {name} получил предупреждение.",
    "ai_plan_status": "Текущий ИИ-тариф этой группы: {plan}",
    "ai_plan_set_done": "✅ ИИ-тариф этой группы установлен на \"{plan}\".",
    "ai_plan_set_invalid": "Недопустимый тариф. Используйте один из: free, pro, premium",
    "ai_err_plan_not_allowed": "⛔️ Эта функция недоступна на текущем тарифе группы.",
    "ai_err_rate_limited": "⏳ Дневной лимит запросов к ИИ исчерпан; попробуйте завтра.",
    "ai_err_not_configured": "⚙️ ИИ ещё не настроен для тарифа этой группы (сообщите администратору бота).",
    "ai_err_provider_error": "⚠️ Не удалось связаться с сервисом ИИ; попробуйте снова через момент.",
    "ai_err_bad_response": "⚠️ Ответ ИИ не удалось разобрать; попробуйте снова.",
    "ai_err_unknown": "⚠️ Неожиданная ошибка NEXOR Copilot; она записана в журнал.",
    "ai_err_action_failed": "⚠️ Не удалось выполнить действие.",
    "ai_risk_low": "Низкий",
    "ai_risk_medium": "Средний",
    "ai_risk_high": "Высокий",
    "ai_priority_high": "Высокий приоритет",
    "ai_priority_suspicious": "Подозрительно",
    "ai_priority_low": "Низкий приоритет",
    "ai_priority_false": "Вероятно ложная жалоба",
    "ai_action_none": "Без действия",
    "ai_action_delete": "Удалить сообщение",
    "ai_action_warn": "Предупредить",
    "ai_action_delete_warn": "Удалить + предупредить",
    "ai_action_mute": "Заглушить",
    "ai_action_ban": "Забанить",
    "ai_trend_up": "Растёт 📈",
    "ai_trend_down": "Снижается 📉",
    "ai_trend_stable": "Стабильно ➖",
    "ai_btn_apply_delwarn": "🗑️+⚠️ Удалить и предупредить",
    "ai_btn_apply_mute": "🔇 Заглушить",
    "ai_btn_apply_ban": "🚫 Забанить",
    "ai_btn_dismiss": "Отклонить",
    "ai_btn_confirm": "✅ Подтвердить и создать",
    "ai_btn_cancel": "❌ Отмена",
    "ai_analyze_message_result": "🤖 Анализ NEXOR Copilot\n\nРиск: {risk}\nСпам: {spam}%\nРеклама: {ad}%\nПодозрительно: {suspicious}%\nТоксично: {toxic}%\n\nРезюме: {summary}\n\n💡 Рекомендация: {action}\nПричина: {reason}\n\nОкончательное решение за вами:",
    "ai_explain_result": "🤖 Объяснение NEXOR Copilot\n\n{explanation}\n\nКлючевые факторы:\n{factors}",
    "ai_reports_header": "🗂 Открытые жалобы по категориям:",
    "ai_reports_item": "• #{id} — {priority}: {reason}",
    "ai_reports_summary": "\nРезюме: {summary}",
    "ai_health_result": "📊 Здоровье группы\n\nУровень спама: {spam_level}\nТренд нарушений: {trend}\n\nРиски:\n{risks}\n\n💡 Рекомендация: {recommendation}",
    "ai_rule_advisor_result": "➕ Предложение советника по правилам\n\nУсловие: {trigger}\nДействие: {action}\nОбласть применения: {scope}\nПричина: {reason}\nУверенность: {confidence}%\n\nПодтвердите создание этого правила:",
    "ai_optimize_result": "🛠 Результат оптимизации правил\n\nДубликаты: {duplicates}\nКонфликты: {conflicts}\nСлишком частые: {too_frequent}\nОпасные конфигурации: {dangerous}\n\nПредложения:\n{suggestions}",
    "ai_incident_result": "🚨 Сводка инцидента\n\n{summary}\n\nСерьёзность: {severity}\n\nХронология:\n{timeline}\n\n💡 Рекомендация: {recommendation}",
    "ai_local_summary_safe": "Короткое сообщение без признаков риска; локально классифицировано как низкий риск.",
    "ai_local_reason_no_ai_needed": "Проверка ИИ не потребовалась.",

    # ==================== Guide Panel ====================
    "guide_intro": "📖 Гид по NEXOR\nНажми на раздел, чтобы узнать, что он делает, а затем на любое слово под ним — увидишь, что реально печатать в чате вместо команды.",
    "guide_btn_locks": "🔒 Блокировки и фильтры",
    "guide_btn_moderation": "🛡 Модерация и наказания",
    "guide_btn_roles": "👮 Повышение / понижение",
    "guide_btn_settings": "⚙️ Настройки группы",
    "guide_btn_security": "🚨 Антирейд и полная блокировка",
    "guide_btn_rules": "📜 Правила группы",
    "guide_btn_autoreply": "💬 Ключевые слова и команды",
    "guide_btn_channel": "📢 Канал и посты",
    "guide_btn_autoactions": "🤖 Автоматические действия",
    "guide_btn_notes": "📝 Заметки",
    "guide_btn_reports_logs": "🚩 Жалобы и журнал",
    "guide_btn_federation": "🌐 Федерация",
    "guide_btn_ai_copilot": "🧠 NEXOR Copilot (ИИ)",
    "guide_title_locks": "🔒 Блокировки и фильтры",
    "guide_title_moderation": "🛡 Модерация и наказания",
    "guide_title_roles": "👮 Повышение / понижение",
    "guide_title_settings": "⚙️ Настройки группы",
    "guide_title_security": "🚨 Антирейд и полная блокировка",
    "guide_title_rules": "📜 Правила группы",
    "guide_title_autoreply": "💬 Ключевые слова и команды",
    "guide_title_channel": "📢 Канал и посты",
    "guide_title_autoactions": "🤖 Автоматические действия",
    "guide_title_notes": "📝 Заметки",
    "guide_title_reports_logs": "🚩 Жалобы и журнал",
    "guide_title_federation": "🌐 Федерация",
    "guide_title_ai_copilot": "🧠 NEXOR Copilot (ИИ)",
    "guide_desc_locks": "Блокируй рискованный контент — ссылки, фото, стикеры, репосты и другое — он будет удаляться мгновенно. Добавляй фильтры слов или доменов для всего остального.",
    "guide_desc_moderation": "Предупреждай, заглушай, исключай или банируй нарушителей, удаляй одно сообщение или очищай целый диапазон разом — полный набор инструментов модерации.",
    "guide_desc_roles": "Повышай проверенных участников до внутренних модераторов, понижай их позже и сразу видь, у кого какая роль и права.",
    "guide_desc_settings": "Один экран со всем о группе — блокировки, фильтры, капча, предупреждения, язык — плюс быстрый доступ к панели админа.",
    "guide_desc_security": "Автоматическое обнаружение рейдов ловит внезапный наплыв новых участников; полная блокировка закрывает всю группу одним нажатием.",
    "guide_desc_rules": "Напиши правила группы один раз, показывай их по запросу или полностью очисти и начни заново.",
    "guide_desc_autoreply": "Научи бота автоматически отвечать на определённые слова или создай собственные текстовые команды.",
    "guide_desc_channel": "Привяжи канал к группе, публикуй или планируй посты, редактируй или удаляй их позже и следи за статистикой канала.",
    "guide_desc_autoactions": "Простые правила «если это — то сделай то»: бот сам реагирует на тип сообщения или число предупреждений.",
    "guide_desc_notes": "Сохрани текст или файл один раз и мгновенно доставай его по короткому тегу, когда понадобится.",
    "guide_desc_reports_logs": "Участники жалуются одним нажатием; у тебя есть полный журнал всех действий любого админа.",
    "guide_desc_federation": "Единый бан-лист сразу для нескольких групп — забанил один раз, и человек забанен во всей федерации.",
    "guide_desc_ai_copilot": "ИИ-ассистент для админов: анализирует сообщения, объясняет прошлые действия и предлагает новые правила.",
    "guide_kw_lock": "Заблокировать тип контента (например, ссылки, фото) для авто-удаления.",
    "guide_kw_unlock": "Снять активную блокировку.",
    "guide_kw_locks": "Показать все активные блокировки в группе.",
    "guide_kw_filter": "Добавить запрещённое слово/фразу для авто-удаления.",
    "guide_kw_stopfilter": "Убрать фильтр слова.",
    "guide_kw_filters": "Список всех активных фильтров слов.",
    "guide_kw_domains": "Показать или изменить список заблокированных доменов.",
    "guide_kw_forwardrules": "Показать правила разрешения/блокировки пересланных сообщений.",
    "guide_kw_warn": "Выдать участнику предупреждение.",
    "guide_kw_unwarn": "Снять одно предупреждение с участника.",
    "guide_kw_warns": "Показать число предупреждений участника.",
    "guide_kw_mute": "Заглушить участника на заданное время.",
    "guide_kw_unmute": "Снять заглушение с участника.",
    "guide_kw_ban": "Навсегда удалить участника из группы.",
    "guide_kw_unban": "Разрешить забаненному участнику вернуться.",
    "guide_kw_kick": "Исключить участника (сможет вступить снова).",
    "guide_kw_del": "Удалить сообщение — сначала ответь на него.",
    "guide_kw_purge": "Удалить целый диапазон сообщений разом.",
    "guide_kw_promote": "Повысить участника до внутреннего модератора.",
    "guide_kw_demote": "Снять роль внутреннего модератора.",
    "guide_kw_roles": "Список всех с ролью внутреннего модератора.",
    "guide_kw_profiles": "Управлять кастомными профилями прав.",
    "guide_kw_myperms": "Показать твои текущие права.",
    "guide_kw_settings": "Обзор всех настроек этой группы.",
    "guide_kw_setlang": "Сменить язык группы.",
    "guide_kw_captcha": "Включить/выключить капчу для новых участников.",
    "guide_kw_goodbye": "Включить/выключить прощальное сообщение.",
    "guide_kw_adminpanel": "Открыть панель быстрых админ-ярлыков.",
    "guide_kw_antiraid": "Включить/выключить автоматическое обнаружение рейдов.",
    "guide_kw_lockdown": "Мгновенно заблокировать всю группу.",
    "guide_kw_unlockchat": "Снять полную блокировку.",
    "guide_kw_rules": "Показать правила группы.",
    "guide_kw_setrules": "Написать или обновить правила группы.",
    "guide_kw_clearrules": "Удалить правила группы.",
    "guide_kw_addkeyword": "Добавить слово для автоматического ответа.",
    "guide_kw_delkeyword": "Удалить ключевое слово автоответа.",
    "guide_kw_keywords": "Список всех ключевых слов автоответа.",
    "guide_kw_addcmd": "Создать свою кастомную текстовую команду.",
    "guide_kw_delcmd": "Удалить кастомную команду.",
    "guide_kw_cmds": "Список всех кастомных команд.",
    "guide_kw_setanswer": "Настроить автоответ (текст/медиа, до 20 случайных ответов) для ключевого слова.",
    "guide_kw_answerlist": "Показать список настроенных автоответов.",
    "guide_kw_delanswer": "Удалить автоответ по его ключевому слову.",
    "guide_kw_cleananswerlist": "Очистить все автоответы этой группы.",
    "guide_kw_setchannel": "Привязать канал к этой группе.",
    "guide_kw_post": "Опубликовать пост в привязанном канале.",
    "guide_kw_schedulepost": "Запланировать пост на будущее.",
    "guide_kw_editpost": "Отредактировать уже опубликованный пост.",
    "guide_kw_delpost": "Удалить опубликованный пост.",
    "guide_kw_channelstats": "Показать статистику привязанного канала.",
    "guide_kw_addautoaction": "Создать автоматическое правило «если... то...».",
    "guide_kw_delautoaction": "Удалить автоматическое правило.",
    "guide_kw_autoactions": "Список всех автоматических правил.",
    "guide_kw_save": "Сохранить заметку/фрагмент для повторного использования.",
    "guide_kw_get": "Получить сохранённую заметку по имени.",
    "guide_kw_notes": "Список всех сохранённых заметок.",
    "guide_kw_clear": "Удалить сохранённую заметку.",
    "guide_kw_report": "Пожаловаться админам на сообщение.",
    "guide_kw_reports": "Показать открытые нерешённые жалобы.",
    "guide_kw_alerts": "Настроить, куда отправлять уведомления админам.",
    "guide_kw_adminabuseprotection": "Предупреждает, если администратор внезапно совершает много деструктивных действий.",
    "guide_kw_logs": "Показать последние действия админов.",
    "guide_kw_exportsettings": "Экспортировать настройки группы как резервную копию.",
    "guide_kw_setlogchannel": "Задать канал для получения журнала аудита.",
    "guide_kw_fnew": "Создать новую федерацию (общий бан-лист).",
    "guide_kw_fjoin": "Присоединить эту группу к существующей федерации.",
    "guide_kw_fleave": "Покинуть текущую федерацию.",
    "guide_kw_finfo": "Показать информацию о текущей федерации.",
    "guide_kw_fban": "Забанить пользователя во всей федерации.",
    "guide_kw_funban": "Разбанить пользователя во всей федерации.",
    "guide_kw_copilot": "Открыть меню ИИ-ассистента NEXOR Copilot.",
    "guide_kw_aicheck": "Попросить ИИ проанализировать сообщение — сначала ответь на него.",
    "guide_kw_aiexplain": "Спросить у ИИ, почему к кому-то было применено действие.",
    "guide_kw_aireports": "Дать ИИ рассортировать открытые жалобы по приоритету.",
    "guide_kw_aihealth": "Получить ИИ-сводку о состоянии группы.",
    "guide_kw_airule": "Опиши проблему — получи предложенное ИИ правило.",
    "guide_kw_aioptimize": "Попросить ИИ проверить твои автоматические правила.",
    "guide_kw_aiincident": "Получить ИИ-сводку недавнего инцидента.",
    "guide_kw_aiplan": "Показать или задать ИИ-план этой группы.",

    # --- Слой естественного языка (на основе намерений) — nlu/ ---
    "nlu_confirm_mute": "Замьютить {name} на {duration}?",
    "nlu_btn_confirm": "✅ Подтвердить",
    "nlu_btn_cancel": "❌ Отмена",
    "nlu_ask_duration": "На сколько замьютить {name}? (например: 30m, 2h, 1d)",
    "nlu_context_expired": "⌛️ Срок этого запроса истёк. Попробуйте снова.",
    "nlu_not_your_confirmation": "Эта кнопка не для вашего запроса.",
    "nlu_need_reply_target": "❗️Ответьте на сообщение этого пользователя, чтобы я понял, кого вы имеете в виду.",
    "nlu_fallback_intro": "🤔 Я не совсем понял. Попробуйте /help или сформулируйте точнее.",
    "nlu_confirm_unmute": "Снять мут с {name}?",
    "nlu_confirm_ban": "Забанить {name} на {duration}?",
    "nlu_confirm_unban": "Разбанить {name}?",
    "nlu_confirm_kick": "Кикнуть {name} из группы?",
    "nlu_action_cancelled": "❌ Отменено; ничего не сделано.",
    "nlu_confirm_delete": "Удалить это сообщение?",
    "nlu_delete_done": "🗑 Сообщение удалено.",
    "nlu_confirm_setrules": "Заменить правила группы на этот текст?\n\n{text}",
    "nlu_setrules_format_hint": "Чтобы установить правила так, используй формат:\n«установить правила: текст правила» (всё после «:» сохраняется как есть).",

    # --- Onboarding (handlers/onboarding.py + onboarding_logic.py) ---
    "onboarding_welcome": "👋 Привет! Я NEXOR — помогаю поддерживать порядок и безопасность в этой группе: модерация, антиспам, приветствие/правила, автоответы и другое.",
    "onboarding_needs_admin": "⚠️ Я ещё не администратор здесь, поэтому большинство функций не будут работать. Сделай меня администратором (как минимум: удаление сообщений, ограничение участников, приглашение пользователей, закрепление сообщений), и я начну работать.",
    "onboarding_missing_perms": "⚠️ Я администратор, но мне не хватает: {perms}. Некоторым функциям это нужно — можешь выдать эти права в любое время в настройках группы.",
    "onboarding_all_set": "✅ У меня есть все нужные права. Давай настроим основное.",
    "onboarding_btn_security": "🛡 Настроить безопасность",
    "onboarding_btn_help": "❓ Что ты умеешь?",
    "perm_restrict": "ограничение участников (мут/кик/бан)",
    "perm_delete": "удаление сообщений",
    "perm_invite": "приглашение пользователей",
    "perm_pin": "закрепление сообщений",
    "err_unexpected": "⚠️ Что-то пошло не так при выполнении этого действия. Попробуйте снова — если повторится, сообщите администратору группы.",
    "nlu_delanswer_format_hint": "Чтобы удалить автоответ так, используй формат:\n«удалить автоответ: ключевое слово» (точное ключевое слово для удаления).",
    "nlu_confirm_delanswer": "Удалить автоответ для ключевого слова «{keyword}»?",
    # ---- Ads system (added) ----
    'ads_btn_cancel': '❌ Отмена',
    'ads_btn_free': '🆓 Разместить бесплатное объявление (1 раз в день)',
    'ads_btn_paid': '💳 Купить рекламу (1–5 раз в день)',
    'ads_intro': '📢 Система рекламы NEXOR\n\nРеклама показывается только в группах на бесплатном тарифе (группы Pro/Premium рекламу не видят).\nБесплатное объявление показывается раз в день; купленная реклама может показываться от 1 до 5 раз в день (цена растёт соответственно).\n\nЧто выберешь?',
    'ads_ask_banner': '🖼 Сначала отправь баннер (фото) для объявления.\nЕсли баннер не нужен, напиши: пропустить',
    'ads_banner_invalid': 'Отправь фото или напиши «пропустить», чтобы продолжить без баннера.',
    'ads_ask_text': '✍️ Теперь отправь текст объявления (то, что будет видно в группах).',
    'ads_text_empty': 'Текст объявления не может быть пустым. Отправь ещё раз.',
    'ads_times_btn': '{n}×/день',
    'ads_ask_times': '📅 Сколько раз в день показывать объявление? (чем больше — тем дороже)',
    'ads_free_submitted': '✅ Бесплатное объявление #{id} отправлено на проверку администратору.\nПосле одобрения оно будет показываться раз в день в бесплатных группах, подключённых к боту.',
    'ads_duration_btn': '{days} дн. — ⭐{stars}',
    'ads_ask_duration': 'Выбери срок показа объявления (выбранная частота: {times}×/день):',
    'ads_btn_pay_stars': '⭐ Оплатить Stars ({stars})',
    'ads_btn_pay_ton': '💎 Оплатить TON ({ton})',
    'ads_order_summary': 'Сводка заказа #{id}:\n• Частота: {times}×/день\n• Срок: {days} дн.\n• Цена: ⭐{stars}',
    'ads_order_summary_ton_suffix': ' / 💎{ton} TON',
    'ads_order_summary_footer': '\n\nВыбери способ оплаты:',
    'ads_order_invalid': '⚠️ Этот заказ больше не действителен.',
    'ads_sending_invoice': '⭐ Отправляем счёт для оплаты через Telegram Stars...',
    'ads_invoice_title': '📢 Покупка рекламы — заказ #{id}',
    'ads_invoice_desc': 'Покупка показов рекламы в группах, подключённых к NEXOR (только бесплатный тариф).',
    'ads_invoice_label': 'Реклама NEXOR',
    'ads_ton_disabled': '⚠️ Оплата через TON сейчас недоступна, либо заказ недействителен.',
    'ads_ton_payment_info': '💎 Оплата через TON — заказ #{id}\n\nСумма: {amount} TON\nАдрес кошелька: {address}\n⚠️ Обязательно укажи этот код в Comment/Memo перевода:\n{memo}\n\nПрямая ссылка: {link}\n\nПосле перевода транзакция будет проверена автоматически, и объявление попадёт в очередь на проверку администратора.',
    'ads_cancelled': 'Отменено.',
    'ads_ton_confirmed': '✅ Оплата TON подтверждена! Заказ на рекламу #{id} отправлен на проверку администратору.',
    'ads_admin_none_pending': 'Нет объявлений, ожидающих проверки.',
    'ads_btn_approve': '✅ Одобрить',
    'ads_btn_reject': '❌ Отклонить',
    'ads_kind_free': '🆓 Бесплатное',
    'ads_kind_paid': '💳 Купленное',
    'ads_admin_caption': '#{id} — {kind}\nЧастота/день: {times} — Срок: {days} дн.\n\n{text}',
    'ads_approved_toast': 'Одобрено ✅',
    'ads_approved_notify': '✅ Объявление #{id} одобрено и будет показываться в бесплатных группах по расписанию.',
    'ads_rejected_toast': 'Отклонено ❌',
    'ads_none_yet': 'Ты ещё не размещал объявлений. Начни с /ads.',
    'ads_status_draft': 'Черновик',
    'ads_status_pending_payment': 'Ожидает оплаты',
    'ads_status_pending_review': 'На проверке',
    'ads_status_active': 'Активно',
    'ads_status_rejected': 'Отклонено',
    'ads_status_expired': 'Истекло',
    'ads_status_active2': '✅ Активно',
    'ads_status_rejected2': '❌ Отклонено',
    'ads_status_expired2': '⌛ Истекло',
    'ads_myads_header': '📋 Твои объявления:\n',
    'ads_myads_line': '#{id} — {status} — {times}×/день — {days} дн.',
    'ads_myads_footer': '\nЧтобы посмотреть статистику объявления: /adstats <номер объявления> — например /adstats {id}',
    'ads_stats_usage': 'Укажи ещё и номер объявления, например:\n/adstats 3\n\nНомера своих объявлений можно увидеть через /myads.',
    'ads_stats_not_found': 'Такое объявление не найдено или оно не твоё.',
    'ads_stats_title': '📊 Статистика объявления #{id}',
    'ads_stats_status': 'Статус: {status}',
    'ads_stats_quota': 'Дневная квота: {quota}×/день',
    'ads_stats_today': 'Показано сегодня: {today} из {quota}',
    'ads_stats_total': 'Всего показов (с самого начала): {total}',
    'ads_stats_unique': 'Количество уникальных групп, где показывалось объявление: {n}',
    'ads_stats_perday_header': '\nПо дням (последние дни):',
    'ads_stats_perday_line': '  {day}: {count} раз',
    'ads_stats_no_views': '\nПоказов по этому объявлению пока нет (или оно ещё не одобрено/не активно).',
    'ads_stars_confirmed': '✅ Оплата подтверждена! Заказ на рекламу #{id} отправлен на проверку администратору.',
    'err_invalid_language': 'Неверный язык.',
    # ---- Buyplan payments (added) ----
    'buyplan_invoice_title': '👑 Подписка {plan} ({months} мес.)',
    'buyplan_invoice_desc': 'Повышение группы до тарифа {plan} на {months} мес.',
    'buyplan_invoice_price_label': '{plan} — {months} мес.',
    'err_order_invalid': 'Этот заказ больше не действителен.',
    'buyplan_stars_confirmed': '✅ Оплата подтверждена!\n👑 Группа переведена на тариф {plan}.',
    'buyplan_card_order_not_found': '⚠️ Заказ не найден или уже обработан.',
    'buyplan_card_confirmed_dm': '✅ Оплата картой подтверждена!\n👑 Группа переведена на тариф {plan}.',
    'buyplan_card_admin_confirmed': '✅ Заказ #{id} подтверждён, тариф {plan} активирован.',
    'buyplan_card_admin_rejected': '❌ Заказ #{id} отклонён.',
    'buyplan_card_none_pending': 'Нет карточных заказов, ожидающих проверки.',
    'buyplan_card_pending_header': '💳 Карточные заказы, ожидающие подтверждения:\n',
    'buyplan_card_pending_line': '#{id} — {plan} × {months} мес. — код: {code}',
    'buyplan_ton_instructions': '💎 Покупка подписки {plan} через TON\n\nСумма: {amount} TON\nАдрес кошелька: {address}\n⚠️ Обязательно укажи этот код в Comment/Memo перевода:\n{memo}\n\nИли используй эту ссылку в своём кошельке:\n{link}\n\nПосле получения перевода транзакция проверяется автоматически, и подписка активируется (может занять несколько минут).',
    'buyplan_ton_confirmed': '✅ Оплата TON подтверждена!\n👑 Группа переведена на тариф {plan}.',
    'buyplan_card_header': '💳 Покупка подписки {plan} банковским переводом\n',
    'buyplan_card_amount': 'Сумма: {amount} туманов',
    'buyplan_card_number': 'Номер карты: {number}',
    'buyplan_card_holder': 'Получатель: {holder}',
    'buyplan_card_reference': '\nКод заказа для отслеживания: {ref}',
    'buyplan_card_instructions': 'После перевода отправь фото чека вместе с кодом заказа выше администратору бота, чтобы подписку подтвердили и активировали вручную.',
    'buyplan_header': '👑 Повышение тарифа NEXOR Copilot\nВыбери тариф:',
    'buyplan_choose_method': 'Тариф {plan} — выбери способ оплаты:',
    'buyplan_closed': 'Закрыто.',
    'buyplan_dm_failed': '⚠️ Не удалось отправить тебе личное сообщение. Сначала напиши боту /start в личном чате, затем снова попробуй /buyplan.',
    'buyplan_stars_sent': '⭐ Счёт на оплату через Stars отправлен в твой личный чат с ботом. Заверши оплату там.',
    'buyplan_ton_sent': '💎 Инструкции по оплате TON (адрес кошелька + код memo) отправлены в твой личный чат с ботом.',
    'buyplan_ton_unavailable': '⚠️ Оплата через TON сейчас недоступна для этого тарифа.',
    # ---- Command menu descriptions (added) ----
    'cmd_desc_start': 'Начать работу с ботом',
    'cmd_desc_help': 'Справка по командам',
    'cmd_desc_settings': 'Настройки группы',
    'cmd_desc_setlang': 'Сменить язык группы (админ)',
    'cmd_desc_rules': 'Правила группы',
    'cmd_desc_warn': 'Предупредить пользователя',
    'cmd_desc_unwarn': 'Снять одно предупреждение',
    'cmd_desc_warns': 'Показать предупреждения пользователя',
    'cmd_desc_mute': 'Заглушить пользователя',
    'cmd_desc_unmute': 'Снять заглушение',
    'cmd_desc_ban': 'Забанить пользователя',
    'cmd_desc_unban': 'Разбанить пользователя',
    'cmd_desc_kick': 'Выгнать пользователя',
    'cmd_desc_del': 'Удалить сообщение (ответом)',
    'cmd_desc_purge': 'Массовое удаление сообщений',
    'cmd_desc_lock': 'Заблокировать тип контента',
    'cmd_desc_unlock': 'Снять блокировку',
    'cmd_desc_locks': 'Показать активные блокировки',
    'cmd_desc_promote': 'Повысить до внутреннего админа',
    'cmd_desc_demote': 'Снять с внутреннего админа',
    'cmd_desc_roles': 'Список внутренних админов',
    'cmd_desc_logs': 'Последние действия админов',
    'cmd_desc_copilot': '🤖 NEXOR Copilot (AI-помощник админов)',
    'cmd_desc_buyplan': '👑 Повысить тариф (Stars / TON) — без рекламы',
    'cmd_desc_ads': '📢 Разместить бесплатное объявление или купить рекламу',
    'cmd_desc_myads': '📋 Мои объявления',
    'cmd_desc_adstats': '📊 Статистика объявления',
    'cmd_desc_adadmin': '🛠 Очередь проверки объявлений (админ)',

    # ==================== Ежедневные уведомления (Daily Notify) ====================
    "day_mon": "Понедельник", "day_tue": "Вторник", "day_wed": "Среда", "day_thu": "Четверг",
    "day_fri": "Пятница", "day_sat": "Суббота", "day_sun": "Воскресенье",
    "month_g_1": "Январь", "month_g_2": "Февраль", "month_g_3": "Март", "month_g_4": "Апрель",
    "month_g_5": "Май", "month_g_6": "Июнь", "month_g_7": "Июль", "month_g_8": "Август",
    "month_g_9": "Сентябрь", "month_g_10": "Октябрь", "month_g_11": "Ноябрь", "month_g_12": "Декабрь",
    "month_j_1": "Farvardin", "month_j_2": "Ordibehesht", "month_j_3": "Khordad", "month_j_4": "Tir",
    "month_j_5": "Mordad", "month_j_6": "Shahrivar", "month_j_7": "Mehr", "month_j_8": "Aban",
    "month_j_9": "Azar", "month_j_10": "Dey", "month_j_11": "Bahman", "month_j_12": "Esfand",
    "date_format_gregorian": "{weekday}, {day} {month} {year}",
    "date_format_jalali": "{weekday}, {day} {month} {year}",

    "daily_date_line": "📅 Сегодня: {date}",
    "daily_occasion_line": "🎉 Праздник: {occasion}",

    "daily_price_header": "💰 Курсы на сегодня",
    "daily_price_line": "• {asset}: {value} {unit}",
    "daily_price_footer": "Источник: {sources}",

    "daily_news_header": "📰 Новости дня",
    "daily_news_item": "{n}. {title}",
    "daily_news_summary": "   {summary}",
    "daily_news_source": "   🔗 Источник: {source}",

    "asset_gold18": "Золото 750 пробы (18К)", "asset_usd": "Доллар США (USD)", "asset_eur": "Евро (EUR)",
    "asset_usdt": "Tether (USDT)", "asset_ton": "Toncoin (TON)", "asset_stars": "Telegram Stars",
    "asset_btc": "Биткоин (BTC)", "asset_eth": "Эфириум (ETH)",
    "unit_toman": "туман", "unit_usd": "USD",

    "panel_not_owner": "Эта панель отвечает только тому, кто её открыл.",

    "dn_menu_header": "🔔 *Ежедневные уведомления*",
    "dn_menu_prices": "💰 Курсы: {state} — в {time}",
    "dn_menu_assets_line": "   Активные активы: {assets}",
    "dn_menu_news": "📰 Новости: {state} — в {time}",
    "dn_menu_timezone": "🌍 Часовой пояс: {tz}",
    "dn_menu_date_flags": "📅 Дата/праздник — Курсы: {dp}/{op}   Новости: {dn}/{on}",

    "dn_btn_toggle_prices": "💰 Вкл/выкл курсы",
    "dn_btn_toggle_news": "📰 Вкл/выкл новости",
    "dn_btn_assets": "🪙 Выбрать активы",
    "dn_btn_flags": "📅 Настройки даты/праздника",
    "dn_btn_test_price": "🧪 Тест курсов",
    "dn_btn_test_news": "🧪 Тест новостей",
    "dn_btn_help": "❓ Помощь",
    "dn_btn_close": "❌ Закрыть",

    "dn_assets_header": "🪙 Нажмите на актив, чтобы включить/выключить его:",
    "dn_flags_header": "📅 Настройте показ даты/праздника отдельно для курсов и новостей:",
    "dn_flag_date_price": "Дата в сообщении с курсами",
    "dn_flag_occasion_price": "Праздник в сообщении с курсами",
    "dn_flag_date_news": "Дата в сообщении с новостями",
    "dn_flag_occasion_news": "Праздник в сообщении с новостями",

    "dn_help_text": (
        "📖 *Справка по ежедневным уведомлениям*\n\n"
        "💰 Курсы и 📰 Новости отправляются в эту группу каждый день в указанное время.\n\n"
        "/setpricetime HH:MM — время отправки курсов\n"
        "/setnewstime HH:MM — время отправки новостей\n"
        "/setdailytz часовой_пояс — например Asia/Tehran (по умолчанию — по языку группы)\n"
        "/testdailyprice   /testdailynews — отправить тестовое сообщение сейчас\n"
        "/dailyassets — выбрать отображаемые активы\n"
        "Остальные настройки (вкл/выкл, дата/праздник) меняются кнопками выше."
    ),
    "dn_toast_saved": "✅ Сохранено.",
    "dn_toast_sending": "⏳ Отправка...",
    "dn_test_no_data": "⚠️ Сейчас нет достоверных данных (провайдер недоступен или новых материалов ещё нет).",

    "dn_log_toggle_prices": "Ежедневные курсы: {state}",
    "dn_log_toggle_news": "Ежедневные новости: {state}",
    "dn_log_settime": "Время отправки {what}: {time}",
    "dn_log_settz": "Часовой пояс ежедневных уведомлений: {tz}",

    "dn_settime_usage": "Использование: {cmd} HH:MM (например 09:00)",
    "dn_settime_invalid": "⛔️ Неверный формат времени. Используйте HH:MM (например 09:00).",
    "dn_settime_done": "✅ Время отправки установлено на {time}.",
    "dn_settz_usage": "Использование: /setdailytz часовой_пояс (например Asia/Tehran)",
    "dn_settz_invalid": "⛔️ Неверный часовой пояс. Введите корректный IANA часовой пояс, например Asia/Tehran.",
    "dn_settz_done": "✅ Часовой пояс группы: {tz}",

    "cmd_desc_dailynotify": "🔔 Настройки ежедневных уведомлений (курсы/новости)",
}


# ---------------------------------------------------------------------------
# TEXT_TRIGGERS (Русский) — کلمه/عبارتی که کاربر به‌جای دستور "/" تایپ می‌کند
# تا با همون تابع handlers/text_commands.py وصل بشه. هر شناسه (کلید) دقیقاً
# با همون نامی که در handlers/text_commands.py::COMMANDS استفاده شده باید یکی باشه.
# ---------------------------------------------------------------------------
TEXT_TRIGGERS = {
    "help": ["помощь"],
    "settings": ["настройки"],
    "warn": ["предупреждение"],
    "unwarn": ["снять предупреждение"],
    "warns": ["предупреждения"],
    "mute": ["мут"],
    "unmute": ["снять мут"],
    "ban": ["бан"],
    "unban": ["разбан"],
    "kick": ["кик"],
    "del": ["удалить"],
    "purge": ["очистить"],
    "promote": ["повысить"],
    "demote": ["понизить"],
    "roles": ["модераторы"],
    "logs": ["журнал"],
    "setlang": ["сменить язык"],
    "lock": ["заблокировать"],
    "unlock": ["разблокировать"],
    "locks": ["блокировки"],
    "filter": ["фильтр"],
    "stopfilter": ["удалить фильтр"],
    "filters": ["фильтры"],
    "domains": ["заблокированные домены"],
    "forwardrules": ["правила пересылки"],
    "antiraid": ["антирейд"],
    "lockdown": ["полная блокировка"],
    "unlockchat": ["открыть группу"],
    "captcha": ["капча"],
    "goodbye": ["прощание"],
    "rules": ["правила"],
    "setrules": ["установить правила"],
    "clearrules": ["очистить правила"],
    "addkeyword": ["добавить ключевое слово"],
    "delkeyword": ["удалить ключевое слово"],
    "keywords": ["ключевые слова"],
    "setanswer": ["настроить автоответ"],
    "answerlist": ["список автоответов"],
    "cleananswerlist": ["очистить список автоответов"],
    "delanswer": ["удалить автоответ"],
    "addcmd": ["добавить команду"],
    "delcmd": ["удалить команду"],
    "cmds": ["команды"],
    "setchannel": ["установить канал"],
    "post": ["пост"],
    "schedulepost": ["запланировать пост"],
    "editpost": ["редактировать пост"],
    "delpost": ["удалить пост"],
    "channelstats": ["статистика канала"],
    "addautoaction": ["добавить автодействие"],
    "delautoaction": ["удалить автодействие"],
    "autoactions": ["автодействия"],
    "profiles": ["профили"],
    "myperms": ["мои права"],
    "report": ["жалоба"],
    "reports": ["жалобы"],
    "alerts": ["уведомления"],
    "exportsettings": ["экспорт настроек"],
    "save": ["сохранить"],
    "get": ["получить"],
    "notes": ["заметки"],
    "clear": ["очистить заметку"],
    "setlogchannel": ["установить канал журнала"],
    "fnew": ["новая федерация"],
    "fjoin": ["вступить в федерацию"],
    "fleave": ["покинуть федерацию"],
    "finfo": ["информация о федерации"],
    "adminpanel": ["админ", "панель"],
    "fban": ["бан по федерации"],
    "funban": ["разбан по федерации"],
    "copilot": ["помощник", "ии помощник", "копилот"],
    "aicheck": ["проверка ии"],
    "aiexplain": ["объяснить действие"],
    "aireports": ["анализ жалоб"],
    "aihealth": ["здоровье группы"],
    "airule": ["советник по правилам"],
    "aioptimize": ["оптимизация правил"],
    "aiincident": ["анализ инцидента"],
    "aiplan": ["ии тариф"],
    # ==================== Phase 3 migration additions ====================
    "allowword": ["разрешить слово"],
    "disallowword": ["запретить слово"],
    "blockdomain": ["заблокировать домен"],
    "unblockdomain": ["разблокировать домен"],
    "allowdomain": ["разрешить домен"],
    "unallowdomain": ["отменить разрешение домена"],
    "allowforward": ["разрешить пересылку"],
    "blockforward": ["заблокировать пересылку"],
    "unruleforward": ["удалить правило пересылки"],
    "setfilteraction": ["настроить действие фильтра"],
    "mentionprotection": ["защита от упоминаний"],
    "setmentionlimit": ["установить лимит упоминаний"],
    "setmentionaction": ["настроить действие упоминания"],
    "antispam": ["антиспам"],
    "setspamaction": ["настроить действие спама"],
    "dupcross": ["дубли между группами"],
    "setdupcross": ["настроить дубли между группами"],
    "setflood": ["настроить флуд"],
    "setfloodaction": ["настроить действие флуда"],
    "setraidthreshold": ["настроить порог рейда"],
    "setmaxwarns": ["установить макс. предупреждений"],
    "setwarnaction": ["настроить действие предупреждения"],
    "setwelcomedelete": ["автоудаление приветствия"],
    "setgoodbye": ["настроить прощание"],
    "resetgoodbye": ["сбросить прощание"],
    "createprofile": ["создать профиль"],
    "delprofile": ["удалить профиль"],
    "assignprofile": ["назначить профиль"],
    "unassignprofile": ["снять профиль"],
    "setalertchannel": ["настроить канал оповещений"],
    "importsettings": ["импортировать настройки"],
    "schedulerecurring": ["запланировать повторяющийся пост"],
    "recurringposts": ["повторяющиеся посты"],
    "delrecurring": ["удалить повторяющийся пост"],
    "autoactiontoggle": ["переключить автодействие"],
    "dailynotify": ["ежедневное уведомление"],
    "setpricetime": ["настроить время цены"],
    "setnewstime": ["настроить время новостей"],
    "setdailytz": ["настроить часовой пояс"],
    "testdailyprice": ["тест ежедневной цены"],
    "testdailynews": ["тест ежедневных новостей"],
    "dailyassets": ["ежедневные активы"],
    "ads": ["реклама"],
    "myads": ["мои объявления"],
    "adadmin": ["управление рекламой"],
    "adstats": ["статистика рекламы"],
    "buyplan": ["купить план"],
}
