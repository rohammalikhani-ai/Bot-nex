# -*- coding: utf-8 -*-
"""
Auto Actions (Priority 4, Item 24): Rule Engine ساده‌ی Condition → Action.

Conditionها:
    message_type:<photo|video|sticker|voice|gif|video_note|document|poll|forward|link|text>
    user_role:<user|moderator|admin>
    warns_gte:<n>                (تعداد اخطار فعلی کاربر >= n — از handlers/moderation.py صدا زده می‌شه)

Actionها:
    delete | warn | mute:<minutes> | ban | kick

نکات مهم:
- این سیستم مستقل از قوانین Warning استاندارد (MAX_WARNS/setwarnaction) عمل
  می‌کند؛ یعنی مکمل آن‌هاست، نه جایگزین.
- روی ادمین/مالک واقعی گروه هرگز اکشن خودکار اجرا نمی‌شود (Hierarchy رعایت می‌شود).
"""
import re

from telegram import Update, ChatPermissions
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc
from config import (
    RANK_ADMIN, RANK_MODERATOR, RANK_USER,
    AUTO_ACTION_CONDITION_TYPES, AUTO_ACTION_MESSAGE_TYPES,
    AUTO_ACTION_USER_ROLES, AUTO_ACTION_TYPES, AUTO_ACTION_MUTE_MINUTES,
)
from handlers.common import admin_only, get_rank, log_action, authorize_action
from utils import parse_duration

LINK_REGEX = re.compile(r"(https?://\S+|www\.\S+)", re.IGNORECASE)

_ROLE_LABEL = {RANK_USER: "user", RANK_MODERATOR: "moderator", RANK_ADMIN: "admin"}


def _detect_message_type(message) -> str:
    if message.photo:
        return "photo"
    if message.video:
        return "video"
    if message.sticker:
        return "sticker"
    if message.voice:
        return "voice"
    if message.animation:
        return "gif"
    if message.video_note:
        return "video_note"
    if message.document:
        return "document"
    if message.poll:
        return "poll"
    if getattr(message, "forward_origin", None) or getattr(message, "forward_from", None):
        return "forward"
    if message.text and LINK_REGEX.search(message.text):
        return "link"
    if message.text:
        return "text"
    return ""


# Authorization is centralized in handlers.common -> services.authorization.
async def _execute_action(context: ContextTypes.DEFAULT_TYPE, chat_id: int, user_id: int, name: str,
                           action_type: str, action_value: str, rule_id: int):
    reason = tc(chat_id, "autoaction_reason", id=rule_id)
    capability = action_type
    minimum_rank = RANK_ADMIN if action_type == "ban" else RANK_MODERATOR
    target_for_auth = None if action_type == "delete" else user_id
    allowed, _ = await authorize_action(context, chat_id, context.bot.id, capability, target_for_auth, minimum_rank)
    if not allowed:
        return
    try:
        if action_type == "delete":
            return  # حذف پیام در فراخوان (evaluate_message) انجام می‌شود چون به message نیاز داره
        elif action_type == "warn":
            from handlers.moderation import _do_warn  # جلوگیری از Import حلقوی
            await _do_warn(context, chat_id, user_id, name, reason, context.bot.id, "AutoAction")
        elif action_type == "mute":
            from datetime import datetime, timedelta
            if action_value and action_value.isdigit():
                seconds = int(action_value) * 60
            elif action_value:
                seconds = parse_duration(action_value) or (AUTO_ACTION_MUTE_MINUTES * 60)
            else:
                seconds = AUTO_ACTION_MUTE_MINUTES * 60
            until = datetime.now() + timedelta(seconds=seconds)
            await context.bot.restrict_chat_member(
                chat_id, user_id, permissions=ChatPermissions(can_send_messages=False), until_date=until
            )
        elif action_type == "ban":
            await context.bot.ban_chat_member(chat_id, user_id)
        elif action_type == "kick":
            await context.bot.ban_chat_member(chat_id, user_id)
            await context.bot.unban_chat_member(chat_id, user_id)
        await log_action(context, chat_id, f"AutoAction #{rule_id}: {action_type} -> {name}",
                          context.bot.id, "AutoAction", f"autoaction_{action_type}", user_id, name, reason)
    except Exception:
        import logging
        logging.getLogger(__name__).exception("auto action %s failed for chat %s user %s", action_type, chat_id, user_id)


async def evaluate_message_rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """روی هر پیام معمولی (غیر Command) اجرا می‌شود — گروه جدا از بقیه‌ی پایپ‌لاین."""
    message = update.message
    if not message or not update.effective_user:
        return
    chat_id = update.effective_chat.id
    user_id = update.effective_user.id

    if db.get_setting(chat_id, "autoaction_enabled", "on") != "on":
        return

    rank = await get_rank(context, chat_id, user_id)
    if rank >= RANK_ADMIN:
        return  # هرگز روی ادمین/مالک واقعی اکشن خودکار اجرا نمی‌شه

    msg_type = _detect_message_type(message)
    role_label = _ROLE_LABEL.get(rank, "user")
    name = update.effective_user.first_name or str(user_id)

    rules = db.get_auto_action_rules(chat_id, "message_type") + db.get_auto_action_rules(chat_id, "user_role")
    for rule_id, condition_type, condition_value, action_type, action_value in rules:
        matched = (
            (condition_type == "message_type" and condition_value == msg_type) or
            (condition_type == "user_role" and condition_value == role_label)
        )
        if not matched:
            continue
        if action_type == "delete":
            try:
                await message.delete()
            except Exception as exc:
                import logging
                logging.getLogger(__name__).warning("auto-delete failed for chat %s: %s", chat_id, exc)
            await log_action(context, chat_id, f"AutoAction #{rule_id}: delete -> {name}",
                              context.bot.id, "AutoAction", "autoaction_delete", user_id, name,
                              tc(chat_id, "autoaction_reason", id=rule_id))
        else:
            await _execute_action(context, chat_id, user_id, name, action_type, action_value, rule_id)
        return  # فقط اولین قانون منطبق اجرا می‌شود تا اکشن‌های متناقض روی هم اجرا نشن


async def evaluate_warn_rules(context: ContextTypes.DEFAULT_TYPE, chat_id: int, user_id: int, name: str, count: int):
    """از handlers/moderation.py بعد از هر اخطار صدا زده می‌شود (زیرساخت مشترک)."""
    if db.get_setting(chat_id, "autoaction_enabled", "on") != "on":
        return
    for rule_id, condition_type, condition_value, action_type, action_value in db.get_auto_action_rules(chat_id, "warns_gte"):
        try:
            threshold = int(condition_value)
        except ValueError:
            continue
        if count >= threshold:
            await _execute_action(context, chat_id, user_id, name, action_type, action_value, rule_id)
            return


# ---------------- Commands ----------------

def _parse_condition(raw: str):
    if ":" not in raw:
        return None
    ctype, cvalue = raw.split(":", 1)
    ctype, cvalue = ctype.strip().lower(), cvalue.strip().lower()
    if ctype not in AUTO_ACTION_CONDITION_TYPES:
        return None
    if ctype == "message_type" and cvalue not in AUTO_ACTION_MESSAGE_TYPES:
        return None
    if ctype == "user_role" and cvalue not in AUTO_ACTION_USER_ROLES:
        return None
    if ctype == "warns_gte" and not cvalue.isdigit():
        return None
    return ctype, cvalue


def _parse_action(raw: str):
    atype, _, avalue = raw.partition(":")
    atype = atype.strip().lower()
    if atype not in AUTO_ACTION_TYPES:
        return None
    avalue = avalue.strip()
    if atype == "mute" and avalue and not avalue.isdigit() and parse_duration(avalue) is None:
        return None
    return atype, avalue


async def addautoaction_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    args = context.args or []
    if len(args) < 2:
        await update.message.reply_text(tc(chat_id, "addautoaction_usage"))
        return

    condition = _parse_condition(args[0])
    if not condition:
        await update.message.reply_text(tc(chat_id, "addautoaction_invalid_condition"))
        return
    action = _parse_action(args[1])
    if not action:
        await update.message.reply_text(tc(chat_id, "addautoaction_invalid_action"))
        return

    ctype, cvalue = condition
    atype, avalue = action
    rule_id = db.add_auto_action_rule(chat_id, ctype, cvalue, atype, avalue)
    await update.message.reply_text(tc(
        chat_id, "addautoaction_done", id=rule_id,
        condition=f"{ctype}:{cvalue}", action=f"{atype}:{avalue}" if avalue else atype,
    ))


async def delautoaction_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text(tc(chat_id, "delautoaction_usage"))
        return
    rule_id = int(context.args[0])
    if db.remove_auto_action_rule(rule_id, chat_id):
        await update.message.reply_text(tc(chat_id, "delautoaction_done", id=rule_id))
    else:
        await update.message.reply_text(tc(chat_id, "delautoaction_notfound"))


async def autoactions_list_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    rows = db.get_auto_action_rules(chat_id)
    if not rows:
        await update.message.reply_text(tc(chat_id, "autoactions_empty"))
        return
    header = tc(chat_id, "autoactions_header")
    lines = [header]
    for rule_id, ctype, cvalue, atype, avalue in rows:
        action_label = f"{atype}:{avalue}" if avalue else atype
        lines.append(f"#{rule_id} — {ctype}:{cvalue} → {action_label}")
    await update.message.reply_text("\n".join(lines))


async def autoactiontoggle_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("on", "off"):
        await update.message.reply_text(tc(chat_id, "autoactiontoggle_usage"))
        return
    state = context.args[0].lower()
    db.set_setting(chat_id, "autoaction_enabled", state)
    state_label = tc(chat_id, "state_on") if state == "on" else tc(chat_id, "state_off")
    await update.message.reply_text(tc(chat_id, "autoactiontoggle_done", state=state_label))
