# -*- coding: utf-8 -*-
"""
Filters (Priority 4, Item 21): Keyword Trigger -> Automatic Response.

مهم: این قابلیت کاملاً مستقل از Forbidden Words Filter (handlers/locks_filters.py,
دستورات /filter /stopfilter /filters) است و نباید با آن ادغام شود — آن سیستم
پیام را حذف/اکشن می‌کند، این سیستم فقط یک پاسخ خودکار برمی‌گرداند و کاری به
حذف پیام ندارد. به همین دلیل نام دستورها هم متفاوت انتخاب شده (addkeyword/
delkeyword/keywords) تا با /filter تداخل نکند.
"""
from telegram import Update
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc
from handlers.common import admin_only

MAX_KEYWORD_LEN = 64


async def addkeyword_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    args = context.args or []
    if not args:
        await update.message.reply_text(tc(chat_id, "addkeyword_usage"))
        return

    keyword = args[0].lower().strip()[:MAX_KEYWORD_LEN]

    if update.message.reply_to_message:
        response = update.message.reply_to_message.text or update.message.reply_to_message.caption or ""
    else:
        response = " ".join(args[1:]).strip()

    if not response:
        await update.message.reply_text(tc(chat_id, "addkeyword_usage"))
        return

    is_new = db.add_keyword_trigger(chat_id, keyword, response)
    key = "addkeyword_done" if is_new else "addkeyword_updated"
    await update.message.reply_text(tc(chat_id, key, keyword=keyword))


async def delkeyword_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "delkeyword_usage"))
        return
    keyword = context.args[0].lower().strip()
    if db.remove_keyword_trigger(chat_id, keyword):
        await update.message.reply_text(tc(chat_id, "delkeyword_done", keyword=keyword))
    else:
        await update.message.reply_text(tc(chat_id, "delkeyword_notfound"))


async def keywords_list_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    rows = db.list_keyword_triggers(chat_id)
    if not rows:
        await update.message.reply_text(tc(chat_id, "keywords_empty"))
        return
    header = tc(chat_id, "keywords_header")
    lines = [f"• {kw}" for kw, _ in rows]
    await update.message.reply_text(header + "\n" + "\n".join(lines))


async def keyword_trigger_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    روی هر پیام متنی معمولی اجرا می‌شود (گروه جدا و مستقل از پایپ‌لاین
    Moderation) و اگر متن پیام حاوی یکی از Keywordهای ثبت‌شده باشد،
    پاسخ خودکار مربوطه را می‌فرستد. با دستورات (/...) کاری ندارد.
    """
    message = update.message
    if not message or not message.text:
        return
    chat_id = update.effective_chat.id
    text_lower = message.text.lower()

    rows = db.list_keyword_triggers(chat_id)
    for keyword, response in rows:
        if keyword in text_lower:
            await message.reply_text(response)
            return
