# -*- coding: utf-8 -*-
"""
مدیریت اعضا: Ban/Unban، Mute/Unmute، Kick، Warning System، Delete/Purge.

پشتیبانی از سه روش هدف‌گیری کاربر: ریپلای، @username، user_id عددی.
پشتیبانی از مدت‌زمان (Temporary Ban/Mute) با فرمت‌هایی مثل 10m / 2h / 1d.
پشتیبانی از دلیل (Reason) که در پیام و در Audit Log ثبت می‌شود.
تمام اکشن‌ها Hierarchy-aware هستند و همه‌ی متن‌ها چندزبانه (i18n) هستند.
"""
from __future__ import annotations  # keep list[int] hints working on Python < 3.9

import logging
import time
from datetime import datetime, timedelta

from telegram import Update, ChatPermissions, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc, get_lang, t
from config import MAX_WARNS, DEFAULT_WARN_ACTION, DEFAULT_WARN_MUTE_MINUTES, RANK_ADMIN, RANK_MODERATOR
from handlers.common import (
    admin_only, moderator_only, resolve_target, parse_reason_and_duration,
    log_action, get_rank, authorize_action,
)
from handlers import auto_actions
from utils import format_duration

FULL_PERMISSIONS = ChatPermissions(
    can_send_messages=True, can_send_photos=True, can_send_videos=True,
    can_send_other_messages=True, can_send_polls=True, can_add_web_page_previews=True,
)


logger = logging.getLogger(__name__)

async def _need_target(update, usage: str):
    chat_id = update.effective_chat.id
    await update.message.reply_text(tc(chat_id, "err_need_target", usage=usage))


def _quick_actions_keyboard(chat_id: int, target_id: int):
    lang = get_lang(chat_id)
    return InlineKeyboardMarkup([[
        InlineKeyboardButton(t(lang, "btn_remove_warn"), callback_data=f"modact:unwarn:{chat_id}:{target_id}"),
        InlineKeyboardButton(t(lang, "btn_mute"), callback_data=f"modact:mute:{chat_id}:{target_id}"),
        InlineKeyboardButton(t(lang, "btn_ban"), callback_data=f"modact:ban:{chat_id}:{target_id}"),
    ]])


async def _do_warn(context, chat_id, target_id, name, reason, actor_id, actor_name):
    """
    هسته‌ی مشترک Warn: هم از دستور /warn استفاده می‌شه هم از سیستم‌های خودکار
    (Anti-Spam/Anti-Flood/Forbidden Words) با actor_name سیستمی مثل "AntiSpam".
    """
    max_warns = int(db.get_setting(chat_id, "max_warns", MAX_WARNS))
    count = db.get_warns(chat_id, target_id) + 1
    now = time.time()
    db.set_warns(chat_id, target_id, count, reason, now)
    db.add_warn_log(chat_id, target_id, actor_id, reason or "-", now)

    # Priority 4, Item 24 — Auto Actions: قوانین warns_gte مستقل از سقف اخطار استاندارد
    await auto_actions.evaluate_warn_rules(context, chat_id, target_id, name, count)

    if count >= max_warns:
        action = db.get_setting(chat_id, "warn_action", DEFAULT_WARN_ACTION)
        db.set_warns(chat_id, target_id, 0)
        if action == "mute":
            until = datetime.now() + timedelta(minutes=DEFAULT_WARN_MUTE_MINUTES)
            await context.bot.restrict_chat_member(
                chat_id, target_id, permissions=ChatPermissions(can_send_messages=False), until_date=until
            )
            text = tc(chat_id, "warn_escalate_mute", name=name, max=max_warns,
                      duration=format_duration(DEFAULT_WARN_MUTE_MINUTES * 60))
            log_verb = "warn_escalate_mute"
        else:
            await context.bot.ban_chat_member(chat_id, target_id)
            text = tc(chat_id, "warn_escalate_ban", name=name, max=max_warns)
            log_verb = "warn_escalate_ban"
        await context.bot.send_message(chat_id, text)
        await log_action(context, chat_id, text, actor_id, actor_name, log_verb, target_id, name, reason)
        return None
    else:
        text = tc(chat_id, "warn_given", name=name, count=count, max=max_warns)
        if reason:
            text += tc(chat_id, "warn_reason_line", reason=reason)
        sent = await context.bot.send_message(chat_id, text, reply_markup=_quick_actions_keyboard(chat_id, target_id))
        await log_action(context, chat_id, text, actor_id, actor_name, "warn", target_id, name, reason)
        return sent


async def apply_enforcement(context: ContextTypes.DEFAULT_TYPE, chat_id: int, target_id: int, name: str,
                             action: str, reason: str, actor_id: int = 0, actor_name: str = "System"):
    """
    اجرای اکشن قابل‌تنظیم برای سیستم‌های خودکار (Anti-Spam، Anti-Flood،
    Forbidden Words، Link Protection): "delete" یعنی فقط همون پیام حذف بشه
    (که قبلش توسط caller انجام شده)، "warn"/"mute"/"ban" یعنی علاوه بر حذف،
    این تنبیه هم روی کاربر اعمال بشه — با همون قالب پیام و لاگ دستورهای دستی.
    """
    if action == "delete" or not action:
        await log_action(context, chat_id, f"🗑️ {actor_name}: {reason} ({name})",
                          actor_id, actor_name, f"auto_delete", target_id, name, reason)
        return

    if action == "warn":
        await _do_warn(context, chat_id, target_id, name, reason, actor_id, actor_name)
        return

    if action == "mute":
        until = datetime.now() + timedelta(minutes=AUTO_ACTION_MUTE_MINUTES)
        await context.bot.restrict_chat_member(
            chat_id, target_id, permissions=ChatPermissions(can_send_messages=False), until_date=until
        )
        text = tc(chat_id, "mute_done", name=name, duration=format_duration(AUTO_ACTION_MUTE_MINUTES * 60))
        text += tc(chat_id, "warn_reason_line", reason=reason)
        await context.bot.send_message(chat_id, text)
        await log_action(context, chat_id, text, actor_id, actor_name, "auto_mute", target_id, name, reason)
        return

    if action == "ban":
        await context.bot.ban_chat_member(chat_id, target_id)
        text = tc(chat_id, "ban_done", name=name, duration=tc(chat_id, "duration_permanent"))
        text += tc(chat_id, "warn_reason_line", reason=reason)
        await context.bot.send_message(chat_id, text)
        await log_action(context, chat_id, text, actor_id, actor_name, "auto_ban", target_id, name, reason)
        return


# ---------------- Warn ----------------

async def warn_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    target_id, name, rest = await resolve_target(update, context)
    if not target_id:
        await _need_target(update, "/warn [ریپلای|@user|id] [دلیل]")
        return
    ok, err = await authorize_action(context, chat_id, update.effective_user.id, "warn", target_id, RANK_MODERATOR)
    if not ok:
        await update.message.reply_text(err)
        return

    _, reason = parse_reason_and_duration(rest)
    actor = update.effective_user
    await _do_warn(context, chat_id, target_id, name, reason, actor.id, actor.first_name)


async def unwarn_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    target_id, name, _ = await resolve_target(update, context)
    if not target_id:
        await _need_target(update, "/unwarn [ریپلای|@user|id]")
        return
    ok, err = await authorize_action(context, chat_id, update.effective_user.id, "unwarn", target_id, RANK_MODERATOR)
    if not ok:
        await update.message.reply_text(err)
        return
    count = max(0, db.get_warns(chat_id, target_id) - 1)
    db.set_warns(chat_id, target_id, count)
    max_warns = int(db.get_setting(chat_id, "max_warns", MAX_WARNS))
    await update.message.reply_text(tc(chat_id, "warn_removed", name=name, count=count, max=max_warns))


async def warns_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """نمایش تعداد و تاریخچه اخطارهای یک کاربر."""
    chat_id = update.effective_chat.id
    target_id, name, _ = await resolve_target(update, context)
    if not target_id:
        await _need_target(update, "/warns [ریپلای|@user|id]")
        return
    count = db.get_warns(chat_id, target_id)
    max_warns = int(db.get_setting(chat_id, "max_warns", MAX_WARNS))
    history = db.get_warn_history(chat_id, target_id, limit=5)
    lines = [tc(chat_id, "warns_header", name=name, count=count, max=max_warns)]
    no_reason = tc(chat_id, "warns_no_reason")
    for actor_id, reason, ts in history:
        when = datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")
        lines.append(tc(chat_id, "warns_history_line", when=when, reason=reason or no_reason,
                         actor=db.get_cached_name(actor_id)))
    await update.message.reply_text("\n".join(lines))


async def setwarnaction_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("mute", "ban"):
        await update.message.reply_text(tc(chat_id, "setwarnaction_usage"))
        return
    db.set_setting(chat_id, "warn_action", context.args[0].lower())
    await update.message.reply_text(tc(chat_id, "setwarnaction_done", action=context.args[0].lower()))


async def setmaxwarns_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or not context.args[0].isdigit() or int(context.args[0]) < 1:
        await update.message.reply_text(tc(chat_id, "setmaxwarns_usage"))
        return
    db.set_setting(chat_id, "max_warns", int(context.args[0]))
    await update.message.reply_text(tc(chat_id, "setmaxwarns_done", n=context.args[0]))


# ---------------- Mute / Unmute ----------------

async def _execute_mute(context: ContextTypes.DEFAULT_TYPE, chat_id: int, target_id: int,
                         name: str, duration, reason) -> str:
    """اکشن واقعی mute (بدون reply/log) — استخراج‌شده از mute_cmd تا هم دستور
    «/mute» و هم مسیر تایید Natural Language (handlers/natural_language.py)
    دقیقاً از همین یک پیاده‌سازی استفاده کنند و منطق دوبار نوشته نشود.
    رفتار/خروجی نسبت به نسخه‌ی قبلی mute_cmd کاملاً بدون تغییر است.
    """
    until = datetime.now() + timedelta(seconds=duration) if duration else None
    await context.bot.restrict_chat_member(
        chat_id, target_id, permissions=ChatPermissions(can_send_messages=False), until_date=until,
    )
    dur_text = format_duration(duration) if duration else tc(chat_id, "duration_permanent")
    text = tc(chat_id, "mute_done", name=name, duration=dur_text)
    if reason:
        text += tc(chat_id, "warn_reason_line", reason=reason)
    return text


async def mute_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    target_id, name, rest = await resolve_target(update, context)
    if not target_id:
        await _need_target(update, "/mute [ریپلای|@user|id] [مدت] [دلیل]")
        return
    ok, err = await authorize_action(context, chat_id, update.effective_user.id, "mute", target_id, RANK_MODERATOR)
    if not ok:
        await update.message.reply_text(err)
        return

    duration, reason = parse_reason_and_duration(rest)
    text = await _execute_mute(context, chat_id, target_id, name, duration, reason)
    await update.message.reply_text(text)
    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "mute", target_id, name, reason)


async def unmute_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    target_id, name, _ = await resolve_target(update, context)
    if not target_id:
        await _need_target(update, "/unmute [ریپلای|@user|id]")
        return
    ok, err = await authorize_action(context, chat_id, update.effective_user.id, "unmute", target_id, RANK_MODERATOR)
    if not ok:
        await update.message.reply_text(err)
        return
    text = await _execute_unmute(context, chat_id, target_id, name)
    await update.message.reply_text(text)
    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "unmute", target_id, name, None)


async def _execute_unmute(context: ContextTypes.DEFAULT_TYPE, chat_id: int, target_id: int, name: str) -> str:
    """استخراج‌شده از unmute_cmd — دلیل و رفتار مثل _execute_mute (بالا)."""
    await context.bot.restrict_chat_member(chat_id, target_id, permissions=FULL_PERMISSIONS)
    return tc(chat_id, "unmute_done", name=name)


# ---------------- Ban / Unban ----------------

async def _execute_ban(context: ContextTypes.DEFAULT_TYPE, chat_id: int, target_id: int,
                        name: str, duration, reason) -> str:
    """استخراج‌شده از ban_cmd — تا هم «/ban» و هم مسیر تایید Natural Language
    (handlers/natural_language.py) از همین یک پیاده‌سازی استفاده کنند."""
    until = datetime.now() + timedelta(seconds=duration) if duration else None
    await context.bot.ban_chat_member(chat_id, target_id, until_date=until)
    dur_text = format_duration(duration) if duration else tc(chat_id, "duration_permanent")
    text = tc(chat_id, "ban_done", name=name, duration=dur_text)
    if reason:
        text += tc(chat_id, "warn_reason_line", reason=reason)
    return text


async def ban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    target_id, name, rest = await resolve_target(update, context)
    if not target_id:
        await _need_target(update, "/ban [ریپلای|@user|id] [مدت] [دلیل]")
        return
    ok, err = await authorize_action(context, chat_id, update.effective_user.id, "ban", target_id, RANK_ADMIN)
    if not ok:
        await update.message.reply_text(err)
        return

    duration, reason = parse_reason_and_duration(rest)
    text = await _execute_ban(context, chat_id, target_id, name, duration, reason)
    await update.message.reply_text(text)
    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "ban", target_id, name, reason)


async def _execute_unban(context: ContextTypes.DEFAULT_TYPE, chat_id: int, target_id: int, name: str) -> str:
    """استخراج‌شده از unban_cmd."""
    await context.bot.unban_chat_member(chat_id, target_id)
    return tc(chat_id, "unban_done", name=name)


async def unban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    target_id, name, _ = await resolve_target(update, context)
    if not target_id:
        await _need_target(update, "/unban [ریپلای|@user|id]")
        return
    ok, err = await authorize_action(context, chat_id, update.effective_user.id, "unban", target_id, RANK_ADMIN)
    if not ok:
        await update.message.reply_text(err)
        return
    text = await _execute_unban(context, chat_id, target_id, name)
    await update.message.reply_text(text)
    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "unban", target_id, name, None)


# ---------------- Kick ----------------

async def _execute_kick(context: ContextTypes.DEFAULT_TYPE, chat_id: int, target_id: int,
                         name: str, reason) -> str:
    """استخراج‌شده از kick_cmd."""
    await context.bot.ban_chat_member(chat_id, target_id)
    await context.bot.unban_chat_member(chat_id, target_id)
    text = tc(chat_id, "kick_done", name=name)
    if reason:
        text += tc(chat_id, "warn_reason_line", reason=reason)
    return text


async def kick_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    target_id, name, rest = await resolve_target(update, context)
    if not target_id:
        await _need_target(update, "/kick [ریپلای|@user|id] [دلیل]")
        return
    ok, err = await authorize_action(context, chat_id, update.effective_user.id, "kick", target_id, RANK_MODERATOR)
    if not ok:
        await update.message.reply_text(err)
        return

    _, reason = parse_reason_and_duration(rest)
    text = await _execute_kick(context, chat_id, target_id, name, reason)
    await update.message.reply_text(text)
    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "kick", target_id, name, reason)


# ---------------- Delete / Purge ----------------

async def _execute_delete_messages(context: ContextTypes.DEFAULT_TYPE, chat_id: int, message_ids: list[int]) -> int:
    """استخراج‌شده از del_cmd/purge_cmd — حذف best-effort یک یا چند پیام
    (خطای هر پیام جداگانه لاگ می‌شه و مانع بقیه نمی‌شه، دقیقاً مثل رفتار
    قبلی این دو تابع)."""
    deleted = 0
    for mid in message_ids:
        try:
            await context.bot.delete_message(chat_id, mid)
            deleted += 1
        except Exception:
            logger.exception("non-fatal operation failed")
    return deleted


async def del_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    ok, err = await authorize_action(context, chat_id, update.effective_user.id, "delete", None, RANK_MODERATOR)
    if not ok:
        await update.message.reply_text(err)
        return
    if not update.message.reply_to_message:
        await update.message.reply_text(tc(chat_id, "del_usage"))
        return
    await _execute_delete_messages(
        context, chat_id, [update.message.reply_to_message.message_id, update.message.message_id],
    )


async def purge_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /purge (با ریپلای روی یک پیام) → همه‌ی پیام‌های از آن پیام تا الان را حذف می‌کند.
    /purge N → آخرین N پیام (شامل خود دستور) را حذف می‌کند.
    """
    chat_id = update.effective_chat.id
    ok, err = await authorize_action(context, chat_id, update.effective_user.id, "purge", None, RANK_MODERATOR)
    if not ok:
        await update.message.reply_text(err)
        return
    cmd_msg_id = update.message.message_id

    if update.message.reply_to_message:
        start_id = update.message.reply_to_message.message_id
        ids = list(range(start_id, cmd_msg_id + 1))
    elif context.args and context.args[0].isdigit():
        n = min(int(context.args[0]), 200)
        ids = list(range(cmd_msg_id - n + 1, cmd_msg_id + 1))
    else:
        await update.message.reply_text(tc(chat_id, "purge_usage"))
        return

    deleted = 0
    for mid in ids:
        try:
            await context.bot.delete_message(chat_id, mid)
            deleted += 1
        except Exception:
            logger.exception("failed to delete message %s during purge in chat %s", mid, chat_id)

    actor = update.effective_user
    await context.bot.send_message(chat_id, tc(chat_id, "purge_done", count=deleted))
    await log_action(context, chat_id, tc(chat_id, "purge_done", count=deleted),
                      actor.id, actor.first_name, "purge", None, None, f"{deleted}")


# ---------------- Callback Query دکمه‌های سریع (امن) ----------------

async def modact_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Server-side validation کامل: صرفاً چون دکمه نمایش داده شده به این معنی
    نیست که کاربر مجازه. اینجا rank فرستنده‌ی کلیک و rank هدف دوباره از صفر
    چک می‌شود؛ کاربر نمی‌تونه با ساختن/تغییر callback_data یک اکشن مدیریتی
    غیرمجاز اجرا کنه چون همه‌چیز دوباره از API/دیتابیس verify میشه.
    """
    query = update.callback_query
    chat_id = update.effective_chat.id
    try:
        _, action, chat_id_s, target_id_s = query.data.split(":")
        cb_chat_id, target_id = int(chat_id_s), int(target_id_s)
    except ValueError:
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return

    if cb_chat_id != chat_id:
        await query.answer(tc(chat_id, "modact_wrong_chat"), show_alert=True)
        return

    clicker_id = query.from_user.id
    min_rank = RANK_ADMIN if action == "ban" else RANK_MODERATOR
    ok, err = await authorize_action(context, chat_id, clicker_id, action, target_id, min_rank)
    if not ok:
        await query.answer(err, show_alert=True)
        return

    target_name = db.get_cached_name(target_id)

    if action == "unwarn":
        count = max(0, db.get_warns(chat_id, target_id) - 1)
        db.set_warns(chat_id, target_id, count)
        result_text = tc(chat_id, "modact_unwarn_result", name=target_name, count=count)
    elif action == "mute":
        until = datetime.now() + timedelta(minutes=DEFAULT_WARN_MUTE_MINUTES)
        await context.bot.restrict_chat_member(
            chat_id, target_id, permissions=ChatPermissions(can_send_messages=False), until_date=until
        )
        result_text = tc(chat_id, "modact_mute_result", name=target_name, minutes=DEFAULT_WARN_MUTE_MINUTES)
    elif action == "ban":
        await context.bot.ban_chat_member(chat_id, target_id)
        result_text = tc(chat_id, "modact_ban_result", name=target_name)
    else:
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return

    await query.answer(tc(chat_id, "modact_done"))
    try:
        await query.edit_message_text(result_text)
    except Exception:
        logger.exception("non-fatal operation failed")

    clicker = query.from_user
    await log_action(context, chat_id, result_text, clicker.id, clicker.first_name,
                      f"quick_{action}", target_id, target_name, None)
