# -*- coding: utf-8 -*-
"""
Priority 5, Item 25 — Permission Profiles

علاوه بر Hierarchy فعلی (Owner / Admin / Moderator / User)، این ماژول امکان
ساخت Profile سفارشی را می‌دهد تا Owner بتواند دقیقاً مشخص کند یک کاربر خاص
(بدون ارتقای کامل به Moderator/Admin) به چه قابلیت‌هایی (config.CAPABILITIES)
دسترسی داشته باشد — مثلاً کاربری که فقط اجازه‌ی "delete" و "reports" دارد.

نکته امنیتی مهم: این سیستم هیچ‌وقت جایگزین Hierarchy نمی‌شود. یک کاربر با
Profile سفارشی هنوز هم فقط می‌تواند روی کاربرانی با Rank پایین‌تر از خودش
اکشن بزند (چک can_act_on همیشه جداگانه اجرا می‌شود) — Profile فقط "کدام
قابلیت‌ها" را مشخص می‌کند، نه اینکه Rank را دور بزند.

ساخت/حذف Profile فقط برای Owner است (چون این خودِ تعریفِ سطح دسترسی‌هاست)؛
Assign کردن یک Profile موجود به یک کاربر برای Admin به بالا هم آزاد است.
"""
from telegram import Update
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc
from config import CAPABILITIES, RANK_OWNER
from handlers.common import admin_only, require_rank, resolve_target, get_rank, log_action


async def createprofile_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/createprofile <name> <cap1,cap2,...> — فقط Owner."""
    if not await require_rank(update, context, RANK_OWNER):
        return
    chat_id = update.effective_chat.id
    args = context.args or []
    if len(args) < 2:
        await update.message.reply_text(tc(chat_id, "createprofile_usage", caps=", ".join(sorted(CAPABILITIES))))
        return

    name = args[0].lower().strip()
    raw_caps = {c.strip().lower() for c in " ".join(args[1:]).replace(" ", ",").split(",") if c.strip()}
    invalid = raw_caps - CAPABILITIES
    if invalid:
        await update.message.reply_text(
            tc(chat_id, "profile_invalid_caps", invalid=", ".join(sorted(invalid)), caps=", ".join(sorted(CAPABILITIES)))
        )
        return
    if not raw_caps:
        await update.message.reply_text(tc(chat_id, "createprofile_usage", caps=", ".join(sorted(CAPABILITIES))))
        return

    existed = db.get_permission_profile(chat_id, name) is not None
    db.set_permission_profile(chat_id, name, ",".join(sorted(raw_caps)))
    text = tc(chat_id, "createprofile_updated" if existed else "createprofile_done",
              name=name, caps=", ".join(sorted(raw_caps)))
    await update.message.reply_text(text)
    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "createprofile", None, name, None)


async def delprofile_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/delprofile <name> — فقط Owner."""
    if not await require_rank(update, context, RANK_OWNER):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "delprofile_usage"))
        return
    name = context.args[0].lower().strip()
    if not db.delete_permission_profile(chat_id, name):
        await update.message.reply_text(tc(chat_id, "delprofile_notfound"))
        return
    text = tc(chat_id, "delprofile_done", name=name)
    await update.message.reply_text(text)
    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "delprofile", None, name, None)


async def profiles_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/profiles — نمایش همه‌ی Profileهای این گروه به همراه کاربران Assign‌شده."""
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    rows = db.list_permission_profiles(chat_id)
    if not rows:
        await update.message.reply_text(tc(chat_id, "profiles_empty"))
        return
    assignments = db.list_profile_assignments(chat_id)
    lines = [tc(chat_id, "profiles_header")]
    for name, caps in rows:
        members = [uid for uid, prof in assignments if prof == name]
        member_names = ", ".join(db.get_cached_name(uid) for uid in members) if members else tc(chat_id, "none")
        lines.append(tc(chat_id, "profile_item", name=name, caps=caps.replace(",", ", "), members=member_names))
    await update.message.reply_text("\n".join(lines))


async def assignprofile_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/assignprofile [ریپلای|@user|id] <profile> — ادمین به بالا."""
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    target_id, name, rest = await resolve_target(update, context)
    if not target_id or not rest:
        await update.message.reply_text(tc(chat_id, "assignprofile_usage"))
        return
    profile_name = rest[0].lower().strip()
    if db.get_permission_profile(chat_id, profile_name) is None:
        await update.message.reply_text(tc(chat_id, "assignprofile_notfound_profile", name=profile_name))
        return
    db.assign_profile(chat_id, target_id, profile_name)
    text = tc(chat_id, "assignprofile_done", name=name, profile=profile_name)
    await update.message.reply_text(text)
    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "assignprofile", target_id, name, profile_name)


async def unassignprofile_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/unassignprofile [ریپلای|@user|id] — ادمین به بالا."""
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    target_id, name, _ = await resolve_target(update, context)
    if not target_id:
        await update.message.reply_text(tc(chat_id, "unassignprofile_usage"))
        return
    if not db.unassign_profile(chat_id, target_id):
        await update.message.reply_text(tc(chat_id, "unassignprofile_notfound"))
        return
    text = tc(chat_id, "unassignprofile_done", name=name)
    await update.message.reply_text(text)
    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "unassignprofile", target_id, name, None)


async def myperms_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/myperms — نمایش Rank فعلی و قابلیت‌های Profile اختصاصی (اگر داشته باشد)."""
    chat_id = update.effective_chat.id
    user = update.effective_user
    from config import RANK_USER, RANK_MODERATOR, RANK_ADMIN
    rank = await get_rank(context, chat_id, user.id)
    rank_key = {RANK_USER: "rank_user", RANK_MODERATOR: "rank_moderator",
                RANK_ADMIN: "rank_admin", RANK_OWNER: "rank_owner"}[rank]
    profile = db.get_profile_assignment(chat_id, user.id)
    if profile:
        caps = db.get_permission_profile(chat_id, profile) or ""
        text = tc(chat_id, "myperms_with_profile", rank=tc(chat_id, rank_key),
                   profile=profile, caps=caps.replace(",", ", "))
    else:
        text = tc(chat_id, "myperms_no_profile", rank=tc(chat_id, rank_key))
    await update.message.reply_text(text)
