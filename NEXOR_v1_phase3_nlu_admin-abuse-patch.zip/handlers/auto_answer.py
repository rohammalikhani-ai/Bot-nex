# -*- coding: utf-8 -*-
"""
پاسخ خودکار (Auto-Answer): کلیدواژه -> یک یا چند پاسخ (متن/رسانه)، با
هدف‌گذاری مخاطب (همه/فقط مقام‌داران/فقط مالکین) و کول‌داون ضدِاسپم.

کاملاً مستقل از handlers/keywords.py (سیستم قدیمی‌تر Keyword Trigger که
فقط متن ساده و بدون هدف‌گذاری/رسانه/کول‌داون است) — طبق همون قاعده‌ای که
خود آن ماژول هم رعایت کرده: هیچ ادغامی با سیستم‌های مشابه، تا رفتار هرکدوم
قابل پیش‌بینی و مستقل بمونه.

معماری Wizard (مراحل تنظیم در پیوی):
 ۱) در گروه، دستور «تنظیم پاسخ»/«/setanswer» یک دکمه‌ی «ورود به پیوی» با
    Deep Link می‌سازه (?start=aa_<chat_id>).
 ۲) با کلیک، basic.start_cmd پی‌لود رو تشخیص می‌ده و به start_wizard اینجا
    واگذار می‌کنه؛ اونجا رتبه‌ی کاربر توی همون گروه دوباره (از API واقعی
    تلگرام) چک می‌شه — نه صرفاً اعتماد به این‌که دکمه رو کی زده.
 ۳) وضعیت Wizard در context.user_data نگه داشته می‌شه (per-user، نه
    per-chat) چون خود مکالمه در پیوی (چت خصوصی با ربات) جریان داره، در حالی
    که چت هدف یک گروه دیگه‌ست؛ chat_data اینجا معنی نداره.
 ۴) مراحل: audience -> keyword -> responses (حداکثر ۲۰ پاسخ، هرکدوم متن یا
    یکی از انواع رسانه) -> با دکمه‌ی «پایان» ذخیره‌ی نهایی در دیتابیس.
"""
from __future__ import annotations

import logging
import random
import time

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import TelegramError
from telegram.ext import ContextTypes, filters

from repositories import store as db
from i18n import t, tc, get_lang, DEFAULT_LANG
from config import RANK_ADMIN, RANK_OWNER
from handlers.common import admin_only, get_rank

logger = logging.getLogger(__name__)

MAX_KEYWORD_LEN = 64
MAX_RESPONSES = 20
COOLDOWN_SECONDS = 10  # حداقل فاصله بین دو بار فعال شدن یک کلیدواژه در یک گروه

_WIZARD_KEY = "aa_wizard"

_AUDIENCE_LABEL_KEYS = {
    "all": "autoanswer_audience_all",
    "admins": "autoanswer_audience_admins",
    "owners": "autoanswer_audience_owners",
}

# کول‌داون ضدِاسپم: صرفاً در حافظه (نه دیتابیس) — با ری‌استارت ربات پاک
# می‌شه که مشکلی نیست، چون فقط جلوی اسپم لحظه‌ای رو می‌گیره.
_last_fired: dict[tuple[int, str], float] = {}

# فیلتر پیام‌های پیوی که ممکنه بخشی از Wizard باشن (متن یا یکی از انواع
# رسانه‌ی پشتیبانی‌شده)؛ private_content_handler خودش چک می‌کنه که کاربر
# واقعاً وسط Wizard هست یا نه — اگر نبود، کاملاً بی‌صدا رد می‌شه.
private_content_filter = (
    filters.ChatType.PRIVATE & ~filters.COMMAND & (
        filters.TEXT | filters.PHOTO | filters.VIDEO | filters.VOICE | filters.AUDIO
        | filters.Document.ALL | filters.ANIMATION | filters.Sticker.ALL | filters.VIDEO_NOTE
    )
)

# تریگر Auto-Answer فقط داخل گروه/سوپرگروه معنی داره.
group_text_filter = filters.TEXT & ~filters.COMMAND & filters.ChatType.GROUPS


# ---------------------------------------------------------------------------
# بخش گروه: دستورهای /setanswer /answerlist /cleananswerlist /delanswer
# ---------------------------------------------------------------------------

async def setanswer_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat = update.effective_chat
    if chat.type not in ("group", "supergroup"):
        await update.message.reply_text(tc(chat.id, "autoanswer_group_only"))
        return

    bot_username = context.bot.username
    deep_link = f"https://t.me/{bot_username}?start=aa_{chat.id}"
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(tc(chat.id, "autoanswer_pm_button"), url=deep_link)],
    ])
    await update.message.reply_text(
        tc(chat.id, "autoanswer_setup_intro", title=chat.title or ""),
        reply_markup=keyboard,
    )


async def answerlist_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    rows = db.list_auto_answers(chat_id)
    if not rows:
        await update.message.reply_text(tc(chat_id, "autoanswer_list_empty"))
        return

    lang = get_lang(chat_id)
    lines = [tc(chat_id, "autoanswer_list_header")]
    for keyword, audience, responses in rows:
        audience_label = t(lang, _AUDIENCE_LABEL_KEYS.get(audience, "autoanswer_audience_all"))
        lines.append(
            tc(chat_id, "autoanswer_list_item", keyword=keyword, audience=audience_label, count=len(responses))
        )
    await update.message.reply_text("\n".join(lines))


async def cleananswerlist_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    removed = db.clear_auto_answers(chat_id)
    if removed:
        await update.message.reply_text(tc(chat_id, "autoanswer_cleaned", count=removed))
    else:
        await update.message.reply_text(tc(chat_id, "autoanswer_list_empty"))


async def delanswer_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "delanswer_usage"))
        return
    keyword = context.args[0].lower().strip()
    if db.remove_auto_answer(chat_id, keyword):
        await update.message.reply_text(tc(chat_id, "delanswer_done", keyword=keyword))
    else:
        await update.message.reply_text(tc(chat_id, "delanswer_notfound"))


# ---------------------------------------------------------------------------
# بخش پیوی: Wizard چندمرحله‌ای
# ---------------------------------------------------------------------------

def _audience_kb(lang: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(t(lang, "autoanswer_audience_all"), callback_data="aa:aud:all")],
        [InlineKeyboardButton(t(lang, "autoanswer_audience_admins"), callback_data="aa:aud:admins")],
        [InlineKeyboardButton(t(lang, "autoanswer_audience_owners"), callback_data="aa:aud:owners")],
    ])


def _responses_kb(lang: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(t(lang, "autoanswer_btn_done"), callback_data="aa:done")],
        [InlineKeyboardButton(t(lang, "autoanswer_btn_cancel"), callback_data="aa:cancel")],
    ])


async def start_wizard(update: Update, context: ContextTypes.DEFAULT_TYPE, payload: str):
    """از basic.start_cmd صدا زده می‌شود وقتی پی‌لود با aa_ شروع شده باشد."""
    user = update.effective_user
    try:
        group_chat_id = int(payload[len("aa_"):])
    except ValueError:
        await update.message.reply_text(tc(update.effective_chat.id, "autoanswer_invalid_link"))
        return

    try:
        chat = await context.bot.get_chat(group_chat_id)
    except TelegramError:
        await update.message.reply_text(tc(update.effective_chat.id, "autoanswer_invalid_link"))
        return

    lang = get_lang(group_chat_id)
    rank = await get_rank(context, group_chat_id, user.id)
    if rank < RANK_ADMIN:
        await update.message.reply_text(t(lang, "autoanswer_not_admin"))
        return

    context.user_data[_WIZARD_KEY] = {
        "chat_id": group_chat_id,
        "chat_title": chat.title or str(group_chat_id),
        "lang": lang,
        "step": "audience",
        "audience": None,
        "keyword": None,
        "responses": [],
    }
    await update.message.reply_text(
        t(lang, "autoanswer_ask_audience", title=chat.title or ""),
        reply_markup=_audience_kb(lang),
    )


async def audience_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    wizard = context.user_data.get(_WIZARD_KEY)
    if not wizard or wizard.get("step") != "audience":
        await query.answer(t(DEFAULT_LANG, "autoanswer_expired"), show_alert=True)
        return

    lang = wizard["lang"]
    _, _, audience = query.data.split(":", 2)
    if audience not in ("all", "admins", "owners"):
        await query.answer()
        return

    # دفاع در عمق: شاید بین باز شدن Wizard و این کلیک، کاربر دیمود شده باشه.
    rank = await get_rank(context, wizard["chat_id"], query.from_user.id)
    if rank < RANK_ADMIN:
        await query.answer(t(lang, "autoanswer_not_admin"), show_alert=True)
        context.user_data.pop(_WIZARD_KEY, None)
        return

    wizard["audience"] = audience
    wizard["step"] = "keyword"
    await query.answer()
    try:
        await query.edit_message_text(t(lang, "autoanswer_ask_keyword"))
    except TelegramError:
        pass


async def done_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    wizard = context.user_data.get(_WIZARD_KEY)
    if not wizard or wizard.get("step") != "responses":
        await query.answer(t(DEFAULT_LANG, "autoanswer_expired"), show_alert=True)
        return

    lang = wizard["lang"]
    if not wizard["responses"]:
        await query.answer(t(lang, "autoanswer_need_one_response"), show_alert=True)
        return

    is_new = db.add_auto_answer(
        wizard["chat_id"], wizard["keyword"], wizard["audience"],
        wizard["responses"], query.from_user.id,
    )
    audience_label = t(lang, _AUDIENCE_LABEL_KEYS[wizard["audience"]])
    await query.answer()
    key = "autoanswer_saved" if is_new else "autoanswer_updated"
    try:
        await query.edit_message_text(t(
            lang, key,
            title=wizard["chat_title"], keyword=wizard["keyword"],
            audience=audience_label, count=len(wizard["responses"]),
        ))
    except TelegramError:
        pass
    context.user_data.pop(_WIZARD_KEY, None)


async def cancel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    wizard = context.user_data.pop(_WIZARD_KEY, None)
    lang = wizard["lang"] if wizard else DEFAULT_LANG
    await query.answer()
    try:
        await query.edit_message_text(t(lang, "autoanswer_cancelled"))
    except TelegramError:
        pass


def _extract_response(message) -> dict | None:
    """پیام پیوی را به یک آیتم پاسخ (dict) تبدیل می‌کند؛ اگر نوع پشتیبانی‌نشده باشد None."""
    if message.text:
        return {"type": "text", "text": message.text}
    if message.photo:
        return {"type": "photo", "file_id": message.photo[-1].file_id, "caption": message.caption or ""}
    if message.video:
        return {"type": "video", "file_id": message.video.file_id, "caption": message.caption or ""}
    if message.voice:
        return {"type": "voice", "file_id": message.voice.file_id, "caption": message.caption or ""}
    if message.audio:
        return {"type": "audio", "file_id": message.audio.file_id, "caption": message.caption or ""}
    if message.animation:
        return {"type": "animation", "file_id": message.animation.file_id, "caption": message.caption or ""}
    if message.document:
        return {"type": "document", "file_id": message.document.file_id, "caption": message.caption or ""}
    if message.sticker:
        return {"type": "sticker", "file_id": message.sticker.file_id, "caption": ""}
    if message.video_note:
        return {"type": "video_note", "file_id": message.video_note.file_id, "caption": ""}
    return None


async def private_content_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """روی هر پیام (متن/رسانه) در چت خصوصی اجرا می‌شود؛ اگر کاربر وسط Wizard
    نباشد، کاری نمی‌کند (کاملاً بی‌صدا، تا با سایر گفتگوهای پیوی تداخل نکند)."""
    wizard = context.user_data.get(_WIZARD_KEY)
    if not wizard:
        return
    message = update.effective_message
    lang = wizard["lang"]

    if wizard["step"] == "keyword":
        if not message.text:
            await message.reply_text(t(lang, "autoanswer_ask_keyword"))
            return
        keyword = message.text.lower().strip()[:MAX_KEYWORD_LEN]
        if not keyword:
            await message.reply_text(t(lang, "autoanswer_ask_keyword"))
            return
        wizard["keyword"] = keyword
        wizard["step"] = "responses"
        await message.reply_text(
            t(lang, "autoanswer_ask_response", keyword=keyword),
            reply_markup=_responses_kb(lang),
        )
        return

    if wizard["step"] == "responses":
        if len(wizard["responses"]) >= MAX_RESPONSES:
            await message.reply_text(t(lang, "autoanswer_max_responses", max=MAX_RESPONSES),
                                      reply_markup=_responses_kb(lang))
            return
        item = _extract_response(message)
        if item is None:
            await message.reply_text(t(lang, "autoanswer_unsupported_content"),
                                      reply_markup=_responses_kb(lang))
            return
        wizard["responses"].append(item)
        await message.reply_text(
            t(lang, "autoanswer_response_added", count=len(wizard["responses"]), max=MAX_RESPONSES),
            reply_markup=_responses_kb(lang),
        )
        return


# ---------------------------------------------------------------------------
# بخش گروه: تشخیص و ارسال پاسخ خودکار روی پیام‌های معمولی
# ---------------------------------------------------------------------------

async def _send_response(message, item: dict):
    kind = item.get("type")
    caption = item.get("caption") or None
    if kind == "text":
        await message.reply_text(item.get("text", ""))
    elif kind == "photo":
        await message.reply_photo(item["file_id"], caption=caption)
    elif kind == "video":
        await message.reply_video(item["file_id"], caption=caption)
    elif kind == "voice":
        await message.reply_voice(item["file_id"], caption=caption)
    elif kind == "audio":
        await message.reply_audio(item["file_id"], caption=caption)
    elif kind == "animation":
        await message.reply_animation(item["file_id"], caption=caption)
    elif kind == "document":
        await message.reply_document(item["file_id"], caption=caption)
    elif kind == "sticker":
        await message.reply_sticker(item["file_id"])
    elif kind == "video_note":
        await message.reply_video_note(item["file_id"])


async def auto_answer_trigger_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """روی هر پیام متنی معمولی گروه اجرا می‌شود (مستقل از Moderation/Keyword
    Trigger قدیمی) و در صورت تطبیق کلیدواژه، هدف‌گذاری مخاطب و رد شدن از
    کول‌داون ضدِاسپم، یکی از پاسخ‌های ثبت‌شده را (به‌صورت تصادفی) می‌فرستد."""
    message = update.message
    if not message or not message.text:
        return
    chat_id = update.effective_chat.id
    match = db.find_matching_auto_answer(chat_id, message.text.lower())
    if not match:
        return
    keyword, audience, responses = match
    if not responses:
        return

    user = update.effective_user
    if audience != "all":
        rank = await get_rank(context, chat_id, user.id)
        if audience == "admins" and rank < RANK_ADMIN:
            return
        if audience == "owners" and rank < RANK_OWNER:
            return

    cooldown_key = (chat_id, keyword)
    now = time.time()
    last = _last_fired.get(cooldown_key, 0.0)
    if now - last < COOLDOWN_SECONDS:
        return
    _last_fired[cooldown_key] = now

    try:
        await _send_response(message, random.choice(responses))
    except TelegramError:
        logger.exception("Auto-Answer: failed to send response for keyword %r in chat %s", keyword, chat_id)
