# -*- coding: utf-8 -*-
"""
هندلر سراسری خطا: هر خطای مدیریت‌نشده رو لاگ می‌کنه و در صورت تنظیم
OWNER_ID، خلاصه‌ی خطا رو به چت خصوصی صاحب ربات می‌فرسته تا خبردار بشه.
"""

import html
import logging
import traceback

from telegram import Update
from telegram.ext import ContextTypes

from config import OWNER_ID
from i18n import tc

logger = logging.getLogger(__name__)


async def _notify_user_of_error(update: object) -> None:
    """بخش 21 پرامپت (Error UX): قبلاً وقتی یک دستور با خطای مدیریت‌نشده
    مواجه می‌شد، فقط owner ربات خبردار می‌شد — کاربری که دستور رو زده بود
    هیچی نمی‌دید (نه پیام خطا، نه هیچ چیز؛ سکوت کامل). این تابع (best-effort،
    هیچ‌وقت exception اضافه پرتاب نمی‌کنه) یک پیام کوتاه و localized به
    همون کاربر می‌فرسته: چه اتفاقی افتاد + چیکار کنه (دوباره امتحان کنه)."""
    if not isinstance(update, Update):
        return
    message = update.effective_message
    if not message:
        return
    chat = update.effective_chat
    if not chat:
        return
    try:
        await message.reply_text(tc(chat.id, "err_unexpected"))
    except Exception:
        logger.exception("non-fatal operation failed")


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.error("خطای مدیریت‌نشده رخ داد:", exc_info=context.error)

    await _notify_user_of_error(update)

    if not OWNER_ID:
        return  # اگه owner تنظیم نشده، فقط لاگ می‌کنیم

    tb_list = traceback.format_exception(None, context.error, context.error.__traceback__)
    tb_string = "".join(tb_list)[-2500:]  # فقط بخش انتهایی برای جلوگیری از پیام خیلی طولانی

    update_str = update.to_dict() if isinstance(update, Update) else str(update)

    message = (
        "⚠️ <b>خطای ربات</b>\n\n"
        f"<pre>{html.escape(str(context.error))}</pre>\n\n"
        f"<b>Update:</b>\n<pre>{html.escape(str(update_str)[:500])}</pre>\n\n"
        f"<b>Traceback:</b>\n<pre>{html.escape(tb_string)}</pre>"
    )

    try:
        # تلگرام پیام‌های HTML رو محدود به ۴۰۹۶ کاراکتر می‌کنه
        await context.bot.send_message(chat_id=OWNER_ID, text=message[:4000], parse_mode="HTML")
    except Exception:
        # اگه حتی گزارش خطا هم fail بشه، فقط لاگ می‌مونه
        logger.error("گزارش خطا به owner هم ناموفق بود.")


async def healthcheck_job(context: ContextTypes.DEFAULT_TYPE):
    """هر چند ساعت یک‌بار یک پیام سلامت به owner می‌فرسته (اختیاری)."""
    if not OWNER_ID:
        return
    try:
        await context.bot.send_message(chat_id=OWNER_ID, text="✅ ربات سالم و در حال اجراست.")
    except Exception:
        logger.exception("non-fatal operation failed")
