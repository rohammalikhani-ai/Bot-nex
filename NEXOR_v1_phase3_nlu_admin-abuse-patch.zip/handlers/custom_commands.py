# -*- coding: utf-8 -*-
"""
Custom Commands (Priority 4, Item 22): امکان ساخت Command سفارشی توسط Admin.

پیاده‌سازی: نام‌های سفارشی در دیتابیس ذخیره می‌شوند و یک MessageHandler عمومی
(روی همه‌ی پیام‌های Command) در آخرین گروه هندلرها ثبت می‌شود تا هرگز با
دستورهای واقعی ربات (که در main.py با CommandHandler ثبت شده‌اند) تداخل
نکند؛ به‌علاوه از ساخت Command با نام رزروشده (RESERVED_COMMAND_NAMES) هم
جلوگیری می‌شود.
"""
from telegram import Update
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc
from config import RESERVED_COMMAND_NAMES
from handlers.common import admin_only

MAX_NAME_LEN = 32


async def addcmd_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    args = context.args or []
    if not args:
        await update.message.reply_text(tc(chat_id, "addcmd_usage"))
        return

    name = args[0].lower().strip().lstrip("/")[:MAX_NAME_LEN]
    if not name or not all(c.isalnum() or c == "_" for c in name):
        await update.message.reply_text(tc(chat_id, "addcmd_usage"))
        return

    if name in RESERVED_COMMAND_NAMES:
        await update.message.reply_text(tc(chat_id, "addcmd_reserved"))
        return

    if update.message.reply_to_message:
        response = update.message.reply_to_message.text or update.message.reply_to_message.caption or ""
    else:
        response = " ".join(args[1:]).strip()

    if not response:
        await update.message.reply_text(tc(chat_id, "addcmd_usage"))
        return

    is_new = db.add_custom_command(chat_id, name, response)
    key = "addcmd_done" if is_new else "addcmd_updated"
    await update.message.reply_text(tc(chat_id, key, name=name))


async def delcmd_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "delcmd_usage"))
        return
    name = context.args[0].lower().strip().lstrip("/")
    if db.remove_custom_command(chat_id, name):
        await update.message.reply_text(tc(chat_id, "delcmd_done", name=name))
    else:
        await update.message.reply_text(tc(chat_id, "delcmd_notfound"))


async def cmds_list_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    rows = db.list_custom_commands(chat_id)
    if not rows:
        await update.message.reply_text(tc(chat_id, "cmds_empty"))
        return
    header = tc(chat_id, "cmds_header")
    lines = [f"/{name}" for name, _ in rows]
    await update.message.reply_text(header + "\n" + "\n".join(lines))


async def dispatch_custom_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    روی همه‌ی پیام‌های Command اجرا می‌شود (گروه بسیار پایین‌تر از دستورهای
    واقعی). اگر متن دستور در جدول custom_commands این چت پیدا شود، پاسخ آن
    فرستاده می‌شود؛ در غیر این صورت هیچ کاری نمی‌کند (روی دستورهای واقعی که
    قبلاً توسط CommandHandler خودشان پردازش شدند اثری ندارد).
    """
    message = update.message
    if not message or not message.text or not message.text.startswith("/"):
        return
    chat = update.effective_chat
    if chat.type not in ("group", "supergroup"):
        return

    cmd_token = message.text.split()[0][1:]
    cmd_name = cmd_token.split("@")[0].lower()  # حذف @botusername اگر باشه

    if cmd_name in RESERVED_COMMAND_NAMES:
        return

    response = db.get_custom_command(chat.id, cmd_name)
    if response:
        await message.reply_text(response)
