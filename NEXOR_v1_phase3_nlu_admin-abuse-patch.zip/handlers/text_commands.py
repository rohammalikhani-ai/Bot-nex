# -*- coding: utf-8 -*-
"""
اجرای دستورات با تایپ یک کلمه/عبارت عادی، بدون نیاز به «/» — به زبان خود گروه.

مثال: در گروهی که زبانش فارسی است نوشتن «راهنما» همون کاری رو می‌کنه که
«/help» می‌کنه؛ در گروهی که زبانش انگلیسی است، همون کار با نوشتن «help»
انجام می‌شه. عبارت‌ها از locales/<lang>.py::TEXT_TRIGGERS خونده می‌شن، پس
اضافه‌کردن زبان جدید فقط نیاز به یک TEXT_TRIGGERS در فایل زبان جدید داره.

طراحی: هر عبارت به همون تابع‌هایی که در handlers/registry.py برای
دستورهای اصلی (/) استفاده می‌شن وصل می‌شه؛ یعنی منطق دقیقاً یکی هست، فقط
روش صدا زدنش فرق داره.

نکته‌ی امنیتی مهم (رفع باگ):
قبلاً این دیسپچر مستقیماً تابع دستور رو صدا می‌زد و اجازه می‌داد خود تابع
(با admin_only/authorize_action) تصمیم بگیره. مشکل این بود که حتی وقتی
فرستنده اصلاً اجازه نداشت، دیسپچر پیام رو "قاپیده" و یک پاسخ (پیام خطا یا
درخواست هدف) از ربات نشون می‌داد — یعنی از دید کاربر، تایپ کلمه‌ی «اخراج»
هم برای عضو عادی و هم برای ادمین "یه اتفاقی" می‌افتاد، در حالی که فقط برای
ادمین/مدیر باید اتفاقی بیفته. الان COMMANDS پایین، حداقل رتبه‌ی لازم برای
هر دستور رو نگه می‌داره و دیسپچر قبل از صدا زدن تابع، رتبه‌ی فرستنده رو
چک می‌کنه؛ اگر کافی نبود، دیسپچر کلاً کاری نمی‌کنه (کاملاً بی‌صدا) — دقیقاً
مثل این‌که کاربر عادی هیچ‌وقت این عبارت رو ننوشته. این چک صرفاً یک "فیلتر
سریع" برای همین سطح دیسپچره؛ چک نهایی و دقیق (Hierarchy با هدف، Permission
Profile و ...) هنوز هم داخل خود تابع دستور (authorize_action/admin_only)
انجام می‌شه و دست‌نخورده مونده.
"""
from telegram import Update
from telegram.ext import ContextTypes, filters

from config import RANK_USER, RANK_MODERATOR, RANK_ADMIN, RANK_OWNER
from i18n import get_lang, DEFAULT_LANG
from handlers.common import get_rank, profile_capabilities
from handlers import (
    basic, moderation, locks_filters, captcha, notes, channel, federation,
    roles, security, rules, keywords, custom_commands, auto_actions,
    profiles, reports, alerts, settings_io, logs, admin_panel, ai_copilot, guide,
    auto_answer, ads, daily_notify, payments,
)

# ---------------------------------------------------------------------------
# رجیستری مرکزی: شناسه‌ی دستور -> (تابع اجراکننده، حداقل رتبه‌ی لازم، قابلیت
# قابل‌واگذاری با Permission Profile).
#
# min_rank=None یعنی دستور عمومیه (مثل راهنما یا نمایش تنظیمات فعلی) و همه
# می‌تونن با تایپ کلمه اجراش کنن — دقیقاً هم‌رفتار با نسخه‌ی «/» همون دستور.
#
# capability فقط برای دستورهایی پر می‌شه که از authorize_action با Permission
# Profile استفاده می‌کنن (warn/mute/kick/ban/...)؛ یعنی حتی اگر رتبه‌ی
# فرستنده کافی نباشه ولی یک Profile اختصاصی این قابلیت رو بهش داده باشه،
# دیسپچر اجازه‌ی رد شدن به مرحله‌ی بعد (چک دقیق داخل خود تابع) رو می‌ده.
# ---------------------------------------------------------------------------
COMMANDS = {
    "help": (guide.guide_cmd, None, None),
    "settings": (basic.settings_cmd, RANK_ADMIN, None),

    "warn": (moderation.warn_cmd, RANK_MODERATOR, "warn"),
    "unwarn": (moderation.unwarn_cmd, RANK_MODERATOR, "unwarn"),
    "warns": (moderation.warns_cmd, None, None),
    "mute": (moderation.mute_cmd, RANK_MODERATOR, "mute"),
    "unmute": (moderation.unmute_cmd, RANK_MODERATOR, "unmute"),
    "ban": (moderation.ban_cmd, RANK_ADMIN, "ban"),
    "unban": (moderation.unban_cmd, RANK_ADMIN, "unban"),
    "kick": (moderation.kick_cmd, RANK_MODERATOR, "kick"),
    "del": (moderation.del_cmd, RANK_MODERATOR, "delete"),
    "purge": (moderation.purge_cmd, RANK_MODERATOR, "purge"),

    "promote": (roles.promote_cmd, RANK_ADMIN, None),
    "demote": (roles.demote_cmd, RANK_ADMIN, None),
    "roles": (roles.roles_cmd, None, None),
    "logs": (roles.logs_cmd, RANK_ADMIN, None),
    "setlang": (roles.setlang_cmd, RANK_ADMIN, None),

    "lock": (locks_filters.lock_cmd, RANK_ADMIN, None),
    "unlock": (locks_filters.unlock_cmd, RANK_ADMIN, None),
    "locks": (locks_filters.locks_cmd, None, None),
    "filter": (locks_filters.filter_cmd, RANK_ADMIN, None),
    "stopfilter": (locks_filters.stopfilter_cmd, RANK_ADMIN, None),
    "filters": (locks_filters.filters_cmd, None, None),
    "domains": (locks_filters.domains_cmd, None, None),
    "forwardrules": (locks_filters.forwardrules_cmd, None, None),

    "antiraid": (security.antiraid_cmd, RANK_ADMIN, None),
    "lockdown": (security.lockdown_cmd, RANK_ADMIN, None),
    "unlockchat": (security.unlock_cmd, RANK_ADMIN, None),

    "captcha": (captcha.captcha_toggle_cmd, RANK_ADMIN, None),
    "goodbye": (captcha.goodbye_toggle_cmd, RANK_ADMIN, None),

    "rules": (rules.rules_cmd, None, None),
    "setrules": (rules.setrules_cmd, RANK_ADMIN, None),
    "clearrules": (rules.clearrules_cmd, RANK_ADMIN, None),

    "addkeyword": (keywords.addkeyword_cmd, RANK_ADMIN, None),
    "delkeyword": (keywords.delkeyword_cmd, RANK_ADMIN, None),
    "keywords": (keywords.keywords_list_cmd, None, None),

    "setanswer": (auto_answer.setanswer_cmd, RANK_ADMIN, None),
    "answerlist": (auto_answer.answerlist_cmd, None, None),
    "cleananswerlist": (auto_answer.cleananswerlist_cmd, RANK_ADMIN, None),
    "delanswer": (auto_answer.delanswer_cmd, RANK_ADMIN, None),

    "addcmd": (custom_commands.addcmd_cmd, RANK_ADMIN, None),
    "delcmd": (custom_commands.delcmd_cmd, RANK_ADMIN, None),
    "cmds": (custom_commands.cmds_list_cmd, None, None),

    "setchannel": (channel.setchannel_cmd, RANK_ADMIN, None),
    "post": (channel.post_cmd, RANK_ADMIN, None),
    "schedulepost": (channel.schedulepost_cmd, RANK_ADMIN, None),
    "editpost": (channel.editpost_cmd, RANK_ADMIN, None),
    "delpost": (channel.delpost_cmd, RANK_ADMIN, None),
    "channelstats": (channel.channelstats_cmd, None, None),

    "addautoaction": (auto_actions.addautoaction_cmd, RANK_ADMIN, None),
    "delautoaction": (auto_actions.delautoaction_cmd, RANK_ADMIN, None),
    "autoactions": (auto_actions.autoactions_list_cmd, RANK_ADMIN, None),

    "profiles": (profiles.profiles_cmd, RANK_ADMIN, None),
    "myperms": (profiles.myperms_cmd, None, None),

    "report": (reports.report_cmd, None, None),
    "reports": (reports.reports_cmd, RANK_MODERATOR, "reports"),
    "alerts": (alerts.alerts_cmd, RANK_ADMIN, None),
    "adminabuseprotection": (alerts.adminabuseprotection_cmd, RANK_OWNER, None),

    "exportsettings": (settings_io.exportsettings_cmd, RANK_ADMIN, None),

    "save": (notes.save_note_cmd, RANK_ADMIN, None),
    "get": (notes.get_note_cmd, None, None),
    "notes": (notes.notes_list_cmd, None, None),
    "clear": (notes.clear_note_cmd, RANK_ADMIN, None),

    "setlogchannel": (logs.setlogchannel_cmd, RANK_ADMIN, None),

    "fnew": (federation.fnew_cmd, RANK_ADMIN, None),
    "fjoin": (federation.fjoin_cmd, RANK_ADMIN, None),
    "fleave": (federation.fleave_cmd, RANK_ADMIN, None),
    "finfo": (federation.finfo_cmd, None, None),
    "fban": (federation.fban_cmd, RANK_ADMIN, None),
    "funban": (federation.funban_cmd, RANK_ADMIN, None),

    "adminpanel": (admin_panel.admin_panel_cmd, RANK_MODERATOR, None),

    "copilot": (ai_copilot.copilot_cmd, RANK_MODERATOR, "ai_copilot"),
    "aicheck": (ai_copilot.aicheck_cmd, RANK_MODERATOR, "ai_copilot"),
    "aiexplain": (ai_copilot.aiexplain_cmd, RANK_MODERATOR, "ai_copilot"),
    "aireports": (ai_copilot.aireports_cmd, RANK_MODERATOR, "ai_copilot"),
    "aihealth": (ai_copilot.aihealth_cmd, RANK_MODERATOR, "ai_copilot"),
    "airule": (ai_copilot.airule_cmd, RANK_MODERATOR, "ai_copilot"),
    "aioptimize": (ai_copilot.aioptimize_cmd, RANK_MODERATOR, "ai_copilot"),
    "aiincident": (ai_copilot.aiincident_cmd, RANK_MODERATOR, "ai_copilot"),
    "aiplan": (ai_copilot.aiplan_cmd, None, None),

    # ==================== Phase 3 migration: previously slash-only ====================
    # لاک/فیلتر پیشرفته
    "allowword": (locks_filters.allowword_cmd, RANK_ADMIN, None),
    "disallowword": (locks_filters.disallowword_cmd, RANK_ADMIN, None),
    "blockdomain": (locks_filters.blockdomain_cmd, RANK_ADMIN, None),
    "unblockdomain": (locks_filters.unblockdomain_cmd, RANK_ADMIN, None),
    "allowdomain": (locks_filters.allowdomain_cmd, RANK_ADMIN, None),
    "unallowdomain": (locks_filters.unallowdomain_cmd, RANK_ADMIN, None),
    "allowforward": (locks_filters.allowforward_cmd, RANK_ADMIN, None),
    "blockforward": (locks_filters.blockforward_cmd, RANK_ADMIN, None),
    "unruleforward": (locks_filters.unruleforward_cmd, RANK_ADMIN, None),
    "setfilteraction": (locks_filters.setfilteraction_cmd, RANK_ADMIN, None),
    "mentionprotection": (locks_filters.mentionprotection_cmd, RANK_ADMIN, None),
    "setmentionlimit": (locks_filters.setmentionlimit_cmd, RANK_ADMIN, None),
    "setmentionaction": (locks_filters.setmentionaction_cmd, RANK_ADMIN, None),
    "antispam": (locks_filters.antispam_cmd, RANK_ADMIN, None),
    "setspamaction": (locks_filters.setspamaction_cmd, RANK_ADMIN, None),
    "dupcross": (locks_filters.dupcross_cmd, RANK_ADMIN, None),
    "setdupcross": (locks_filters.setdupcross_cmd, RANK_ADMIN, None),
    "setflood": (locks_filters.setflood_cmd, RANK_ADMIN, None),
    "setfloodaction": (locks_filters.setfloodaction_cmd, RANK_ADMIN, None),

    # امنیت
    "setraidthreshold": (security.setraidthreshold_cmd, RANK_ADMIN, None),

    # اخطار/خداحافظی
    "setmaxwarns": (moderation.setmaxwarns_cmd, RANK_ADMIN, None),
    "setwarnaction": (moderation.setwarnaction_cmd, RANK_ADMIN, None),
    "setwelcomedelete": (captcha.setwelcomedelete_cmd, RANK_ADMIN, None),
    "setgoodbye": (captcha.setgoodbye_cmd, RANK_ADMIN, None),
    "resetgoodbye": (captcha.resetgoodbye_cmd, RANK_ADMIN, None),

    # پروفایل‌ها (مالک)
    "createprofile": (profiles.createprofile_cmd, RANK_OWNER, None),
    "delprofile": (profiles.delprofile_cmd, RANK_OWNER, None),
    "assignprofile": (profiles.assignprofile_cmd, RANK_ADMIN, None),
    "unassignprofile": (profiles.unassignprofile_cmd, RANK_ADMIN, None),

    # هشدار/تنظیمات
    "setalertchannel": (alerts.setalertchannel_cmd, RANK_ADMIN, None),
    "importsettings": (settings_io.importsettings_cmd, RANK_OWNER, None),

    # کانال/زمان‌بندی
    "schedulerecurring": (channel.schedulerecurring_cmd, RANK_ADMIN, None),
    "recurringposts": (channel.recurringposts_cmd, RANK_ADMIN, None),
    "delrecurring": (channel.delrecurring_cmd, RANK_ADMIN, None),

    # Auto Actions
    "autoactiontoggle": (auto_actions.autoactiontoggle_cmd, RANK_ADMIN, None),

    # Daily Notify
    "dailynotify": (daily_notify.dailynotify_cmd, RANK_ADMIN, None),
    "setpricetime": (daily_notify.setpricetime_cmd, RANK_ADMIN, None),
    "setnewstime": (daily_notify.setnewstime_cmd, RANK_ADMIN, None),
    "setdailytz": (daily_notify.setdailytz_cmd, RANK_ADMIN, None),
    "testdailyprice": (daily_notify.testdailyprice_cmd, RANK_ADMIN, None),
    "testdailynews": (daily_notify.testdailynews_cmd, RANK_ADMIN, None),
    "dailyassets": (daily_notify.dailyassets_cmd, RANK_ADMIN, None),

    # تبلیغات و پرداخت (ads/myads/adadmin/adstats همگی داخل خودشون admin_only دارن؛
    # buyplan عمومی است — همه می‌تونن پلن بخرن)
    "ads": (ads.ads_cmd, RANK_ADMIN, None),
    "myads": (ads.myads_cmd, RANK_ADMIN, None),
    "adadmin": (ads.adadmin_cmd, RANK_ADMIN, None),
    "adstats": (ads.adstats_cmd, RANK_ADMIN, None),
    "buyplan": (payments.buyplan_cmd, None, None),

    # توجه: "start" عمداً اضافه نشده — /start فقط جریان PV (deep-link) است و
    # text_trigger_filter فقط داخل گروه‌ها فعاله؛ اضافه‌کردنش بی‌معنیه.
}

# کش عبارت‌های مرتب‌شده (طولانی‌ترین به کوتاه‌ترین) به ازای هر زبان، تا هر
# پیام مجبور نباشه دوباره TEXT_TRIGGERS رو مرتب کنه.
_SORTED_TRIGGERS_CACHE = {}


def _sorted_triggers_for(lang: str):
    """
    لیست (کلمات_عبارت, شناسه‌ی_دستور) برای یک زبان را برمی‌گرداند، مرتب‌شده
    از طولانی‌ترین عبارت (بیشترین تعداد کلمه) به کوتاه‌ترین — تا مثلاً
    عبارت دو‌کلمه‌ای «حذف پست» قبل از عبارت یک‌کلمه‌ای «حذف» چک بشه.

    اگر زبانی TEXT_TRIGGERS نداشته باشه (یا فایلش هنوز اضافه نشده)،
    به‌صورت خودکار از زبان پیش‌فرض (فارسی) استفاده می‌شه.
    """
    if lang in _SORTED_TRIGGERS_CACHE:
        return _SORTED_TRIGGERS_CACHE[lang]

    try:
        strings_module = __import__(f"locales.{lang}", fromlist=["TEXT_TRIGGERS"])
        triggers = getattr(strings_module, "TEXT_TRIGGERS", None)
    except ImportError:
        triggers = None

    if not triggers:
        default_module = __import__(f"locales.{DEFAULT_LANG}", fromlist=["TEXT_TRIGGERS"])
        triggers = getattr(default_module, "TEXT_TRIGGERS", {})

    pairs = []
    for cmd_id, phrases in triggers.items():
        if cmd_id not in COMMANDS:
            # شناسه‌ای که در locale نوشته شده ولی در COMMANDS تعریف نشده —
            # نادیده گرفته می‌شه تا یک typo در فایل زبان باعث کرش نشه.
            continue
        for phrase in phrases:
            pairs.append((phrase.casefold().split(), cmd_id))

    sorted_pairs = sorted(pairs, key=lambda item: -len(item[0]))
    _SORTED_TRIGGERS_CACHE[lang] = sorted_pairs
    return sorted_pairs


async def text_command_dispatcher(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.effective_message
    if not message or not message.text:
        return
    raw_words = message.text.strip().split()
    if not raw_words:
        return
    folded_words = [w.casefold() for w in raw_words]

    chat_id = update.effective_chat.id
    lang = get_lang(chat_id)

    for trigger_words, cmd_id in _sorted_triggers_for(lang):
        n = len(trigger_words)
        if folded_words[:n] != trigger_words:
            continue

        handler, min_rank, capability = COMMANDS[cmd_id]

        if min_rank is not None:
            actor_id = update.effective_user.id
            actor_rank = await get_rank(context, chat_id, actor_id)
            allowed = actor_rank >= min_rank
            if not allowed and capability:
                caps = await profile_capabilities(context, chat_id, actor_id)
                allowed = capability in caps
            if not allowed:
                # فرستنده اصلاً اجازه‌ی این دستور رو نداره: دیسپچر کاملاً
                # بی‌صدا برمی‌گرده، انگار این پیام هیچ‌وقت یک "دستور متنی"
                # نبوده. (چک دقیق‌تر Hierarchy با هدف، همچنان داخل خود
                # handler با authorize_action انجام می‌شه.)
                return

        # آرگومان‌های باقی‌مانده رو از متن اصلی (نه نسخه‌ی lower/casefold
        # شده) برمی‌داریم تا کیس حروف در @username/دلیل/... خراب نشه.
        context.args = raw_words[n:]
        await handler(update, context)
        return


# فیلتر: فقط متن‌های معمولی (نه دستور با /) و فقط داخل گروه‌ها
text_trigger_filter = filters.TEXT & ~filters.COMMAND & filters.ChatType.GROUPS
