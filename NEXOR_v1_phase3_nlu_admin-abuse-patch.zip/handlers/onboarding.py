# -*- coding: utf-8 -*-
"""
Onboarding واقعی (بخش 12 پرامپت): وقتی NEXOR به یک گروه جدید اضافه می‌شه،
به‌جای سکوت کامل (وضعیت فعلی پروژه — هیچ ChatMemberHandler ثبت نشده بود)،
یک پیام خوش‌آمد کوتاه می‌فرسته که می‌گه NEXOR چیه، چه دسترسی‌هایی کم داره
(اگه کم داره)، و دو دکمه‌ی ساده برای شروع می‌ده — نه بمباران با ۵۰ گزینه
(بخش 13: Progressive Disclosure).

تصمیم «کِی بفرستیم» و «کدوم دسترسی‌ها کمه» در onboarding_logic.py (خالص،
تست‌شده) است؛ این فایل فقط همون تصمیم رو می‌گیره و پیام تلگرامی می‌سازه.

⚠️ اعلام صادقانه: این فایل به python-telegram-bot وابسته است و در این
sandbox (بدون اینترنت برای نصب آن پکیج) اجرا/تست نشده. فقط
onboarding_logic.py واقعاً با unit test تست شده.
"""
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

import time

from i18n import tc
from onboarding_logic import should_send_welcome, missing_permission_keys, REQUIRED_ADMIN_PERMS
from repositories import store as db


async def bot_added_to_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    result = update.my_chat_member
    if not result:
        return
    chat = result.chat
    if chat.type not in ("group", "supergroup"):
        return

    old_status = result.old_chat_member.status
    new_status = result.new_chat_member.status

    # known_chats registry (services/ads.py از این برای پخش روزانه‌ی تبلیغ
    # استفاده می‌کنه) — مستقل از اینکه پیام خوش‌آمد فرستاده می‌شه یا نه.
    if new_status in ("member", "administrator"):
        db.touch_known_chat(chat.id, chat.title, time.time())
    elif new_status in ("left", "kicked"):
        db.mark_known_chat_inactive(chat.id)

    if not should_send_welcome(old_status, new_status):
        return

    chat_id = chat.id
    is_admin = new_status == "administrator"

    text_parts = [tc(chat_id, "onboarding_welcome")]
    if not is_admin:
        text_parts.append(tc(chat_id, "onboarding_needs_admin"))
    else:
        granted = {
            attr: getattr(result.new_chat_member, attr, False)
            for attr, _ in REQUIRED_ADMIN_PERMS
        }
        missing_keys = missing_permission_keys(granted)
        if missing_keys:
            missing_labels = "، ".join(tc(chat_id, k) for k in missing_keys)
            text_parts.append(tc(chat_id, "onboarding_missing_perms", perms=missing_labels))
        else:
            text_parts.append(tc(chat_id, "onboarding_all_set"))

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(tc(chat_id, "onboarding_btn_security"), callback_data="guide:locks")],
        [InlineKeyboardButton(tc(chat_id, "onboarding_btn_help"), callback_data="onboarding:help")],
    ])

    try:
        await context.bot.send_message(
            chat_id, "\n\n".join(text_parts), reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN,
        )
    except Exception:
        # غیربحرانی: اگه گروه هنوز اجازه‌ی ارسال پیام از ربات‌ها رو نداده یا
        # هر خطای موقتی دیگه‌ای بود، Onboarding نباید کل add-to-group رو خراب کنه.
        pass


async def onboarding_help_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    chat_id = update.effective_chat.id
    await query.message.reply_text(tc(chat_id, "help_text"), parse_mode=ParseMode.MARKDOWN)
