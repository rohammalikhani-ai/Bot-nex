# -*- coding: utf-8 -*-
"""
سیستم کامل /rules — نمایش قوانین گروه، مدیریت (تنظیم/حذف) توسط ادمین، و
پشتیبانی از چند زبان: هر گروه می‌تواند برای هر زبان متن قوانین جداگانه‌ای
ثبت کند (مثلاً /setrules fa ... و /setrules en ...)؛ اگر آرگومان زبان داده
نشود، زبان فعلی همان گروه (i18n) استفاده می‌شود.
"""
from __future__ import annotations  # keep list[str] hints working on Python < 3.9

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc, get_lang, SUPPORTED_LANGUAGES
from handlers.common import admin_only
from utils import strip_prefix_words


def _split_lang(args: list[str], chat_id: int):
    """اگر اولین آرگومان یک کد زبان معتبر بود، آن را جدا می‌کند؛ وگرنه زبان فعلی گروه."""
    if args and args[0].lower() in SUPPORTED_LANGUAGES:
        return args[0].lower(), args[1:]
    return get_lang(chat_id), args


async def rules_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    lang = get_lang(chat_id)
    text = db.get_rules(chat_id, lang)
    if text is None:
        fallback = db.get_any_rules(chat_id)
        if fallback is None:
            await update.message.reply_text(tc(chat_id, "rules_empty"))
            return
        _, text = fallback
    header = tc(chat_id, "rules_header")
    await update.message.reply_text(f"{header}\n\n{text}", parse_mode=ParseMode.MARKDOWN)


async def setrules_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    full_text = update.message.text

    # رفع باگ واقعی: قبلاً فرض می‌شد پیشوند دستور همیشه دقیقاً یک کلمه‌ست
    # (`full_text.split(None, 1)[1]`) — درست برای «/setrules» ولی غلط برای
    # Aliasهای چندکلمه‌ای («تنظیم قوانین»، «kuralları ayarla»، ...) که در
    # هر ۶ زبان دقیقاً دوکلمه‌ای‌اند؛ نتیجه این بود که کلمه‌ی دومِ Alias به
    # متنِ قوانینِ ذخیره‌شده می‌چسبید. اینجا با context.args (که هم برای
    # مسیر «/» و هم برای مسیر Alias درست محاسبه شده) تعداد واقعی کلمات
    # پیشوند رو حساب می‌کنیم و همون تعداد رو از متن خام (با حفظ newline)
    # حذف می‌کنیم.
    total_words = len(full_text.split())
    prefix_word_count = total_words - len(context.args or [])
    raw = strip_prefix_words(full_text, prefix_word_count)

    tokens = raw.split(None, 1)
    first_token = tokens[0] if tokens else ""

    if first_token.lower() in SUPPORTED_LANGUAGES:
        lang = first_token.lower()
        rules_text = tokens[1] if len(tokens) > 1 else ""
    else:
        lang = get_lang(chat_id)
        rules_text = raw

    rules_text = rules_text.strip()
    if not rules_text:
        await update.message.reply_text(tc(chat_id, "setrules_usage"))
        return

    db.set_rules(chat_id, lang, rules_text)
    await update.message.reply_text(tc(chat_id, "setrules_done", lang=SUPPORTED_LANGUAGES.get(lang, lang)))


async def clearrules_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    lang, _ = _split_lang(list(context.args or []), chat_id)
    if db.clear_rules(chat_id, lang):
        await update.message.reply_text(tc(chat_id, "clearrules_done", lang=SUPPORTED_LANGUAGES.get(lang, lang)))
    else:
        await update.message.reply_text(tc(chat_id, "clearrules_notfound"))
