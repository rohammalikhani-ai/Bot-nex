# -*- coding: utf-8 -*-
"""
مدیریت کانال از داخل گروه.
پیش‌نیاز: ربات باید در کانال هم ادمین باشد (با دسترسی post messages).

سینتکس دکمه‌ها (اختیاری) — بعد از متن پست یک خط "---" بگذارید و بعدش
هر دکمه را در یک خط به شکل  متن|لینک  بنویسید:

/post
سلام به همه!
---
سایت ما|https://example.com
کانال تلگرام|https://t.me/example
"""
from __future__ import annotations

import logging
import json
from datetime import datetime, time as dtime, timedelta

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc
from config import WEEKDAY_NAMES
from handlers.common import admin_only
from utils import call_with_retry


logger = logging.getLogger(__name__)

def _parse_text_and_buttons(raw: str):
    """raw = همه‌ی متن بعد از دستور. خروجی: (متن پست, InlineKeyboardMarkup یا None)"""
    if "\n---\n" in raw:
        text_part, buttons_part = raw.split("\n---\n", 1)
    else:
        text_part, buttons_part = raw, ""

    text_part = text_part.strip()
    keyboard = []
    for line in buttons_part.strip().splitlines():
        line = line.strip()
        if not line or "|" not in line:
            continue
        label, url = line.split("|", 1)
        label, url = label.strip(), url.strip()
        if label and url:
            keyboard.append([InlineKeyboardButton(label, url=url)])

    markup = InlineKeyboardMarkup(keyboard) if keyboard else None
    return text_part, markup


def _get_channel(chat_id: int):
    return db.get_setting(chat_id, "linked_channel")


async def setchannel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "channel_set_usage"))
        return
    channel = context.args[0]
    try:
        chat = await context.bot.get_chat(channel)
    except Exception as e:
        await update.message.reply_text(tc(chat_id, "channel_set_error", error=e))
        return

    db.set_setting(chat_id, "linked_channel", str(chat.id))
    await update.message.reply_text(tc(chat_id, "channel_set_done", title=chat.title))


async def post_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    channel = _get_channel(chat_id)
    if not channel:
        await update.message.reply_text(tc(chat_id, "channel_no_channel"))
        return

    full_text = update.message.text
    raw = full_text.split(None, 1)[1] if len(full_text.split(None, 1)) > 1 else ""
    if not raw:
        await update.message.reply_text(tc(chat_id, "channel_post_empty"))
        return

    text_part, markup = _parse_text_and_buttons(raw)
    try:
        sent = await call_with_retry(
            context.bot.send_message, chat_id=int(channel), text=text_part, reply_markup=markup
        )
        await update.message.reply_text(tc(chat_id, "channel_post_sent", id=sent.message_id))
    except Exception as e:
        await update.message.reply_text(tc(chat_id, "channel_post_failed", error=e))


async def schedulepost_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    channel = _get_channel(chat_id)
    if not channel:
        await update.message.reply_text(tc(chat_id, "channel_no_channel"))
        return

    if not context.args:
        await update.message.reply_text(tc(chat_id, "channel_schedule_usage"))
        return

    try:
        minutes = int(context.args[0])
    except ValueError:
        await update.message.reply_text(tc(chat_id, "channel_schedule_invalid_minutes"))
        return

    full_text = update.message.text
    first_line, _, rest = full_text.partition("\n")
    raw = rest.strip()
    if not raw:
        await update.message.reply_text(tc(chat_id, "channel_schedule_empty"))
        return

    text_part, markup = _parse_text_and_buttons(raw)

    context.job_queue.run_once(
        _send_scheduled_post,
        when=minutes * 60,
        data={
            "channel": channel,
            "text": text_part,
            "buttons": [[(b.text, b.url) for b in row] for row in (markup.inline_keyboard if markup else [])],
            "notify_chat": chat_id,
        },
        name=f"schedpost_{chat_id}_{update.message.message_id}",
    )
    await update.message.reply_text(tc(chat_id, "channel_schedule_done", minutes=minutes))


async def _send_scheduled_post(context: ContextTypes.DEFAULT_TYPE):
    data = context.job.data
    notify_chat = data["notify_chat"]
    markup = None
    if data["buttons"]:
        markup = InlineKeyboardMarkup(
            [[InlineKeyboardButton(text, url=url) for text, url in row] for row in data["buttons"]]
        )
    try:
        sent = await call_with_retry(
            context.bot.send_message, chat_id=int(data["channel"]), text=data["text"], reply_markup=markup
        )
        await call_with_retry(
            context.bot.send_message, chat_id=notify_chat,
            text=tc(notify_chat, "channel_scheduled_sent", id=sent.message_id),
        )
    except Exception as e:
        await call_with_retry(
            context.bot.send_message, chat_id=notify_chat,
            text=tc(notify_chat, "channel_scheduled_failed", error=e),
        )


async def editpost_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    channel = _get_channel(chat_id)
    if not channel:
        await update.message.reply_text(tc(chat_id, "channel_no_channel"))
        return
    if not context.args:
        await update.message.reply_text(tc(chat_id, "channel_editpost_usage"))
        return

    try:
        message_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text(tc(chat_id, "channel_editpost_invalid_id"))
        return

    full_text = update.message.text
    _, _, rest = full_text.partition("\n")
    raw = rest.strip()
    if not raw:
        await update.message.reply_text(tc(chat_id, "channel_editpost_empty"))
        return

    text_part, markup = _parse_text_and_buttons(raw)
    try:
        await context.bot.edit_message_text(chat_id=int(channel), message_id=message_id, text=text_part, reply_markup=markup)
        await update.message.reply_text(tc(chat_id, "channel_editpost_done"))
    except Exception as e:
        await update.message.reply_text(tc(chat_id, "channel_editpost_failed", error=e))


async def delpost_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    channel = _get_channel(chat_id)
    if not channel:
        await update.message.reply_text(tc(chat_id, "channel_no_channel"))
        return
    if not context.args:
        await update.message.reply_text(tc(chat_id, "channel_delpost_usage"))
        return
    try:
        message_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text(tc(chat_id, "channel_editpost_invalid_id"))
        return
    try:
        await context.bot.delete_message(chat_id=int(channel), message_id=message_id)
        await update.message.reply_text(tc(chat_id, "channel_delpost_done"))
    except Exception as e:
        await update.message.reply_text(tc(chat_id, "channel_delpost_failed", error=e))


async def channelstats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    channel = _get_channel(chat_id)
    if not channel:
        await update.message.reply_text(tc(chat_id, "channel_no_channel"))
        return
    try:
        chat = await context.bot.get_chat(int(channel))
        count = await context.bot.get_chat_member_count(int(channel))
        await update.message.reply_text(tc(chat_id, "channel_stats_text", title=chat.title, count=count))
    except Exception as e:
        await update.message.reply_text(tc(chat_id, "channel_stats_failed", error=e))


# =====================================================================
# Priority 4, Item 23: Scheduled Messages — Recurring (Daily/Weekly/Monthly)
# مکمل /schedulepost موجود (که یک‌باره است و دست‌نخورده باقی مانده)؛
# این بخش پست‌های تکرارشونده را اضافه می‌کند و در دیتابیس دائمی ذخیره
# می‌شوند تا با ری‌استارت ربات از بین نروند (reschedule_recurring_posts
# هنگام استارت در main.py صدا زده می‌شود).
# =====================================================================

def _job_name(post_id: int) -> str:
    return f"recur_{post_id}"


def _buttons_to_rows(markup: InlineKeyboardMarkup | None):
    if not markup:
        return []
    return [[(b.text, b.url) for b in row] for row in markup.inline_keyboard]


def _rows_to_markup(rows: list):
    if not rows:
        return None
    return InlineKeyboardMarkup([[InlineKeyboardButton(text, url=url) for text, url in row] for row in rows])


def _describe_schedule(chat_id: int, schedule_type: str, weekday, day_of_month, hour: int, minute: int) -> str:
    hhmm = f"{hour:02d}:{minute:02d}"
    if schedule_type == "daily":
        return tc(chat_id, "recurring_desc_daily", time=hhmm)
    if schedule_type == "weekly":
        weekday_label = [k for k, v in WEEKDAY_NAMES.items() if v == weekday]
        return tc(chat_id, "recurring_desc_weekly", weekday=(weekday_label[0] if weekday_label else "?"), time=hhmm)
    return tc(chat_id, "recurring_desc_monthly", day=day_of_month, time=hhmm)


def _schedule_recurring_job(job_queue, post_id: int, chat_id: int, channel: str, schedule_type: str,
                             weekday, day_of_month, hour: int, minute: int, text: str, buttons_rows: list):
    if job_queue is None:
        return
    data = {
        "post_id": post_id, "chat_id": chat_id, "channel": channel, "text": text,
        "buttons": buttons_rows, "day_of_month": day_of_month,
    }
    fire_time = dtime(hour=hour, minute=minute)
    if schedule_type == "daily":
        job_queue.run_daily(_fire_recurring_post, time=fire_time, data=data, name=_job_name(post_id))
    elif schedule_type == "weekly":
        job_queue.run_daily(_fire_recurring_post, time=fire_time, days=(weekday,), data=data, name=_job_name(post_id))
    else:  # monthly — چون run_daily روزهای ماه رو پشتیبانی نمی‌کنه، هر روز چک می‌کنیم
        job_queue.run_daily(_fire_recurring_post, time=fire_time, data=data, name=_job_name(post_id))


def _is_target_day_of_month(today: datetime, day_of_month: int) -> bool:
    if today.day == day_of_month:
        return True
    # اگه روز هدف بزرگ‌تر از تعداد روزهای این ماه بود (مثلاً 31 در فوریه)،
    # آخرین روز ماه را معادل آن در نظر می‌گیریم تا پست از قلم نیفته.
    next_month = today.replace(day=28) + timedelta(days=4)
    last_day_of_month = (next_month - timedelta(days=next_month.day)).day
    return today.day == last_day_of_month and day_of_month > last_day_of_month


async def _fire_recurring_post(context: ContextTypes.DEFAULT_TYPE):
    data = context.job.data
    if data.get("day_of_month") is not None:
        if not _is_target_day_of_month(datetime.now(), data["day_of_month"]):
            return
    markup = _rows_to_markup(data["buttons"])
    try:
        await call_with_retry(
            context.bot.send_message, chat_id=int(data["channel"]), text=data["text"], reply_markup=markup
        )
    except Exception:
        logger.exception("non-fatal operation failed")


async def schedulerecurring_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    channel = _get_channel(chat_id)
    if not channel:
        await update.message.reply_text(tc(chat_id, "channel_no_channel"))
        return

    args = context.args or []
    if len(args) < 2 or args[0].lower() not in ("daily", "weekly", "monthly"):
        await update.message.reply_text(tc(chat_id, "schedulerecurring_usage"))
        return

    schedule_type = args[0].lower()
    weekday = None
    day_of_month = None

    if schedule_type == "daily":
        time_token = args[1]
    elif schedule_type == "weekly":
        if len(args) < 3 or args[1].lower() not in WEEKDAY_NAMES:
            await update.message.reply_text(tc(chat_id, "schedulerecurring_invalid_weekday"))
            return
        weekday = WEEKDAY_NAMES[args[1].lower()]
        time_token = args[2]
    else:  # monthly
        if len(args) < 3 or not args[1].isdigit() or not (1 <= int(args[1]) <= 28):
            await update.message.reply_text(tc(chat_id, "schedulerecurring_invalid_day"))
            return
        day_of_month = int(args[1])
        time_token = args[2]

    if ":" not in time_token:
        await update.message.reply_text(tc(chat_id, "schedulerecurring_invalid_time"))
        return
    try:
        hour_s, minute_s = time_token.split(":", 1)
        hour, minute = int(hour_s), int(minute_s)
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            raise ValueError
    except ValueError:
        await update.message.reply_text(tc(chat_id, "schedulerecurring_invalid_time"))
        return

    # متن پست: همه‌ی خط اول (دستور + آرگومان‌ها) کنار گذاشته می‌شه، بقیه پیام متن پسته
    first_line, _, rest = update.message.text.partition("\n")
    raw = rest.strip()
    if not raw:
        await update.message.reply_text(tc(chat_id, "schedulerecurring_empty_text"))
        return

    text_part, markup = _parse_text_and_buttons(raw)
    buttons_rows = _buttons_to_rows(markup)

    post_id = db.add_recurring_post(
        chat_id, channel, schedule_type, weekday, day_of_month, hour, minute,
        text_part, json.dumps(buttons_rows), update.effective_user.id,
    )
    _schedule_recurring_job(context.job_queue, post_id, chat_id, channel, schedule_type,
                             weekday, day_of_month, hour, minute, text_part, buttons_rows)
    await update.message.reply_text(tc(chat_id, "schedulerecurring_done", id=post_id))


async def recurringposts_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    rows = db.get_recurring_posts(chat_id)
    if not rows:
        await update.message.reply_text(tc(chat_id, "recurringposts_empty"))
        return
    header = tc(chat_id, "recurringposts_header")
    lines = [header]
    for post_id, channel, schedule_type, weekday, day_of_month, hour, minute, text, buttons_json in rows:
        schedule_desc = _describe_schedule(chat_id, schedule_type, weekday, day_of_month, hour, minute)
        preview = text[:40] + ("…" if len(text) > 40 else "")
        lines.append(tc(chat_id, "recurringposts_item", id=post_id, schedule=schedule_desc, preview=preview))
    await update.message.reply_text("\n".join(lines))


async def delrecurring_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text(tc(chat_id, "delrecurring_usage"))
        return
    post_id = int(context.args[0])
    if not db.deactivate_recurring_post(post_id, chat_id):
        await update.message.reply_text(tc(chat_id, "delrecurring_notfound"))
        return
    if context.job_queue:
        for job in context.job_queue.get_jobs_by_name(_job_name(post_id)):
            job.schedule_removal()
    await update.message.reply_text(tc(chat_id, "delrecurring_done", id=post_id))


def reschedule_recurring_posts(app):
    """هنگام استارت ربات صدا زده می‌شود تا تمام Jobهای تکرارشونده‌ی فعال دوباره ثبت شوند."""
    if not app.job_queue:
        return
    for (post_id, chat_id, channel, schedule_type, weekday, day_of_month,
         hour, minute, text, buttons_json) in db.get_all_active_recurring_posts():
        try:
            buttons_rows = json.loads(buttons_json) if buttons_json else []
        except Exception:
            buttons_rows = []
        _schedule_recurring_job(app.job_queue, post_id, chat_id, channel, schedule_type,
                                 weekday, day_of_month, hour, minute, text, buttons_rows)
