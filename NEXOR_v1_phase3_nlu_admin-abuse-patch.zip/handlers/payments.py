# -*- coding: utf-8 -*-
"""
handlers/payments.py

لایه‌ی Telegram برای خرید اشتراک pro/premium با سه روش: ⭐ Stars، 💎 TON،
💳 کارت‌به‌کارت. منطق واقعی (قیمت‌گذاری، اعمال پلن، تطبیق تراکنش TON) در
services/payments.py و services/ton_wallet.py هست؛ این ماژول فقط پیام‌های
تلگرامی رو می‌سازه/جواب می‌ده.

⭐ Stars و 💎 TON از طریق دستور /buyplan (پایین همین فایل: buyplan_cmd /
buyplan_callback) به رابط کاربری وصل هستن — در handlers/registry.py و
core/bootstrap.py (Job دوره‌ای ton_check_job) رجیستر شدن.

⚠️ 💳 کارت‌به‌کارت طبق تصمیم صریح مالک پروژه عمداً هنوز به UI وصل نشده
(نه در buyplan_cmd، نه هیچ‌جای دیگه) — تا وقتی یا درگاه رسمی جایگزینش بشه یا
تصمیم بگیرن با همین روش دستی جلو برن. توابع کارتی این فایل (start_card_purchase
و admin_*_card_order) کاملاً کاردرست‌اند ولی صرفاً هنوز به هیچ دستوری وصل
نشدن. جزئیات/چک‌لیست کامل در services/PAYMENTS_INTEGRATION_NOTES.md.
"""
from __future__ import annotations

import logging

from telegram import LabeledPrice, Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from repositories import store as db
from handlers.common import admin_only
from services import payments
from config import AI_PLAN_PRO, AI_PLAN_PREMIUM
from i18n import tc

logger = logging.getLogger(__name__)

_PLAN_LABELS = {AI_PLAN_PRO: "NEXOR Pro", AI_PLAN_PREMIUM: "NEXOR Premium"}


# ==================== ⭐ Telegram Stars ====================

async def send_plan_invoice_stars(context: ContextTypes.DEFAULT_TYPE, chat_id: int,
                                   user_id: int, plan: str, months: int = 1) -> bool:
    """صورتحساب Stars (XTR) رو برای ارتقای پلن `chat_id` به `plan` می‌فرسته.
    طبق مستندات Bot API برای واحد پول XTR، provider_token خالی می‌مونه."""
    order = payments.create_stars_order(chat_id, user_id, plan, months)
    if order is None:
        return False
    label = _PLAN_LABELS.get(plan, plan)
    await context.bot.send_invoice(
        chat_id=user_id,
        title=tc(chat_id, "buyplan_invoice_title", plan=label, months=months),
        description=tc(chat_id, "buyplan_invoice_desc", plan=label, months=months),
        payload=order["stars_invoice_payload"],
        provider_token="",  # برای XTR (Stars) طبق مستندات Bot API خالی می‌ماند
        currency="XTR",
        prices=[LabeledPrice(tc(chat_id, "buyplan_invoice_price_label", plan=label, months=months), order["amount_stars"])],
    )
    return True


async def stars_precheckout_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """یک PreCheckoutQueryHandler سراسری برای کل ربات — طبق payload prefix بین
    خرید پلن (nexor_sub_...) و خرید تبلیغات (nexor_ad_...) مسیریابی می‌کنه، چون
    python-telegram-bot به ازای هر Update فقط یک PreCheckoutQueryHandler را در
    یک Group صدا می‌زند."""
    query = update.pre_checkout_query
    if query.invoice_payload.startswith("nexor_ad_"):
        from repositories import store as ad_db
        order = ad_db.get_ad_order_by_stars_payload(query.invoice_payload)
        if order is None or order["status"] != "pending_payment":
            lang_chat = order.get("owner_chat_id") if order else query.from_user.id
            await query.answer(ok=False, error_message=tc(lang_chat, "err_order_invalid"))
            return
        await query.answer(ok=True)
        return
    order = db.get_subscription_order_by_payload(query.invoice_payload)
    if order is None or order["status"] != "pending":
        lang_chat = order.get("chat_id") if order else query.from_user.id
        await query.answer(ok=False, error_message=tc(lang_chat, "err_order_invalid"))
        return
    await query.answer(ok=True)


async def stars_successful_payment_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """مسیریابی مشابه precheckout — همون دلیل (یک MessageHandler سراسری برای موفقیت پرداخت)."""
    payment = update.effective_message.successful_payment
    if payment.invoice_payload.startswith("nexor_ad_"):
        from services import ads as ads_service
        order = ads_service.confirm_stars_payment(payment.invoice_payload, payment.telegram_payment_charge_id)
        if order is None:
            return
        await update.effective_message.reply_text(
            tc(order.get("owner_chat_id", update.effective_chat.id), "ads_stars_confirmed", id=order["id"])
        )
        return
    order = payments.confirm_stars_payment(payment.invoice_payload, payment.telegram_payment_charge_id)
    if order is None:
        # سفارش قبلاً تایید شده بود (successful_payment تکراری از تلگرام) — بی‌صدا رد می‌شیم.
        return
    label = _PLAN_LABELS.get(order["plan"], order["plan"])
    lang_chat = order.get("chat_id", update.effective_chat.id)
    upgraded = await apply_plan_to_owned_groups(context, order["user_id"], order["plan"], order["months"])
    if upgraded:
        await update.effective_message.reply_text(
            tc(lang_chat, "buyplan_stars_confirmed_groups", plan=label, count=len(upgraded))
        )
    else:
        await update.effective_message.reply_text(
            tc(lang_chat, "buyplan_stars_confirmed_no_groups", plan=label)
        )


# ==================== 💎 TON ====================

async def start_ton_purchase(context: ContextTypes.DEFAULT_TYPE, chat_id: int, user_id: int,
                              plan: str, months: int = 1) -> str | None:
    """سفارش TON می‌سازه و متن راهنما (آدرس، مبلغ، memo، لینک ton://) رو برمی‌گردونه."""
    order = payments.create_ton_order(chat_id, user_id, plan, months)
    if order is None:
        return None
    label = _PLAN_LABELS.get(plan, plan)
    return tc(
        chat_id, "buyplan_ton_instructions", plan=label,
        amount=f"{order['amount_ton']:g}", address=order["address"],
        memo=order["memo"], link=order["transfer_link"],
    )


async def ton_check_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Job دوره‌ای (اگه به job_queue اضافه بشه) — سفارش‌های TON در انتظار رو
    با تراکنش‌های تازه‌ی toncenter تطبیق می‌ده و کاربر رو خبر می‌کنه."""
    confirmed = payments.check_ton_payments_once()
    for order in confirmed:
        label = _PLAN_LABELS.get(order["plan"], order["plan"])
        lang_chat = order.get("chat_id", order["user_id"])
        upgraded = await apply_plan_to_owned_groups(context, order["user_id"], order["plan"], order["months"])
        key = "buyplan_ton_confirmed_groups" if upgraded else "buyplan_ton_confirmed_no_groups"
        try:
            await context.bot.send_message(
                chat_id=order["user_id"],
                text=tc(lang_chat, key, plan=label, count=len(upgraded)),
            )
        except Exception:
            logger.exception("خطا در اطلاع‌رسانی تایید پرداخت TON")


# ==================== 👑 اعمال پلن روی همه‌ی گروه‌های مالکیتِ خریدار ====================
# خرید از طریق /buyplan همیشه در PV انجام می‌شه (نه داخل یک گروه خاص)؛ بعد از
# تایید پرداخت، باید بفهمیم این کاربر مالک (owner/creator واقعی تلگرام) کدوم
# گروه‌هایی هست که ربات توشونه، و پلن رو روی همه‌ی اون‌ها اعمال کنیم — نه فقط
# یک گروه ثابت. هیچ جدول جداگانه‌ای برای owner نگه نمی‌داریم؛ در لحظه‌ی تایید
# پرداخت، برای هر گروه فعال (db.list_active_group_chats — همون رجیستری
# known_chats که سیستم تبلیغات هم ازش استفاده می‌کنه) از خود تلگرام
# get_chat_member می‌پرسیم و status == "creator" رو معیار مالکیت می‌گیریم.

async def resolve_owned_group_ids(bot, user_id: int) -> list[int]:
    owned: list[int] = []
    for chat_id in db.list_active_group_chats():
        try:
            member = await bot.get_chat_member(chat_id, user_id)
        except Exception:
            # ربات دیگه توی اون گروه نیست / کاربر عضو نیست / خطای شبکه — رد می‌شیم.
            continue
        if getattr(member, "status", None) == "creator":
            owned.append(chat_id)
    return owned


async def apply_plan_to_owned_groups(context: ContextTypes.DEFAULT_TYPE, user_id: int,
                                      plan: str, months: int) -> list[int]:
    """پلن رو روی همه‌ی گروه‌هایی که `user_id` مالکشونه اعمال می‌کنه.
    خروجی: لیست chat_id هایی که ارتقا پیدا کردن (برای پیام تایید به کاربر)."""
    group_ids = await resolve_owned_group_ids(context.bot, user_id)
    for gid in group_ids:
        payments.apply_subscription(gid, plan, months)
    return group_ids


# ==================== 💳 کارت‌به‌کارت (دستی) ====================

async def start_card_purchase(chat_id: int, user_id: int, plan: str, months: int = 1) -> str | None:
    order = payments.create_card_order(chat_id, user_id, plan, months)
    if order is None:
        return None
    label = _PLAN_LABELS.get(plan, plan)
    lines = [tc(chat_id, "buyplan_card_header", plan=label)]
    if order["amount_toman"]:
        lines.append(tc(chat_id, "buyplan_card_amount", amount=f"{order['amount_toman']:,}"))
    lines.append(tc(chat_id, "buyplan_card_number", number=order["card_number"]))
    if order.get("card_holder"):
        lines.append(tc(chat_id, "buyplan_card_holder", holder=order["card_holder"]))
    lines.append(tc(chat_id, "buyplan_card_reference", ref=order["reference"]))
    lines.append(tc(chat_id, "buyplan_card_instructions"))
    return "\n".join(lines)


async def admin_confirm_card_order(update: Update, context: ContextTypes.DEFAULT_TYPE, order_id: int) -> str:
    """ادمین بعد از بررسی دستی رسید، سفارش کارتی رو تایید می‌کنه."""
    if not await admin_only(update, context):
        return ""
    admin_chat_id = update.effective_chat.id
    order = payments.confirm_card_order(order_id, update.effective_user.id)
    if order is None:
        return tc(admin_chat_id, "buyplan_card_order_not_found")
    label = _PLAN_LABELS.get(order["plan"], order["plan"])
    try:
        await context.bot.send_message(
            chat_id=order["user_id"],
            text=tc(order.get("chat_id", order["user_id"]), "buyplan_card_confirmed_dm", plan=label),
        )
    except Exception:
        logger.exception("خطا در اطلاع‌رسانی تایید پرداخت کارتی")
    return tc(admin_chat_id, "buyplan_card_admin_confirmed", id=order_id, plan=label)


async def admin_reject_card_order(update: Update, context: ContextTypes.DEFAULT_TYPE, order_id: int) -> str:
    if not await admin_only(update, context):
        return ""
    chat_id = update.effective_chat.id
    ok = payments.reject_card_order(order_id, update.effective_user.id)
    return tc(chat_id, "buyplan_card_admin_rejected", id=order_id) if ok else tc(chat_id, "buyplan_card_order_not_found")


async def admin_list_pending_card_orders(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not await admin_only(update, context):
        return ""
    chat_id = update.effective_chat.id
    pending = db.list_pending_card_orders()
    if not pending:
        return tc(chat_id, "buyplan_card_none_pending")
    lines = [tc(chat_id, "buyplan_card_pending_header")]
    for o in pending:
        label = _PLAN_LABELS.get(o["plan"], o["plan"])
        lines.append(tc(chat_id, "buyplan_card_pending_line", id=o["id"], plan=label, months=o["months"], code=o["card_reference"]))
    return "\n".join(lines)


# ==================== 🛒 /buyplan (UI برای Stars + TON) ====================
# طبق تصمیم صریح مالک پروژه: فقط ⭐ Stars و 💎 TON اینجا نمایش داده می‌شن.
# 💳 کارت‌به‌کارت عمداً از این منو کنار گذاشته شده، حتی اگه NEXOR_CARD_NUMBER
# در .env ست بشه — تا تصمیم درباره‌ی درگاه رسمی/مشورت خانوادگی گرفته بشه.
# جریان: /buyplan (فقط ادمین) -> انتخاب پلن -> انتخاب روش پرداخت -> اجرا.
# هر callback دوباره از صفر admin_only + مالکیت پنل (owner_id) رو چک می‌کنه،
# دقیقاً هم‌الگو با handlers/admin_panel.py.

def _buyplan_plan_kb(owner_id: int) -> InlineKeyboardMarkup:
    rows = []
    for plan in payments.PURCHASABLE_PLANS:
        label = _PLAN_LABELS.get(plan, plan)
        stars = payments.price_stars(plan)
        price_bits = [f"⭐{stars}"]
        if payments.ton_enabled():
            price_bits.append(f"💎{payments.price_ton(plan):g}TON")
        button_text = f"{label} ({' / '.join(price_bits)})"
        rows.append([InlineKeyboardButton(button_text, callback_data=f"buyplan:{owner_id}:plan:{plan}")])
    rows.append([InlineKeyboardButton("❌", callback_data=f"buyplan:{owner_id}:close")])
    return InlineKeyboardMarkup(rows)


def _buyplan_method_kb(chat_id: int, owner_id: int, plan: str) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton("⭐ Telegram Stars", callback_data=f"buyplan:{owner_id}:pay:{plan}:stars")]]
    if payments.ton_enabled():
        rows.append([InlineKeyboardButton("💎 TON", callback_data=f"buyplan:{owner_id}:pay:{plan}:ton")])
    rows.append([InlineKeyboardButton(tc(chat_id, "panel_btn_back"), callback_data=f"buyplan:{owner_id}:back")])
    return InlineKeyboardMarkup(rows)


async def buyplan_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/buyplan — فقط در PV (پیام خصوصی ربات). این یک خرید شخصیه: بعد از تایید
    پرداخت، پلن روی همه‌ی گروه‌هایی که خودِ کاربر مالک (owner/creator) آن‌هاست
    اعمال می‌شه، نه یک گروه مشخص — پس نیازی نیست از داخل گروه اجرا بشه."""
    chat = update.effective_chat
    if chat.type != "private":
        await update.effective_message.reply_text(tc(chat.id, "buyplan_use_pv"))
        return
    user = update.effective_user
    await update.effective_message.reply_text(
        tc(chat.id, "buyplan_header"), reply_markup=_buyplan_plan_kb(user.id),
    )


async def buyplan_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = update.effective_chat.id
    parts = (query.data or "").split(":")
    if len(parts) < 3:
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return

    try:
        owner_id = int(parts[1])
    except ValueError:
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return
    action = parts[2]
    if update.effective_chat.type != "private":
        # /buyplan فقط از PV باز می‌شه؛ این فقط یک محافظ اضافیه برای پیام‌های
        # قدیمی‌ای که قبل از این تغییر داخل گروه ساخته شده بودن.
        await query.answer(tc(chat_id, "buyplan_use_pv"), show_alert=True)
        return
    if query.from_user.id != owner_id:
        await query.answer(tc(chat_id, "panel_not_yours"), show_alert=True)
        return
    # چون این یک خرید شخصیه (نه یک اکشن مدیریتی روی یک گروه خاص)، رتبه‌ی
    # ادمین‌بودن در یک گروه معنی نداره — همینکه owner_id == query.from_user.id
    # تایید شده کافیه.

    if action == "close":
        await query.answer()
        await query.edit_message_text(tc(chat_id, "buyplan_closed"))
        return

    if action == "back":
        await query.answer()
        await query.edit_message_text(tc(chat_id, "buyplan_header"), reply_markup=_buyplan_plan_kb(owner_id))
        return

    if action == "plan" and len(parts) >= 4:
        plan = parts[3]
        if plan not in payments.PURCHASABLE_PLANS:
            await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
            return
        await query.answer()
        label = _PLAN_LABELS.get(plan, plan)
        await query.edit_message_text(
            tc(chat_id, "buyplan_choose_method", plan=label),
            reply_markup=_buyplan_method_kb(chat_id, owner_id, plan),
        )
        return

    if action == "pay" and len(parts) >= 5:
        plan, method = parts[3], parts[4]
        if plan not in payments.PURCHASABLE_PLANS or method not in ("stars", "ton"):
            await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
            return
        await query.answer()
        text = await _execute_buyplan_payment(context, chat_id, owner_id, plan, method)
        await query.edit_message_text(text)
        return

    await query.answer()


async def _execute_buyplan_payment(context: ContextTypes.DEFAULT_TYPE, chat_id: int,
                                    user_id: int, plan: str, method: str) -> str:
    """Invoice/راهنمای پرداخت رو در DM کاربر می‌فرسته (نه توی گروه، تا مبلغ/آدرس
    عمومی پخش نشه). اگه کاربر هیچ‌وقت با ربات در PV چت نزده باشه، تلگرام اجازه‌ی
    شروع مکالمه رو به ربات نمی‌ده — این حالت جدا مدیریت می‌شه."""
    if method == "stars":
        try:
            sent = await send_plan_invoice_stars(context, chat_id, user_id, plan)
        except Exception:
            logger.exception("خطا در ارسال Invoice استارز برای buyplan")
            sent = False
        if not sent:
            return tc(chat_id, "buyplan_dm_failed")
        return tc(chat_id, "buyplan_stars_sent")

    # method == "ton"
    try:
        guide_text = await start_ton_purchase(context, chat_id, user_id, plan)
    except Exception:
        logger.exception("خطا در ساخت سفارش TON برای buyplan")
        guide_text = None
    if guide_text is None:
        return tc(chat_id, "buyplan_ton_unavailable")
    try:
        await context.bot.send_message(chat_id=user_id, text=guide_text)
    except Exception:
        return tc(chat_id, "buyplan_dm_failed")
    return tc(chat_id, "buyplan_ton_sent")
