# -*- coding: utf-8 -*-
"""
هسته مشترک: تشخیص Hierarchy واقعی (Owner/Admin/Moderator/User)، resolve هدف
(ریپلای یا @username یا user_id عددی)، ثبت اقدامات در Audit Log، و کمک‌کننده‌ی
زبان (هر متنی که به کاربر نمایش داده می‌شود باید از i18n.tc بیاد، نه hardcode).

نکته امنیتی مهم:
- Rank واقعی تلگرام (creator/administrator) همیشه از خود API چک می‌شود؛
  هیچ‌جا صرفاً به یک مقدار ذخیره‌شده در دیتابیس اعتماد نمی‌کنیم.
- نقش Moderator یک نقش داخلی رباته (در جدول roles) و هیچ‌وقت نمی‌تونه
  روی ادمین/مالک واقعی تلگرام اکشن بزنه.
"""
from __future__ import annotations  # keep tuple[...]/int | None hints working on Python < 3.9/3.10

import logging
import threading
import time

from telegram import Update
from telegram.error import TelegramError
from telegram.constants import ChatMemberStatus
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc
from config import (
    RANK_USER, RANK_MODERATOR, RANK_ADMIN, RANK_OWNER,
    ADMIN_ABUSE_ACTIONS, ADMIN_ABUSE_WINDOW_MINUTES, ADMIN_ABUSE_THRESHOLD,
)
from services.authorization import has_required_capability, effective_rank, can_target, authorize

logger = logging.getLogger(__name__)

_RANK_KEYS = {
    RANK_USER: "rank_user",
    RANK_MODERATOR: "rank_moderator",
    RANK_ADMIN: "rank_admin",
    RANK_OWNER: "rank_owner",
}


# ---------------- Rank cache (Priority fix: get_chat_member روی هر پیام) ----------------
# get_rank قبلاً به ازای هر پیام یک فراخوانی زنده به Telegram API (get_chat_member)
# می‌زد؛ در گروه شلوغ همین یکی کافی بود برای خوردن به rate-limit تلگرام و کند
# شدن کل ربات (چون event loop بین همه‌ی گروه‌ها مشترکه). اینجا نتیجه با TTL
# کوتاه در حافظه کش می‌شه. TTL کوتاه انتخاب شده چون ترفیع/عزل ادمین رویداد
# نادریه؛ چند دقیقه تاخیر در دیدنش ریسک امنیتی نداره (یعنی ادمین
# تازه‌ترفیع‌شده تا سقف TTL هنوز عادی دیده می‌شه که conservative/fail-closed
# هست، نه برعکس).
_RANK_CACHE_TTL_SECONDS = 120
_rank_cache: dict = {}
_rank_cache_lock = threading.Lock()


def invalidate_rank_cache(chat_id: int, user_id: int | None = None) -> None:
    """رتبه‌ی کش‌شده را فوراً باطل می‌کند؛ بعد از هر تغییر نقش داخلی
    (moderator) یا هر جای دیگری که مطمئنیم رتبه‌ی یک کاربر عوض شده صدا زده می‌شود."""
    with _rank_cache_lock:
        if user_id is None:
            for key in list(_rank_cache.keys()):
                if key[0] == chat_id:
                    _rank_cache.pop(key, None)
        else:
            _rank_cache.pop((chat_id, user_id), None)


def reset_rank_cache() -> None:
    """کل کش رتبه را خالی می‌کند. فقط برای تست‌ها (تا حالت هر تست از تست قبلی
    مستقل بمونه، هم‌روال با providers.reset_provider_cache در ai_copilot)."""
    with _rank_cache_lock:
        _rank_cache.clear()


async def get_rank(context: ContextTypes.DEFAULT_TYPE, chat_id: int, user_id: int) -> int:
    """Rank کاربر را از Telegram API می‌گیرد و فقط نقش داخلی Moderator را از DB می‌خواند.

    نتیجه با TTL کوتاه کش می‌شود تا در گروه شلوغ هر پیام یک فراخوانی
    شبکه‌ای جدا به تلگرام نزنه.

    در خطای API عمداً به سطح بالا fallback نمی‌کنیم؛ نتیجه‌ی محافظه‌کارانه
    RANK_USER است تا اختلال شبکه/Telegram باعث اعطای دسترسی مدیریتی نشود.
    خطای شبکه/API عمداً کش نمی‌شود، تا رتبه‌ی واقعی به‌محض برطرف شدن اختلال
    (پیام بعدی) به‌جای RANK_USER موقت جایگزین بشه.
    عملیات حساس روی target از can_act_on_strict استفاده می‌کنند که حتی
    در صورت نامشخص بودن target نیز fail-closed است.
    """
    cache_key = (chat_id, user_id)
    now = time.monotonic()
    with _rank_cache_lock:
        cached = _rank_cache.get(cache_key)
        if cached is not None and cached[1] > now:
            return cached[0]

    try:
        member = await context.bot.get_chat_member(chat_id, user_id)
    except TelegramError:
        return RANK_USER
    except Exception:
        logger.exception("unexpected Telegram error while resolving rank for user %s in chat %s", user_id, chat_id)
        return RANK_USER

    if member.status == ChatMemberStatus.OWNER:
        rank = RANK_OWNER
    elif member.status == ChatMemberStatus.ADMINISTRATOR:
        rank = RANK_ADMIN
    elif db.get_role(chat_id, user_id) == "moderator":
        rank = RANK_MODERATOR
    else:
        rank = RANK_USER

    with _rank_cache_lock:
        _rank_cache[cache_key] = (rank, now + _RANK_CACHE_TTL_SECONDS)
    return rank


async def _telegram_rank_strict(context: ContextTypes.DEFAULT_TYPE, chat_id: int, user_id: int):
    """Rank واقعی Telegram؛ None یعنی وضعیت کاربر قابل اعتماد نیست."""
    try:
        member = await context.bot.get_chat_member(chat_id, user_id)
    except TelegramError:
        return None
    except Exception:
        logger.exception("unexpected Telegram error while resolving strict rank for user %s in chat %s", user_id, chat_id)
        return None
    if member.status == ChatMemberStatus.OWNER:
        return RANK_OWNER
    if member.status == ChatMemberStatus.ADMINISTRATOR:
        return RANK_ADMIN
    if db.get_role(chat_id, user_id) == "moderator":
        return RANK_MODERATOR
    return RANK_USER


async def is_admin(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id: int | None = None) -> bool:
    chat = update.effective_chat
    uid = user_id or update.effective_user.id
    return await get_rank(context, chat.id, uid) >= RANK_ADMIN


async def require_rank(update: Update, context: ContextTypes.DEFAULT_TYPE, min_rank: int) -> bool:
    """
    True اگر کاربر فرستنده حداقل min_rank را داشته باشد؛ در غیراینصورت پیام
    خطا (به زبان همان گروه) می‌فرستد و False برمی‌گرداند.
    """
    chat = update.effective_chat
    user = update.effective_user
    rank = await get_rank(context, chat.id, user.id)
    if rank < min_rank:
        rank_label = tc(chat.id, _RANK_KEYS[min_rank])
        await update.message.reply_text(tc(chat.id, "err_need_rank", rank=rank_label))
        return False
    return True


async def admin_only(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    return await require_rank(update, context, RANK_ADMIN)


async def owner_only(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """مثل admin_only ولی فقط برای مالک واقعی گروه — برای تنظیماتی که حتی یک
    ادمین معمولی هم نباید بتونه تغییرشون بده (مثل خاموش‌کردن Anti-Admin Abuse)."""
    return await require_rank(update, context, RANK_OWNER)


async def moderator_only(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    return await require_rank(update, context, RANK_MODERATOR)


async def can_act_on(context: ContextTypes.DEFAULT_TYPE, chat_id: int, actor_id: int, target_id: int) -> tuple[bool, str]:
    """
    بررسی می‌کند آیا actor مجاز است روی target اکشن مدیریتی بزند.
    قانون: actor باید Rank بالاتری از target داشته باشد (نه فقط برابر یا بیشتر مساوی).
    این یعنی یک ادمین معمولی نمی‌تونه روی ادمین دیگه یا مالک اکشن بزنه.
    """
    actor_rank = await _telegram_rank_strict(context, chat_id, actor_id)
    target_rank = await _telegram_rank_strict(context, chat_id, target_id)
    if not can_target(actor_rank, target_rank, same_user=(actor_id == target_id)):
        return False, tc(chat_id, "err_self_action" if actor_id == target_id else "err_rank_too_low")
    return True, ""


async def profile_capabilities(context: ContextTypes.DEFAULT_TYPE, chat_id: int, user_id: int) -> set:
    """
    Priority 5, Item 25 — قابلیت‌های Permission Profile اختصاصی که به این کاربر
    Assign شده (اگر اصلاً پروفایلی نداشته باشد، مجموعه‌ی خالی برمی‌گرداند).
    این مستقل از Rank اصلی است؛ صرفاً یک لایه‌ی اضافه برای واگذاری دقیق قابلیت‌هاست.
    """
    profile = db.get_profile_assignment(chat_id, user_id)
    if not profile:
        return set()
    caps = db.get_permission_profile(chat_id, profile)
    if not caps:
        return set()
    return {c for c in caps.split(",") if c}


async def has_capability(context: ContextTypes.DEFAULT_TYPE, chat_id: int, user_id: int,
                          capability: str, min_rank_without_profile: int = RANK_ADMIN) -> bool:
    """
    True اگر کاربر مجاز به انجام یک اکشن مشخص باشد: یا Rank او به‌تنهایی کافی است
    (>= min_rank_without_profile — مثلاً Moderator برای mute/delete، Admin برای ban)،
    یا Permission Profile اختصاصی او این قابلیت را صریحاً به او داده باشد.
    توجه: این تابع جایگزین can_act_on نمی‌شود — چک Hierarchy (actor باید rank بالاتر
    از target داشته باشد) همیشه باید جداگانه هم انجام شود.
    """
    rank = await get_rank(context, chat_id, user_id)
    caps = await profile_capabilities(context, chat_id, user_id)
    return has_required_capability(rank, caps, capability, min_rank_without_profile)


async def authorize_action(context: ContextTypes.DEFAULT_TYPE, chat_id: int, actor_id: int,
                           capability: str, target_id: int | None = None,
                           min_rank_without_profile: int = RANK_ADMIN) -> tuple[bool, str]:
    """مجوز نهایی اکشن: capability + hierarchy.

    Profile یک سطح مدیریتی واقعی در Telegram ایجاد نمی‌کند؛ فقط برای همان
    capability، کاربر عادی را تا سطح Moderator برای مقایسه با target بالا می‌برد.
    بنابراین Profile User می‌تواند User را مدیریت کند، ولی Moderator/Admin/Owner را نه.
    """
    actual_rank = await get_rank(context, chat_id, actor_id)
    profile_caps = await profile_capabilities(context, chat_id, actor_id)

    if target_id is None:
        if not authorize(actual_rank, None, profile_caps, capability, min_rank_without_profile, RANK_MODERATOR):
            return False, tc(chat_id, "modact_no_permission")
        return True, ""

    if actor_id == target_id:
        return False, tc(chat_id, "err_self_action")

    target_rank = await _telegram_rank_strict(context, chat_id, target_id)
    if target_rank is None:
        return False, tc(chat_id, "err_rank_too_low")

    if not authorize(actual_rank, target_rank, profile_caps, capability, min_rank_without_profile, RANK_MODERATOR):
        return False, tc(chat_id, "err_rank_too_low")
    return True, ""


async def resolve_target(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    هدف اکشن را از یکی از این حالت‌ها استخراج می‌کند:
      1) ریپلای روی پیام کاربر
      2) اولین آرگومان به شکل @username (از کش داخلی ربات resolve می‌شه)
      3) اولین آرگومان به شکل عددی user_id (باید عضو گروه باشه تا نامش گرفته شود)

    خروجی: (user_id, display_name, remaining_args) یا (None, None, args) اگر پیدا نشد.
    """
    args = list(context.args or [])

    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        u = update.message.reply_to_message.from_user
        return u.id, (u.first_name or u.username or str(u.id)), args

    if not args:
        return None, None, args

    token = args[0]

    if token.startswith("@"):
        found = db.find_user_by_username(token)
        if found:
            uid, name = found
            return uid, name, args[1:]
        await update.message.reply_text(tc(update.effective_chat.id, "err_user_not_found_username"))
        return None, None, args

    if token.lstrip("-").isdigit():
        uid = int(token)
        name = db.get_cached_name(uid)
        try:
            member = await context.bot.get_chat_member(update.effective_chat.id, uid)
            name = member.user.first_name or member.user.username or name
        except TelegramError:
            return None, None, args
        return uid, name, args[1:]

    return None, None, args


def get_target_user(update: Update):
    """نگه‌داشته‌شده برای سازگاری با کد قدیمی — فقط حالت ریپلای را می‌پوشاند."""
    if update.message.reply_to_message:
        return update.message.reply_to_message.from_user
    return None


def parse_reason_and_duration(args: list[str]):
    """
    از باقی آرگومان‌ها (بعد از حذف شناسه کاربر)، اگر توکن اول مدت‌زمان بود
    (مثل 10m/2h/1d) آن را جدا می‌کند؛ باقی متن به عنوان دلیل برمی‌گردد.
    خروجی: (duration_seconds_or_None, reason_str)
    """
    from utils import parse_duration
    if not args:
        return None, None
    duration = parse_duration(args[0])
    reason_tokens = args[1:] if duration is not None else args
    reason = " ".join(reason_tokens).strip() or None
    return duration, reason


async def _check_admin_abuse(context: ContextTypes.DEFAULT_TYPE, chat_id: int,
                              actor_id: int | None, actor_name: str | None, action: str | None) -> None:
    """
    Priority 7 — Anti-Admin Abuse.

    این تابع هیچ اکشنی رو مسدود نمی‌کنه (چون از نظر Hierarchy کاملاً مجازه)؛
    فقط اگر یک actor مشخص در یک بازه‌ی زمانی کوتاه تعداد غیرعادی اکشن مخرب
    (ban/mute/kick/warn) روی این گروه زده باشه، بلافاصله یک Alert (از طریق
    handlers.alerts.raise_alert) صادر می‌کنه تا Owner فوراً بفهمه — چه اکانت
    ادمین هک شده باشه، چه یک Moderator/Admin واقعاً داره سوءاستفاده می‌کنه.
    قبلاً تنها راه دیدن این الگو، بررسی دستی /logs بود.

    هشدار فقط دقیقاً موقع رسیدن به هر مضربی از آستانه صادر می‌شه (نه هر بار
    که actor یک اکشن مخرب دیگه بزنه) تا اسپم نشه.
    """
    if not actor_id or action not in ADMIN_ABUSE_ACTIONS:
        return
    if db.get_setting(chat_id, "admin_abuse_protection", "on") != "on":
        return

    threshold = int(db.get_setting(chat_id, "admin_abuse_threshold", ADMIN_ABUSE_THRESHOLD))
    if threshold <= 0:
        return
    window_minutes = int(db.get_setting(chat_id, "admin_abuse_window_minutes", ADMIN_ABUSE_WINDOW_MINUTES))
    since = time.time() - (window_minutes * 60)

    count = db.count_actor_destructive_actions(chat_id, actor_id, ADMIN_ABUSE_ACTIONS, since)
    if count == 0 or count % threshold != 0:
        return

    # ایمپورت داخل تابع: handlers/alerts.py خودش از handlers/common.py (log_action)
    # ایمپورت می‌کنه، پس ایمپورت سطح-ماژول اینجا یک Circular Import می‌ساخت.
    from handlers.alerts import raise_alert, ALERT_TYPE_ADMIN_ABUSE
    detail = tc(chat_id, "admin_abuse_alert_detail",
                name=actor_name or str(actor_id), count=count, minutes=window_minutes)
    await raise_alert(context, chat_id, ALERT_TYPE_ADMIN_ABUSE, detail)


async def log_action(context: ContextTypes.DEFAULT_TYPE, chat_id: int, text: str,
                      actor_id: int = None, actor_name: str = None, action: str = None,
                      target_id: int = None, target_name: str = None, reason: str = None):
    """
    اگر لاگ‌چنل تنظیم شده باشد، متن قابل‌خوانش را آن‌جا می‌فرستد؛ و در هر حالت
    رکورد ساخت‌یافته را در audit_log ذخیره می‌کند تا با /logs قابل مشاهده و
    برای Moderator Audit قابل تحلیل باشد. همچنین (Priority 7) بعد از ثبت،
    الگوی actor را برای Anti-Admin Abuse بررسی می‌کند.
    """
    if action:
        db.add_audit(chat_id, actor_id, actor_name or "-", action,
                     target_id, target_name or "-", reason, time.time())
        await _check_admin_abuse(context, chat_id, actor_id, actor_name, action)

    log_chat = db.get_setting(chat_id, "log_channel")
    if not log_chat:
        return
    try:
        await context.bot.send_message(chat_id=int(log_chat), text=text)
    except TelegramError as exc:
        import logging
        logging.getLogger(__name__).warning("audit log delivery failed for chat %s: %s", chat_id, exc)


async def cache_user_from_update(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """روی هر پیام اجرا می‌شود تا user_id<->username کاربران را برای resolve بعدی کش کند."""
    user = update.effective_user
    if user:
        db.upsert_user(user.id, user.username, user.first_name, time.time())
    chat = update.effective_chat
    if chat and chat.type in ("group", "supergroup"):
        # ثبت/به‌روزرسانی known_chats — سیستم تبلیغات (services/ads.py) از این
        # لیست برای پیدا کردن گروه‌هایی که ربات هنوز توشون عضوه استفاده می‌کنه.
        db.touch_known_chat(chat.id, chat.title, time.time())
