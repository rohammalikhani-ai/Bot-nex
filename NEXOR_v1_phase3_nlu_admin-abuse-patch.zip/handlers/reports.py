# -*- coding: utf-8 -*-
"""
Priority 5, Item 26 — Reports

هر عضو گروه می‌تواند با ریپلای روی یک پیام و زدن /report آن را به ادمین‌ها
گزارش کند. گزارش هم در جدول reports دائمی ذخیره می‌شود (برای /reports و برای
تحلیل بعدی) و هم بلافاصله با دکمه‌های اکشن سریع (سکوت/بن/حذف پیام/رد گزارش)
برای ادمین‌ها ارسال می‌شود — شبیه دکمه‌های سریع warn در moderation.py، با
همان اصل Server-side validation کامل روی هر کلیک.

اتصال به Item 27 (Admin Alerts): اگر چند Report مجزا در بازه‌ی کوتاه روی یک
کاربر ثبت شود، یک Alert از نوع "Multiple Reports" هم صادر می‌شود.
"""
import logging
import time
from datetime import datetime, timedelta

from telegram import Update, ChatPermissions, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc, t, get_lang
from config import REPORT_COOLDOWN_SECONDS, MULTI_REPORT_THRESHOLD, MULTI_REPORT_WINDOW_SECONDS
from config import RANK_ADMIN, RANK_MODERATOR, DEFAULT_WARN_MUTE_MINUTES
from handlers.common import log_action, authorize_action
from handlers import alerts as alerts_module


logger = logging.getLogger(__name__)

def _report_keyboard(chat_id: int, report_id: int):
    lang = get_lang(chat_id)
    return InlineKeyboardMarkup([[
        InlineKeyboardButton(t(lang, "btn_report_mute"), callback_data=f"report:{report_id}:mute"),
        InlineKeyboardButton(t(lang, "btn_report_ban"), callback_data=f"report:{report_id}:ban"),
    ], [
        InlineKeyboardButton(t(lang, "btn_report_delete"), callback_data=f"report:{report_id}:delete"),
        InlineKeyboardButton(t(lang, "btn_report_dismiss"), callback_data=f"report:{report_id}:dismiss"),
    ]])


async def report_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/report [دلیل] — باید ریپلای روی پیام کاربر مورد نظر باشد."""
    chat_id = update.effective_chat.id
    reply = update.message.reply_to_message
    if not reply or not reply.from_user:
        await update.message.reply_text(tc(chat_id, "report_need_reply"))
        return

    reporter = update.effective_user
    target = reply.from_user

    if target.id == reporter.id:
        await update.message.reply_text(tc(chat_id, "report_self"))
        return

    now = time.time()
    if db.find_recent_report_by_reporter(chat_id, reporter.id, reply.message_id, now - REPORT_COOLDOWN_SECONDS):
        await update.message.reply_text(tc(chat_id, "report_already"))
        return

    reason = " ".join(context.args) if context.args else None
    target_name = target.first_name or target.username or str(target.id)
    report_id = db.add_report(chat_id, reporter.id, reporter.first_name, target.id, target_name,
                               reply.message_id, reason, now)

    await update.message.reply_text(tc(chat_id, "report_done"))

    alert_text = tc(chat_id, "report_alert_header", id=report_id, reporter=reporter.first_name,
                     target=target_name, reason=reason or tc(chat_id, "warns_no_reason"))
    await alerts_module.notify_admins(context, chat_id, alert_text, reply_markup=_report_keyboard(chat_id, report_id))

    await log_action(context, chat_id, alert_text, reporter.id, reporter.first_name, "report",
                      target.id, target_name, reason)

    # Item 27 — اگر چند Report مجزا روی همین کاربر در بازه‌ی کوتاه جمع شده، Alert جدا بده
    recent_count = db.count_recent_reports_on_target(chat_id, target.id, now - MULTI_REPORT_WINDOW_SECONDS)
    if recent_count >= MULTI_REPORT_THRESHOLD:
        await alerts_module.raise_alert(
            context, chat_id, alerts_module.ALERT_TYPE_MULTI_REPORTS,
            tc(chat_id, "alert_multi_reports_text", target=target_name, count=recent_count,
               window=MULTI_REPORT_WINDOW_SECONDS),
        )


async def reports_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/reports — لیست گزارش‌های باز این گروه (ادمین به بالا یا Profile با قابلیت reports)."""
    chat_id = update.effective_chat.id
    user_id = update.effective_user.id
    ok, err = await authorize_action(context, chat_id, user_id, "reports", None, RANK_MODERATOR)
    if not ok:
        await update.message.reply_text(err)
        return
    rows = db.list_open_reports(chat_id, limit=15)
    if not rows:
        await update.message.reply_text(tc(chat_id, "reports_empty"))
        return
    lines = [tc(chat_id, "reports_header")]
    for rid, reporter_name, target_name, reason, ts in rows:
        when = datetime.fromtimestamp(ts).strftime("%m-%d %H:%M")
        lines.append(tc(chat_id, "report_item", id=rid, when=when, reporter=reporter_name,
                         target=target_name, reason=reason or tc(chat_id, "warns_no_reason")))
    await update.message.reply_text("\n".join(lines))


async def report_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    دکمه‌های سریع روی Alert گزارش. مثل modact_callback، همه‌چیز دوباره از صفر
    (Rank/Profile/Hierarchy) روی سرور چک می‌شود؛ فقط نمایش دکمه به کاربر هیچ
    مجوزی نمی‌دهد.
    """
    query = update.callback_query
    chat_id = update.effective_chat.id
    try:
        _, report_id_s, action = query.data.split(":")
        report_id = int(report_id_s)
    except ValueError:
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return

    row = db.get_report(report_id)
    if not row:
        await query.answer(tc(chat_id, "report_not_found"), show_alert=True)
        return
    _, report_chat_id, _, _, target_id, target_name, message_id, reason, ts, status = row
    if report_chat_id != chat_id:
        await query.answer(tc(chat_id, "modact_wrong_chat"), show_alert=True)
        return
    if status != "open":
        await query.answer(tc(chat_id, "report_not_found"), show_alert=True)
        return

    clicker_id = query.from_user.id

    if action == "dismiss":
        allowed, err = await authorize_action(context, chat_id, clicker_id, "reports", None, RANK_MODERATOR)
        if not allowed:
            await query.answer(err, show_alert=True)
            return
        db.set_report_status(report_id, "dismissed")
        result_text = tc(chat_id, "report_action_done_dismiss", id=report_id, target=target_name)
        await query.answer(tc(chat_id, "modact_done"))
        try:
            await query.edit_message_text(result_text)
        except Exception:
            logger.exception("failed to edit report message %s", report_id)
        clicker = query.from_user
        await log_action(context, chat_id, result_text, clicker.id, clicker.first_name,
                          "report_dismiss", target_id, target_name, None)
        return

    cap_needed = {"mute": "mute", "ban": "ban", "delete": "delete"}[action]
    min_rank = RANK_ADMIN if action == "ban" else RANK_MODERATOR
    target_for_auth = target_id if action in {"mute", "ban"} else None
    ok, err = await authorize_action(context, chat_id, clicker_id, cap_needed, target_for_auth, min_rank)
    if not ok:
        await query.answer(err, show_alert=True)
        return

    if action == "mute":
        until = datetime.now() + timedelta(minutes=DEFAULT_WARN_MUTE_MINUTES)
        await context.bot.restrict_chat_member(
            chat_id, target_id, permissions=ChatPermissions(can_send_messages=False), until_date=until
        )
        result_text = tc(chat_id, "report_action_done_mute", target=target_name, minutes=DEFAULT_WARN_MUTE_MINUTES)
    elif action == "ban":
        await context.bot.ban_chat_member(chat_id, target_id)
        result_text = tc(chat_id, "report_action_done_ban", target=target_name)
    elif action == "delete":
        try:
            await context.bot.delete_message(chat_id, message_id)
        except Exception:
            logger.exception("failed to delete reported message %s in chat %s", message_id, chat_id)
        result_text = tc(chat_id, "report_action_done_delete", target=target_name)
    else:
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return

    db.set_report_status(report_id, "resolved")
    await query.answer(tc(chat_id, "modact_done"))
    try:
        await query.edit_message_text(result_text)
    except Exception:
        logger.exception("non-fatal operation failed")

    clicker = query.from_user
    await log_action(context, chat_id, result_text, clicker.id, clicker.first_name,
                      f"report_{action}", target_id, target_name, reason)
