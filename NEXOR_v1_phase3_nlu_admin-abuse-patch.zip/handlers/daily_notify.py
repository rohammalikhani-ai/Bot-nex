# -*- coding: utf-8 -*-
"""
handlers/daily_notify.py

⚙️ سیستم اطلاع‌رسانی روزانه (💰 قیمت‌ها + 📰 اخبار + 📅 تاریخ/مناسبت).

این ماژول فقط لایه‌ی Telegram (دستورها، منوی دکمه‌ای، Jobهای JobQueue) است؛
تمام منطق واقعی در services/daily_message_builder.py (و DateService/
OccasionService/PriceService/NewsService زیرمجموعه‌اش) قرار دارد — دقیقاً
طبق معماری خواسته‌شده، تا منطق در این Handler تکرار نشود.

Scheduler: از همون JobQueue موجود پروژه استفاده می‌شه (دقیقاً هم‌الگو با
handlers/channel.py::_schedule_recurring_job/reschedule_recurring_posts):
  - هر گروه دو Job دائمی دارد: daily_price_<chat_id> و daily_news_<chat_id>.
  - قبل از ثبت Job جدید، Jobهای قبلی با همون اسم حذف می‌شن (جلوگیری از
    Duplicate Job وقتی ادمین ساعت را عوض می‌کند یا ربات Restart می‌شود).
  - زمان با tzinfo خود Timezone گروه ست می‌شه (نه UTC سرور) — چون
    python-telegram-bot's JobQueue.run_daily مستقیماً از tzinfo خود
    datetime.time استفاده می‌کنه.
  - هر Job قبل از ارسال واقعی چک می‌کنه که امروز (به وقت محلی گروه) قبلاً
    ارسال نشده (last_price_sent_day/last_news_sent_day) تا با Restart یا
    اجرای تصادفی دوباره، پیام دوبار ارسال نشه.
"""
from __future__ import annotations

import datetime
import logging

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc, get_lang
from config import RANK_ADMIN
from handlers.common import admin_only, get_rank, log_action
from services import daily_message_builder as dmb
from services import date_service
from services.price_providers import SUPPORTED_ASSETS
from utils import call_with_retry

logger = logging.getLogger(__name__)


def _price_job_name(chat_id: int) -> str:
    return f"daily_price_{chat_id}"


def _news_job_name(chat_id: int) -> str:
    return f"daily_news_{chat_id}"


def _cancel_jobs(job_queue, name: str) -> None:
    if job_queue is None:
        return
    for job in job_queue.get_jobs_by_name(name):
        job.schedule_removal()


def schedule_group_jobs(job_queue, chat_id: int, cfg: dict | None = None) -> None:
    """Job روزانه‌ی قیمت/خبر این گروه را (دوباره) ثبت می‌کند؛ اول Job قبلی
    با همون اسم حذف می‌شه تا Duplicate Job ساخته نشه."""
    if job_queue is None:
        return
    cfg = cfg or dmb.get_config(chat_id)
    lang = get_lang(chat_id)
    tz = date_service.resolve_timezone(cfg.get("timezone"), lang)

    price_name = _price_job_name(chat_id)
    _cancel_jobs(job_queue, price_name)
    if cfg.get("prices_enabled"):
        fire_time = datetime.time(hour=cfg.get("price_hour", 9), minute=cfg.get("price_minute", 0), tzinfo=tz)
        job_queue.run_daily(_price_job, time=fire_time, data=chat_id, name=price_name)

    news_name = _news_job_name(chat_id)
    _cancel_jobs(job_queue, news_name)
    if cfg.get("news_enabled"):
        fire_time = datetime.time(hour=cfg.get("news_hour", 18), minute=cfg.get("news_minute", 0), tzinfo=tz)
        job_queue.run_daily(_news_job, time=fire_time, data=chat_id, name=news_name)


def reschedule_all(app) -> None:
    """موقع استارت ربات صدا زده می‌شه تا Jobهای همه‌ی گروه‌هایی که قبلاً
    این سیستم را تنظیم کرده‌اند، دوباره ثبت شوند (Persistent بعد از Restart)."""
    if not app.job_queue:
        return
    for chat_id in db.list_daily_notify_chats():
        try:
            cfg = dmb.get_config(chat_id)
            if cfg.get("prices_enabled") or cfg.get("news_enabled"):
                schedule_group_jobs(app.job_queue, chat_id, cfg)
        except Exception:
            logger.exception("daily_notify: failed to reschedule jobs for chat %s", chat_id)


async def _price_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = context.job.data
    try:
        cfg = dmb.get_config(chat_id)
        if not cfg.get("prices_enabled"):
            return
        lang = get_lang(chat_id)
        resolved = date_service.resolve_today(chat_id, lang, cfg.get("timezone"))
        today_key = date_service.day_key_str(resolved)
        if cfg.get("last_price_sent_day") == today_key:
            return  # قبلاً امروز ارسال شده — از ارسال دوباره جلوگیری می‌شه
        result = dmb.build_price_message(chat_id)
        if result.text:
            await call_with_retry(context.bot.send_message, chat_id=chat_id, text=result.text)
        if result.day_key:
            dmb.record_price_sent(chat_id, result.day_key)
    except Exception:
        logger.exception("daily_notify: price job failed for chat %s", chat_id)


async def _news_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = context.job.data
    try:
        cfg = dmb.get_config(chat_id)
        if not cfg.get("news_enabled"):
            return
        lang = get_lang(chat_id)
        resolved = date_service.resolve_today(chat_id, lang, cfg.get("timezone"))
        today_key = date_service.day_key_str(resolved)
        if cfg.get("last_news_sent_day") == today_key:
            return
        result = dmb.build_news_message(chat_id)
        if result.text:
            await call_with_retry(context.bot.send_message, chat_id=chat_id, text=result.text)
        if result.day_key:
            dmb.record_news_sent(chat_id, result.day_key, result.new_fingerprints)
    except Exception:
        logger.exception("daily_notify: news job failed for chat %s", chat_id)


# ==================== منوی دکمه‌ای (پنل شخصیِ owner، هم‌الگو با admin_panel.py) ====================

def _state_label(chat_id: int, enabled: bool) -> str:
    return tc(chat_id, "state_on") if enabled else tc(chat_id, "state_off")


def _btn(chat_id: int, owner_id: int, text_key: str, action: str, **fmt) -> InlineKeyboardButton:
    label = tc(chat_id, text_key, **fmt) if fmt else tc(chat_id, text_key)
    return InlineKeyboardButton(label, callback_data=f"dn:{owner_id}:{action}")


def _main_menu_text(chat_id: int, cfg: dict) -> str:
    lang = get_lang(chat_id)
    resolved = date_service.resolve_today(chat_id, lang, cfg.get("timezone"))
    price_time = f"{cfg.get('price_hour', 9):02d}:{cfg.get('price_minute', 0):02d}"
    news_time = f"{cfg.get('news_hour', 18):02d}:{cfg.get('news_minute', 0):02d}"
    asset_labels = ", ".join(
        tc(chat_id, dmb.asset_label_key(a)) for a in cfg.get("assets", [])
    ) or tc(chat_id, "none")
    return "\n".join([
        tc(chat_id, "dn_menu_header"),
        "",
        tc(chat_id, "dn_menu_prices", state=_state_label(chat_id, cfg.get("prices_enabled")), time=price_time),
        tc(chat_id, "dn_menu_assets_line", assets=asset_labels),
        tc(chat_id, "dn_menu_news", state=_state_label(chat_id, cfg.get("news_enabled")), time=news_time),
        tc(chat_id, "dn_menu_timezone", tz=resolved.timezone),
        "",
        tc(chat_id, "dn_menu_date_flags",
           dp=_state_label(chat_id, cfg.get("date_before_price")),
           op=_state_label(chat_id, cfg.get("occasion_before_price")),
           dn=_state_label(chat_id, cfg.get("date_before_news")),
           on=_state_label(chat_id, cfg.get("occasion_before_news"))),
    ])


def status_text(chat_id: int) -> str:
    """متن وضعیت فعلی اطلاع‌رسانی روزانه — همون چیزی که /dailynotify نشون
    می‌ده. جدا از _main_menu_text تعریف شده تا /adminpanel (بخش «daily»)
    هم بتونه همین متن رو بدون تکرار منطق نمایش بده (تک منبع حقیقت)."""
    return _main_menu_text(chat_id, dmb.get_config(chat_id))


def _main_menu_kb(chat_id: int, owner_id: int, cfg: dict) -> InlineKeyboardMarkup:
    rows = [
        [_btn(chat_id, owner_id, "dn_btn_toggle_prices", "toggle_prices")],
        [_btn(chat_id, owner_id, "dn_btn_toggle_news", "toggle_news")],
        [_btn(chat_id, owner_id, "dn_btn_assets", "assets")],
        [_btn(chat_id, owner_id, "dn_btn_flags", "flags")],
        [_btn(chat_id, owner_id, "dn_btn_test_price", "test_price"),
         _btn(chat_id, owner_id, "dn_btn_test_news", "test_news")],
        [_btn(chat_id, owner_id, "dn_btn_help", "help")],
        [_btn(chat_id, owner_id, "dn_btn_close", "close")],
    ]
    return InlineKeyboardMarkup(rows)


def _assets_kb(chat_id: int, owner_id: int, cfg: dict) -> InlineKeyboardMarkup:
    enabled = set(cfg.get("assets", []))
    rows = []
    for asset in SUPPORTED_ASSETS:
        mark = "✅" if asset in enabled else "▫️"
        label = f"{mark} {tc(chat_id, dmb.asset_label_key(asset))}"
        rows.append([InlineKeyboardButton(label, callback_data=f"dn:{owner_id}:asset:{asset}")])
    rows.append([_btn(chat_id, owner_id, "panel_btn_back", "main")])
    return InlineKeyboardMarkup(rows)


def _flags_kb(chat_id: int, owner_id: int, cfg: dict) -> InlineKeyboardMarkup:
    def line(flag_key: str, label_key: str):
        mark = "✅" if cfg.get(flag_key) else "▫️"
        return [InlineKeyboardButton(f"{mark} {tc(chat_id, label_key)}", callback_data=f"dn:{owner_id}:flag:{flag_key}")]

    rows = [
        line("date_before_price", "dn_flag_date_price"),
        line("occasion_before_price", "dn_flag_occasion_price"),
        line("date_before_news", "dn_flag_date_news"),
        line("occasion_before_news", "dn_flag_occasion_news"),
        [_btn(chat_id, owner_id, "panel_btn_back", "main")],
    ]
    return InlineKeyboardMarkup(rows)


async def dailynotify_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    owner_id = update.effective_user.id
    cfg = dmb.get_config(chat_id)
    await update.message.reply_text(
        _main_menu_text(chat_id, cfg), reply_markup=_main_menu_kb(chat_id, owner_id, cfg),
    )


async def daily_notify_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    chat_id = update.effective_chat.id
    parts = query.data.split(":")
    # dn:<owner_id>:<action>[:<value>]
    owner_id = int(parts[1])
    action = parts[2]
    value = parts[3] if len(parts) > 3 else None

    clicker_id = update.effective_user.id
    if clicker_id != owner_id:
        await query.answer(tc(chat_id, "panel_not_owner"), show_alert=True)
        return
    if await get_rank(context, chat_id, clicker_id) < RANK_ADMIN:
        await query.answer(tc(chat_id, "err_need_rank", rank=tc(chat_id, "rank_admin")), show_alert=True)
        return

    cfg = dmb.get_config(chat_id)

    if action == "close":
        await query.answer()
        await query.message.delete()
        return

    if action == "main":
        await query.answer()
        await query.edit_message_text(_main_menu_text(chat_id, cfg), reply_markup=_main_menu_kb(chat_id, owner_id, cfg))
        return

    if action == "toggle_prices":
        cfg["prices_enabled"] = not cfg.get("prices_enabled")
        dmb.save_config(chat_id, cfg)
        schedule_group_jobs(context.job_queue, chat_id, cfg)
        await log_action(context, chat_id, tc(chat_id, "dn_log_toggle_prices", state=_state_label(chat_id, cfg["prices_enabled"])),
                          actor_id=clicker_id, action="daily_notify_toggle_prices")
        await query.answer(tc(chat_id, "dn_toast_saved"))
        await query.edit_message_text(_main_menu_text(chat_id, cfg), reply_markup=_main_menu_kb(chat_id, owner_id, cfg))
        return

    if action == "toggle_news":
        cfg["news_enabled"] = not cfg.get("news_enabled")
        dmb.save_config(chat_id, cfg)
        schedule_group_jobs(context.job_queue, chat_id, cfg)
        await log_action(context, chat_id, tc(chat_id, "dn_log_toggle_news", state=_state_label(chat_id, cfg["news_enabled"])),
                          actor_id=clicker_id, action="daily_notify_toggle_news")
        await query.answer(tc(chat_id, "dn_toast_saved"))
        await query.edit_message_text(_main_menu_text(chat_id, cfg), reply_markup=_main_menu_kb(chat_id, owner_id, cfg))
        return

    if action == "assets":
        await query.answer()
        await query.edit_message_text(tc(chat_id, "dn_assets_header"), reply_markup=_assets_kb(chat_id, owner_id, cfg))
        return

    if action == "asset":
        assets = set(cfg.get("assets", []))
        if value in assets:
            assets.discard(value)
        elif value in SUPPORTED_ASSETS:
            assets.add(value)
        cfg["assets"] = [a for a in SUPPORTED_ASSETS if a in assets]
        dmb.save_config(chat_id, cfg)
        await query.answer(tc(chat_id, "dn_toast_saved"))
        await query.edit_message_text(tc(chat_id, "dn_assets_header"), reply_markup=_assets_kb(chat_id, owner_id, cfg))
        return

    if action == "flags":
        await query.answer()
        await query.edit_message_text(tc(chat_id, "dn_flags_header"), reply_markup=_flags_kb(chat_id, owner_id, cfg))
        return

    if action == "flag":
        if value in ("date_before_price", "occasion_before_price", "date_before_news", "occasion_before_news"):
            cfg[value] = not cfg.get(value)
            dmb.save_config(chat_id, cfg)
        await query.answer(tc(chat_id, "dn_toast_saved"))
        await query.edit_message_text(tc(chat_id, "dn_flags_header"), reply_markup=_flags_kb(chat_id, owner_id, cfg))
        return

    if action == "test_price":
        await query.answer(tc(chat_id, "dn_toast_sending"))
        result = dmb.build_price_message(chat_id, force=True)
        text = result.text or tc(chat_id, "dn_test_no_data")
        try:
            await call_with_retry(context.bot.send_message, chat_id=chat_id, text=text)
        except Exception:
            logger.exception("daily_notify: test price send failed for chat %s", chat_id)
        return

    if action == "test_news":
        await query.answer(tc(chat_id, "dn_toast_sending"))
        result = dmb.build_news_message(chat_id, force=True)
        text = result.text or tc(chat_id, "dn_test_no_data")
        try:
            await call_with_retry(context.bot.send_message, chat_id=chat_id, text=text)
        except Exception:
            logger.exception("daily_notify: test news send failed for chat %s", chat_id)
        return

    if action == "help":
        await query.answer()
        await query.edit_message_text(tc(chat_id, "dn_help_text"), reply_markup=_main_menu_kb(chat_id, owner_id, cfg))
        return

    await query.answer()


# ==================== دستورهای متنی مکمل (ساعت/Timezone نیاز به ورودی متنی دارن) ====================

async def setpricetime_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    args = context.args or []
    if len(args) != 1 or ":" not in args[0]:
        await update.message.reply_text(tc(chat_id, "dn_settime_usage", cmd="/setpricetime"))
        return
    try:
        hour_s, minute_s = args[0].split(":", 1)
        hour, minute = int(hour_s), int(minute_s)
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            raise ValueError
    except ValueError:
        await update.message.reply_text(tc(chat_id, "dn_settime_invalid"))
        return

    cfg = dmb.get_config(chat_id)
    cfg["price_hour"], cfg["price_minute"] = hour, minute
    dmb.save_config(chat_id, cfg)
    schedule_group_jobs(context.job_queue, chat_id, cfg)
    await log_action(context, chat_id, tc(chat_id, "dn_log_settime", what="price", time=args[0]),
                      actor_id=update.effective_user.id, action="daily_notify_set_price_time")
    await update.message.reply_text(tc(chat_id, "dn_settime_done", time=f"{hour:02d}:{minute:02d}"))


async def setnewstime_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    args = context.args or []
    if len(args) != 1 or ":" not in args[0]:
        await update.message.reply_text(tc(chat_id, "dn_settime_usage", cmd="/setnewstime"))
        return
    try:
        hour_s, minute_s = args[0].split(":", 1)
        hour, minute = int(hour_s), int(minute_s)
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            raise ValueError
    except ValueError:
        await update.message.reply_text(tc(chat_id, "dn_settime_invalid"))
        return

    cfg = dmb.get_config(chat_id)
    cfg["news_hour"], cfg["news_minute"] = hour, minute
    dmb.save_config(chat_id, cfg)
    schedule_group_jobs(context.job_queue, chat_id, cfg)
    await log_action(context, chat_id, tc(chat_id, "dn_log_settime", what="news", time=args[0]),
                      actor_id=update.effective_user.id, action="daily_notify_set_news_time")
    await update.message.reply_text(tc(chat_id, "dn_settime_done", time=f"{hour:02d}:{minute:02d}"))


async def setdailytz_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    args = context.args or []
    if len(args) != 1:
        await update.message.reply_text(tc(chat_id, "dn_settz_usage"))
        return
    tz_name = args[0].strip()
    if not date_service.is_valid_timezone(tz_name):
        await update.message.reply_text(tc(chat_id, "dn_settz_invalid"))
        return

    cfg = dmb.get_config(chat_id)
    cfg["timezone"] = tz_name
    dmb.save_config(chat_id, cfg)
    schedule_group_jobs(context.job_queue, chat_id, cfg)
    await log_action(context, chat_id, tc(chat_id, "dn_log_settz", tz=tz_name),
                      actor_id=update.effective_user.id, action="daily_notify_set_timezone")
    await update.message.reply_text(tc(chat_id, "dn_settz_done", tz=tz_name))


async def testdailyprice_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    result = dmb.build_price_message(chat_id, force=True)
    await update.message.reply_text(result.text or tc(chat_id, "dn_test_no_data"))


async def testdailynews_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    result = dmb.build_news_message(chat_id, force=True)
    await update.message.reply_text(result.text or tc(chat_id, "dn_test_no_data"))


async def dailyassets_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    owner_id = update.effective_user.id
    cfg = dmb.get_config(chat_id)
    await update.message.reply_text(tc(chat_id, "dn_assets_header"), reply_markup=_assets_kb(chat_id, owner_id, cfg))
