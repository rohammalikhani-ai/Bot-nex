# -*- coding: utf-8 -*-
"""
handlers/ads.py

لایه‌ی تلگرامی سیستم تبلیغات: منوی /ads (ثبت آگهی رایگان یا خرید تبلیغات
پولی با بنر+توضیحات+تعداد دفعات ارسال در روز)، پرداخت (⭐ Stars / 💎 TON با
همون الگوی handlers/payments.py) و صف بررسی ادمین با /adadmin.

منطق واقعی (قیمت‌گذاری، چرخش نمایش، DB) در services/ads.py است؛ این فایل
فقط ویزارد Telegram (ConversationHandler) و پیام‌ها را می‌سازد.
"""
from __future__ import annotations

import logging

from telegram import LabeledPrice, Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes, ConversationHandler, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters,
)

from handlers.common import admin_only
from services import ads as ads_service
from config import AD_MIN_TIMES_PER_DAY, AD_MAX_TIMES_PER_DAY, AD_DURATION_CHOICES_DAYS
from i18n import tc, get_lang

logger = logging.getLogger(__name__)

WAIT_BANNER, WAIT_TEXT, WAIT_TIMES, WAIT_DURATION, WAIT_METHOD = range(5)


def _cancel_kb(chat_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton(tc(chat_id, "ads_btn_cancel"), callback_data="ads:cancel")]])


# ==================== شروع ویزارد ====================

async def ads_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return ConversationHandler.END
    chat_id = update.effective_chat.id
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(tc(chat_id, "ads_btn_free"), callback_data="ads:new:free")],
        [InlineKeyboardButton(tc(chat_id, "ads_btn_paid"), callback_data="ads:new:paid")],
        [InlineKeyboardButton(tc(chat_id, "ads_btn_cancel"), callback_data="ads:cancel")],
    ])
    await update.effective_message.reply_text(
        tc(chat_id, "ads_intro"),
        reply_markup=kb,
    )
    return ConversationHandler.END  # entry واقعی از طریق callback زیره


async def ads_new_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    if not await admin_only(update, context):
        return ConversationHandler.END
    kind = query.data.split(":")[-1]  # free | paid
    chat_id = update.effective_chat.id
    context.user_data["ad_wizard"] = {
        "owner_chat_id": chat_id,
        "user_id": update.effective_user.id,
        "kind": kind,
        "banner_file_id": None,
        "text": None,
        "times_per_day": AD_MIN_TIMES_PER_DAY,
        "duration_days": AD_DURATION_CHOICES_DAYS[0],
    }
    await query.edit_message_text(tc(chat_id, "ads_ask_banner"))
    return WAIT_BANNER


async def ads_banner_step(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    wiz = context.user_data.get("ad_wizard")
    if not wiz:
        return ConversationHandler.END
    chat_id = update.effective_chat.id
    if update.message.photo:
        wiz["banner_file_id"] = update.message.photo[-1].file_id
    elif update.message.text and update.message.text.strip() not in ("رد", "/skip", "skip"):
        await update.message.reply_text(tc(chat_id, "ads_banner_invalid"))
        return WAIT_BANNER
    await update.message.reply_text(tc(chat_id, "ads_ask_text"))
    return WAIT_TEXT


async def ads_text_step(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    wiz = context.user_data.get("ad_wizard")
    if not wiz:
        return ConversationHandler.END
    chat_id = update.effective_chat.id
    text = (update.message.text or "").strip()
    if not text:
        await update.message.reply_text(tc(chat_id, "ads_text_empty"))
        return WAIT_TEXT
    if len(text) > 900:
        text = text[:900]
    wiz["text"] = text

    if wiz["kind"] == ads_service.KIND_FREE:
        return await _finalize_free(update, context)

    rows = []
    row = []
    for n in range(AD_MIN_TIMES_PER_DAY, AD_MAX_TIMES_PER_DAY + 1):
        row.append(InlineKeyboardButton(tc(chat_id, "ads_times_btn", n=n), callback_data=f"ads:times:{n}"))
        if len(row) == 3:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton(tc(chat_id, "ads_btn_cancel"), callback_data="ads:cancel")])
    await update.message.reply_text(
        tc(chat_id, "ads_ask_times"),
        reply_markup=InlineKeyboardMarkup(rows),
    )
    return WAIT_TIMES


async def _finalize_free(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    wiz = context.user_data.pop("ad_wizard")
    chat_id = update.effective_chat.id
    ad_id = ads_service.create_draft(
        owner_chat_id=wiz["owner_chat_id"], user_id=wiz["user_id"], kind=ads_service.KIND_FREE,
        banner_file_id=wiz["banner_file_id"], text=wiz["text"], times_per_day=1, duration_days=1,
    )
    ads_service.submit_free_ad(ad_id)
    await update.message.reply_text(tc(chat_id, "ads_free_submitted", id=ad_id))
    return ConversationHandler.END


async def ads_times_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    wiz = context.user_data.get("ad_wizard")
    if not wiz:
        return ConversationHandler.END
    chat_id = update.effective_chat.id
    times = int(query.data.split(":")[-1])
    wiz["times_per_day"] = ads_service.clamp_times_per_day(times)

    rows = []
    for d in AD_DURATION_CHOICES_DAYS:
        stars = ads_service.price_stars(wiz["times_per_day"], d)
        rows.append([InlineKeyboardButton(tc(chat_id, "ads_duration_btn", days=d, stars=stars), callback_data=f"ads:dur:{d}")])
    rows.append([InlineKeyboardButton(tc(chat_id, "ads_btn_cancel"), callback_data="ads:cancel")])
    await query.edit_message_text(
        tc(chat_id, "ads_ask_duration", times=wiz["times_per_day"]),
        reply_markup=InlineKeyboardMarkup(rows),
    )
    return WAIT_DURATION


async def ads_duration_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    wiz = context.user_data.get("ad_wizard")
    if not wiz:
        return ConversationHandler.END
    chat_id = update.effective_chat.id
    duration = int(query.data.split(":")[-1])
    wiz["duration_days"] = duration if duration in AD_DURATION_CHOICES_DAYS else AD_DURATION_CHOICES_DAYS[0]

    ad_id = ads_service.create_draft(
        owner_chat_id=wiz["owner_chat_id"], user_id=wiz["user_id"], kind=ads_service.KIND_PAID,
        banner_file_id=wiz["banner_file_id"], text=wiz["text"],
        times_per_day=wiz["times_per_day"], duration_days=wiz["duration_days"],
    )
    wiz["ad_id"] = ad_id

    stars = ads_service.price_stars(wiz["times_per_day"], wiz["duration_days"])
    rows = [[InlineKeyboardButton(tc(chat_id, "ads_btn_pay_stars", stars=stars), callback_data=f"ads:pay:stars:{ad_id}")]]
    summary = tc(chat_id, "ads_order_summary", id=ad_id, times=wiz["times_per_day"], days=wiz["duration_days"], stars=stars)
    if ads_service.ton_enabled():
        ton_amount = ads_service.price_ton(wiz["times_per_day"], wiz["duration_days"])
        rows.append([InlineKeyboardButton(tc(chat_id, "ads_btn_pay_ton", ton=f"{ton_amount:g}"), callback_data=f"ads:pay:ton:{ad_id}")])
        summary += tc(chat_id, "ads_order_summary_ton_suffix", ton=f"{ton_amount:g}")
    rows.append([InlineKeyboardButton(tc(chat_id, "ads_btn_cancel"), callback_data="ads:cancel")])
    summary += tc(chat_id, "ads_order_summary_footer")

    await query.edit_message_text(
        summary,
        reply_markup=InlineKeyboardMarkup(rows),
    )
    return WAIT_METHOD


async def ads_pay_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    chat_id = update.effective_chat.id
    _, _, method, ad_id_str = query.data.split(":")
    ad_id = int(ad_id_str)
    wiz = context.user_data.pop("ad_wizard", None)

    if method == "stars":
        result = ads_service.start_stars_payment(ad_id)
        if result is None:
            await query.edit_message_text(tc(chat_id, "ads_order_invalid"))
            return ConversationHandler.END
        await query.edit_message_text(tc(chat_id, "ads_sending_invoice"))
        await context.bot.send_invoice(
            chat_id=update.effective_user.id,
            title=tc(chat_id, "ads_invoice_title", id=ad_id),
            description=tc(chat_id, "ads_invoice_desc"),
            payload=result["payload"],
            provider_token="",
            currency="XTR",
            prices=[LabeledPrice(tc(chat_id, "ads_invoice_label"), result["amount_stars"])],
        )
        return ConversationHandler.END

    if method == "ton":
        owner_chat_id = wiz["owner_chat_id"] if wiz else update.effective_chat.id
        info = ads_service.start_ton_payment(ad_id, owner_chat_id, update.effective_user.id)
        if info is None:
            await query.edit_message_text(tc(chat_id, "ads_ton_disabled"))
            return ConversationHandler.END
        await query.edit_message_text(
            tc(
                chat_id, "ads_ton_payment_info", id=ad_id,
                amount=f"{info['amount_ton']:g}", address=info["address"],
                memo=info["memo"], link=info["transfer_link"],
            )
        )
        return ConversationHandler.END

    return ConversationHandler.END


async def ads_cancel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    context.user_data.pop("ad_wizard", None)
    await query.edit_message_text(tc(update.effective_chat.id, "ads_cancelled"))
    return ConversationHandler.END


async def ads_cancel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.pop("ad_wizard", None)
    await update.effective_message.reply_text(tc(update.effective_chat.id, "ads_cancelled"))
    return ConversationHandler.END


ads_conversation = ConversationHandler(
    entry_points=[
        CallbackQueryHandler(ads_new_callback, pattern=r"^ads:new:(free|paid)$"),
    ],
    states={
        WAIT_BANNER: [MessageHandler(filters.PHOTO | (filters.TEXT & ~filters.COMMAND), ads_banner_step)],
        WAIT_TEXT: [MessageHandler(filters.TEXT & ~filters.COMMAND, ads_text_step)],
        WAIT_TIMES: [CallbackQueryHandler(ads_times_callback, pattern=r"^ads:times:\d+$")],
        WAIT_DURATION: [CallbackQueryHandler(ads_duration_callback, pattern=r"^ads:dur:\d+$")],
        WAIT_METHOD: [CallbackQueryHandler(ads_pay_callback, pattern=r"^ads:pay:(stars|ton):\d+$")],
    },
    fallbacks=[
        CallbackQueryHandler(ads_cancel_callback, pattern=r"^ads:cancel$"),
        CommandHandler("cancel", ads_cancel_cmd),
    ],
    per_message=False,
)


# ==================== پرداخت Stars: تایید ====================
# نکته: PreCheckoutQueryHandler و MessageHandler(SUCCESSFUL_PAYMENT) سراسری‌اند
# و در handlers/payments.py رجیستر شدن (چون هر Update فقط به یکی از هرکدوم
# می‌رسه) — از اونجا بر اساس payload prefix ("nexor_ad_") به
# services/ads.py.confirm_stars_payment مسیریابی می‌شن. اینجا فقط Job دوره‌ی TON.


async def ads_ton_check_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Job دوره‌ای (مثل payments.ton_check_job) — سفارش‌های تبلیغ با TON در
    انتظار رو با تراکنش‌های تازه‌ی toncenter تطبیق می‌ده. با تایید، سفارش وارد
    صف بررسی ادمین می‌شه (هنوز فعال نیست) و صاحب آگهی مطلع می‌شه."""
    confirmed = ads_service.check_ton_payments_once()
    for order in confirmed:
        try:
            await context.bot.send_message(
                chat_id=order["user_id"],
                text=tc(order.get("owner_chat_id", order["user_id"]), "ads_ton_confirmed", id=order["id"]),
            )
        except Exception:
            logger.exception("اطلاع‌رسانی تایید پرداخت TON آگهی شکست خورد")


# ==================== صف بررسی ادمین ====================

async def adadmin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    pending = ads_service.list_pending()
    if not pending:
        await update.effective_message.reply_text(tc(chat_id, "ads_admin_none_pending"))
        return
    for ad in pending[:10]:
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton(tc(chat_id, "ads_btn_approve"), callback_data=f"adrev:approve:{ad['id']}"),
            InlineKeyboardButton(tc(chat_id, "ads_btn_reject"), callback_data=f"adrev:reject:{ad['id']}"),
        ]])
        kind_label = tc(chat_id, "ads_kind_free") if ad["kind"] == "free" else tc(chat_id, "ads_kind_paid")
        caption = tc(
            chat_id, "ads_admin_caption", id=ad["id"], kind=kind_label,
            times=ad["times_per_day"], days=ad["duration_days"], text=ad["text"],
        )
        if ad.get("banner_file_id"):
            await context.bot.send_photo(chat_id=update.effective_chat.id, photo=ad["banner_file_id"],
                                          caption=caption, reply_markup=kb)
        else:
            await update.effective_message.reply_text(caption, reply_markup=kb)


async def adadmin_review_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not await admin_only(update, context):
        await query.answer()
        return
    _, action, ad_id_str = query.data.split(":")
    ad_id = int(ad_id_str)
    admin_chat_id = update.effective_chat.id
    if action == "approve":
        order = ads_service.approve(ad_id, update.effective_user.id)
        await query.answer(tc(admin_chat_id, "ads_approved_toast"))
        if order:
            try:
                await context.bot.send_message(
                    chat_id=order["user_id"],
                    text=tc(order.get("owner_chat_id", order["user_id"]), "ads_approved_notify", id=ad_id),
                )
            except Exception:
                logger.exception("اطلاع‌رسانی تایید آگهی شکست خورد")
    else:
        ads_service.reject(ad_id, update.effective_user.id, None)
        await query.answer(tc(admin_chat_id, "ads_rejected_toast"))
    try:
        await query.edit_message_reply_markup(reply_markup=None)
    except Exception:
        pass


async def myads_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    rows = ads_service.my_ads(chat_id)
    if not rows:
        await update.effective_message.reply_text(tc(chat_id, "ads_none_yet"))
        return
    status_labels = {
        "draft": tc(chat_id, "ads_status_draft"),
        "pending_payment": tc(chat_id, "ads_status_pending_payment"),
        "pending_review": tc(chat_id, "ads_status_pending_review"),
        "active": tc(chat_id, "ads_status_active"),
        "rejected": tc(chat_id, "ads_status_rejected"),
        "expired": tc(chat_id, "ads_status_expired"),
    }
    lines = [tc(chat_id, "ads_myads_header")]
    for ad in rows:
        lines.append(tc(
            chat_id, "ads_myads_line", id=ad["id"],
            status=status_labels.get(ad["status"], ad["status"]),
            times=ad["times_per_day"], days=ad["duration_days"],
        ))
    lines.append(tc(chat_id, "ads_myads_footer", id=rows[0]["id"]))
    await update.effective_message.reply_text("\n".join(lines))


async def adstats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or not context.args[0].isdigit():
        await update.effective_message.reply_text(tc(chat_id, "ads_stats_usage"))
        return
    ad_id = int(context.args[0])
    stats = ads_service.ad_stats(ad_id, chat_id, update.effective_user.id)
    if stats is None:
        await update.effective_message.reply_text(tc(chat_id, "ads_stats_not_found"))
        return

    order = stats["order"]
    status_labels = {
        "draft": tc(chat_id, "ads_status_draft"),
        "pending_payment": tc(chat_id, "ads_status_pending_payment"),
        "pending_review": tc(chat_id, "ads_status_pending_review"),
        "active": tc(chat_id, "ads_status_active2"),
        "rejected": tc(chat_id, "ads_status_rejected2"),
        "expired": tc(chat_id, "ads_status_expired2"),
    }
    lines = [
        tc(chat_id, "ads_stats_title", id=ad_id),
        tc(chat_id, "ads_stats_status", status=status_labels.get(order["status"], order["status"])),
        tc(chat_id, "ads_stats_quota", quota=stats["daily_quota"]),
        tc(chat_id, "ads_stats_today", today=stats["today_count"], quota=stats["daily_quota"]),
        tc(chat_id, "ads_stats_total", total=stats["total"]),
        tc(chat_id, "ads_stats_unique", n=stats["unique_chats"]),
    ]
    if stats["per_day"]:
        lines.append(tc(chat_id, "ads_stats_perday_header"))
        for row in stats["per_day"]:
            lines.append(tc(chat_id, "ads_stats_perday_line", day=row["day"], count=row["count"]))
    else:
        lines.append(tc(chat_id, "ads_stats_no_views"))
    await update.effective_message.reply_text("\n".join(lines))
