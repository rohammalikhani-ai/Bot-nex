# -*- coding: utf-8 -*-
from telegram import Update
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc
from handlers.common import admin_only


async def save_note_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "save_usage"))
        return

    name = context.args[0].lower()

    if update.message.reply_to_message:
        content = update.message.reply_to_message.text or update.message.reply_to_message.caption or ""
    else:
        content = " ".join(context.args[1:])

    if not content:
        await update.message.reply_text(tc(chat_id, "save_empty"))
        return

    db.save_note(chat_id, name, content)
    await update.message.reply_text(tc(chat_id, "save_done", name=name))


async def get_note_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "get_usage"))
        return
    name = context.args[0].lower()
    content = db.get_note(chat_id, name)
    if content is None:
        await update.message.reply_text(tc(chat_id, "get_not_found"))
        return
    await update.message.reply_text(content)


async def notes_list_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    names = db.list_notes(chat_id)
    if not names:
        await update.message.reply_text(tc(chat_id, "notes_empty"))
        return
    header = tc(chat_id, "notes_list_header")
    await update.message.reply_text(header + "\n" + "\n".join(f"#{n}" for n in names))


async def clear_note_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "clear_usage"))
        return
    name = context.args[0].lower()
    db.delete_note(chat_id, name)
    await update.message.reply_text(tc(chat_id, "clear_done", name=name))


async def hashtag_note_trigger(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """وقتی کاربر یک پیام فقط شامل #نام بفرسته، یادداشت مربوطه نمایش داده می‌شه."""
    text = (update.message.text or "").strip()
    if not text.startswith("#") or " " in text:
        return
    name = text[1:].lower()
    if not name:
        return
    content = db.get_note(update.effective_chat.id, name)
    if content:
        await update.message.reply_text(content)
