# -*- coding: utf-8 -*-
"""
راهنمای شیشه‌ای ربات (Interactive Guide Panel).

جایگزین /help متنی قدیمی: یک پنل دکمه‌ای چندسطحیه که به‌جای یک تکست بلند و
خسته‌کننده، ربات رو به «دسته‌بندی»‌های موضوعی می‌شکنه (قفل‌ها، مدیریت، نقش‌ها،
تنظیمات، ...). با زدن هر دسته یک توضیح کوتاه و جذاب درباره‌ی همون بخش نشون
داده می‌شه؛ زیرش هم یک ردیف دکمه‌ی شیشه‌ای (Inline Keyboard) با همون
کلمه‌هایی که واقعاً باید به‌جای دستور "/" توی چت تایپ بشن (از
locales/<lang>.py::TEXT_TRIGGERS خونده می‌شه، نه از COMMANDS انگلیسی) —
با زدن هر کلمه، یک popup با توضیح یک‌خطی همون قابلیت باز می‌شه.

چندزبانه بودن:
تمام متن‌های ثابت (عنوان دسته، توضیح دسته، توضیح یک‌خطی هر کلیدواژه) از
locales/<lang>.py::STRINGS با کلیدهای guide_* خونده می‌شن؛ خودِ برچسب دکمه‌ی
کلیدواژه هم از TEXT_TRIGGERS همون زبان گروه گرفته می‌شه. یعنی برای اضافه
کردن یک زبان جدید فقط کافیه همون کلیدهای guide_* (این فایل مرجعشونه) رو به
locales/<lang_جدید>.py اضافه کنی؛ هیچ‌جای این فایل نیازی به تغییر نداره.

معماری دکمه‌ها دقیقاً از الگوی handlers/admin_panel.py پیروی می‌کنه: پنل
شخصیه (owner_id داخل callback_data)، هرکسی غیر از بازکننده بزنه فقط یک
alert کوچیک می‌بینه.
"""
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

import importlib

from i18n import tc, get_lang

# ---------------------------------------------------------------------------
# دسته‌بندی موضوعی: (شناسه‌ی دسته، ایموجی، [شناسه‌ی دستورهایی که TEXT_TRIGGERS دارن])
# شناسه‌ی هر دستور دقیقاً همون کلیدیه که در handlers/text_commands.py::COMMANDS
# و در locales/<lang>.py::TEXT_TRIGGERS استفاده شده.
# ---------------------------------------------------------------------------
GUIDE_CATEGORIES = [
    ("locks", ["lock", "unlock", "locks", "filter", "stopfilter", "filters", "domains", "forwardrules"]),
    ("moderation", ["warn", "unwarn", "warns", "mute", "unmute", "ban", "unban", "kick", "del", "purge"]),
    ("roles", ["promote", "demote", "roles", "profiles", "myperms"]),
    ("settings", ["settings", "setlang", "captcha", "goodbye", "adminpanel"]),
    ("security", ["antiraid", "lockdown", "unlockchat"]),
    ("rules", ["rules", "setrules", "clearrules"]),
    ("autoreply", ["addkeyword", "delkeyword", "keywords", "addcmd", "delcmd", "cmds",
                   "setanswer", "answerlist", "delanswer", "cleananswerlist"]),
    ("channel", ["setchannel", "post", "schedulepost", "editpost", "delpost", "channelstats"]),
    ("autoactions", ["addautoaction", "delautoaction", "autoactions"]),
    ("notes", ["save", "get", "notes", "clear"]),
    ("reports_logs", ["report", "reports", "alerts", "adminabuseprotection", "logs", "exportsettings", "setlogchannel"]),
    ("federation", ["fnew", "fjoin", "fleave", "finfo", "fban", "funban"]),
    ("ai_copilot", ["copilot", "aicheck", "aiexplain", "aireports", "aihealth", "airule", "aioptimize", "aiincident", "aiplan"]),
]
_CATEGORY_CMDS = dict(GUIDE_CATEGORIES)

_TRIGGERS_CACHE = {}


def _triggers_for(lang: str) -> dict:
    """اولین عبارت TEXT_TRIGGERS هر شناسه‌ی دستور را برای یک زبان برمی‌گرداند."""
    if lang not in _TRIGGERS_CACHE:
        try:
            mod = importlib.import_module(f"locales.{lang}")
            triggers = getattr(mod, "TEXT_TRIGGERS", {})
        except ImportError:
            triggers = {}
        _TRIGGERS_CACHE[lang] = {cmd_id: phrases[0] for cmd_id, phrases in triggers.items() if phrases}
    return _TRIGGERS_CACHE[lang]


def _keyword_label(lang: str, cmd_id: str) -> str:
    return _triggers_for(lang).get(cmd_id, cmd_id)


def _btn(chat_id: int, owner_id: int, text: str, action: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text, callback_data=f"guide:{owner_id}:{action}")


def _main_menu_kb(chat_id: int, owner_id: int) -> InlineKeyboardMarkup:
    rows = []
    pending = None
    for cat_id, _cmds in GUIDE_CATEGORIES:
        label = tc(chat_id, f"guide_btn_{cat_id}")
        btn = _btn(chat_id, owner_id, label, f"cat:{cat_id}")
        if pending is None:
            pending = btn
        else:
            rows.append([pending, btn])
            pending = None
    if pending is not None:
        rows.append([pending])
    rows.append([_btn(chat_id, owner_id, tc(chat_id, "panel_btn_close"), "close")])
    return InlineKeyboardMarkup(rows)


def _category_kb(chat_id: int, owner_id: int, cat_id: str) -> InlineKeyboardMarkup:
    lang = get_lang(chat_id)
    cmds = _CATEGORY_CMDS.get(cat_id, [])
    rows = []
    pending = None
    for cmd_id in cmds:
        label = _keyword_label(lang, cmd_id)
        btn = _btn(chat_id, owner_id, label, f"kw:{cat_id}:{cmd_id}")
        if pending is None:
            pending = btn
        else:
            rows.append([pending, btn])
            pending = None
    if pending is not None:
        rows.append([pending])
    rows.append([_btn(chat_id, owner_id, tc(chat_id, "panel_btn_back"), "main")])
    return InlineKeyboardMarkup(rows)


async def guide_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """نقطه‌ی ورود عمومی (/help یا کلمه‌ی «راهنما»/«کمک») — برای همه در دسترسه."""
    chat_id = update.effective_chat.id
    user = update.effective_user
    text = tc(chat_id, "guide_intro")
    await update.effective_message.reply_text(text, reply_markup=_main_menu_kb(chat_id, user.id))


async def guide_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = update.effective_chat.id
    try:
        _, owner_id_s, rest = query.data.split(":", 2)
        owner_id = int(owner_id_s)
    except ValueError:
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return

    if query.from_user.id != owner_id:
        # این پنل شخصیه؛ دقیقاً مثل پنل ادمین (handlers/admin_panel.py).
        await query.answer(tc(chat_id, "panel_not_yours"), show_alert=True)
        return

    parts = rest.split(":")
    action = parts[0]

    if action == "close":
        await query.answer()
        try:
            await query.edit_message_text(tc(chat_id, "panel_closed"))
        except Exception:
            pass
        return

    if action == "main":
        await query.answer()
        text = tc(chat_id, "guide_intro")
        try:
            await query.edit_message_text(text, reply_markup=_main_menu_kb(chat_id, owner_id))
        except Exception:
            pass
        return

    if action == "cat" and len(parts) == 2:
        cat_id = parts[1]
        if cat_id not in _CATEGORY_CMDS:
            await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
            return
        await query.answer()
        text = f"{tc(chat_id, f'guide_title_{cat_id}')}\n\n{tc(chat_id, f'guide_desc_{cat_id}')}"
        try:
            await query.edit_message_text(text, reply_markup=_category_kb(chat_id, owner_id, cat_id))
        except Exception:
            pass
        return

    if action == "kw" and len(parts) == 3:
        _cat_id, cmd_id = parts[1], parts[2]
        lang = get_lang(chat_id)
        word = _keyword_label(lang, cmd_id)
        one_liner = tc(chat_id, f"guide_kw_{cmd_id}")
        await query.answer(f"「{word}」\n{one_liner}", show_alert=True)
        return

    await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
