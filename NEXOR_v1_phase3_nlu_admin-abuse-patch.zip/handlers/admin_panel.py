# -*- coding: utf-8 -*-
"""
پنل شخصی ادمین/مدیر.

با نوشتن کلمه‌ی «ادمین» یا «پنل» (یا معادلش به زبان خود گروه — همه از
locales/<lang>.py::TEXT_TRIGGERS["adminpanel"] خونده می‌شه) یا با دستور
/adminpanel، یک منوی دکمه‌ای باز می‌شه که میان‌بر سریع به مهم‌ترین گزارش‌های
فقط‌خواندنی گروهه (تنظیمات، قفل‌ها، فیلترها، قوانین، گزارش‌های باز، لاگ،
مدیران). خود این دستور از قبل توسط handlers/text_commands.py با حداقل رتبه‌ی
RANK_MODERATOR گیت شده، پس فقط مدیر/ادمین/مالک گروه می‌تونه بازش کنه.

نکته‌ی مهم دربارهٔ "شخصی" بودن پنل:
هر پیام پنل، آی‌دی کسی که بازش کرده رو داخل callback_data نگه می‌داره
(panel:<owner_id>:<section>). با هر کلیک، دوباره چک می‌شه که:
  ۱) کلیک‌کننده همون owner_id باشه (وگرنه فقط یک alert کوچیک می‌بینه، نه
     تغییر داده‌ای) — یعنی این واقعاً پنل شخصیه، نه یک منوی عمومی که هرکسی
     تو گروه بتونه ازش استفاده کنه.
  ۲) رتبه‌ی کلیک‌کننده هنوز کافیه (شاید بین باز شدن پنل و کلیک، دیمود شده
     باشه).
"""
from datetime import datetime

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc, t, get_lang
from config import RANK_MODERATOR
from handlers.common import get_rank, moderator_only
from handlers import daily_notify


def _btn(chat_id: int, owner_id: int, key: str, section: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(tc(chat_id, key), callback_data=f"panel:{owner_id}:{section}")


def _main_menu_kb(chat_id: int, owner_id: int) -> InlineKeyboardMarkup:
    rows = [
        [_btn(chat_id, owner_id, "panel_btn_settings", "settings"),
         _btn(chat_id, owner_id, "panel_btn_locks", "locks")],
        [_btn(chat_id, owner_id, "panel_btn_filters", "filters"),
         _btn(chat_id, owner_id, "panel_btn_rules", "rules")],
        [_btn(chat_id, owner_id, "panel_btn_reports", "reports"),
         _btn(chat_id, owner_id, "panel_btn_logs", "logs")],
        [_btn(chat_id, owner_id, "panel_btn_roles", "roles")],
        [_btn(chat_id, owner_id, "panel_btn_daily", "daily")],
        [_btn(chat_id, owner_id, "panel_btn_close", "close")],
    ]
    return InlineKeyboardMarkup(rows)


def _back_kb(chat_id: int, owner_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_btn(chat_id, owner_id, "panel_btn_back", "main")]])


def _section_settings_text(chat_id: int) -> str:
    none_ = tc(chat_id, "none")
    not_set = tc(chat_id, "not_set")
    on_ = tc(chat_id, "state_on")
    off_ = tc(chat_id, "state_off")

    locks = db.get_locks(chat_id)
    filters_ = db.get_filters(chat_id)
    captcha_state = tc(chat_id, "captcha_on") if db.get_setting(chat_id, "captcha_enabled", "off") == "on" else tc(chat_id, "captcha_off")
    channel = db.get_setting(chat_id, "linked_channel", not_set)
    log_channel = db.get_setting(chat_id, "log_channel", not_set)
    max_warns = db.get_setting(chat_id, "max_warns", "3")
    warn_action = db.get_setting(chat_id, "warn_action", "ban")
    goodbye_state = on_ if db.get_setting(chat_id, "goodbye_enabled", "on") == "on" else off_

    lines = [
        tc(chat_id, "settings_header"), "",
        tc(chat_id, "settings_locks", locks=", ".join(locks) if locks else none_),
        tc(chat_id, "settings_filters", filters=", ".join(filters_) if filters_ else none_),
        tc(chat_id, "settings_captcha", state=captcha_state),
        tc(chat_id, "settings_goodbye", state=goodbye_state),
        tc(chat_id, "settings_warns", max=max_warns, action=warn_action),
        tc(chat_id, "settings_channel", channel=channel),
        tc(chat_id, "settings_logchannel", log=log_channel),
    ]
    return "\n".join(lines)


def _section_locks_text(chat_id: int) -> str:
    active = db.get_locks(chat_id)
    return tc(chat_id, "locks_active", locks=", ".join(active) if active else tc(chat_id, "none"))


def _section_filters_text(chat_id: int) -> str:
    active = db.get_filters(chat_id)
    return tc(chat_id, "filters_active", filters=", ".join(active) if active else tc(chat_id, "none"))


def _section_rules_text(chat_id: int) -> str:
    lang = get_lang(chat_id)
    text = db.get_rules(chat_id, lang)
    if text is None:
        fallback = db.get_any_rules(chat_id)
        if fallback is None:
            return tc(chat_id, "rules_empty")
        _, text = fallback
    return f"{tc(chat_id, 'rules_header')}\n\n{text}"


def _section_reports_text(chat_id: int) -> str:
    rows = db.list_open_reports(chat_id, limit=15)
    if not rows:
        return tc(chat_id, "reports_empty")
    lines = [tc(chat_id, "reports_header")]
    for rid, reporter_name, target_name, reason, ts in rows:
        when = datetime.fromtimestamp(ts).strftime("%m-%d %H:%M")
        lines.append(tc(chat_id, "report_item", id=rid, when=when, reporter=reporter_name,
                         target=target_name, reason=reason or tc(chat_id, "warns_no_reason")))
    return "\n".join(lines)


def _section_logs_text(chat_id: int) -> str:
    rows = db.get_recent_audit(chat_id, limit=15)
    if not rows:
        return tc(chat_id, "logs_empty")
    lines = [tc(chat_id, "logs_header")]
    for actor_name, action, target_name, reason, ts in rows:
        when = datetime.fromtimestamp(ts).strftime("%m-%d %H:%M")
        target_part = f" ← {target_name}" if target_name and target_name != "-" else ""
        reason_part = f" ({reason})" if reason else ""
        lines.append(f"• [{when}] {actor_name}: {action}{target_part}{reason_part}")
    return "\n".join(lines)


def _section_roles_text(chat_id: int) -> str:
    rows = db.list_roles(chat_id)
    if not rows:
        return tc(chat_id, "roles_empty")
    lang = get_lang(chat_id)
    lines = [tc(chat_id, "roles_header")]
    for uid, role in rows:
        lines.append(f"• {db.get_cached_name(uid)} ({uid}) — {t(lang, 'rank_moderator')}")
    return "\n".join(lines)


def _section_daily_text(chat_id: int) -> str:
    return daily_notify.status_text(chat_id) + "\n\n" + tc(chat_id, "panel_daily_hint")


_SECTION_BUILDERS = {
    "settings": _section_settings_text,
    "locks": _section_locks_text,
    "filters": _section_filters_text,
    "rules": _section_rules_text,
    "reports": _section_reports_text,
    "logs": _section_logs_text,
    "roles": _section_roles_text,
    "daily": _section_daily_text,
}


async def admin_panel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # این چک اینجا هم لازمه (نه فقط توی text_commands.py)، چون این تابع از
    # طریق دستور «/adminpanel» هم مستقیماً صدا زده می‌شه و اون مسیر از
    # دیسپچر متنی رد نمی‌شه.
    if not await moderator_only(update, context):
        return
    chat_id = update.effective_chat.id
    user = update.effective_user
    text = tc(chat_id, "panel_header", name=user.first_name)
    await update.effective_message.reply_text(text, reply_markup=_main_menu_kb(chat_id, user.id))


async def panel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = update.effective_chat.id
    try:
        _, owner_id_s, section = query.data.split(":", 2)
        owner_id = int(owner_id_s)
    except ValueError:
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return

    clicker_id = query.from_user.id
    if clicker_id != owner_id:
        # پنل شخصیه: فقط کسی که بازش کرده می‌تونه باهاش کار کنه.
        await query.answer(tc(chat_id, "panel_not_yours"), show_alert=True)
        return

    # دوباره چک رتبه روی سرور (شاید بین باز شدن پنل و این کلیک، دیمود شده باشه).
    rank = await get_rank(context, chat_id, clicker_id)
    if rank < RANK_MODERATOR:
        await query.answer(tc(chat_id, "err_rank_too_low"), show_alert=True)
        try:
            await query.edit_message_text(tc(chat_id, "panel_closed"))
        except Exception:
            pass
        return

    if section == "close":
        await query.answer()
        try:
            await query.edit_message_text(tc(chat_id, "panel_closed"))
        except Exception:
            pass
        return

    if section == "main":
        await query.answer()
        text = tc(chat_id, "panel_header", name=query.from_user.first_name)
        try:
            await query.edit_message_text(text, reply_markup=_main_menu_kb(chat_id, owner_id))
        except Exception:
            pass
        return

    builder = _SECTION_BUILDERS.get(section)
    if builder is None:
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return

    await query.answer()
    text = builder(chat_id)
    try:
        await query.edit_message_text(text, reply_markup=_back_kb(chat_id, owner_id))
    except Exception:
        pass
