# -*- coding: utf-8 -*-
import logging
import time

from telegram import Update, ChatPermissions, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc
from config import CAPTCHA_TIMEOUT_SECONDS
from handlers.common import admin_only
from utils import parse_duration


# ---------------- Priority 4, Item 18: Welcome auto-delete ----------------

logger = logging.getLogger(__name__)

async def setwelcomedelete_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "setwelcomedelete_usage"))
        return
    token = context.args[0].lower()
    if token == "off":
        db.set_setting(chat_id, "welcome_autodelete_seconds", "0")
        await update.message.reply_text(tc(chat_id, "setwelcomedelete_off"))
        return
    seconds = parse_duration(token) if not token.isdigit() else int(token)
    if not seconds or seconds <= 0:
        await update.message.reply_text(tc(chat_id, "setwelcomedelete_usage"))
        return
    db.set_setting(chat_id, "welcome_autodelete_seconds", str(seconds))
    await update.message.reply_text(tc(chat_id, "setwelcomedelete_done", seconds=seconds))


async def _schedule_welcome_autodelete(context: ContextTypes.DEFAULT_TYPE, chat_id: int, message_id: int):
    seconds = int(db.get_setting(chat_id, "welcome_autodelete_seconds", "0") or "0")
    if seconds > 0 and context.job_queue:
        context.job_queue.run_once(
            _delete_welcome_message, when=seconds,
            data={"chat_id": chat_id, "message_id": message_id},
            name=f"welcomedel_{chat_id}_{message_id}",
        )


async def _delete_welcome_message(context: ContextTypes.DEFAULT_TYPE):
    data = context.job.data
    try:
        await context.bot.delete_message(chat_id=data["chat_id"], message_id=data["message_id"])
    except Exception:
        logger.exception("non-fatal operation failed")


# ---------------- Priority 4, Item 19: Goodbye — قابل شخصی‌سازی کامل ----------------

_GOODBYE_TOGGLE_KEY = "goodbye_enabled"
_GOODBYE_TEMPLATE_KEY = "goodbye_message"


async def setgoodbye_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    full_text = update.message.text
    parts = full_text.split(None, 1)
    if len(parts) < 2 or not parts[1].strip():
        await update.message.reply_text(tc(chat_id, "setgoodbye_usage"))
        return
    db.set_setting(chat_id, _GOODBYE_TEMPLATE_KEY, parts[1].strip())
    await update.message.reply_text(tc(chat_id, "setgoodbye_done"))


async def resetgoodbye_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    db.set_setting(chat_id, _GOODBYE_TEMPLATE_KEY, "")
    await update.message.reply_text(tc(chat_id, "resetgoodbye_done"))


async def goodbye_toggle_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("on", "off"):
        await update.message.reply_text(tc(chat_id, "goodbye_toggle_usage"))
        return
    state = context.args[0].lower()
    db.set_setting(chat_id, _GOODBYE_TOGGLE_KEY, state)
    state_label = tc(chat_id, "state_on") if state == "on" else tc(chat_id, "state_off")
    await update.message.reply_text(tc(chat_id, "goodbye_toggle_done", state=state_label))


async def captcha_toggle_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("on", "off"):
        await update.message.reply_text(tc(chat_id, "captcha_toggle_usage"))
        return
    state = context.args[0].lower()
    db.set_setting(chat_id, "captcha_enabled", state)
    state_label = tc(chat_id, "captcha_on") if state == "on" else tc(chat_id, "captcha_off")
    await update.message.reply_text(tc(chat_id, "captcha_toggle_done", state=state_label))


# حداکثر تعداد عضو تازه‌وارد که در یک پیام خوش‌آمد واحد جا می‌شن. اگه یکجا
# بیشتر از این تعداد جوین بشن (مثلاً import دسته‌جمعی)، به چند پیامِ batch‌شده
# (نه یکی به‌ازای هر نفر) تقسیم می‌شن تا هم پیام/کیبورد غول‌پیکر نشه هم به
# Flood limit تلگرام نخوریم.
_MAX_WELCOME_BATCH_SIZE = 15


async def greet_new_members(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """پیام خوش‌آمد را برای همه‌ی اعضای تازه‌وارد در یک آپدیت (new_chat_members)
    batch می‌کند تا در ورود دسته‌جمعی (مثلاً افزودن هم‌زمان چند نفر)، به‌جای
    ارسال N پیام جدا -- که هم چت را اسپم می‌کند هم به Flood limit خود
    تلگرام می‌خورد -- فقط یک پیام (یا چند پیامِ batch شده در گروه‌های خیلی
    بزرگ) فرستاده بشه.

    توجه: restrict_chat_member و ثبت pending_captcha هنوز به‌ازای هر عضو
    جداست، چون این‌ها per-user هستن و batch کردنشون معنی نداره؛ فقط متن و
    دکمه‌ی خوش‌آمد ترکیب می‌شن.
    """
    chat = update.effective_chat
    chat_id = chat.id
    captcha_on = db.get_setting(chat_id, "captcha_enabled", "off") == "on"

    members = [
        m for m in update.message.new_chat_members
        if not (m.is_bot and m.id == context.bot.id)
    ]
    if not members:
        return

    for start in range(0, len(members), _MAX_WELCOME_BATCH_SIZE):
        batch = members[start:start + _MAX_WELCOME_BATCH_SIZE]
        mentions = "، ".join(f"[{m.first_name}](tg://user?id={m.id})" for m in batch)

        if not captcha_on:
            key = "welcome_simple" if len(batch) == 1 else "welcome_simple_multi"
            text = tc(chat_id, key, mention=mentions, mentions=mentions, chat=chat.title)
            try:
                sent = await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)
            except Exception:
                logger.exception("failed to send welcome message for chat %s", chat_id)
                continue
            await _schedule_welcome_autodelete(context, chat_id, sent.message_id)
            continue

        # محدود کردن هر عضو تا زمان تایید کپچا (per-user، قابل batch نیست)
        for member in batch:
            try:
                await context.bot.restrict_chat_member(
                    chat_id, member.id,
                    permissions=ChatPermissions(can_send_messages=False),
                )
            except Exception:
                logger.exception(
                    "failed to restrict new member %s in chat %s pending captcha", member.id, chat_id
                )
            db.add_pending_captcha(chat_id, member.id, time.time())

        # یک پیام واحد با یک دکمه‌ی تایید جدا برای هر عضو (هرکس فقط دکمه‌ی خودش را می‌زند)
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton(f"✅ {member.first_name}", callback_data=f"captcha:{chat_id}:{member.id}")]
            for member in batch
        ])
        key = "welcome_captcha" if len(batch) == 1 else "welcome_captcha_multi"
        text = tc(chat_id, key, mention=mentions, mentions=mentions, chat=chat.title)
        try:
            sent = await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=keyboard)
        except Exception:
            logger.exception("failed to send captcha welcome message for chat %s", chat_id)
            continue
        await _schedule_welcome_autodelete(context, chat_id, sent.message_id)

        # زمان‌بندی حذف خودکار در صورت عدم تایید، به‌ازای هر عضو جدا
        for member in batch:
            context.job_queue.run_once(
                kick_unverified,
                when=CAPTCHA_TIMEOUT_SECONDS,
                data={"chat_id": chat_id, "user_id": member.id, "message_id": sent.message_id},
                name=f"captcha_{chat_id}_{member.id}",
            )


async def captcha_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    _, chat_id_s, user_id_s = query.data.split(":")
    chat_id, user_id = int(chat_id_s), int(user_id_s)

    if query.from_user.id != user_id:
        await query.answer(tc(chat_id, "captcha_not_yours"), show_alert=True)
        return

    if not db.is_pending_captcha(chat_id, user_id):
        await query.answer(tc(chat_id, "captcha_expired"), show_alert=True)
        return

    try:
        await context.bot.restrict_chat_member(
            chat_id, user_id,
            permissions=ChatPermissions(
                can_send_messages=True, can_send_photos=True,
                can_send_videos=True, can_send_other_messages=True,
            ),
        )
    except Exception:
        logger.exception("non-fatal operation failed")

    db.remove_pending_captcha(chat_id, user_id)
    await query.answer(tc(chat_id, "captcha_verified_alert"))
    try:
        await query.edit_message_text(tc(chat_id, "captcha_verified_msg", name=query.from_user.first_name))
    except Exception:
        logger.exception("non-fatal operation failed")


async def kick_unverified(context: ContextTypes.DEFAULT_TYPE):
    job_data = context.job.data
    chat_id, user_id = job_data["chat_id"], job_data["user_id"]

    if not db.is_pending_captcha(chat_id, user_id):
        return  # کاربر قبلاً تایید شده

    try:
        await context.bot.ban_chat_member(chat_id, user_id)
        await context.bot.unban_chat_member(chat_id, user_id)  # اجازه ورود مجدد در آینده
    except Exception:
        logger.exception("non-fatal operation failed")
    db.remove_pending_captcha(chat_id, user_id)

    try:
        await context.bot.edit_message_text(
            chat_id=chat_id,
            message_id=job_data["message_id"],
            text=tc(chat_id, "captcha_timeout_msg"),
        )
    except Exception:
        logger.exception("non-fatal operation failed")


async def farewell_member(update: Update, context: ContextTypes.DEFAULT_TYPE):
    left = update.message.left_chat_member
    chat_id = update.effective_chat.id
    if not left or left.is_bot:
        return

    if db.get_setting(chat_id, _GOODBYE_TOGGLE_KEY, "on") == "off":
        return

    template = db.get_setting(chat_id, _GOODBYE_TEMPLATE_KEY, "")
    if template:
        try:
            count = await context.bot.get_chat_member_count(chat_id)
        except Exception:
            logger.exception("failed to read member count for chat %s", chat_id)
            count = "-"
        mention = f"[{left.first_name}](tg://user?id={left.id})"
        try:
            text = template.format(
                name=left.first_name or str(left.id),
                username=f"@{left.username}" if left.username else (left.first_name or str(left.id)),
                mention=mention,
                chat=update.effective_chat.title or "",
                count=count,
            )
        except Exception:
            logger.exception("failed to format goodbye template for chat %s", chat_id)
            text = template
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)
    else:
        await update.message.reply_text(tc(chat_id, "goodbye_msg", name=left.first_name))
