# -*- coding: utf-8 -*-
"""
مدیریت نقش داخلی Moderator (جدا از ادمین واقعی تلگرام) + نمایش لاگ/آدیت +
انتخاب زبان گروه.

Moderator یک نقش سبک‌تره: می‌تونه warn/mute/kick/purge بزنه ولی نمی‌تونه
ban/promote/تغییر settings بده و هیچ‌وقت نمی‌تونه روی ادمین واقعی یا مالک
تلگرام اکشن بزنه (چون rank او پایین‌تره — چک در common.can_act_on).
"""
import logging
from datetime import datetime

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc, t, get_lang, set_lang, SUPPORTED_LANGUAGES
from config import RANK_ADMIN
from handlers.common import admin_only, resolve_target, get_rank, log_action, invalidate_rank_cache


logger = logging.getLogger(__name__)

async def promote_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/promote (ریپلای یا @user/id) — کاربر را Moderator داخلی ربات می‌کند."""
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    target_id, name, _ = await resolve_target(update, context)
    if not target_id:
        await update.message.reply_text(tc(chat_id, "promote_usage"))
        return
    current_rank = await get_rank(context, chat_id, target_id)
    if current_rank >= RANK_ADMIN:
        await update.message.reply_text(tc(chat_id, "promote_already_admin"))
        return
    db.set_role(chat_id, target_id, "moderator")
    invalidate_rank_cache(chat_id, target_id)
    text = tc(chat_id, "promote_done", name=name)
    await update.message.reply_text(text)
    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "promote", target_id, name, None)


async def demote_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    target_id, name, _ = await resolve_target(update, context)
    if not target_id:
        await update.message.reply_text(tc(chat_id, "promote_usage"))
        return
    db.remove_role(chat_id, target_id)
    invalidate_rank_cache(chat_id, target_id)
    text = tc(chat_id, "demote_done", name=name)
    await update.message.reply_text(text)
    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "demote", target_id, name, None)


async def roles_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """نمایش لیست Moderatorهای داخلی این گروه (ادمین‌های واقعی از خود تلگرام قابل مشاهده‌اند)."""
    chat_id = update.effective_chat.id
    rows = db.list_roles(chat_id)
    if not rows:
        await update.message.reply_text(tc(chat_id, "roles_empty"))
        return
    lang = get_lang(chat_id)
    lines = [tc(chat_id, "roles_header")]
    for uid, role in rows:
        lines.append(f"• {db.get_cached_name(uid)} ({uid}) — {t(lang, 'rank_moderator')}")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def logs_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """نمایش آخرین رکوردهای Audit Log مستقیم داخل تلگرام (بدون نیاز به لاگ‌چنل)."""
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    rows = db.get_recent_audit(chat_id, limit=15)
    if not rows:
        await update.message.reply_text(tc(chat_id, "logs_empty"))
        return
    lines = [tc(chat_id, "logs_header")]
    for actor_name, action, target_name, reason, ts in rows:
        when = datetime.fromtimestamp(ts).strftime("%m-%d %H:%M")
        target_part = f" ← {target_name}" if target_name and target_name != "-" else ""
        reason_part = f" ({reason})" if reason else ""
        lines.append(f"• [{when}] {actor_name}: {action}{target_part}{reason_part}")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


# ---------------- زبان گروه ----------------

def _lang_keyboard():
    buttons = [
        InlineKeyboardButton(label, callback_data=f"setlang:{code}")
        for code, label in SUPPORTED_LANGUAGES.items()
    ]
    rows = [buttons[i:i + 2] for i in range(0, len(buttons), 2)]
    return InlineKeyboardMarkup(rows)


async def setlang_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/setlang — کیبورد انتخاب زبان گروه را نشان می‌دهد (فقط ادمین به بالا)."""
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    await update.message.reply_text(tc(chat_id, "setlang_prompt"), reply_markup=_lang_keyboard())


async def setlang_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Server-side validation: دوباره چک می‌کنیم کلیک‌کننده ادمین/مالک است، نه فقط چون دکمه دیده شده."""
    query = update.callback_query
    chat_id = update.effective_chat.id
    _, lang_code = query.data.split(":", 1)

    clicker_rank = await get_rank(context, chat_id, query.from_user.id)
    if clicker_rank < RANK_ADMIN:
        await query.answer(tc(chat_id, "err_need_rank", rank=t(get_lang(chat_id), "rank_admin")), show_alert=True)
        return

    if not set_lang(chat_id, lang_code):
        await query.answer(tc(chat_id, "err_invalid_language"), show_alert=True)
        return

    await query.answer()
    label = SUPPORTED_LANGUAGES[lang_code]
    try:
        await query.edit_message_text(t(lang_code, "setlang_done", lang_name=label))
    except Exception:
        logger.exception("non-fatal operation failed")
