# -*- coding: utf-8 -*-
"""
لایه‌ی Natural Language واقعی و intent-based (بخش‌های 5/6/8/9/10/11 پرامپت).

جایگاه در پایپ‌لاین (handlers/registry.py، گروه 16 — درست بعد از
text_command_dispatcher در گروه 15، قبل از notes/keywords/auto_answer):
اگر پیام از قبل یک Alias دقیق (TEXT_TRIGGERS) داشته باشه، این dispatcher
اصلاً وارد عمل نمی‌شه — تا هم رفتار موجود دست‌نخورده بمونه و هم پیام دوبار
پاسخ داده نشه.

اصل «don't duplicate business logic» (بخش 23): این ماژول هیچ منطق جدیدی
برای mute/lock نمی‌سازه؛ فقط intent را (با nlu.intent_parser، که کاملاً
مستقل و تست‌شده است) تشخیص می‌ده و همون handlerها/توابع موجود
(locks_filters.lock_cmd، rules.rules_cmd، guide.guide_cmd،
moderation._execute_mute) را صدا می‌زنه.

⚠️ اعلام صادقانه (طبق قانون «NO FAKE SUCCESS» پرامپت):
این فایل به python-telegram-bot وابسته است. در sandboxی که این تغییرات
نوشته شده، اینترنت در دسترس نیست و python-telegram-bot قابل نصب نبود؛
بنابراین این فایل import/اجرا/تست نشده. آنچه واقعاً با unit test تست شده:
nlu/intent_parser.py، nlu/context_store.py، nlu/ai_escalation_log.py، و
لایه‌ی سرویس AI (ai_copilot/service.py::interpret_request، با Provider
جعلی، بدون نیاز به شبکه یا API key واقعی). خودِ فراخوان HTTP واقعی به یک
سرویس AI واقعی در این sandbox قابل تست نبوده. جزئیات کامل در گزارش پایانی
آمده — این را «تست‌شده» اعلام نکن.
"""
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, filters

from i18n import get_lang, tc, SUPPORTED_LANGUAGES
from utils import format_duration
from config import RANK_MODERATOR, RANK_ADMIN
from handlers.common import admin_only, authorize_action, get_rank, log_action
from handlers import moderation, locks_filters, rules, guide, text_commands, auto_answer, ai_copilot, reports
from handlers import ads, daily_notify, channel
from repositories import store as db
from ai_copilot import service as ai_service
from nlu.intent_parser import parse, extract_duration_seconds, ParsedIntent, KNOWN_INTENTS
from nlu.context_store import context_store
from nlu import ai_escalation_log
from nlu import learned_phrases

# فقط متن‌های معمولی (نه دستور با /) و فقط داخل گروه‌ها — دقیقاً مثل
# text_commands.text_trigger_filter، چون این dispatcher لایه‌ی بعدی همون
# پایپ‌لاینه.
natural_language_filter = filters.TEXT & ~filters.COMMAND & filters.ChatType.GROUPS


# ---------------------------------------------------------------------------
# Wake Word (طبق درخواست صریح کاربر): این dispatcher به NLU سریع/AI فقط وقتی
# اجازه‌ی ورود می‌ده که پیام با یک کلمه‌ی «صدازدنِ ربات» شروع شده باشه (مثلاً
# «ربات ساکتش کن»، نه صرفاً «ساکتش کن») — تا در چت عادی گروه، جمله‌های معمولی
# اعضا به‌اشتباه به‌عنوان دستور اجرا نشن. این محدودیت فقط مال همین لایه‌ی
# freeform NLU/AI است؛ Aliasهای دقیق موجود (بخش text_commands.py، مثل تایپ
# «گزارش» برای /report) قبلاً هم بدون نیاز به wake word کار می‌کردن و همینطور
# می‌مونن (چون اون‌ها کلمات ثابت و بدون ابهامن، نه جمله‌ی آزاد).
#
# هر زبان کلمه‌ی خودش رو داره؛ برای زبان‌هایی که هنوز کلمه‌ی اختصاصی ندارن
# (یا زبان تازه‌ای بعداً اضافه بشه)، «bot» به‌عنوان fallback همیشه کار می‌کنه
# — یعنی قابلیت روی هر زبانی (نه فقط فارسی) از قبل فعاله.
WAKE_WORDS = {
    "fa": ("ربات",),
    "en": ("bot",),
    "ar": ("بوت", "الروبوت", "روبوت"),
    "tr": ("bot",),
    "ru": ("бот",),
    "es": ("bot",),
}
_FALLBACK_WAKE_WORDS = ("bot",)
_WAKE_WORD_STRIP_CHARS = " \t\u200c,:：،!ـ-–—."


def _strip_wake_word(text: str, lang: str):
    """اگه پیام با یکی از کلمات بیدارسازیِ این زبان (یا fallback «bot»، که
    برای همه‌ی زبان‌ها همیشه معتبره) شروع شده باشه، همون کلمه رو حذف می‌کنه
    و بقیه‌ی متن (trim‌شده) رو برمی‌گردونه. اگه پیام با هیچ‌کدوم شروع نشده
    باشه None برمی‌گردونه — یعنی این پیام اصلاً به این dispatcher مربوط نیست."""
    stripped = text.strip()
    if not stripped:
        return None
    folded = stripped.casefold()
    candidates = tuple(WAKE_WORDS.get(lang, ())) + _FALLBACK_WAKE_WORDS
    for word in candidates:
        wf = word.casefold()
        if folded == wf:
            return ""
        if folded.startswith(wf):
            # باید بعد از کلمه یا فاصله/علامت باشه یا تمومِ متن، وگرنه یعنی
            # داخل یک کلمه‌ی دیگه بوده (مثلاً "botanic" نباید match بشه با "bot").
            next_char = stripped[len(wf):len(wf) + 1]
            if next_char == "" or not (next_char.isalnum()):
                return stripped[len(wf):].lstrip(_WAKE_WORD_STRIP_CHARS)
    return None


def _already_has_exact_alias(text: str, lang: str) -> bool:
    """True اگر همین پیام با یک Alias دقیق موجود (TEXT_TRIGGERS) شروع بشه —
    یعنی گروه 15 (text_command_dispatcher) خودش قبلاً جوابش رو داده/می‌ده."""
    raw_words = text.strip().split()
    folded_words = [w.casefold() for w in raw_words]
    for trigger_words, _cmd_id in text_commands._sorted_triggers_for(lang):
        n = len(trigger_words)
        if folded_words[:n] == trigger_words:
            return True
    return False


async def natural_language_dispatcher(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.effective_message
    if not message or not message.text:
        return

    chat_id = update.effective_chat.id
    lang = get_lang(chat_id)
    text = message.text
    user_id = update.effective_user.id

    if _already_has_exact_alias(text, lang):
        return

    # --- بخش 10: آیا یک follow-up برای یک mute در انتظار مدت‌زمانه؟ ---
    pending = context_store.peek_pending(chat_id, user_id)
    if pending and pending.get("intent") == "mute_user" and pending.get("duration_seconds") is None:
        duration = extract_duration_seconds(text, lang)
        if duration is not None:
            context_store.pop_pending(chat_id, user_id)
            await _ask_action_confirmation(
                update, chat_id, user_id, "mute_user", pending["target_id"], pending["name"],
                {"duration_seconds": duration},
            )
            return
        # جواب مرتبط با مدت‌زمان نبود؛ context رو دست‌نخورده می‌ذاریم تا خودش expire بشه.

    # --- Wake Word: بدون صدازدنِ صریح ربات، وارد NLU/AI نمی‌شیم (سکوت کامل). ---
    rest = _strip_wake_word(text, lang)
    if rest is None:
        return
    if not rest:
        # فقط «ربات»/«bot» تنها، بدون هیچ دستوری بعدش -> چیزی برای تشخیص نیست.
        return
    text = rest

    result = parse(text, lang)

    if result.intent or result.ambiguous:
        await _dispatch_intent(update, context, chat_id, user_id, result)
        return

    # لایه‌ی سریع/قطعی چیزی نشناخت -> لایه‌ی سوم Smart Router (بخش 6/7): AI،
    # فقط برای مدیران (تا هزینه/نویز AI روی چت عادی اعضا اعمال نشه).
    await _escalate_to_ai(update, context, chat_id, user_id, lang, text)
    return


async def _dispatch_intent(update: Update, context: ContextTypes.DEFAULT_TYPE,
                            chat_id: int, user_id: int, result) -> None:
    """یک ParsedIntent (از لایه‌ی سریع NLU یا از لایه‌ی AI، فرقی نمی‌کنه) رو
    به همون handler/capability موجودش می‌رسونه. این تابع تنها محل این
    if/elif هست — هم مسیر سریع و هم مسیر AI از همینجا رد می‌شن، تا منطق
    dispatch دوبار نوشته نشه (بخش 23)."""
    if result.intent == "mute_user":
        await _handle_dangerous_intent(update, context, chat_id, user_id, "mute_user", result)
        return

    if result.intent == "unmute_user":
        await _handle_dangerous_intent(update, context, chat_id, user_id, "unmute_user", result)
        return

    if result.intent == "ban_user":
        await _handle_dangerous_intent(update, context, chat_id, user_id, "ban_user", result)
        return

    if result.intent == "unban_user":
        await _handle_dangerous_intent(update, context, chat_id, user_id, "unban_user", result)
        return

    if result.intent == "kick_user":
        await _handle_dangerous_intent(update, context, chat_id, user_id, "kick_user", result)
        return

    if result.intent == "warn_user":
        # طبق بخش 9، warn جزو لیست صریح اکشن‌های نیازمند confirmation نیست
        # (بر خلاف ban/unban/mute/kick) — همون رفتار سریع دکمه‌های
        # _quick_actions_keyboard موجود در moderation.py را دنبال می‌کنیم:
        # هدف صریح (ریپلای) لازمه، ولی بدون دکمه‌ی تایید اضافه اجرا می‌شه.
        await _handle_warn_intent(update, context, chat_id, user_id)
        return

    if result.intent == "delete_message":
        await _handle_delete_intent(update, context, chat_id, user_id)
        return

    if result.intent == "update_rules":
        await _handle_update_rules_intent(update, context, chat_id, user_id, result)
        return

    if result.intent == "list_auto_answers":
        await auto_answer.answerlist_cmd(update, context)
        return

    if result.intent == "create_auto_answer":
        await auto_answer.setanswer_cmd(update, context)
        return

    if result.intent == "delete_auto_answer":
        await _handle_delete_auto_answer_intent(update, context, chat_id, user_id, result)
        return

    if result.intent == "group_health_report":
        # بخش 14/15/16: قابلیت AI Copilot از قبل وجود داشت (handlers/ai_copilot.py
        # ::aihealth_cmd) — کاملاً با rate-limit/plan-gate/fallback مناسب اگه AI
        # در دسترس نباشه (بخش 23: duplicate business logic نساز؛ فقط یک راه
        # ورود Natural Language جدید به همون قابلیت موجود اضافه می‌شه).
        await ai_copilot.aihealth_cmd(update, context)
        return

    if result.intent == "show_moderation_report":
        await reports.reports_cmd(update, context)
        return

    if result.intent == "configure_link_protection":
        await _handle_link_protection_intent(update, context, result)
        return

    if result.intent == "configure_mention_protection":
        await _handle_toggle_intent(update, context, result, "mentionprotection")
        return

    if result.intent == "configure_antispam":
        await _handle_toggle_intent(update, context, result, "antispam")
        return

    if result.intent == "configure_dupcross":
        await _handle_toggle_intent(update, context, result, "dupcross")
        return

    if result.intent == "show_ads_list":
        await ads.ads_cmd(update, context)
        return

    if result.intent == "show_my_ads":
        await ads.myads_cmd(update, context)
        return

    if result.intent == "show_ad_admin_queue":
        await ads.adadmin_cmd(update, context)
        return

    if result.intent == "show_daily_notify_menu":
        await daily_notify.dailynotify_cmd(update, context)
        return

    if result.intent == "show_daily_assets":
        await daily_notify.dailyassets_cmd(update, context)
        return

    if result.intent == "test_daily_price":
        await daily_notify.testdailyprice_cmd(update, context)
        return

    if result.intent == "test_daily_news":
        await daily_notify.testdailynews_cmd(update, context)
        return

    if result.intent == "show_recurring_posts":
        await channel.recurringposts_cmd(update, context)
        return

    if result.intent == "show_security_status":
        await locks_filters.locks_cmd(update, context)
        return

    if result.intent == "show_rules":
        await rules.rules_cmd(update, context)
        return

    if result.intent == "help":
        await guide.guide_cmd(update, context)
        return

    if result.ambiguous:
        await _send_fallback(update, chat_id, result.candidates)
        return

    # intent شناخته نشد: طبق بخش 11، برای چیز نامشخص حدس نمی‌زنیم و سکوت
    # می‌کنیم.
    return


# ---------------------------------------------------------------------------
# لایه‌ی سوم Smart Router (بخش 6/7): AI — فقط وقتی لایه‌ی سریع/قطعی چیزی
# نشناخت. AI فقط classifier است (کدوم intent از پیش‌موجود)؛ اجرای واقعی
# همیشه از همون _dispatch_intent بالا رد می‌شه — دقیقاً مثل لایه‌ی سریع.
# ---------------------------------------------------------------------------

# intentهایی که بدون entity اضافه (یا فقط duration که extract_duration_seconds
# خودش امن استخراج می‌کنه) قابل اجرا هستن. سه‌تای زیر عمداً از این لیست
# بیرون‌اند چون AI (طبق ai_copilot/prompts.py::interpret_request_prompt) فقط
# intent برمی‌گردونه، نه entity، و برای این سه‌تا حدس‌زدن entity خطرناک/نادرسته:
#   - configure_link_protection: بدون enable/disable قابل اجرا نیست
#   - update_rules / delete_auto_answer: نیازمند فرمت صریح ":" هستن؛ اگه به
#     این‌جا رسیده باشیم یعنی فرمت صریح در پیام نبوده (چون لایه‌ی سریع خودش
#     این فرمت رو مستقیم و بدون AI تشخیص می‌ده)، پس اجرا از طریق AI یعنی
#     دقیقاً همون «حدس‌زدن روی اکشن حساس» که بخش 9 ممنوعش کرده.
_AI_DISPATCHABLE_INTENTS = {
    "mute_user", "unmute_user", "ban_user", "unban_user", "kick_user", "warn_user",
    "delete_message", "show_security_status", "show_rules", "help",
    "list_auto_answers", "create_auto_answer", "group_health_report", "show_moderation_report",
    # Phase 3: فقط دستورهای بدون‌پارامتر — سه‌تای configure_mention_protection/
    # configure_antispam/configure_dupcross عمداً بیرون‌اند، دقیقاً به همون
    # دلیلی که configure_link_protection بیرونه (بالا): AI فقط intent
    # برمی‌گردونه نه enabled/disabled، و حدس‌زدن جهت روی یک تنظیمات گروه
    # خطرناکه.
    "show_ads_list", "show_my_ads", "show_ad_admin_queue",
    "show_daily_notify_menu", "show_daily_assets",
    "test_daily_price", "test_daily_news", "show_recurring_posts",
}


async def _escalate_to_ai(update: Update, context: ContextTypes.DEFAULT_TYPE,
                           chat_id: int, user_id: int, lang: str, text: str) -> None:
    # فقط مدیران — همون سطح دسترسی سایر قابلیت‌های AI Copilot (بخش 6/19:
    # هزینه/نویز AI نباید روی چت عادی اعضا اعمال بشه).
    ok, _ = await authorize_action(context, chat_id, user_id, "ai_copilot", None, RANK_MODERATOR)
    if not ok:
        return

    ai_result = await ai_service.interpret_request(chat_id, user_id, text=text, lang=lang)

    intent_name = None
    confidence = None
    error_code = None
    if ai_result.ok:
        candidate = ai_result.data.get("intent")
        confidence = ai_result.data.get("confidence")
        # هیچ‌وقت به AI اعتماد کور نکن: اسم intent باید دقیقاً یکی از
        # KNOWN_INTENTS و جزو _AI_DISPATCHABLE_INTENTS باشه، وگرنه (توهم
        # مدل، یا intentی که نباید بدون entity دقیق اجرا بشه) نادیده گرفته می‌شه.
        if candidate in KNOWN_INTENTS and candidate in _AI_DISPATCHABLE_INTENTS:
            intent_name = candidate
    else:
        error_code = ai_result.error_code

    # طبق درخواست صریح کاربر: هر escalation به AI (موفق یا ناموفق) با متن
    # اصلی و «منظور» تشخیص‌داده‌شده در یک فایل لاگ می‌شه — تا بعداً بشه از
    # روی جمله‌های واقعی کاربرها، واژگان لایه‌ی سریع/رایگان (nlu/intent_parser.py)
    # رو گسترش داد و وابستگی به AI رو کم‌کم کم کرد.
    ai_escalation_log.log_ai_interpretation(
        chat_id=chat_id, lang=lang, text=text, intent=intent_name, confidence=confidence,
        used_ai=ai_result.used_ai, error_code=error_code,
    )

    if not intent_name:
        return  # چه AI در دسترس نبود چه چیزی رو نشناخت -> سکوت (بدون نویز اضافه)

    # حلقه‌ی یادگیری (بخش 3): اگر AI با Confidence کافی این intent رو
    # تشخیص داد، عبارت رو ذخیره کن تا دفعات بعد بدون AI (مستقیم از
    # nlu/intent_parser.py::parse) اجرا بشه. best-effort/fail-silent —
    # شکست این ذخیره‌سازی هرگز نباید جلوی پاسخ به کاربر همین الان رو بگیره.
    learned_phrases.record_learned_phrase(text, lang, intent_name, confidence)

    # entity extraction همچنان از همون منطق قطعی/تست‌شده‌ی خودمون میاد —
    # AI فقط "کدوم intent" رو گفته، نه جزئیات (بخش 23 + کاهش سطح اعتماد به AI).
    entities = {}
    if intent_name in ("mute_user", "ban_user"):
        entities["duration_seconds"] = extract_duration_seconds(text, lang)

    ai_parsed = ParsedIntent(intent=intent_name, entities=entities)
    await _dispatch_intent(update, context, chat_id, user_id, ai_parsed)


# ---------------------------------------------------------------------------
# Dangerous actions (بخش 8/9): یک registry عمومی، تا هیچ منطقی برای هر
# اکشن جدا نوشته نشه و همه از یک مسیر confirm/execute/log واحد رد بشن.
# ---------------------------------------------------------------------------

def _duration_confirm_text(key: str):
    async def _build(chat_id: int, name: str, entities: dict) -> str:
        duration = entities.get("duration_seconds")
        dur_text = format_duration(duration) if duration else tc(chat_id, "duration_permanent")
        return tc(chat_id, key, name=name, duration=dur_text)
    return _build


def _simple_confirm_text(key: str):
    async def _build(chat_id: int, name: str, entities: dict) -> str:
        return tc(chat_id, key, name=name)
    return _build


DANGEROUS_ACTIONS = {
    "mute_user": {
        "capability": "mute", "min_rank": RANK_MODERATOR,
        "confirm_text": _duration_confirm_text("nlu_confirm_mute"),
        "execute": lambda context, chat_id, target_id, name, entities: moderation._execute_mute(
            context, chat_id, target_id, name, entities.get("duration_seconds"), None),
        "log_verb": "mute",
        "needs_duration_followup": True,
    },
    "unmute_user": {
        "capability": "unmute", "min_rank": RANK_MODERATOR,
        "confirm_text": _simple_confirm_text("nlu_confirm_unmute"),
        "execute": lambda context, chat_id, target_id, name, entities: moderation._execute_unmute(
            context, chat_id, target_id, name),
        "log_verb": "unmute",
        "needs_duration_followup": False,
    },
    "ban_user": {
        "capability": "ban", "min_rank": RANK_ADMIN,
        "confirm_text": _duration_confirm_text("nlu_confirm_ban"),
        "execute": lambda context, chat_id, target_id, name, entities: moderation._execute_ban(
            context, chat_id, target_id, name, entities.get("duration_seconds"), None),
        "log_verb": "ban",
        "needs_duration_followup": False,  # طبق بخش 9 فقط برای mute «سؤال مدت» می‌کنیم؛ ban بدون مدت یعنی permanent (رفتار خود /ban هم همینه)
    },
    "unban_user": {
        "capability": "unban", "min_rank": RANK_ADMIN,
        "confirm_text": _simple_confirm_text("nlu_confirm_unban"),
        "execute": lambda context, chat_id, target_id, name, entities: moderation._execute_unban(
            context, chat_id, target_id, name),
        "log_verb": "unban",
        "needs_duration_followup": False,
    },
    "kick_user": {
        "capability": "kick", "min_rank": RANK_MODERATOR,
        "confirm_text": _simple_confirm_text("nlu_confirm_kick"),
        "execute": lambda context, chat_id, target_id, name, entities: moderation._execute_kick(
            context, chat_id, target_id, name, None),
        "log_verb": "kick",
        "needs_duration_followup": False,
    },
}


async def _handle_dangerous_intent(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                    chat_id: int, user_id: int, intent: str, result):
    cfg = DANGEROUS_ACTIONS[intent]
    message = update.effective_message

    # بخش 9: هیچ‌وقت برای اکشن خطرناک حدس نزن — هدف باید صریح (ریپلای) باشه.
    if not message.reply_to_message or not message.reply_to_message.from_user:
        await message.reply_text(tc(chat_id, "nlu_need_reply_target"))
        return

    target_user = message.reply_to_message.from_user
    target_id = target_user.id
    name = target_user.first_name or target_user.username or str(target_user.id)

    ok, err = await authorize_action(context, chat_id, user_id, cfg["capability"], target_id, cfg["min_rank"])
    if not ok:
        await message.reply_text(err)
        return

    entities = result.entities
    if cfg["needs_duration_followup"] and entities.get("duration_seconds") is None:
        # بخش 10: منتظر جواب بعدی کاربر برای مدت‌زمان می‌مونیم.
        context_store.put_pending(chat_id, user_id, {
            "intent": intent, "target_id": target_id, "name": name, "duration_seconds": None,
        })
        await message.reply_text(tc(chat_id, "nlu_ask_duration", name=name))
        return

    await _ask_action_confirmation(update, chat_id, user_id, intent, target_id, name, entities)


async def _ask_action_confirmation(update: Update, chat_id: int, requester_id: int, intent: str,
                                    target_id: int, name: str, entities: dict):
    cfg = DANGEROUS_ACTIONS[intent]
    token = context_store.put_token({
        "intent": intent,
        "chat_id": chat_id,
        "requested_by": requester_id,
        "target_id": target_id,
        "name": name,
        "entities": entities,
    })
    text = await cfg["confirm_text"](chat_id, name, entities)
    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton(tc(chat_id, "nlu_btn_confirm"), callback_data=f"nlu:c:{token}"),
        InlineKeyboardButton(tc(chat_id, "nlu_btn_cancel"), callback_data=f"nlu:x:{token}"),
    ]])
    await update.effective_message.reply_text(text, reply_markup=keyboard)


async def natural_language_confirm_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = update.effective_chat.id
    parts = query.data.split(":")  # "nlu", "c"|"x", token
    action, token = parts[1], parts[2]

    payload = context_store.pop_token(token)
    await query.answer()

    if not payload:
        await query.edit_message_text(tc(chat_id, "nlu_context_expired"))
        return

    # حذف پیام و تنظیم قوانین شکل متفاوتی دارن (message_ids یا rules_text،
    # نه target_id/name کاربر)، پس جدا از DANGEROUS_ACTIONS (که حول اکشن
    # روی یک کاربر طراحی شده) هندل می‌شن.
    if payload["intent"] == "delete_message":
        await _confirm_delete_callback(update, context, chat_id, action, payload)
        return
    if payload["intent"] == "update_rules":
        await _confirm_setrules_callback(update, context, chat_id, action, payload)
        return
    if payload["intent"] == "delete_auto_answer":
        await _confirm_delanswer_callback(update, context, chat_id, action, payload)
        return

    cfg = DANGEROUS_ACTIONS[payload["intent"]]

    if payload["requested_by"] != update.effective_user.id:
        actor_rank = await get_rank(context, chat_id, update.effective_user.id)
        if actor_rank < cfg["min_rank"]:
            await query.answer(tc(chat_id, "nlu_not_your_confirmation"), show_alert=True)
            # payload رو دوباره برمی‌گردونیم چون این تلاش معتبر نبود و نباید مصرف بشه.
            context_store.put_token(payload, ttl_seconds=60)
            return

    if action == "x":
        await query.edit_message_text(tc(chat_id, "nlu_action_cancelled"))
        return

    # دوباره authorize می‌کنیم چون ممکنه بین لحظه‌ی سؤال و لحظه‌ی تایید،
    # رتبه/شرایط target عوض شده باشه (fail-closed، نه فقط اعتماد به گذشته).
    ok, err = await authorize_action(
        context, chat_id, payload["requested_by"], cfg["capability"], payload["target_id"], cfg["min_rank"],
    )
    if not ok:
        await query.edit_message_text(err)
        return

    text = await cfg["execute"](context, chat_id, payload["target_id"], payload["name"], payload["entities"])
    await query.edit_message_text(text)

    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name,
                      cfg["log_verb"], payload["target_id"], payload["name"], None)


async def _confirm_delete_callback(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int, action: str, payload: dict):
    if payload["requested_by"] != update.effective_user.id:
        actor_rank = await get_rank(context, chat_id, update.effective_user.id)
        if actor_rank < RANK_MODERATOR:
            await update.callback_query.answer(tc(chat_id, "nlu_not_your_confirmation"), show_alert=True)
            context_store.put_token(payload, ttl_seconds=60)
            return

    if action == "x":
        await update.callback_query.edit_message_text(tc(chat_id, "nlu_action_cancelled"))
        return

    ok, err = await authorize_action(context, chat_id, payload["requested_by"], "delete", None, RANK_MODERATOR)
    if not ok:
        await update.callback_query.edit_message_text(err)
        return

    await moderation._execute_delete_messages(context, chat_id, payload["message_ids"])
    await update.callback_query.edit_message_text(tc(chat_id, "nlu_delete_done"))


async def _confirm_setrules_callback(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int, action: str, payload: dict):
    """تایید نهایی تنظیم قوانین. طبق بخش 2/9: این یک اکشن حساسه (تغییر
    Configuration گروه)، پس حداقل رتبه‌ی لازم RANK_ADMIN است (دقیقاً همون
    چیزی که admin_only/setrules_cmd هم می‌خواد) — نه RANK_MODERATOR."""
    if payload["requested_by"] != update.effective_user.id:
        actor_rank = await get_rank(context, chat_id, update.effective_user.id)
        if actor_rank < RANK_ADMIN:
            await update.callback_query.answer(tc(chat_id, "nlu_not_your_confirmation"), show_alert=True)
            context_store.put_token(payload, ttl_seconds=60)
            return

    if action == "x":
        await update.callback_query.edit_message_text(tc(chat_id, "nlu_action_cancelled"))
        return

    # دوباره چک ادمین بودن (fail-closed) — دقیقاً هم‌ارز admin_only، ولی
    # چون اینجا یک callback_query است نه یک پیام معمولی، مستقیم از get_rank
    # استفاده می‌کنیم (admin_only انتظار update.message داره که در callback
    # وجود نداره).
    actor_rank = await get_rank(context, chat_id, payload["requested_by"])
    if actor_rank < RANK_ADMIN:
        await update.callback_query.edit_message_text(
            tc(chat_id, "err_need_rank", rank=tc(chat_id, "rank_admin")),
        )
        return

    # همون تابع ذخیره‌سازی واقعی که خودِ setrules_cmd هم صدا می‌زنه (بخش 23:
    # duplicate business logic نساز) — اینجا فقط چون NLU خودش متن قوانین رو
    # از قبل تمیز استخراج کرده، مستقیم db.set_rules صدا زده می‌شه، بدون نیاز
    # به دوباره‌پردازی متن خام از طریق setrules_cmd.
    db.set_rules(chat_id, payload["lang"], payload["rules_text"])
    await update.callback_query.edit_message_text(
        tc(chat_id, "setrules_done", lang=SUPPORTED_LANGUAGES.get(payload["lang"], payload["lang"])),
    )


# ---------------------------------------------------------------------------
# Update rules (بخش 8: update_rules؛ نیازمند preview + confirmation صریح،
# چون تغییر مستقیم محتوای گروهه و ریسک data integrity داره)
# ---------------------------------------------------------------------------

async def _handle_update_rules_intent(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                       chat_id: int, user_id: int, result):
    if not await admin_only(update, context):
        return

    rules_text = (result.entities.get("rules_text") or "").strip()
    if not rules_text:
        await update.effective_message.reply_text(tc(chat_id, "nlu_setrules_format_hint"))
        return

    lang = get_lang(chat_id)
    token = context_store.put_token({
        "intent": "update_rules",
        "chat_id": chat_id,
        "requested_by": user_id,
        "lang": lang,
        "rules_text": rules_text,
    })
    # Preview صریح متن دقیقی که ذخیره می‌شه — تا ادمین قبل از تایید، دقیقاً
    # ببینه چی جایگزین قوانین فعلی می‌شه (رفع نگرانی data integrity).
    preview = tc(chat_id, "nlu_confirm_setrules", text=rules_text)
    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton(tc(chat_id, "nlu_btn_confirm"), callback_data=f"nlu:c:{token}"),
        InlineKeyboardButton(tc(chat_id, "nlu_btn_cancel"), callback_data=f"nlu:x:{token}"),
    ]])
    await update.effective_message.reply_text(preview, reply_markup=keyboard)


# ---------------------------------------------------------------------------
# Delete auto-answer (بخش 8: delete_auto_answer؛ مثل update_rules، فرمت
# صریح با ":" لازمه + همیشه preview/confirm — تا اشتباهی automation درستی
# پاک نشه)
# ---------------------------------------------------------------------------

async def _handle_delete_auto_answer_intent(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                             chat_id: int, user_id: int, result):
    if not await admin_only(update, context):
        return

    keyword = (result.entities.get("keyword") or "").strip().lower()
    if not keyword:
        await update.effective_message.reply_text(tc(chat_id, "nlu_delanswer_format_hint"))
        return

    token = context_store.put_token({
        "intent": "delete_auto_answer",
        "chat_id": chat_id,
        "requested_by": user_id,
        "keyword": keyword,
    })
    preview = tc(chat_id, "nlu_confirm_delanswer", keyword=keyword)
    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton(tc(chat_id, "nlu_btn_confirm"), callback_data=f"nlu:c:{token}"),
        InlineKeyboardButton(tc(chat_id, "nlu_btn_cancel"), callback_data=f"nlu:x:{token}"),
    ]])
    await update.effective_message.reply_text(preview, reply_markup=keyboard)


async def _confirm_delanswer_callback(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int, action: str, payload: dict):
    if payload["requested_by"] != update.effective_user.id:
        actor_rank = await get_rank(context, chat_id, update.effective_user.id)
        if actor_rank < RANK_ADMIN:
            await update.callback_query.answer(tc(chat_id, "nlu_not_your_confirmation"), show_alert=True)
            context_store.put_token(payload, ttl_seconds=60)
            return

    if action == "x":
        await update.callback_query.edit_message_text(tc(chat_id, "nlu_action_cancelled"))
        return

    actor_rank = await get_rank(context, chat_id, payload["requested_by"])
    if actor_rank < RANK_ADMIN:
        await update.callback_query.edit_message_text(
            tc(chat_id, "err_need_rank", rank=tc(chat_id, "rank_admin")),
        )
        return

    # همون تابع واقعی حذف که خودِ delanswer_cmd هم صدا می‌زنه (بخش 23).
    if db.remove_auto_answer(chat_id, payload["keyword"]):
        await update.callback_query.edit_message_text(tc(chat_id, "delanswer_done", keyword=payload["keyword"]))
    else:
        await update.callback_query.edit_message_text(tc(chat_id, "delanswer_notfound"))


# ---------------------------------------------------------------------------
# Delete message (بخش 8/9: delete_message، جزو اکشن‌های نیازمند confirmation)
# ---------------------------------------------------------------------------

async def _handle_delete_intent(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int, user_id: int):
    message = update.effective_message
    # بخش 9/11: بدون ریپلای صریح، هدف مشخص نیست -> حدس نمی‌زنیم.
    if not message.reply_to_message:
        await message.reply_text(tc(chat_id, "nlu_need_reply_target"))
        return

    ok, err = await authorize_action(context, chat_id, user_id, "delete", None, RANK_MODERATOR)
    if not ok:
        await message.reply_text(err)
        return

    token = context_store.put_token({
        "intent": "delete_message",
        "chat_id": chat_id,
        "requested_by": user_id,
        "message_ids": [message.reply_to_message.message_id, message.message_id],
    })
    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton(tc(chat_id, "nlu_btn_confirm"), callback_data=f"nlu:c:{token}"),
        InlineKeyboardButton(tc(chat_id, "nlu_btn_cancel"), callback_data=f"nlu:x:{token}"),
    ]])
    # توجه: خود پیام درخواست هنوز حذف نشده (فقط بعد از تایید)، پس با
    # reply_text معمولی جواب می‌دیم، نه ویرایش یک پیام موجود.
    await message.reply_text(tc(chat_id, "nlu_confirm_delete"), reply_markup=keyboard)


# ---------------------------------------------------------------------------
# Warn (کم‌خطرتر از ban/mute/kick؛ طبق بخش 9 در لیست صریح نیاز-به-confirmation
# نیست، پس دقیقاً مثل دکمه‌های سریع موجود بدون تاییدیه‌ی اضافه اجرا می‌شه)
# ---------------------------------------------------------------------------

async def _handle_warn_intent(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int, user_id: int):
    message = update.effective_message
    if not message.reply_to_message or not message.reply_to_message.from_user:
        await message.reply_text(tc(chat_id, "nlu_need_reply_target"))
        return
    target_user = message.reply_to_message.from_user
    target_id = target_user.id
    name = target_user.first_name or target_user.username or str(target_user.id)

    ok, err = await authorize_action(context, chat_id, user_id, "warn", target_id, RANK_MODERATOR)
    if not ok:
        await message.reply_text(err)
        return

    actor = update.effective_user
    await moderation._do_warn(context, chat_id, target_id, name, None, actor.id, actor.first_name)


# ---------------------------------------------------------------------------
# Link protection (نمونه‌ی اکشن غیرخطرناک با اجرای مستقیم، بدون confirmation)
# ---------------------------------------------------------------------------

async def _handle_link_protection_intent(update: Update, context: ContextTypes.DEFAULT_TYPE, result):
    if not await admin_only(update, context):
        return
    enabled = result.entities.get("enabled", True)
    # دقیقاً همون کاری که text_commands.py برای Alias دقیق «lock»/«unlock»
    # انجام می‌ده: context.args رو می‌سازیم و همون handler موجود رو صدا می‌زنیم.
    context.args = ["link"]
    if enabled:
        await locks_filters.lock_cmd(update, context)
    else:
        await locks_filters.unlock_cmd(update, context)


# --- Phase 3 (گسترش NLU آزاد): سه دستور on/off ساده (mention protection /
# antispam / dupcross) دقیقاً همین الگوی configure_link_protection رو دارن —
# handler خودشون context.args=["on"|"off"] می‌خواد؛ یک تابع عمومی به‌جای
# سه تابع تقریباً یکسان (بخش 23: duplicate business logic نساز).
_TOGGLE_HANDLERS = {
    "mentionprotection": locks_filters.mentionprotection_cmd,
    "antispam": locks_filters.antispam_cmd,
    "dupcross": locks_filters.dupcross_cmd,
}


async def _handle_toggle_intent(update: Update, context: ContextTypes.DEFAULT_TYPE, result, toggle_id: str):
    if not await admin_only(update, context):
        return
    enabled = result.entities.get("enabled", True)
    context.args = ["on" if enabled else "off"]
    await _TOGGLE_HANDLERS[toggle_id](update, context)


# ---------------------------------------------------------------------------
# Fallback (بخش 11) — سؤال به‌جای حدس، وقتی intent مبهمه (نه وقتی کلاً ناشناخته‌ست)
# ---------------------------------------------------------------------------

async def _send_fallback(update: Update, chat_id: int, candidates: list):
    if "update_rules" in candidates:
        # طبق بخش 11: به‌جای پیام مبهمِ عمومی، دقیقاً فرمت مورد انتظار رو نشون بده.
        await update.effective_message.reply_text(tc(chat_id, "nlu_setrules_format_hint"))
        return
    if "delete_auto_answer" in candidates:
        await update.effective_message.reply_text(tc(chat_id, "nlu_delanswer_format_hint"))
        return
    # Phase 3: mention protection/antispam/dupcross هم مثل link protection،
    # وقتی جهت (فعال/غیرفعال) از متن معلوم نیست، حدس نمی‌زنیم — فقط با
    # پیام fallback عمومی و راهنما جواب می‌دیم (نه یک اکشن اشتباه).

    buttons = []
    if "configure_link_protection" in candidates or "show_security_status" in candidates:
        buttons.append([InlineKeyboardButton(tc(chat_id, "guide_btn_locks"), callback_data="guide:locks")])
    await update.effective_message.reply_text(
        tc(chat_id, "nlu_fallback_intro"),
        reply_markup=InlineKeyboardMarkup(buttons) if buttons else None,
    )
