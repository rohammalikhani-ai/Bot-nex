# -*- coding: utf-8 -*-
"""
پایپ‌لاین مدیریت محتوا: قفل محتوا، Link Protection (با Whitelist/Blacklist
دامنه)، فیلتر کلمات ممنوعه (با Whitelist استثنا)، Anti-Spam (پیام تکراری +
لینک از عضو تازه‌وارد)، و Anti-Flood — همه روی یک پیام در یک پاس بررسی می‌شن.
"""
from __future__ import annotations  # keep dict[...]/list[...] hints working on Python < 3.9

import re
import logging
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta
from urllib.parse import urlparse

from telegram import Update, ChatPermissions
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc
from config import (
    VALID_LOCKS, FLOOD_LIMIT, FLOOD_WINDOW_SECONDS, FLOOD_MUTE_MINUTES,
    DEFAULT_SPAM_ACTION, DEFAULT_FILTER_ACTION, DEFAULT_FLOOD_ACTION,
    SPAM_DUPLICATE_THRESHOLD, SPAM_DUPLICATE_WINDOW_SECONDS, SPAM_NEWMEMBER_LINK_MINUTES,
    DEFAULT_FORWARD_ACTION, DEFAULT_MENTION_LIMIT, DEFAULT_MENTION_ACTION,
    SPAM_CROSS_USER_THRESHOLD, SPAM_CROSS_USER_WINDOW_SECONDS, DEFAULT_DUPLICATE_CROSS_ACTION,
)
from handlers.common import admin_only, is_admin

logger = logging.getLogger(__name__)

LINK_REGEX = re.compile(r"(https?://\S+|www\.\S+)", re.IGNORECASE)
TG_INVITE_REGEX = re.compile(r"t\.me/(joinchat/|\+)", re.IGNORECASE)
TG_CHANNEL_REGEX = re.compile(r"t\.me/([A-Za-z0-9_]+)", re.IGNORECASE)

# داده‌های موقت (نیازی به دائمی بودن نیست؛ با ری‌استارت ربات پاک می‌شن)
_message_times: dict[int, dict[int, deque]] = defaultdict(lambda: defaultdict(deque))       # آنتی‌فلاد
_recent_texts: dict[int, dict[int, deque]] = defaultdict(lambda: defaultdict(deque))         # آنتی‌اسپم (تکراری - تک‌کاربر)
_member_join_time: dict[int, dict[int, float]] = defaultdict(dict)                           # آنتی‌اسپم (عضو تازه)
_chat_recent_texts: dict[int, deque] = defaultdict(deque)                                    # آنتی‌اسپم (تکراری بین چند کاربر - Copy/Paste Raid)


def note_member_joined(chat_id: int, user_id: int):
    _member_join_time[chat_id][user_id] = time.time()


async def on_new_members(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    ثبت زمان Join هر عضو جدید — مستقل از روشن/خاموش بودن Anti-Raid، چون
    هیوریستیک «لینک از عضو تازه‌وارد» در Anti-Spam به این داده نیاز داره.
    """
    chat_id = update.effective_chat.id
    for member in update.message.new_chat_members:
        if not member.is_bot:
            note_member_joined(chat_id, member.id)


# ---------------- Lock commands ----------------

async def lock_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in VALID_LOCKS:
        await update.message.reply_text(tc(chat_id, "lock_usage", options="|".join(VALID_LOCKS)))
        return
    kind = context.args[0].lower()
    db.add_lock(chat_id, kind)
    await update.message.reply_text(tc(chat_id, "lock_done", kind=kind))


async def unlock_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in VALID_LOCKS:
        await update.message.reply_text(tc(chat_id, "unlock_usage", options="|".join(VALID_LOCKS)))
        return
    kind = context.args[0].lower()
    db.remove_lock(chat_id, kind)
    await update.message.reply_text(tc(chat_id, "unlock_done", kind=kind))


async def locks_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    active = db.get_locks(chat_id)
    await update.message.reply_text(tc(chat_id, "locks_active", locks=", ".join(active) if active else tc(chat_id, "none")))


# ---------------- Forbidden Words ----------------

async def filter_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "filter_usage"))
        return
    word = " ".join(context.args).lower()
    db.add_filter(chat_id, word)
    await update.message.reply_text(tc(chat_id, "filter_added", word=word))


async def stopfilter_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "stopfilter_usage"))
        return
    word = " ".join(context.args).lower()
    db.remove_filter(chat_id, word)
    await update.message.reply_text(tc(chat_id, "filter_removed", word=word))


async def filters_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    active = db.get_filters(chat_id)
    await update.message.reply_text(tc(chat_id, "filters_active", filters=", ".join(active) if active else tc(chat_id, "none")))


async def setfilteraction_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("delete", "warn", "mute", "ban"):
        await update.message.reply_text(tc(chat_id, "setfilteraction_usage"))
        return
    db.set_setting(chat_id, "filter_action", context.args[0].lower())
    await update.message.reply_text(tc(chat_id, "setfilteraction_done", action=context.args[0].lower()))


async def allowword_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """استثنا برای فیلتر کلمات: اگه پیام شامل این کلمه/عبارت باشه، فیلتر روی آن پیام اجرا نمی‌شه."""
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "allowword_usage"))
        return
    word = " ".join(context.args).lower()
    db.add_filter_whitelist(chat_id, word)
    await update.message.reply_text(tc(chat_id, "allowword_done", word=word))


async def disallowword_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "disallowword_usage"))
        return
    word = " ".join(context.args).lower()
    db.remove_filter_whitelist(chat_id, word)
    await update.message.reply_text(tc(chat_id, "disallowword_done", word=word))


# ---------------- Link Protection: Domain Whitelist/Blacklist ----------------

async def blockdomain_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "blockdomain_usage"))
        return
    domain = context.args[0].lower()
    db.add_domain(chat_id, domain, "blacklist")
    await update.message.reply_text(tc(chat_id, "blockdomain_done", domain=domain))


async def unblockdomain_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "unblockdomain_usage"))
        return
    domain = context.args[0].lower()
    db.remove_domain(chat_id, domain, "blacklist")
    await update.message.reply_text(tc(chat_id, "unblockdomain_done", domain=domain))


async def allowdomain_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "allowdomain_usage"))
        return
    domain = context.args[0].lower()
    db.add_domain(chat_id, domain, "whitelist")
    await update.message.reply_text(tc(chat_id, "allowdomain_done", domain=domain))


async def unallowdomain_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "unallowdomain_usage"))
        return
    domain = context.args[0].lower()
    db.remove_domain(chat_id, domain, "whitelist")
    await update.message.reply_text(tc(chat_id, "unallowdomain_done", domain=domain))


async def domains_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    blocked = db.get_domains(chat_id, "blacklist")
    allowed = db.get_domains(chat_id, "whitelist")
    lines = []
    if blocked:
        lines.append(tc(chat_id, "domains_header_block"))
        lines.extend(f"• {d}" for d in blocked)
    if allowed:
        lines.append(tc(chat_id, "domains_header_allow"))
        lines.extend(f"• {d}" for d in allowed)
    if not lines:
        lines = [tc(chat_id, "domains_empty")]
    await update.message.reply_text("\n".join(lines))


# ---------------- Forward Protection (انتخابی: Source خاص Allow/Block) ----------------

def _forward_source(message):
    """
    منبع Forward یک پیام را برمی‌گرداند: (source_key, source_label) یا None اگر پیام Forward نیست.
    هم با MessageOrigin جدید (Bot API 7+) کار می‌کند هم با فیلدهای قدیمی forward_from/forward_from_chat
    برای سازگاری با نسخه‌های مختلف.
    """
    origin = getattr(message, "forward_origin", None)
    if origin is not None:
        sender_user = getattr(origin, "sender_user", None)
        if sender_user:
            return f"user:{sender_user.id}", sender_user.first_name or str(sender_user.id)
        sender_chat = getattr(origin, "sender_chat", None)
        if sender_chat:
            key = f"chat:{sender_chat.username.lower()}" if sender_chat.username else f"chat:{sender_chat.id}"
            return key, sender_chat.title or sender_chat.username or str(sender_chat.id)
        chat = getattr(origin, "chat", None)
        if chat:
            key = f"chat:{chat.username.lower()}" if chat.username else f"chat:{chat.id}"
            return key, chat.title or chat.username or str(chat.id)
        hidden_name = getattr(origin, "sender_user_name", None)
        if hidden_name:
            return f"name:{hidden_name.lower()}", hidden_name
        # پیام Forward هست ولی منبع دقیقش قابل تشخیص نیست؛ همچنان به‌عنوان Forward علامت بزن
        return "unknown:unknown", "?"

    # سازگاری با نسخه‌های قدیمی‌تر کتابخانه
    ff_chat = getattr(message, "forward_from_chat", None)
    if ff_chat:
        key = f"chat:{ff_chat.username.lower()}" if ff_chat.username else f"chat:{ff_chat.id}"
        return key, ff_chat.title or ff_chat.username or str(ff_chat.id)
    ff_user = getattr(message, "forward_from", None)
    if ff_user:
        return f"user:{ff_user.id}", ff_user.first_name or str(ff_user.id)
    ff_name = getattr(message, "forward_sender_name", None)
    if ff_name:
        return f"name:{ff_name.lower()}", ff_name
    if getattr(message, "forward_date", None):
        return "unknown:unknown", "?"
    return None


def _parse_source_arg(arg: str):
    """ورودی دستور (@username یا عددی) را به همون فرمت source_key تبدیل می‌کند."""
    arg = arg.strip()
    if arg.startswith("@"):
        return f"chat:{arg[1:].lower()}"
    if arg.lstrip("-").isdigit():
        return f"chat:{arg}"
    return f"name:{arg.lower()}"


async def allowforward_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "allowforward_usage"))
        return
    label = " ".join(context.args)
    key = _parse_source_arg(context.args[0])
    db.add_forward_rule(chat_id, key, label, "allow")
    await update.message.reply_text(tc(chat_id, "allowforward_done", source=label))


async def blockforward_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "blockforward_usage"))
        return
    label = " ".join(context.args)
    key = _parse_source_arg(context.args[0])
    db.add_forward_rule(chat_id, key, label, "block")
    await update.message.reply_text(tc(chat_id, "blockforward_done", source=label))


async def unruleforward_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "unruleforward_usage"))
        return
    key = _parse_source_arg(context.args[0])
    db.remove_forward_rule(chat_id, key)
    await update.message.reply_text(tc(chat_id, "unruleforward_done", source=context.args[0]))


async def forwardrules_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    rules = db.list_forward_rules(chat_id)
    allowed = [label for _, label, mode in rules if mode == "allow"]
    blocked = [label for _, label, mode in rules if mode == "block"]
    lines = []
    if blocked:
        lines.append(tc(chat_id, "forwardrules_header_block"))
        lines.extend(f"• {d}" for d in blocked)
    if allowed:
        lines.append(tc(chat_id, "forwardrules_header_allow"))
        lines.extend(f"• {d}" for d in allowed)
    if not lines:
        lines = [tc(chat_id, "forwardrules_empty")]
    await update.message.reply_text("\n".join(lines))


# ---------------- Mention Protection ----------------

MENTION_ENTITY_TYPES = {"mention", "text_mention"}


async def mentionprotection_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("on", "off"):
        await update.message.reply_text(tc(chat_id, "mentionprotection_usage"))
        return
    state = context.args[0].lower()
    db.set_setting(chat_id, "mention_protection", state)
    state_label = tc(chat_id, "state_on") if state == "on" else tc(chat_id, "state_off")
    await update.message.reply_text(tc(chat_id, "mentionprotection_done", state=state_label))


async def setmentionlimit_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or not context.args[0].isdigit() or int(context.args[0]) < 1:
        await update.message.reply_text(tc(chat_id, "setmentionlimit_usage"))
        return
    n = int(context.args[0])
    db.set_setting(chat_id, "mention_limit", n)
    await update.message.reply_text(tc(chat_id, "setmentionlimit_done", n=n))


async def setmentionaction_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("delete", "warn", "mute", "ban"):
        await update.message.reply_text(tc(chat_id, "setmentionaction_usage"))
        return
    db.set_setting(chat_id, "mention_action", context.args[0].lower())
    await update.message.reply_text(tc(chat_id, "setmentionaction_done", action=context.args[0].lower()))


# ---------------- Anti-Spam: تشخیص پیام تکراری بین چند کاربر ----------------

async def dupcross_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("on", "off"):
        await update.message.reply_text(tc(chat_id, "dupcross_usage"))
        return
    state = context.args[0].lower()
    db.set_setting(chat_id, "dupcross_enabled", state)
    state_label = tc(chat_id, "state_on") if state == "on" else tc(chat_id, "state_off")
    await update.message.reply_text(tc(chat_id, "dupcross_done", state=state_label))


async def setdupcross_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if len(context.args) < 2 or not all(a.isdigit() for a in context.args[:2]):
        await update.message.reply_text(tc(chat_id, "setdupcross_usage"))
        return
    threshold, window = int(context.args[0]), int(context.args[1])
    db.set_setting(chat_id, "dupcross_threshold", threshold)
    db.set_setting(chat_id, "dupcross_window", window)
    await update.message.reply_text(tc(chat_id, "setdupcross_done", threshold=threshold, window=window))


# ---------------- Anti-Spam toggle ----------------

async def antispam_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("on", "off"):
        await update.message.reply_text(tc(chat_id, "antispam_toggle_usage"))
        return
    state = context.args[0].lower()
    db.set_setting(chat_id, "antispam_enabled", state)
    state_label = tc(chat_id, "state_on") if state == "on" else tc(chat_id, "state_off")
    await update.message.reply_text(tc(chat_id, "antispam_toggle_done", state=state_label))


async def setspamaction_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("delete", "warn", "mute", "ban"):
        await update.message.reply_text(tc(chat_id, "setspamaction_usage"))
        return
    db.set_setting(chat_id, "spam_action", context.args[0].lower())
    await update.message.reply_text(tc(chat_id, "setspamaction_done", action=context.args[0].lower()))


# ---------------- Anti-Flood settings ----------------

async def setflood_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if len(context.args) < 2 or not all(a.isdigit() for a in context.args[:2]):
        await update.message.reply_text(tc(chat_id, "setflood_usage"))
        return
    limit, window = int(context.args[0]), int(context.args[1])
    db.set_setting(chat_id, "flood_limit", limit)
    db.set_setting(chat_id, "flood_window", window)
    await update.message.reply_text(tc(chat_id, "setflood_done", limit=limit, window=window))


async def setfloodaction_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("delete", "warn", "mute", "ban"):
        await update.message.reply_text(tc(chat_id, "setfloodaction_usage"))
        return
    db.set_setting(chat_id, "flood_action", context.args[0].lower())
    await update.message.reply_text(tc(chat_id, "setfloodaction_done", action=context.args[0].lower()))


# ---------------- پایپ‌لاین اصلی: روی هر پیام غیردستوری ----------------

def _extract_domain(url: str) -> str:
    """استخراج host از یک URL.

    نکته امنیتی: netloc می‌تونه شامل یک بخش userinfo باشه (مثل
    "safe-looking.com@evil.com")؛ اگه این بخش را قبل از استخراج host جدا
    نکنیم، دامنه‌ی واقعی (evil.com) هیچ‌وقت با Blacklist/Whitelist مقایسه
    نمی‌شه و کل Link Protection دور زده می‌شه. همیشه باید فقط چیزی که بعد
    از آخرین '@' میاد را به‌عنوان host در نظر گرفت.
    """
    if not url.startswith(("http://", "https://")):
        url = "http://" + url
    try:
        netloc = urlparse(url).netloc.lower()
        host = netloc.rsplit("@", 1)[-1]  # حذف userinfo احتمالی (user:pass@ یا دامنه‌ی جعلی@)
        return host.split(":")[0]
    except Exception:
        return ""


async def moderate_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """روی هر پیام غیر-دستوری اجرا می‌شود: قفل، Link Protection، فیلتر کلمات، Anti-Spam، Anti-Flood."""
    message = update.message
    if not message or not update.effective_chat or update.effective_chat.type == "private":
        return
    chat_id = update.effective_chat.id
    user = update.effective_user
    if user is None or await is_admin(update, context, user.id):
        return

    # از handlers.moderation اینجا import می‌کنیم تا از circular import در سطح ماژول جلوگیری بشه
    from handlers.moderation import apply_enforcement

    locks = db.get_locks(chat_id)
    text = message.text or message.caption or ""
    text_lower = text.lower()
    links = LINK_REGEX.findall(text) if text else []

    should_delete = False
    violation_reason = None
    violation_action = None  # اگه ست بشه، بعد از حذف پیام، apply_enforcement صدا زده می‌شه

    # ---- Link Protection ----
    for link in links:
        domain = _extract_domain(link)
        if domain and db.is_domain_listed(chat_id, domain, "blacklist"):
            should_delete = True
            violation_reason = tc(chat_id, "link_reason_blacklisted")
            break

    if not should_delete and text:
        if TG_INVITE_REGEX.search(text) and "invitelink" in locks:
            should_delete = True
        elif TG_CHANNEL_REGEX.search(text) and not TG_INVITE_REGEX.search(text) and "channellink" in locks:
            should_delete = True
        elif links and "link" in locks:
            # اگه همه‌ی دامنه‌های این پیام تو وایت‌لیست باشن، لینک "link" رو نادیده بگیر
            non_whitelisted = [l for l in links if not db.is_domain_listed(chat_id, _extract_domain(l), "whitelist")]
            if non_whitelisted:
                should_delete = True

    if "photo" in locks and message.photo:
        should_delete = True
    if "video" in locks and message.video:
        should_delete = True
    if "sticker" in locks and message.sticker:
        should_delete = True
    if "voice" in locks and message.voice:
        should_delete = True
    if "gif" in locks and message.animation:
        should_delete = True
    if "video_note" in locks and message.video_note:
        should_delete = True
    if "document" in locks and message.document:
        should_delete = True
    if "poll" in locks and message.poll:
        should_delete = True

    # ---- Forward Protection (قفل کلی + قوانین انتخابی روی Source خاص) ----
    if not should_delete:
        source = _forward_source(message)
        if source is not None:
            source_key, source_label = source
            rule = db.get_forward_rule(chat_id, source_key)
            if rule == "block":
                should_delete = True
                violation_reason = tc(chat_id, "forward_reason_blocked_source", source=source_label)
                violation_action = db.get_setting(chat_id, "forward_action", DEFAULT_FORWARD_ACTION)
            elif rule == "allow":
                pass  # صراحتاً مجاز شده؛ حتی اگر قفل کلی forward روشن باشد رد می‌شود
            elif "forward" in locks:
                should_delete = True

    # ---- Mention Protection (سوءاستفاده از @mention دسته‌جمعی) ----
    if not should_delete and message.entities:
        mention_on = db.get_setting(chat_id, "mention_protection", "on") == "on"
        if mention_on:
            mention_count = sum(1 for e in message.entities if e.type in MENTION_ENTITY_TYPES)
            mention_limit = int(db.get_setting(chat_id, "mention_limit", DEFAULT_MENTION_LIMIT))
            if mention_count >= mention_limit:
                should_delete = True
                violation_reason = tc(chat_id, "mention_reason", count=mention_count)
                violation_action = db.get_setting(chat_id, "mention_action", DEFAULT_MENTION_ACTION)

    # ---- Forbidden Words (با استثنای Whitelist) ----
    # نکته امنیتی: Whitelist یک لیست استثنای per-word است (مثلاً کلمه‌ی مجاز
    # "classic" که به‌اشتباه با فیلتر "ass" برخورد می‌کنه)، نه یک کلید خاموش‌کننده
    # کلی. اگه حضور *هر* کلمه‌ی Whitelist در پیام باعث بشه اصلاً هیچ فیلتری چک
    # نشه، هرکسی می‌تونه با اضافه کردن یک کلمه‌ی بی‌ضرر از Whitelist، کل فیلتر
    # کلمات ممنوعه رو دور بزنه. پس هر تطابق ممنوعه فقط وقتی نادیده گرفته می‌شه
    # که همون تطابق داخل یک عبارت Whitelist‌شده‌ی حاضر در متن باشه.
    if not should_delete and text:
        whitelist = [w for w in db.get_filter_whitelist(chat_id) if w in text_lower]
        for word in db.get_filters(chat_id):
            if word not in text_lower:
                continue
            if any(word in w for w in whitelist):
                continue  # این تطابق داخل یک عبارت مجازشده است، نه یک نقض مستقل
            should_delete = True
            violation_reason = tc(chat_id, "filter_reason")
            violation_action = db.get_setting(chat_id, "filter_action", DEFAULT_FILTER_ACTION)
            break

    # ---- Anti-Spam (پیام تکراری / لینک از عضو تازه‌وارد) ----
    antispam_on = db.get_setting(chat_id, "antispam_enabled", "on") == "on"
    if not should_delete and antispam_on and text:
        now = time.time()
        dq = _recent_texts[chat_id][user.id]
        dq.append((now, text_lower))
        while dq and now - dq[0][0] > SPAM_DUPLICATE_WINDOW_SECONDS:
            dq.popleft()
        same_count = sum(1 for _, t in dq if t == text_lower)
        if same_count >= SPAM_DUPLICATE_THRESHOLD:
            should_delete = True
            violation_reason = tc(chat_id, "spam_reason_duplicate")
            violation_action = db.get_setting(chat_id, "spam_action", DEFAULT_SPAM_ACTION)
        elif links:
            joined_at = _member_join_time[chat_id].get(user.id)
            if joined_at and (now - joined_at) < SPAM_NEWMEMBER_LINK_MINUTES * 60:
                should_delete = True
                violation_reason = tc(chat_id, "spam_reason_newlink")
                violation_action = db.get_setting(chat_id, "spam_action", DEFAULT_SPAM_ACTION)

        # ---- تشخیص پیام تکراری بین چند کاربر مختلف (Copy/Paste Raid) ----
        if not should_delete and db.get_setting(chat_id, "dupcross_enabled", "on") == "on":
            cdq = _chat_recent_texts[chat_id]
            cross_window = int(db.get_setting(chat_id, "dupcross_window", SPAM_CROSS_USER_WINDOW_SECONDS))
            cdq.append((now, user.id, text_lower))
            while cdq and now - cdq[0][0] > cross_window:
                cdq.popleft()
            distinct_users = {uid for _, uid, t in cdq if t == text_lower}
            cross_threshold = int(db.get_setting(chat_id, "dupcross_threshold", SPAM_CROSS_USER_THRESHOLD))
            if len(distinct_users) >= cross_threshold:
                should_delete = True
                violation_reason = tc(chat_id, "spam_reason_cross_duplicate")
                violation_action = db.get_setting(chat_id, "spam_action", DEFAULT_SPAM_ACTION)

    if should_delete:
        try:
            await message.delete()
        except Exception:
            logger.exception("failed to delete spam message in chat %s", chat_id)
        if violation_action:
            await apply_enforcement(
                context, chat_id, user.id, user.first_name, violation_action,
                violation_reason or "-", actor_id=0, actor_name="AutoMod",
            )
        return

    # ---- Anti-Flood ----
    flood_limit = int(db.get_setting(chat_id, "flood_limit", FLOOD_LIMIT))
    flood_window = int(db.get_setting(chat_id, "flood_window", FLOOD_WINDOW_SECONDS))
    now = time.time()
    dq = _message_times[chat_id][user.id]
    dq.append(now)
    while dq and now - dq[0] > flood_window:
        dq.popleft()

    if len(dq) > flood_limit:
        flood_action = db.get_setting(chat_id, "flood_action", DEFAULT_FLOOD_ACTION)
        dq.clear()
        await apply_enforcement(
            context, chat_id, user.id, user.first_name, flood_action,
            tc(chat_id, "flood_reason"), actor_id=0, actor_name="AntiFlood",
        )
