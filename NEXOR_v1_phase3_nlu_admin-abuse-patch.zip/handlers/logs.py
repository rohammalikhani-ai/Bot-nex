# -*- coding: utf-8 -*-
import logging
from telegram import Update
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc
from handlers.common import admin_only


logger = logging.getLogger(__name__)

async def setlogchannel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "setlogchannel_usage"))
        return
    channel = context.args[0]
    try:
        chat = await context.bot.get_chat(channel)
    except Exception as e:
        await update.message.reply_text(tc(chat_id, "setlogchannel_error", error=e))
        return

    db.set_setting(chat_id, "log_channel", str(chat.id))
    await update.message.reply_text(tc(chat_id, "setlogchannel_done", title=chat.title))
    try:
        await context.bot.send_message(chat.id, tc(chat_id, "setlogchannel_channel_confirm"))
    except Exception:
        logger.exception("non-fatal operation failed")
