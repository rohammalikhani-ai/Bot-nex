# -*- coding: utf-8 -*-
"""
Anti-Raid: تشخیص Join ناگهانی تعداد زیادی کاربر در بازه‌ی کوتاه، قفل خودکار
گروه (Auto Lock)، هشدار به ادمین‌ها (Alert)، و باز شدن خودکار بعد از مدتی
(Auto Unlock). همچنین /lockdown برای قفل دستی فوری (نقش دکمه‌ی اضطراری) و
/unlock برای باز کردن دستی.

محدودیت شناخته‌شده: چون داده‌ی join در حافظه نگه‌داشته می‌شه (نه دیتابیس)،
با ری‌استارت ربات شمارنده صفر می‌شه — برای تشخیص رید در همون لحظه مشکلی
نداره چون فقط بازه‌ی چند ثانیه‌ای اخیر مهمه.
"""
from __future__ import annotations  # keep dict[int, deque] hints working on Python < 3.9

import logging
import time
from collections import defaultdict, deque
from datetime import timedelta

from telegram import Update, ChatPermissions, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc, t, get_lang
from config import DEFAULT_RAID_THRESHOLD, DEFAULT_RAID_WINDOW_SECONDS, DEFAULT_RAID_LOCKDOWN_MINUTES
from handlers.common import admin_only, get_rank
from config import RANK_ADMIN

_join_times: dict[int, deque] = defaultdict(deque)

_OPEN_PERMISSIONS = ChatPermissions(
    can_send_messages=True, can_send_photos=True, can_send_videos=True,
    can_send_other_messages=True, can_send_polls=True, can_add_web_page_previews=True,
)
_LOCKED_PERMISSIONS = ChatPermissions(can_send_messages=False)


logger = logging.getLogger(__name__)

async def antiraid_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("on", "off"):
        await update.message.reply_text(tc(chat_id, "antiraid_toggle_usage"))
        return
    state = context.args[0].lower()
    db.set_setting(chat_id, "antiraid_enabled", state)
    state_label = tc(chat_id, "state_on") if state == "on" else tc(chat_id, "state_off")
    await update.message.reply_text(tc(chat_id, "antiraid_toggle_done", state=state_label))


async def setraidthreshold_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or not context.args[0].isdigit() or int(context.args[0]) < 2:
        await update.message.reply_text(tc(chat_id, "setraidthreshold_usage"))
        return
    db.set_setting(chat_id, "raid_threshold", int(context.args[0]))
    await update.message.reply_text(tc(chat_id, "setraidthreshold_done", n=context.args[0]))


async def _do_lock(context: ContextTypes.DEFAULT_TYPE, chat_id: int):
    await context.bot.set_chat_permissions(chat_id, permissions=_LOCKED_PERMISSIONS)
    db.set_setting(chat_id, "locked", "on")


async def _do_unlock(context: ContextTypes.DEFAULT_TYPE, chat_id: int):
    await context.bot.set_chat_permissions(chat_id, permissions=_OPEN_PERMISSIONS)
    db.set_setting(chat_id, "locked", "off")


async def lockdown_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """قفل دستی فوری — نقش «دکمه اضطراری» رو بازی می‌کنه؛ فقط ادمین به بالا."""
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if db.get_setting(chat_id, "locked", "off") == "on":
        await update.message.reply_text(tc(chat_id, "already_locked"))
        return
    await _do_lock(context, chat_id)
    await update.message.reply_text(tc(chat_id, "lockdown_done"))
    actor = update.effective_user
    from handlers.common import log_action
    await log_action(context, chat_id, tc(chat_id, "lockdown_done"), actor.id, actor.first_name, "lockdown", None, None, None)


async def unlock_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if db.get_setting(chat_id, "locked", "off") == "off":
        await update.message.reply_text(tc(chat_id, "already_unlocked"))
        return
    await _do_unlock(context, chat_id)
    await update.message.reply_text(tc(chat_id, "unlock_done_manual"))
    actor = update.effective_user
    from handlers.common import log_action
    await log_action(context, chat_id, tc(chat_id, "unlock_done_manual"), actor.id, actor.first_name, "unlock", None, None, None)


async def _unlock_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دکمه‌ی «باز کردن قفل الان» روی پیام هشدار رید — با اعتبارسنجی سمت سرور."""
    query = update.callback_query
    chat_id = update.effective_chat.id
    rank = await get_rank(context, chat_id, query.from_user.id)
    if rank < RANK_ADMIN:
        await query.answer(tc(chat_id, "err_need_rank", rank=t(get_lang(chat_id), "rank_admin")), show_alert=True)
        return
    if db.get_setting(chat_id, "locked", "off") == "off":
        await query.answer(tc(chat_id, "already_unlocked"), show_alert=True)
        return
    await _do_unlock(context, chat_id)
    await query.answer(tc(chat_id, "unlock_done_manual"))
    try:
        await query.edit_message_text(tc(chat_id, "unlock_done_manual"))
    except Exception:
        logger.exception("non-fatal operation failed")


async def _auto_unlock_job(context: ContextTypes.DEFAULT_TYPE):
    chat_id = context.job.data["chat_id"]
    if db.get_setting(chat_id, "locked", "off") != "on":
        return  # قبلاً دستی باز شده
    await _do_unlock(context, chat_id)
    try:
        await context.bot.send_message(chat_id, tc(chat_id, "raid_auto_unlock"))
    except Exception:
        logger.exception("non-fatal operation failed")


async def check_raid_on_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """روی هر رویداد ورود عضو جدید اجرا می‌شه؛ اگه در بازه‌ی کوتاه Join زیاد بود، قفل می‌کنه."""
    chat_id = update.effective_chat.id
    if db.get_setting(chat_id, "antiraid_enabled", "off") != "on":
        return
    if db.get_setting(chat_id, "locked", "off") == "on":
        return  # از قبل قفله، نیازی به تشخیص دوباره نیست

    threshold = int(db.get_setting(chat_id, "raid_threshold", DEFAULT_RAID_THRESHOLD))
    window = DEFAULT_RAID_WINDOW_SECONDS
    now = time.time()
    dq = _join_times[chat_id]
    for _ in update.message.new_chat_members:
        dq.append(now)
    while dq and now - dq[0] > window:
        dq.popleft()

    if len(dq) < threshold:
        return

    minutes = DEFAULT_RAID_LOCKDOWN_MINUTES
    await _do_lock(context, chat_id)
    dq.clear()

    lang = get_lang(chat_id)
    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton(t(lang, "btn_unlock_now"), callback_data="raidunlock")
    ]])
    text = tc(chat_id, "raid_detected_alert", count=threshold, window=window, minutes=minutes)
    await context.bot.send_message(chat_id, text, parse_mode=ParseMode.MARKDOWN, reply_markup=keyboard)

    from handlers.common import log_action
    await log_action(context, chat_id, text, 0, "AntiRaid", "raid_lockdown", None, None, f"{threshold} joins/{window}s")

    # Priority 5, Item 27 — ثبت در تاریخچه‌ی عمومی Admin Alerts (قابل مشاهده با /alerts)
    db.add_alert(chat_id, "raid", text, now)

    context.job_queue.run_once(
        _auto_unlock_job, when=minutes * 60, data={"chat_id": chat_id}, name=f"raidunlock_{chat_id}_{now}",
    )


# alias برای callback pattern در main.py
unlock_callback = _unlock_callback
