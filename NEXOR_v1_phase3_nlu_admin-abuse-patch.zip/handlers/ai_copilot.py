# -*- coding: utf-8 -*-
"""
NEXOR Copilot — لایه‌ی Telegram. این فایل تنها جایی است که با ai_copilot.service
صحبت می‌کند؛ خودش هیچ Prompt/Providerی نمی‌شناسد (طبق نکته‌ی معماری بریف).

معماری اجرای واقعی هر Recommendation:
    دکمه‌ی AI → ai_action_callback → authorize_action (دوباره از صفر چک می‌شود)
    → همون توابع موجود moderation (_do_warn/restrict_chat_member/ban_chat_member)
هیچ Ban/Mute/Delete‌ای مستقیماً از داخل ai_copilot صدا زده نمی‌شود.
"""
from __future__ import annotations

import logging
import re
import time
from datetime import datetime, timedelta

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ChatPermissions
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc, t, get_lang
from config import RANK_MODERATOR, RANK_ADMIN, RANK_OWNER, DEFAULT_WARN_MUTE_MINUTES
from handlers.common import authorize_action, get_rank, resolve_target, log_action, require_rank
from ai_copilot import service, formatting as fmt
from ai_copilot import plans as ai_plans

logger = logging.getLogger(__name__)

_PENDING_RULE_KEY = "pending_ai_rule"


def _append_ad(chat_id: int, text: str) -> str:
    """زیر نتیجه‌ی موفق NEXOR Copilot، برای گروه‌های پلن رایگان، یک خط تبلیغاتی
    اضافه می‌کنه (services/ads.py) — Pro/Premium هیچ‌وقت این خط رو نمی‌بینن."""
    try:
        from services import ads as ads_service
        if not ads_service.chat_should_see_ads(chat_id):
            return text
        ad = ads_service.pick_ad_for_footer(chat_id)
        if ad is None:
            return text
        return f"{text}\n\n— — —\n{ads_service.ad_short_line(ad)}"
    except Exception:
        logger.exception("افزودن خط تبلیغاتی زیر پیام Copilot شکست خورد")
        return text
_LINK_RE = re.compile(r"https?://|t\.me/|www\.", re.IGNORECASE)

_ERROR_KEY = {
    "plan_not_allowed": "ai_err_plan_not_allowed",
    "rate_limited": "ai_err_rate_limited",
    "not_configured": "ai_err_not_configured",
    "provider_error": "ai_err_provider_error",
    "bad_response": "ai_err_bad_response",
    "unknown_error": "ai_err_unknown",
}


def _error_text(chat_id: int, result) -> str:
    return tc(chat_id, _ERROR_KEY.get(result.error_code, "ai_err_unknown"))


async def _gate(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    chat_id = update.effective_chat.id
    user_id = update.effective_user.id
    ok, err = await authorize_action(context, chat_id, user_id, "ai_copilot", None, RANK_MODERATOR)
    if not ok:
        await update.effective_message.reply_text(err)
    return ok


# ==================== Panel (Action-based UI) ====================

def _btn(chat_id: int, owner_id: int, key: str, section: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(tc(chat_id, key), callback_data=f"copilot:{owner_id}:{section}")


def _main_menu_kb(chat_id: int, owner_id: int) -> InlineKeyboardMarkup:
    rows = [
        [_btn(chat_id, owner_id, "ai_btn_analyze", "analyze"), _btn(chat_id, owner_id, "ai_btn_explain", "explain")],
        [_btn(chat_id, owner_id, "ai_btn_health", "health"), _btn(chat_id, owner_id, "ai_btn_reports", "reports")],
        [_btn(chat_id, owner_id, "ai_btn_optimize", "optimize"), _btn(chat_id, owner_id, "ai_btn_incident", "incident")],
        [_btn(chat_id, owner_id, "ai_btn_rule", "rule")],
        [_btn(chat_id, owner_id, "ai_btn_close", "close")],
    ]
    return InlineKeyboardMarkup(rows)


def _back_kb(chat_id: int, owner_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_btn(chat_id, owner_id, "panel_btn_back", "main")]])


async def copilot_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _gate(update, context):
        return
    chat_id = update.effective_chat.id
    user = update.effective_user
    await update.effective_message.reply_text(
        tc(chat_id, "ai_panel_header"), reply_markup=_main_menu_kb(chat_id, user.id)
    )


async def copilot_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = update.effective_chat.id
    try:
        _, owner_id_s, section = query.data.split(":", 2)
        owner_id = int(owner_id_s)
    except ValueError:
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return

    clicker_id = query.from_user.id
    if clicker_id != owner_id:
        await query.answer(tc(chat_id, "panel_not_yours"), show_alert=True)
        return

    ok, err = await authorize_action(context, chat_id, clicker_id, "ai_copilot", None, RANK_MODERATOR)
    if not ok:
        await query.answer(err, show_alert=True)
        try:
            await query.edit_message_text(tc(chat_id, "panel_closed"))
        except Exception:
            logger.exception("non-fatal operation failed")
        return

    if section == "close":
        await query.answer()
        try:
            await query.edit_message_text(tc(chat_id, "panel_closed"))
        except Exception:
            logger.exception("non-fatal operation failed")
        return

    if section == "main":
        await query.answer()
        try:
            await query.edit_message_text(tc(chat_id, "ai_panel_header"), reply_markup=_main_menu_kb(chat_id, owner_id))
        except Exception:
            logger.exception("non-fatal operation failed")
        return

    if section in ("analyze", "explain", "rule"):
        await query.answer()
        guide_key = {"analyze": "ai_guide_analyze", "explain": "ai_guide_explain", "rule": "ai_guide_rule"}[section]
        try:
            await query.edit_message_text(tc(chat_id, guide_key), reply_markup=_back_kb(chat_id, owner_id))
        except Exception:
            logger.exception("non-fatal operation failed")
        return

    if section not in ("health", "reports", "optimize", "incident"):
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return

    await query.answer(tc(chat_id, "ai_working"))
    runner = {
        "health": _run_group_health, "reports": _run_analyze_reports,
        "optimize": _run_optimize_rules, "incident": _run_incident_analysis,
    }[section]
    text = await runner(chat_id, clicker_id)
    try:
        await query.edit_message_text(text, reply_markup=_back_kb(chat_id, owner_id))
    except Exception:
        logger.exception("non-fatal operation failed")


# ==================== Shared feature runners (panel + direct commands) ====================

async def _run_group_health(chat_id: int, actor_id: int) -> str:
    now = time.time()
    window = 7 * 24 * 3600
    since, prev_since = now - window, now - 2 * window
    current_total = db.count_audit_actions(chat_id, since)
    since_prev_total = db.count_audit_actions(chat_id, prev_since)
    previous_total = max(0, since_prev_total - current_total)
    trend_pct = round(((current_total - previous_total) / previous_total) * 100) if previous_total > 0 else 0
    stats = {
        "deleted": db.count_audit_actions(chat_id, since, "%delete%"),
        "warns": db.count_audit_actions(chat_id, since, "warn"),
        "bans": db.count_audit_actions(chat_id, since, "%ban%"),
        "open_reports": len(db.list_open_reports(chat_id, limit=100)),
        "security_alerts": len(db.list_recent_alerts(chat_id, limit=50)),
        "trend_pct": trend_pct,
    }
    result = await service.group_health(chat_id, actor_id, stats=stats)
    if not result.ok:
        return _error_text(chat_id, result)
    return fmt.format_group_health(chat_id, result.data)


async def _run_analyze_reports(chat_id: int, actor_id: int) -> str:
    rows = db.list_open_reports(chat_id, limit=15)
    if not rows:
        return tc(chat_id, "ai_reports_empty_for_ai")
    reports = [{"id": r[0], "reporter": r[1], "target": r[2], "reason": r[3] or ""} for r in rows]
    result = await service.analyze_reports(chat_id, actor_id, reports=reports)
    if not result.ok:
        return _error_text(chat_id, result)
    return fmt.format_analyze_reports(chat_id, result.data)


async def _run_optimize_rules(chat_id: int, actor_id: int) -> str:
    rows = db.get_auto_action_rules(chat_id)
    if not rows:
        return tc(chat_id, "ai_optimize_empty")
    since = time.time() - 30 * 24 * 3600
    rules = []
    for rid, ctype, cvalue, atype, avalue in rows:
        fired = db.ai_count_autoaction_firings(chat_id, rid, since)
        rules.append({
            "id": rid, "condition_type": ctype, "condition_value": cvalue,
            "action_type": atype, "action_value": avalue, "fired_recently": fired,
        })
    result = await service.optimize_rules(chat_id, actor_id, rules=rules)
    if not result.ok:
        return _error_text(chat_id, result)
    return fmt.format_rule_optimization(chat_id, result.data)


async def _run_incident_analysis(chat_id: int, actor_id: int) -> str:
    audit_rows = db.get_recent_audit(chat_id, limit=50)
    alert_rows = db.list_recent_alerts(chat_id, limit=20)
    if not audit_rows and not alert_rows:
        return tc(chat_id, "ai_incident_empty")
    audit_lines = [
        f"[{datetime.fromtimestamp(ts).strftime('%m-%d %H:%M')}] {actor}: {action} → {target} ({reason or '-'})"
        for actor, action, target, reason, ts in audit_rows
    ]
    alert_lines = [
        f"[{datetime.fromtimestamp(ts).strftime('%m-%d %H:%M')}] {atype}: {text}"
        for atype, text, ts in alert_rows
    ]
    result = await service.analyze_incident(chat_id, actor_id, audit_lines=audit_lines, alert_lines=alert_lines)
    if not result.ok:
        return _error_text(chat_id, result)
    return fmt.format_incident_analysis(chat_id, result.data)


# ==================== Feature 1: Analyze Message ====================

def _analyze_quick_kb(chat_id: int, target_id: int, message_id: int) -> InlineKeyboardMarkup:
    lang = get_lang(chat_id)
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(t(lang, "ai_btn_apply_delwarn"), callback_data=f"aiact:delwarn:{chat_id}:{target_id}:{message_id}"),
            InlineKeyboardButton(t(lang, "ai_btn_apply_mute"), callback_data=f"aiact:mute:{chat_id}:{target_id}:{message_id}"),
        ],
        [
            InlineKeyboardButton(t(lang, "ai_btn_apply_ban"), callback_data=f"aiact:ban:{chat_id}:{target_id}:{message_id}"),
            InlineKeyboardButton(t(lang, "ai_btn_dismiss"), callback_data=f"aiact:dismiss:{chat_id}:{target_id}:{message_id}"),
        ],
    ])


async def aicheck_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _gate(update, context):
        return
    chat_id = update.effective_chat.id
    reply = update.message.reply_to_message
    if not reply:
        await update.message.reply_text(tc(chat_id, "ai_need_reply"))
        return

    text = reply.text or reply.caption or ""
    is_forward = bool(getattr(reply, "forward_origin", None) or getattr(reply, "forward_from", None)
                       or getattr(reply, "forward_from_chat", None))
    has_link = bool(_LINK_RE.search(text))
    sender = reply.from_user
    warn_count = db.get_warns(chat_id, sender.id) if sender else 0

    actor = update.effective_user
    result = await service.analyze_message(
        chat_id, actor.id, message_text=text, is_forward=is_forward, has_link=has_link,
        sender_warn_count=warn_count, sender_is_new=False,
    )
    if not result.ok:
        await update.message.reply_text(_error_text(chat_id, result))
        return

    out_text = fmt.format_analyze_message(chat_id, result.data)
    kb = _analyze_quick_kb(chat_id, sender.id, reply.message_id) if sender else None
    await update.message.reply_text(_append_ad(chat_id, out_text), reply_markup=kb)
    await log_action(
        context, chat_id, f"NEXOR Copilot: Analyze Message → {sender.first_name if sender else '-'}",
        actor.id, actor.first_name, "ai_analyze_message", sender.id if sender else None,
        sender.first_name if sender else None, result.data.get("risk"),
    )


async def ai_action_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    اجرای واقعی Recommendation فقط بعد از کلیک صریح ادمین، با re-validation
    کامل (دقیقاً مثل handlers/moderation.py:modact_callback) — AI Copilot
    هیچ Authorization مستقلی ندارد.
    """
    query = update.callback_query
    chat_id = update.effective_chat.id
    try:
        _, action, chat_id_s, target_id_s, message_id_s = query.data.split(":")
        cb_chat_id, target_id, message_id = int(chat_id_s), int(target_id_s), int(message_id_s)
    except ValueError:
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return
    if cb_chat_id != chat_id:
        await query.answer(tc(chat_id, "modact_wrong_chat"), show_alert=True)
        return

    clicker = query.from_user
    target_name = db.get_cached_name(target_id)

    if action == "dismiss":
        ok, err = await authorize_action(context, chat_id, clicker.id, "ai_copilot", None, RANK_MODERATOR)
        if not ok:
            await query.answer(err, show_alert=True)
            return
        await query.answer(tc(chat_id, "modact_done"))
        try:
            await query.edit_message_text(tc(chat_id, "ai_dismissed"))
        except Exception:
            logger.exception("non-fatal operation failed")
        return

    capability = "ban" if action == "ban" else ("mute" if action == "mute" else "delete")
    min_rank = RANK_ADMIN if action == "ban" else RANK_MODERATOR
    ok, err = await authorize_action(context, chat_id, clicker.id, capability, target_id, min_rank)
    if not ok:
        await query.answer(err, show_alert=True)
        return

    try:
        if action == "delwarn":
            try:
                await context.bot.delete_message(chat_id, message_id)
            except Exception:
                logger.exception("non-fatal operation failed")
            from handlers.moderation import _do_warn  # جلوگیری از Import حلقوی
            await _do_warn(context, chat_id, target_id, target_name, tc(chat_id, "ai_reason_copilot"),
                            clicker.id, clicker.first_name)
            result_text = tc(chat_id, "ai_action_done_delwarn", name=target_name)
        elif action == "mute":
            until = datetime.now() + timedelta(minutes=DEFAULT_WARN_MUTE_MINUTES)
            await context.bot.restrict_chat_member(
                chat_id, target_id, permissions=ChatPermissions(can_send_messages=False), until_date=until
            )
            result_text = tc(chat_id, "modact_mute_result", name=target_name, minutes=DEFAULT_WARN_MUTE_MINUTES)
        elif action == "ban":
            await context.bot.ban_chat_member(chat_id, target_id)
            result_text = tc(chat_id, "modact_ban_result", name=target_name)
        else:
            await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
            return
    except Exception:
        logger.exception("ai_action_callback failed for chat %s action %s", chat_id, action)
        await query.answer(tc(chat_id, "ai_err_action_failed"), show_alert=True)
        return

    await query.answer(tc(chat_id, "modact_done"))
    try:
        await query.edit_message_text(result_text)
    except Exception:
        logger.exception("non-fatal operation failed")
    await log_action(context, chat_id, result_text, clicker.id, clicker.first_name,
                      f"ai_quick_{action}", target_id, target_name, "NEXOR Copilot")


# ==================== Feature 2: Explain Moderation Action ====================

async def aiexplain_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _gate(update, context):
        return
    chat_id = update.effective_chat.id
    target_id, name, rest = await resolve_target(update, context)
    if not target_id:
        await update.message.reply_text(tc(chat_id, "ai_explain_usage"))
        return

    question = " ".join(rest).strip() or tc(chat_id, "ai_explain_default_question", name=name)
    warn_count = db.get_warns(chat_id, target_id)
    audit_rows = db.get_audit_for_target(chat_id, target_id, limit=8)
    recent_actions = [f"{action} ({reason or '-'})" for _actor, action, reason, _ts in audit_rows]

    active_rule = None
    for _rid, _ctype, cvalue, atype, _avalue in db.get_auto_action_rules(chat_id, "warns_gte"):
        if cvalue.isdigit() and warn_count >= int(cvalue):
            active_rule = f"warns_gte:{cvalue} → {atype}"
            break

    actor = update.effective_user
    result = await service.explain_action(
        chat_id, actor.id, target_name=name, warn_count=warn_count,
        recent_actions=recent_actions, active_rule=active_rule, question=question,
    )
    if not result.ok:
        await update.message.reply_text(_error_text(chat_id, result))
        return
    await update.message.reply_text(_append_ad(chat_id, fmt.format_explain_action(chat_id, result.data)))


# ==================== Feature 3/4/6/7: direct command wrappers ====================

async def aireports_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _gate(update, context):
        return
    chat_id = update.effective_chat.id
    await update.message.reply_text(_append_ad(chat_id, await _run_analyze_reports(chat_id, update.effective_user.id)))


async def aihealth_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _gate(update, context):
        return
    chat_id = update.effective_chat.id
    await update.message.reply_text(_append_ad(chat_id, await _run_group_health(chat_id, update.effective_user.id)))


async def aioptimize_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _gate(update, context):
        return
    chat_id = update.effective_chat.id
    await update.message.reply_text(_append_ad(chat_id, await _run_optimize_rules(chat_id, update.effective_user.id)))


async def aiincident_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _gate(update, context):
        return
    chat_id = update.effective_chat.id
    await update.message.reply_text(_append_ad(chat_id, await _run_incident_analysis(chat_id, update.effective_user.id)))


# ==================== Feature 5: Rule Advisor (نیازمند تأیید صریح ادمین) ====================

async def airule_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _gate(update, context):
        return
    chat_id = update.effective_chat.id
    description = " ".join(context.args or []).strip()
    if not description:
        await update.message.reply_text(tc(chat_id, "ai_rule_usage"))
        return

    actor = update.effective_user
    result = await service.suggest_rule(chat_id, actor.id, admin_description=description)
    if not result.ok:
        await update.message.reply_text(_error_text(chat_id, result))
        return

    data = result.data
    out_text = fmt.format_rule_advisor(chat_id, data)
    if not data.get("is_valid"):
        await update.message.reply_text(out_text + "\n\n" + tc(chat_id, "ai_rule_not_applicable"))
        return

    context.chat_data[_PENDING_RULE_KEY] = {
        "condition_type": data["condition_type"], "condition_value": data["condition_value"],
        "action_type": data["action_type"], "action_value": data["action_value"],
    }
    lang = get_lang(chat_id)
    kb = InlineKeyboardMarkup([[
        InlineKeyboardButton(t(lang, "ai_btn_confirm"), callback_data=f"airule:{actor.id}:confirm"),
        InlineKeyboardButton(t(lang, "ai_btn_cancel"), callback_data=f"airule:{actor.id}:cancel"),
    ]])
    await update.message.reply_text(out_text, reply_markup=kb)


async def airule_confirm_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = update.effective_chat.id
    try:
        _, owner_id_s, decision = query.data.split(":")
        owner_id = int(owner_id_s)
    except ValueError:
        await query.answer(tc(chat_id, "modact_invalid_data"), show_alert=True)
        return

    clicker = query.from_user
    if clicker.id != owner_id:
        await query.answer(tc(chat_id, "panel_not_yours"), show_alert=True)
        return

    # ساخت Rule یک تغییر Configuration سطح گروه است — دقیقاً مثل /addautoaction
    # (که admin_only است)، نه فقط دیدن یک Recommendation؛ پس اینجا Rank Admin لازم است.
    clicker_rank = await get_rank(context, chat_id, clicker.id)
    if clicker_rank < RANK_ADMIN:
        await query.answer(tc(chat_id, "err_need_rank", rank=tc(chat_id, "rank_admin")), show_alert=True)
        return

    pending = context.chat_data.get(_PENDING_RULE_KEY)
    context.chat_data.pop(_PENDING_RULE_KEY, None)

    if decision != "confirm" or not pending:
        await query.answer()
        try:
            await query.edit_message_text(tc(chat_id, "ai_rule_cancelled"))
        except Exception:
            logger.exception("non-fatal operation failed")
        return

    rule_id = db.add_auto_action_rule(
        chat_id, pending["condition_type"], pending["condition_value"],
        pending["action_type"], pending["action_value"],
    )
    action_desc = (f'{pending["action_type"]}:{pending["action_value"]}'
                   if pending["action_value"] else pending["action_type"])
    text = tc(chat_id, "ai_rule_created", id=rule_id,
              condition=f'{pending["condition_type"]}:{pending["condition_value"]}', action=action_desc)

    await query.answer(tc(chat_id, "modact_done"))
    try:
        await query.edit_message_text(text)
    except Exception:
        logger.exception("non-fatal operation failed")
    await log_action(context, chat_id, text, clicker.id, clicker.first_name,
                      "ai_rule_created", None, None, "NEXOR Copilot Rule Advisor")


# ==================== Plan management (Placeholder تا اتصال به Billing واقعی) ====================

async def aiplan_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    if not context.args:
        current = ai_plans.get_chat_plan(chat_id)
        await update.message.reply_text(tc(chat_id, "ai_plan_status", plan=current))
        return
    if not await require_rank(update, context, RANK_OWNER):
        return
    new_plan = context.args[0].strip().lower()
    if ai_plans.set_chat_plan(chat_id, new_plan):
        await update.message.reply_text(tc(chat_id, "ai_plan_set_done", plan=new_plan))
    else:
        await update.message.reply_text(tc(chat_id, "ai_plan_set_invalid"))
