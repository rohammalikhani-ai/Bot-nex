"""Central handler registration.

Feature modules own their callbacks; this module owns Telegram wiring only.
Keeping registration here prevents main.py from becoming a feature/configuration
God-file while preserving the existing handler order and groups.
"""
from telegram.ext import (
    CallbackQueryHandler, CommandHandler, MessageHandler, ChatMemberHandler,
    PreCheckoutQueryHandler, filters,
)

from handlers import (
    basic, moderation, locks_filters, captcha, notes, channel, logs, federation,
    errors, roles, security, rules, keywords, custom_commands, auto_actions,
    profiles, reports, alerts, settings_io, text_commands, admin_panel, ai_copilot, guide,
    auto_answer, natural_language, onboarding, payments, ads, daily_notify,
)
from handlers.common import cache_user_from_update


def _commands(app, module, mapping):
    for command, callback in mapping.items():
        app.add_handler(CommandHandler(command, callback))


def register_commands(app):
    _commands(app, basic, {
        "start": basic.start_cmd, "settings": basic.settings_cmd,
    })
    _commands(app, guide, {"help": guide.guide_cmd})
    _commands(app, moderation, {
        "warn": moderation.warn_cmd, "unwarn": moderation.unwarn_cmd,
        "warns": moderation.warns_cmd, "setwarnaction": moderation.setwarnaction_cmd,
        "setmaxwarns": moderation.setmaxwarns_cmd, "mute": moderation.mute_cmd,
        "unmute": moderation.unmute_cmd, "ban": moderation.ban_cmd,
        "unban": moderation.unban_cmd, "kick": moderation.kick_cmd,
        "del": moderation.del_cmd, "purge": moderation.purge_cmd,
    })
    _commands(app, roles, {
        "promote": roles.promote_cmd, "demote": roles.demote_cmd,
        "roles": roles.roles_cmd, "logs": roles.logs_cmd, "setlang": roles.setlang_cmd,
    })
    _commands(app, locks_filters, {
        "lock": locks_filters.lock_cmd, "unlock": locks_filters.unlock_cmd,
        "locks": locks_filters.locks_cmd, "filter": locks_filters.filter_cmd,
        "stopfilter": locks_filters.stopfilter_cmd, "filters": locks_filters.filters_cmd,
        "setfilteraction": locks_filters.setfilteraction_cmd,
        "allowword": locks_filters.allowword_cmd, "disallowword": locks_filters.disallowword_cmd,
        "blockdomain": locks_filters.blockdomain_cmd, "unblockdomain": locks_filters.unblockdomain_cmd,
        "allowdomain": locks_filters.allowdomain_cmd, "unallowdomain": locks_filters.unallowdomain_cmd,
        "domains": locks_filters.domains_cmd, "allowforward": locks_filters.allowforward_cmd,
        "blockforward": locks_filters.blockforward_cmd, "unruleforward": locks_filters.unruleforward_cmd,
        "forwardrules": locks_filters.forwardrules_cmd,
        "mentionprotection": locks_filters.mentionprotection_cmd,
        "setmentionlimit": locks_filters.setmentionlimit_cmd,
        "setmentionaction": locks_filters.setmentionaction_cmd,
        "antispam": locks_filters.antispam_cmd, "setspamaction": locks_filters.setspamaction_cmd,
        "dupcross": locks_filters.dupcross_cmd, "setdupcross": locks_filters.setdupcross_cmd,
        "setflood": locks_filters.setflood_cmd, "setfloodaction": locks_filters.setfloodaction_cmd,
    })
    _commands(app, security, {
        "antiraid": security.antiraid_cmd, "setraidthreshold": security.setraidthreshold_cmd,
        "lockdown": security.lockdown_cmd, "unlockchat": security.unlock_cmd,
    })
    _commands(app, captcha, {
        "captcha": captcha.captcha_toggle_cmd,
        "setwelcomedelete": captcha.setwelcomedelete_cmd,
        "setgoodbye": captcha.setgoodbye_cmd, "resetgoodbye": captcha.resetgoodbye_cmd,
        "goodbye": captcha.goodbye_toggle_cmd,
    })
    _commands(app, rules, {
        "rules": rules.rules_cmd, "setrules": rules.setrules_cmd, "clearrules": rules.clearrules_cmd,
    })
    _commands(app, keywords, {
        "addkeyword": keywords.addkeyword_cmd, "delkeyword": keywords.delkeyword_cmd,
        "keywords": keywords.keywords_list_cmd,
    })
    _commands(app, custom_commands, {
        "addcmd": custom_commands.addcmd_cmd, "delcmd": custom_commands.delcmd_cmd,
        "cmds": custom_commands.cmds_list_cmd,
    })
    _commands(app, auto_answer, {
        "setanswer": auto_answer.setanswer_cmd, "answerlist": auto_answer.answerlist_cmd,
        "cleananswerlist": auto_answer.cleananswerlist_cmd, "delanswer": auto_answer.delanswer_cmd,
    })
    _commands(app, channel, {
        "schedulerecurring": channel.schedulerecurring_cmd,
        "recurringposts": channel.recurringposts_cmd, "delrecurring": channel.delrecurring_cmd,
        "setchannel": channel.setchannel_cmd, "post": channel.post_cmd,
        "schedulepost": channel.schedulepost_cmd, "editpost": channel.editpost_cmd,
        "delpost": channel.delpost_cmd, "channelstats": channel.channelstats_cmd,
    })
    _commands(app, auto_actions, {
        "addautoaction": auto_actions.addautoaction_cmd,
        "delautoaction": auto_actions.delautoaction_cmd,
        "autoactions": auto_actions.autoactions_list_cmd,
        "autoactiontoggle": auto_actions.autoactiontoggle_cmd,
    })
    _commands(app, profiles, {
        "createprofile": profiles.createprofile_cmd, "delprofile": profiles.delprofile_cmd,
        "profiles": profiles.profiles_cmd, "assignprofile": profiles.assignprofile_cmd,
        "unassignprofile": profiles.unassignprofile_cmd, "myperms": profiles.myperms_cmd,
    })
    _commands(app, reports, {"report": reports.report_cmd, "reports": reports.reports_cmd})
    _commands(app, alerts, {
        "setalertchannel": alerts.setalertchannel_cmd, "alerts": alerts.alerts_cmd,
        "adminabuseprotection": alerts.adminabuseprotection_cmd,
    })
    _commands(app, settings_io, {
        "exportsettings": settings_io.exportsettings_cmd,
        "importsettings": settings_io.importsettings_cmd,
    })
    _commands(app, notes, {
        "save": notes.save_note_cmd, "get": notes.get_note_cmd,
        "notes": notes.notes_list_cmd, "clear": notes.clear_note_cmd,
    })
    _commands(app, logs, {"setlogchannel": logs.setlogchannel_cmd})
    _commands(app, federation, {
        "fnew": federation.fnew_cmd, "fjoin": federation.fjoin_cmd,
        "fleave": federation.fleave_cmd, "finfo": federation.finfo_cmd,
        "fban": federation.fban_cmd, "funban": federation.funban_cmd,
    })
    _commands(app, admin_panel, {"adminpanel": admin_panel.admin_panel_cmd})
    _commands(app, ai_copilot, {
        "copilot": ai_copilot.copilot_cmd, "aicheck": ai_copilot.aicheck_cmd,
        "aiexplain": ai_copilot.aiexplain_cmd, "aireports": ai_copilot.aireports_cmd,
        "aihealth": ai_copilot.aihealth_cmd, "airule": ai_copilot.airule_cmd,
        "aioptimize": ai_copilot.aioptimize_cmd, "aiincident": ai_copilot.aiincident_cmd,
        "aiplan": ai_copilot.aiplan_cmd,
    })
    _commands(app, payments, {"buyplan": payments.buyplan_cmd})
    _commands(app, ads, {
        "ads": ads.ads_cmd, "myads": ads.myads_cmd, "adadmin": ads.adadmin_cmd,
        "adstats": ads.adstats_cmd,
    })
    _commands(app, daily_notify, {
        "dailynotify": daily_notify.dailynotify_cmd,
        "setpricetime": daily_notify.setpricetime_cmd,
        "setnewstime": daily_notify.setnewstime_cmd,
        "setdailytz": daily_notify.setdailytz_cmd,
        "testdailyprice": daily_notify.testdailyprice_cmd,
        "testdailynews": daily_notify.testdailynews_cmd,
        "dailyassets": daily_notify.dailyassets_cmd,
    })


def register_callbacks(app):
    app.add_handler(CallbackQueryHandler(moderation.modact_callback, pattern=r"^modact:"))
    app.add_handler(CallbackQueryHandler(roles.setlang_callback, pattern=r"^setlang:"))
    app.add_handler(CallbackQueryHandler(basic.start_lang_callback, pattern=r"^startlang:"))
    app.add_handler(CallbackQueryHandler(security.unlock_callback, pattern=r"^raidunlock$"))
    app.add_handler(CallbackQueryHandler(captcha.captcha_callback, pattern=r"^captcha:"))
    app.add_handler(CallbackQueryHandler(reports.report_callback, pattern=r"^report:"))
    app.add_handler(CallbackQueryHandler(settings_io.importsettings_callback, pattern=r"^impsettings:"))
    app.add_handler(CallbackQueryHandler(admin_panel.panel_callback, pattern=r"^panel:"))
    app.add_handler(CallbackQueryHandler(daily_notify.daily_notify_callback, pattern=r"^dn:"))
    app.add_handler(CallbackQueryHandler(guide.guide_callback, pattern=r"^guide:"))
    app.add_handler(CallbackQueryHandler(ai_copilot.copilot_callback, pattern=r"^copilot:"))
    app.add_handler(CallbackQueryHandler(ai_copilot.ai_action_callback, pattern=r"^aiact:"))
    app.add_handler(CallbackQueryHandler(ai_copilot.airule_confirm_callback, pattern=r"^airule:"))
    app.add_handler(CallbackQueryHandler(auto_answer.audience_callback, pattern=r"^aa:aud:"))
    app.add_handler(CallbackQueryHandler(auto_answer.done_callback, pattern=r"^aa:done$"))
    app.add_handler(CallbackQueryHandler(auto_answer.cancel_callback, pattern=r"^aa:cancel$"))
    app.add_handler(CallbackQueryHandler(natural_language.natural_language_confirm_callback, pattern=r"^nlu:[cx]:"))
    app.add_handler(CallbackQueryHandler(onboarding.onboarding_help_callback, pattern=r"^onboarding:help$"))
    app.add_handler(ChatMemberHandler(onboarding.bot_added_to_group, ChatMemberHandler.MY_CHAT_MEMBER))
    app.add_handler(CallbackQueryHandler(payments.buyplan_callback, pattern=r"^buyplan:"))
    # ⭐ Stars: pre_checkout باید جواب بده وگرنه تلگرام پرداخت رو رد می‌کنه؛
    # successful_payment بعد از پرداخت واقعی میاد (فقط در PV کاربر، چون
    # send_invoice همیشه به user_id، نه به گروه، فرستاده می‌شه).
    app.add_handler(PreCheckoutQueryHandler(payments.stars_precheckout_callback))
    app.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, payments.stars_successful_payment_callback))
    # 📢 Ads: ویزارد خرید/ثبت تبلیغ + صف بررسی ادمین. ConversationHandler باید
    # زودتر از هر MessageHandler عمومی متن ثبت بشه تا مراحل بنر/متن رو بگیره.
    app.add_handler(ads.ads_conversation)
    app.add_handler(CallbackQueryHandler(ads.adadmin_review_callback, pattern=r"^adrev:"))


def register_message_pipelines(app):
    # These groups intentionally preserve the original processing order.
    app.add_handler(MessageHandler(filters.ALL & filters.ChatType.GROUPS, cache_user_from_update), group=-1)
    app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, captcha.greet_new_members), group=10)
    app.add_handler(MessageHandler(filters.StatusUpdate.LEFT_CHAT_MEMBER, captcha.farewell_member))
    app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, federation.check_federation_ban_on_join), group=11)
    app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, security.check_raid_on_join), group=12)
    app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, locks_filters.on_new_members), group=13)
    app.add_handler(MessageHandler(text_commands.text_trigger_filter, text_commands.text_command_dispatcher), group=15)
    # لایه‌ی Natural Language واقعی (intent-based) — بعد از Alias دقیق (15)،
    # قبل از notes/keywords/auto_answer، تا هیچ‌کدوم duplicate پاسخ ندن.
    app.add_handler(MessageHandler(natural_language.natural_language_filter, natural_language.natural_language_dispatcher), group=16)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, notes.hashtag_note_trigger), group=20)
    app.add_handler(MessageHandler(filters.ALL & ~filters.COMMAND, locks_filters.moderate_message), group=21)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, keywords.keyword_trigger_handler), group=22)
    app.add_handler(MessageHandler(filters.ALL & ~filters.COMMAND, auto_actions.evaluate_message_rules), group=23)
    app.add_handler(MessageHandler(auto_answer.group_text_filter, auto_answer.auto_answer_trigger_handler), group=24)
    app.add_handler(MessageHandler(auto_answer.private_content_filter, auto_answer.private_content_handler), group=25)
    app.add_handler(MessageHandler(filters.COMMAND, custom_commands.dispatch_custom_command), group=30)


def register_lifecycle(app):
    app.add_error_handler(errors.error_handler)


def register_all(app):
    register_commands(app)
    register_callbacks(app)
    register_message_pipelines(app)
    register_lifecycle(app)
