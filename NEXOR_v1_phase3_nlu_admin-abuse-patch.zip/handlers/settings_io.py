# -*- coding: utf-8 -*-
"""
Priority 5, Item 28 — Import / Export Settings

/exportsettings تمام تنظیمات قابل‌انتقال گروه (settings کلید-مقدار، قفل‌ها،
فیلترها، دامنه‌ها، قوانین Forward، Rules، Keyword Triggerها، Custom Commandها،
Auto Action Ruleها، Permission Profileها و Assignmentهای آن‌ها) را به یک فایل JSON تبدیل و ارسال
می‌کند. /importsettings همان فایل را (برای همین گروه یا گروه دیگر) با
Validation کامل روی نسخه و ساختار داده می‌خواند، خلاصه‌ای برای تأیید نشان
می‌دهد، و فقط بعد از تأیید صریح (با دوباره‌چک‌شدن Rank روی سرور) اعمال می‌کند.

نکته امنیتی: Import تنظیمات فعلی گروه را کامل جایگزین می‌کند (نه Merge)، پس
فقط Owner به آن دسترسی دارد و همیشه با یک مرحله‌ی تأیید صریح انجام می‌شود.
جدول‌های تاریخچه‌ای (warns/audit_log/reports/...) هرگز پاک یا Import نمی‌شوند؛ Assignmentهای Profile بخشی از تنظیمات قابل انتقال‌اند.
"""
import json
import logging
from io import BytesIO

from telegram import Update, InputFile, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc, t, get_lang
from config import (
    SETTINGS_EXPORT_VERSION, VALID_LOCKS, RESERVED_COMMAND_NAMES, RANK_OWNER,
    AUTO_ACTION_CONDITION_TYPES, AUTO_ACTION_TYPES, CAPABILITIES,
)
from handlers.common import admin_only, require_rank, get_rank, log_action

_PENDING_KEY = "pending_import"


logger = logging.getLogger(__name__)

def _build_export_payload(chat_id: int) -> dict:
    return {
        "version": SETTINGS_EXPORT_VERSION,
        "settings": db.all_settings(chat_id),
        "locks": sorted(db.get_locks(chat_id)),
        "word_filters": sorted(db.get_filters(chat_id)),
        "filters_whitelist": db.get_filter_whitelist(chat_id),
        "domains": {
            "blacklist": db.get_domains(chat_id, "blacklist"),
            "whitelist": db.get_domains(chat_id, "whitelist"),
        },
        "forward_rules": [
            {"source_key": k, "source_label": l, "mode": m}
            for k, l, m in db.list_forward_rules(chat_id)
        ],
        "chat_rules": [{"lang": lang, "text": text} for lang, text in db.get_all_chat_rules(chat_id)],
        "keyword_triggers": [{"keyword": k, "response": r} for k, r in db.list_keyword_triggers(chat_id)],
        "custom_commands": [{"name": n, "response": r} for n, r in db.list_custom_commands(chat_id)],
        "auto_action_rules": [
            {"condition_type": ct, "condition_value": cv, "action_type": at, "action_value": av}
            for _id, ct, cv, at, av in db.get_auto_action_rules(chat_id)
        ],
        "permission_profiles": [
            {"name": n, "capabilities": c} for n, c in db.list_permission_profiles(chat_id)
        ],
        "profile_assignments": [
            {"user_id": int(user_id), "profile": profile}
            for user_id, profile in db.list_profile_assignments(chat_id)
        ],
    }


def _validate_payload(data):
    """Validate imported configuration before touching the database."""
    if not isinstance(data, dict):
        return False, "structure"
    if data.get("version") != SETTINGS_EXPORT_VERSION:
        return False, "version"
    # Hard upper bounds prevent accidental/hostile oversized imports.
    list_limits = {
        "locks": 50, "word_filters": 2000, "filters_whitelist": 2000,
        "forward_rules": 500, "chat_rules": 20, "keyword_triggers": 2000,
        "custom_commands": 500, "auto_action_rules": 500,
        "permission_profiles": 100, "profile_assignments": 5000,
    }
    for key, limit in list_limits.items():
        value = data.get(key, [])
        if not isinstance(value, list) or len(value) > limit:
            return False, f"{key}_limit"
    settings = data.get("settings", {})
    if not isinstance(settings, dict) or len(settings) > 500:
        return False, "settings"
    if any(len(str(k)) > 200 or len(str(v)) > 10000 for k, v in settings.items()):
        return False, "settings_size"
    if not isinstance(data.get("locks", []), list) or any(l not in VALID_LOCKS for l in data.get("locks", [])):
        return False, "locks"
    if not isinstance(data.get("word_filters", []), list):
        return False, "word_filters"
    if not isinstance(data.get("filters_whitelist", []), list):
        return False, "filters_whitelist"
    domains = data.get("domains", {})
    if (not isinstance(domains, dict) or not isinstance(domains.get("blacklist", []), list)
            or not isinstance(domains.get("whitelist", []), list)):
        return False, "domains"
    if len(domains.get("blacklist", [])) > 2000 or len(domains.get("whitelist", [])) > 2000:
        return False, "domains_limit"
    for r in data.get("forward_rules", []):
        if not isinstance(r, dict) or r.get("mode") not in ("allow", "block") or "source_key" not in r:
            return False, "forward_rules"
    for r in data.get("chat_rules", []):
        if not isinstance(r, dict) or "lang" not in r or "text" not in r:
            return False, "chat_rules"
    for r in data.get("keyword_triggers", []):
        if not isinstance(r, dict) or "keyword" not in r or "response" not in r:
            return False, "keyword_triggers"
    for r in data.get("custom_commands", []):
        if not isinstance(r, dict) or "name" not in r or "response" not in r:
            return False, "custom_commands"
        if str(r["name"]).lower().lstrip("/") in RESERVED_COMMAND_NAMES:
            return False, "custom_commands_reserved"
    for r in data.get("auto_action_rules", []):
        if (not isinstance(r, dict) or r.get("condition_type") not in AUTO_ACTION_CONDITION_TYPES
                or r.get("action_type") not in AUTO_ACTION_TYPES):
            return False, "auto_action_rules"
    for r in data.get("permission_profiles", []):
        if not isinstance(r, dict) or "name" not in r or "capabilities" not in r:
            return False, "permission_profiles"
        caps = {c for c in str(r["capabilities"]).split(",") if c}
        if caps - CAPABILITIES:
            return False, "permission_profiles"
    for item in data.get("profile_assignments", []):
        if not isinstance(item, dict) or not isinstance(item.get("user_id"), int) or item["user_id"] <= 0:
            return False, "profile_assignments"
        if not isinstance(item.get("profile"), str) or len(item["profile"]) > 100:
            return False, "profile_assignments"
    return True, None


def _apply_import(chat_id: int, data: dict):
    db.replace_chat_config(chat_id, data)


def _summarize(data: dict) -> str:
    parts = [
        f"settings:{len(data.get('settings', {}))}",
        f"locks:{len(data.get('locks', []))}",
        f"word_filters:{len(data.get('word_filters', []))}",
        f"domains:{len(data.get('domains', {}).get('blacklist', [])) + len(data.get('domains', {}).get('whitelist', []))}",
        f"forward_rules:{len(data.get('forward_rules', []))}",
        f"chat_rules:{len(data.get('chat_rules', []))}",
        f"keywords:{len(data.get('keyword_triggers', []))}",
        f"commands:{len(data.get('custom_commands', []))}",
        f"auto_actions:{len(data.get('auto_action_rules', []))}",
        f"profiles:{len(data.get('permission_profiles', []))}",
        f"assignments:{len(data.get('profile_assignments', []))}",
    ]
    return ", ".join(parts)


async def exportsettings_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    payload = _build_export_payload(chat_id)
    raw = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
    bio = BytesIO(raw)
    filename = f"settings_{chat_id}.json"
    await update.message.reply_document(
        document=InputFile(bio, filename=filename),
        caption=tc(chat_id, "exportsettings_caption", summary=_summarize(payload)),
    )


async def importsettings_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/importsettings — باید یک فایل .json (ارسالی یا ریپلای‌شده) همراهش باشد. فقط Owner."""
    if not await require_rank(update, context, RANK_OWNER):
        return
    chat_id = update.effective_chat.id
    document = update.message.document
    if not document and update.message.reply_to_message:
        document = update.message.reply_to_message.document
    if not document:
        await update.message.reply_text(tc(chat_id, "importsettings_usage"))
        return

    try:
        tg_file = await context.bot.get_file(document.file_id)
        raw = await tg_file.download_as_bytearray()
        data = json.loads(bytes(raw).decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        await update.message.reply_text(tc(chat_id, "importsettings_invalid_json"))
        return
    except Exception as exc:
        import logging
        logging.getLogger(__name__).exception("failed to download import file for chat %s: %s", chat_id, exc)
        await update.message.reply_text(tc(chat_id, "importsettings_invalid_json"))
        return

    ok, err_code = _validate_payload(data)
    if not ok:
        await update.message.reply_text(tc(chat_id, "importsettings_invalid_schema", detail=err_code))
        return

    context.chat_data[_PENDING_KEY] = data
    lang = get_lang(chat_id)
    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton(t(lang, "btn_import_confirm"), callback_data="impsettings:confirm"),
        InlineKeyboardButton(t(lang, "btn_import_cancel"), callback_data="impsettings:cancel"),
    ]])
    await update.message.reply_text(
        tc(chat_id, "importsettings_confirm_prompt", summary=_summarize(data)), reply_markup=keyboard
    )


async def importsettings_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """تأیید/لغو Import — Rank کلیک‌کننده دوباره از صفر روی سرور چک می‌شود."""
    query = update.callback_query
    chat_id = update.effective_chat.id
    action = query.data.split(":", 1)[1]

    clicker_rank = await get_rank(context, chat_id, query.from_user.id)
    if clicker_rank < RANK_OWNER:
        await query.answer(tc(chat_id, "err_need_rank", rank=tc(chat_id, "rank_owner")), show_alert=True)
        return

    pending = context.chat_data.get(_PENDING_KEY)
    if action == "cancel" or not pending:
        context.chat_data.pop(_PENDING_KEY, None)
        await query.answer()
        try:
            await query.edit_message_text(tc(chat_id, "importsettings_cancelled"))
        except Exception:
            logger.exception("failed to edit import confirmation message in chat %s", chat_id)
        return

    data = pending
    context.chat_data.pop(_PENDING_KEY, None)
    _apply_import(chat_id, data)
    text = tc(chat_id, "importsettings_done", summary=_summarize(data))
    await query.answer(tc(chat_id, "modact_done"))
    try:
        await query.edit_message_text(text)
    except Exception:
        logger.exception("non-fatal operation failed")

    actor = query.from_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "importsettings", None, None, None)
