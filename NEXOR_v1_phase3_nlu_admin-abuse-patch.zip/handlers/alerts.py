# -*- coding: utf-8 -*-
"""
Priority 5, Item 27 — Admin Alerts

قبلاً فقط Raid (در security.py) یک پیام هشدار به گروه می‌فرستاد. این ماژول
سیستم Alert را عمومی می‌کند: هر بخش دیگری از ربات (فعلی یا آینده — مثلاً
Priority 7: Smart Risk Score/Anti-Admin Abuse) می‌تواند با صدا زدن raise_alert
یک هشدار از یکی از انواع زیر صادر کند؛ همه‌ی Alertها هم در admin_alerts دائمی
ذخیره می‌شوند (برای /alerts) و هم فوری به ادمین‌ها اطلاع داده می‌شوند.

مقصد پیام: اگر /setalertchannel تنظیم شده باشد همان‌جا، وگرنه اگر لاگ‌چنل
(setlogchannel) تنظیم شده از همان استفاده می‌شود، وگرنه مستقیم داخل خود گروه.
"""
import logging
import time

from telegram import Update
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc
from handlers.common import admin_only, owner_only, log_action

ALERT_TYPE_MULTI_REPORTS = "multiple_reports"
ALERT_TYPE_SUSPICIOUS = "suspicious_activity"
ALERT_TYPE_SECURITY = "security_event"

logger = logging.getLogger(__name__)
ALERT_TYPE_ABNORMAL = "abnormal_behavior"
# Priority 7 — Anti-Admin Abuse: یک actor (ادمین/مدیر) در بازه‌ی کوتاه اکشن
# مخرب غیرعادی زیاد زده؛ نگاه کن به handlers/common.py::_check_admin_abuse.
ALERT_TYPE_ADMIN_ABUSE = "admin_abuse"

_ALERT_ICONS = {
    ALERT_TYPE_MULTI_REPORTS: "🚩",
    ALERT_TYPE_SUSPICIOUS: "🕵️",
    ALERT_TYPE_SECURITY: "🛡️",
    ALERT_TYPE_ABNORMAL: "⚠️",
    ALERT_TYPE_ADMIN_ABUSE: "🚷",
    "raid": "🚨",
}

_ALERT_LABEL_KEYS = {
    ALERT_TYPE_MULTI_REPORTS: "alert_type_multi_reports",
    ALERT_TYPE_SUSPICIOUS: "alert_type_suspicious",
    ALERT_TYPE_SECURITY: "alert_type_security",
    ALERT_TYPE_ABNORMAL: "alert_type_abnormal",
    ALERT_TYPE_ADMIN_ABUSE: "alert_type_admin_abuse",
    "raid": "alert_type_raid",
}


def _alert_destination(chat_id: int):
    dest = db.get_setting(chat_id, "alert_channel")
    if dest:
        return int(dest)
    log_chat = db.get_setting(chat_id, "log_channel")
    if log_chat:
        return int(log_chat)
    return chat_id


async def notify_admins(context: ContextTypes.DEFAULT_TYPE, chat_id: int, text: str, reply_markup=None):
    """پیام را به مقصد Alert (بالا) می‌فرستد؛ اگر ارسال به مقصد جداگانه شکست خورد، به خود گروه fallback می‌کند."""
    dest = _alert_destination(chat_id)
    try:
        await context.bot.send_message(dest, text, reply_markup=reply_markup)
    except Exception:
        if dest != chat_id:
            try:
                await context.bot.send_message(chat_id, text, reply_markup=reply_markup)
            except Exception:
                logger.exception("failed to send alert fallback to chat %s", chat_id)


async def raise_alert(context: ContextTypes.DEFAULT_TYPE, chat_id: int, alert_type: str, detail_text: str):
    """
    یک Alert جدید صادر می‌کند: هم دائمی ذخیره می‌شود (admin_alerts) هم فوری
    اطلاع‌رسانی می‌شود. سایر ماژول‌ها (Reports، و در آینده Priority 7) این تابع
    را صدا می‌زنند — نیازی به دونستن جزئیات مقصد/فرمت نیست.
    """
    icon = _ALERT_ICONS.get(alert_type, "🔔")
    label = tc(chat_id, _ALERT_LABEL_KEYS.get(alert_type, "alert_type_generic"))
    text = f"{icon} {label}\n{detail_text}"
    db.add_alert(chat_id, alert_type, text, time.time())
    await notify_admins(context, chat_id, text)


async def setalertchannel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/setalertchannel <chat_id> — مقصد اختصاصی Alertها (جدا از لاگ‌چنل)؛ بدون آرگومان = پاک کردن."""
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        db.set_setting(chat_id, "alert_channel", "")
        await update.message.reply_text(tc(chat_id, "setalertchannel_cleared"))
        return
    token = context.args[0]
    if not token.lstrip("-").isdigit():
        await update.message.reply_text(tc(chat_id, "setalertchannel_usage"))
        return
    db.set_setting(chat_id, "alert_channel", token)
    text = tc(chat_id, "setalertchannel_done", channel=token)
    await update.message.reply_text(text)
    actor = update.effective_user
    await log_action(context, chat_id, text, actor.id, actor.first_name, "setalertchannel", None, None, token)


async def adminabuseprotection_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/adminabuseprotection on|off — روشن/خاموش کردن تشخیص Anti-Admin Abuse.

    عمداً فقط Owner (نه admin_only) اجازه‌ی خاموش‌کردنش رو داره: اگر یک ادمین
    معمولی هم می‌تونست خاموشش کنه، خودِ همون ادمینِ سوءاستفاده‌گر می‌تونست قبل
    از رسیدن به آستانه، ناظر رو خاموش کنه — که کل قابلیت رو بی‌فایده می‌کرد."""
    if not await owner_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args or context.args[0].lower() not in ("on", "off"):
        await update.message.reply_text(tc(chat_id, "adminabuseprotection_toggle_usage"))
        return
    state = context.args[0].lower()
    db.set_setting(chat_id, "admin_abuse_protection", state)
    state_label = tc(chat_id, "state_on") if state == "on" else tc(chat_id, "state_off")
    await update.message.reply_text(tc(chat_id, "adminabuseprotection_toggle_done", state=state_label))


async def alerts_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/alerts — تاریخچه‌ی اخیر همه‌ی Alertهای این گروه (Raid، Multiple Reports و غیره)."""
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    rows = db.list_recent_alerts(chat_id, limit=15)
    if not rows:
        await update.message.reply_text(tc(chat_id, "alerts_empty"))
        return
    from datetime import datetime
    lines = [tc(chat_id, "alerts_header")]
    for alert_type, text, ts in rows:
        when = datetime.fromtimestamp(ts).strftime("%m-%d %H:%M")
        first_line = text.split("\n", 1)[0]
        lines.append(f"• [{when}] {first_line}")
    await update.message.reply_text("\n".join(lines))
