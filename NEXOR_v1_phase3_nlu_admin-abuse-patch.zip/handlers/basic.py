# -*- coding: utf-8 -*-
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from repositories import store as db
from i18n import tc, get_lang, set_lang, SUPPORTED_LANGUAGES
from handlers.common import admin_only
from handlers import auto_answer

# دسترسی‌های ادمینی که موقع افزودن به گروه پیش‌فرض پیشنهاد می‌شه
# (کاربر همچنان می‌تونه قبل از تأیید، این‌ها رو دستی تغییر بده)
_ADMIN_RIGHTS_FOR_INVITE = "+".join([
    "change_info", "delete_messages", "restrict_members",
    "invite_users", "pin_messages", "manage_video_chats",
])


# پیام انتخاب زبان قبل از هر چیز دیگه، همیشه به انگلیسی — چون هنوز زبان
# کاربر معلوم نیست و نمی‌شه از i18n استفاده کرد (طبق درخواست صریح کاربر).
_PV_LANG_PROMPT_EN = "🌐 Welcome! Please choose your language:"


def _pv_lang_keyboard() -> InlineKeyboardMarkup:
    buttons = [
        InlineKeyboardButton(label, callback_data=f"startlang:{code}")
        for code, label in SUPPORTED_LANGUAGES.items()
    ]
    rows = [buttons[i:i + 2] for i in range(0, len(buttons), 2)]
    return InlineKeyboardMarkup(rows)


async def _send_start_welcome(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int) -> None:
    """پیام خوش‌آمد واقعی /start، با زبانِ از قبل مشخص‌شده‌ی chat_id."""
    user = update.effective_user
    mention = f"[{user.first_name}](tg://user?id={user.id})"
    text = tc(chat_id, "start_msg", mention=mention)

    bot_username = context.bot.username
    add_to_group_url = (
        f"https://t.me/{bot_username}?startgroup=true&admin={_ADMIN_RIGHTS_FOR_INVITE}"
    )
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(tc(chat_id, "add_to_group_button"), url=add_to_group_url)],
    ])

    await context.bot.send_message(chat_id, text, parse_mode=ParseMode.MARKDOWN, reply_markup=keyboard)


async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Deep Link ورودی از دکمه‌ی "ورود به پیوی" مربوط به Auto-Answer
    # (?start=aa_<chat_id>) — قبل از پیام خوش‌آمد معمولی چک می‌شود، چون این
    # یک جریان مستقل (Wizard) است، نه شروع عادی گفتگو با ربات.
    args = context.args or []
    if args and args[0].startswith("aa_"):
        await auto_answer.start_wizard(update, context, args[0])
        return

    chat = update.effective_chat
    if chat.type == "private":
        # طبق درخواست صریح کاربر: توی PV اول (به انگلیسی) زبان پرسیده می‌شه،
        # بعد با همون زبانِ انتخاب‌شده پیام خوش‌آمد واقعی فرستاده می‌شه.
        await update.message.reply_text(_PV_LANG_PROMPT_EN, reply_markup=_pv_lang_keyboard())
        return

    await _send_start_welcome(update, context, chat.id)


async def start_lang_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """جواب دکمه‌های انتخاب زبان روی پیام /start در PV."""
    query = update.callback_query
    chat_id = update.effective_chat.id
    _, lang_code = query.data.split(":", 1)

    if not set_lang(chat_id, lang_code):
        await query.answer(tc(chat_id, "err_invalid_language"), show_alert=True)
        return

    await query.answer()
    try:
        await query.message.delete()
    except Exception:
        # غیربحرانی: اگه حذف پیام انتخاب زبان به هر دلیلی ممکن نبود
        # (مثلاً پیام خیلی قدیمی شده)، جلوی خوش‌آمدگویی رو نمی‌گیریم.
        pass
    await _send_start_welcome(update, context, chat_id)


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    await update.message.reply_text(tc(chat_id, "help_text"), parse_mode=ParseMode.MARKDOWN)

    # لیست کامل کلمات جایگزین (بدون /) در یک پیام جدا، تا پیام اول به سقف
    # طول پیام تلگرام (۴۰۹۶ کاراکتر) نخوره. اگه زبانی این کلید رو نداشته
    # باشه (مثلاً یک فایل زبان قدیمی که هنوز آپدیت نشده)، فقط بی‌صدا رد می‌شه.
    words_text = tc(chat_id, "help_words_text")
    if words_text and words_text != "help_words_text":
        await update.message.reply_text(words_text, parse_mode=ParseMode.MARKDOWN)


async def settings_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    none_ = tc(chat_id, "none")
    not_set = tc(chat_id, "not_set")
    on_ = tc(chat_id, "state_on")
    off_ = tc(chat_id, "state_off")

    locks = db.get_locks(chat_id)
    filters_ = db.get_filters(chat_id)
    captcha_state = tc(chat_id, "captcha_on") if db.get_setting(chat_id, "captcha_enabled", "off") == "on" else tc(chat_id, "captcha_off")
    channel = db.get_setting(chat_id, "linked_channel", not_set)
    log_channel = db.get_setting(chat_id, "log_channel", not_set)
    max_warns = db.get_setting(chat_id, "max_warns", "3")
    warn_action = db.get_setting(chat_id, "warn_action", "ban")
    lang_label = SUPPORTED_LANGUAGES.get(get_lang(chat_id), get_lang(chat_id))
    antispam_state = on_ if db.get_setting(chat_id, "antispam_enabled", "on") == "on" else off_
    antiraid_state = on_ if db.get_setting(chat_id, "antiraid_enabled", "off") == "on" else off_
    flood_limit = db.get_setting(chat_id, "flood_limit", "5")
    flood_window = db.get_setting(chat_id, "flood_window", "8")
    goodbye_state = on_ if db.get_setting(chat_id, "goodbye_enabled", "on") == "on" else off_
    autoaction_state = on_ if db.get_setting(chat_id, "autoaction_enabled", "on") == "on" else off_

    lines = [
        tc(chat_id, "settings_header"), "",
        tc(chat_id, "settings_locks", locks=", ".join(locks) if locks else none_),
        tc(chat_id, "settings_filters", filters=", ".join(filters_) if filters_ else none_),
        tc(chat_id, "settings_captcha", state=captcha_state),
        tc(chat_id, "settings_goodbye", state=goodbye_state),
        tc(chat_id, "settings_warns", max=max_warns, action=warn_action),
        f"🕵️ Anti-Spam: {antispam_state}",
        f"🚨 Anti-Flood: {flood_limit}/{flood_window}s",
        f"🛡️ Anti-Raid: {antiraid_state}",
        tc(chat_id, "settings_autoaction", state=autoaction_state),
        tc(chat_id, "settings_channel", channel=channel),
        tc(chat_id, "settings_logchannel", log=log_channel),
        tc(chat_id, "settings_lang", lang=lang_label),
    ]
    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)
