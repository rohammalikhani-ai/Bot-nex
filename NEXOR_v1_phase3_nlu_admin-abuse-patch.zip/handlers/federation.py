# -*- coding: utf-8 -*-
"""
Federation: چند گروه می‌تونن به یک فدراسیون مشترک بپیوندن تا لیست بن
بینشون به اشتراک گذاشته بشه. با /fban یک کاربر تو همه‌ی گروه‌های
فدراسیون بن می‌شه، نه فقط گروه فعلی.
"""

from telegram import Update
from telegram.ext import ContextTypes

import logging

from repositories import store as db
from i18n import tc
from utils import call_with_retry
from handlers.common import admin_only, resolve_target

logger = logging.getLogger(__name__)


async def fnew_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "fed_new_usage"))
        return
    name = " ".join(context.args)
    fed_id = db.create_federation(name, update.effective_user.id)
    db.join_federation(fed_id, chat_id)
    await update.message.reply_text(tc(chat_id, "fed_new_done", name=name, id=fed_id))


async def fjoin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    if not context.args:
        await update.message.reply_text(tc(chat_id, "fed_join_usage"))
        return
    try:
        fed_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text(tc(chat_id, "fed_join_invalid_id"))
        return

    fed = db.get_federation(fed_id)
    if not fed:
        await update.message.reply_text(tc(chat_id, "fed_not_found"))
        return

    db.join_federation(fed_id, chat_id)
    await update.message.reply_text(tc(chat_id, "fed_join_done", name=fed[1]))


async def fleave_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    fed = db.get_chat_federation(chat_id)
    if not fed:
        await update.message.reply_text(tc(chat_id, "fed_not_member"))
        return
    db.leave_federation(fed[0], chat_id)
    await update.message.reply_text(tc(chat_id, "fed_left", name=fed[1]))


async def finfo_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    fed = db.get_chat_federation(chat_id)
    if not fed:
        await update.message.reply_text(tc(chat_id, "fed_not_member"))
        return
    fed_id, name, owner_id = fed
    chats = db.get_federation_chats(fed_id)
    await update.message.reply_text(tc(chat_id, "fed_info", name=name, id=fed_id, count=len(chats)))


async def fban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    target_id, name, rest = await resolve_target(update, context)
    if not target_id:
        await update.message.reply_text(tc(chat_id, "fed_ban_no_target"))
        return

    fed = db.get_chat_federation(chat_id)
    if not fed:
        await update.message.reply_text(tc(chat_id, "fed_ban_not_member"))
        return

    fed_id, fed_name, _ = fed
    reason = " ".join(rest) if rest else tc(chat_id, "fed_ban_no_reason")
    db.add_federation_ban(fed_id, target_id, reason)

    chats = db.get_federation_chats(fed_id)
    success, failed = 0, 0
    for cid in chats:
        try:
            await call_with_retry(context.bot.ban_chat_member, chat_id=cid, user_id=target_id)
            success += 1
        except Exception:
            failed += 1

    await update.message.reply_text(
        tc(chat_id, "fed_ban_done", name=name, fed=fed_name, success=success, failed=failed, reason=reason)
    )


async def funban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update, context):
        return
    chat_id = update.effective_chat.id
    target_id, name, _ = await resolve_target(update, context)
    if not target_id:
        await update.message.reply_text(tc(chat_id, "fed_ban_no_target"))
        return

    fed = db.get_chat_federation(chat_id)
    if not fed:
        await update.message.reply_text(tc(chat_id, "fed_not_member"))
        return

    fed_id, fed_name, _ = fed
    db.remove_federation_ban(fed_id, target_id)
    chats = db.get_federation_chats(fed_id)
    success = 0
    for cid in chats:
        try:
            await call_with_retry(context.bot.unban_chat_member, chat_id=cid, user_id=target_id)
            success += 1
        except Exception:
            logger.exception("federation operation failed for chat %s", chat_id)

    await update.message.reply_text(tc(chat_id, "fed_unban_done", name=name, fed=fed_name, success=success))


async def check_federation_ban_on_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """وقتی عضو جدیدی وارد میشه، چک می‌کنه تو فدراسیون بن نباشه؛ اگه بود، خودکار اخراج می‌کنه."""
    chat_id = update.effective_chat.id
    fed = db.get_chat_federation(chat_id)
    if not fed:
        return
    fed_id = fed[0]
    for member in update.message.new_chat_members:
        if member.is_bot:
            continue
        if db.is_federation_banned(fed_id, member.id):
            try:
                await call_with_retry(context.bot.ban_chat_member, chat_id=chat_id, user_id=member.id)
                await update.message.reply_text(tc(chat_id, "fed_raid_kick_notice", name=member.first_name))
            except Exception:
                logger.exception("failed to send federation raid notice in chat %s", chat_id)
