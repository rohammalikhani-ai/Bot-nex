# -*- coding: utf-8 -*-
"""
services/payments.py

منطق «خرید اشتراک» (ارتقای پلن AI Copilot به pro/premium) با سه روش پرداخت:
⭐ Telegram Stars، 💎 TON، و 💳 کارت‌به‌کارت دستی (تایید توسط ادمین).

مثل ai_copilot/plans.py، این ماژول به Telegram وابسته نیست (فقط منطق/متن)؛
فراخوانی واقعی send_invoice و ثبت/تایید سفارش در handlers/payments.py انجام
می‌شه. جدول خام در db.py (subscription_orders) و از طریق repositories/store
در دسترسه.

⚠️ این ماژول عمداً به هیچ دستور/دکمه/منویی وصل نیست. برای وصل‌کردنش به رابط
کاربری، services/PAYMENTS_INTEGRATION_NOTES.md رو ببین.
"""
from __future__ import annotations

import time
from typing import Optional

from repositories import store as db
from config import (
    AI_PLAN_PRO, AI_PLAN_PREMIUM, AI_PLAN_FREE,
    SUBSCRIPTION_PRICE_STARS, SUBSCRIPTION_PRICE_TON, SUBSCRIPTION_PRICE_CARD_TOMAN,
    TON_WALLET_ADDRESS, SUBSCRIPTION_TON_EXPIRY_HOURS,
    SUBSCRIPTION_CARD_NUMBER, SUBSCRIPTION_CARD_HOLDER, SUBSCRIPTION_CARD_EXPIRY_HOURS,
)
from services import ton_wallet

PURCHASABLE_PLANS = (AI_PLAN_PRO, AI_PLAN_PREMIUM)
SETTING_KEY_PLAN_EXPIRES_AT = "ai_plan_expires_at"
SECONDS_PER_DAY = 86400
DAYS_PER_MONTH = 30  # مثل سایر پروژه‌ها (nationbot/shop.py)، ماه = ۳۰ روز ثابت


# ==================== قیمت‌گذاری ====================
# قیمت پایه از config میاد (قابل override با env)؛ اگه بعداً بخوایم مثل
# nationbot/shop.py قیمت از پنل ادمین قابل‌تغییر باشه، همینجا یک لایه‌ی
# db.get_setting(chat_id=0, key=f"price_stars_{plan}") اضافه می‌شه — فعلاً
# برای سادگی و چون هنوز به UI وصل نیست، این لایه اضافه نشده.

def price_stars(plan: str) -> int:
    return SUBSCRIPTION_PRICE_STARS.get(plan, 0)


def price_ton(plan: str) -> float:
    return SUBSCRIPTION_PRICE_TON.get(plan, 0.0)


def price_card_toman(plan: str) -> int:
    return SUBSCRIPTION_PRICE_CARD_TOMAN.get(plan, 0)


def ton_enabled() -> bool:
    return bool(TON_WALLET_ADDRESS)


def card_enabled() -> bool:
    return bool(SUBSCRIPTION_CARD_NUMBER)


# ==================== اعمال پلن بعد از تایید پرداخت ====================

def apply_subscription(chat_id: int, plan: str, months: int) -> float:
    """پلن گروه رو به `plan` ارتقا می‌ده و انقضا رو `months` ماه جلو می‌بره.
    اگه اشتراک فعلی هنوز منقضی نشده، از انتهای همون اشتراک جمع می‌زنه (نه از
    الان) — دقیقاً هم‌رفتار با DEFAULT_VIP_PRICE در nationbot/shop.py.
    خروجی: timestamp انقضای جدید."""
    now = time.time()
    current_expiry_raw = db.get_setting(chat_id, SETTING_KEY_PLAN_EXPIRES_AT, None)
    try:
        current_expiry = float(current_expiry_raw) if current_expiry_raw else 0.0
    except (TypeError, ValueError):
        current_expiry = 0.0
    base = current_expiry if current_expiry > now else now
    new_expiry = base + months * DAYS_PER_MONTH * SECONDS_PER_DAY

    db.set_setting(chat_id, "ai_plan", plan)
    db.set_setting(chat_id, SETTING_KEY_PLAN_EXPIRES_AT, str(new_expiry))
    return new_expiry


def downgrade_if_expired(chat_id: int) -> bool:
    """اگه اشتراک این گروه منقضی شده، پلن رو به free برمی‌گردونه. خروجی: آیا
    downgrade انجام شد یا نه. صدازننده (یک Job دوره‌ای، وصل‌نشده فعلاً) باید
    این رو برای گروه‌های دارای پلن paid صدا بزنه."""
    plan = db.get_setting(chat_id, "ai_plan", AI_PLAN_FREE)
    if plan == AI_PLAN_FREE:
        return False
    expiry_raw = db.get_setting(chat_id, SETTING_KEY_PLAN_EXPIRES_AT, None)
    try:
        expiry = float(expiry_raw) if expiry_raw else 0.0
    except (TypeError, ValueError):
        expiry = 0.0
    if expiry and expiry > time.time():
        return False
    db.set_setting(chat_id, "ai_plan", AI_PLAN_FREE)
    return True


# ==================== ⭐ Stars ====================

def build_stars_invoice_payload(order_id: int) -> str:
    return f"nexor_sub_{order_id}"


def create_stars_order(chat_id: int, user_id: int, plan: str, months: int = 1) -> Optional[dict]:
    if plan not in PURCHASABLE_PLANS:
        return None
    amount = price_stars(plan) * months
    if amount <= 0:
        return None
    # payload خودش شامل order_id هست، پس نمی‌شه در همون INSERT اولیه ساختش؛
    # با یه UNIQUE placeholder موقت می‌سازیم و بلافاصله با db.set_stars_invoice_payload
    # جایگزینش می‌کنیم (idempotent-safe چون order تازه‌ساخته‌شده و pending است).
    placeholder = f"__pending_{time.time_ns()}"
    order_id = db.create_subscription_order(
        chat_id=chat_id, user_id=user_id, plan=plan, months=months,
        method="stars", ts=time.time(), amount_stars=amount,
        stars_invoice_payload=placeholder,
    )
    payload = build_stars_invoice_payload(order_id)
    db.set_stars_invoice_payload(order_id, payload)
    return {"id": order_id, "amount_stars": amount, "stars_invoice_payload": payload}


def confirm_stars_payment(invoice_payload: str, charge_id: str) -> Optional[dict]:
    """صدا زده می‌شه از handlers/payments.py بعد از successful_payment. اگه
    idempotent-check رد بشه (سفارش قبلاً confirmed بوده) None برمی‌گردونه."""
    order = db.confirm_stars_subscription_order(invoice_payload, charge_id, time.time())
    if order is None:
        return None
    apply_subscription(order["chat_id"], order["plan"], order["months"])
    return order


# ==================== 💎 TON ====================

def create_ton_order(chat_id: int, user_id: int, plan: str, months: int = 1) -> Optional[dict]:
    if not ton_enabled() or plan not in PURCHASABLE_PLANS:
        return None
    amount_ton = price_ton(plan) * months
    if amount_ton <= 0:
        return None
    memo = ton_wallet.generate_memo(chat_id, user_id)
    amount_nano = ton_wallet.ton_to_nano(amount_ton)
    order_id = db.create_subscription_order(
        chat_id=chat_id, user_id=user_id, plan=plan, months=months,
        method="ton", ts=time.time(), amount_ton_nano=amount_nano, ton_memo=memo,
    )
    return {
        "id": order_id,
        "memo": memo,
        "amount_ton": amount_ton,
        "amount_nano": amount_nano,
        "transfer_link": ton_wallet.build_ton_transfer_link(TON_WALLET_ADDRESS, amount_ton, memo),
        "address": TON_WALLET_ADDRESS,
    }


def check_ton_payments_once() -> list:
    """یک دور کامل بررسی: منقضی‌کردن سفارش‌های قدیمی، گرفتن تراکنش‌های تازه از
    toncenter، تطبیق، ثبت confirm، و اعمال پلن. خروجی: لیست سفارش‌های تازه‌تاییدشده
    (برای اطلاع‌رسانی به کاربر توسط صدازننده). صدازننده باید یک Job دوره‌ای باشه —
    فعلاً هیچ Jobـی این رو صدا نمی‌زنه (نگاه کن به PAYMENTS_INTEGRATION_NOTES.md)."""
    if not ton_enabled():
        return []
    db.expire_stale_subscription_orders("ton", SUBSCRIPTION_TON_EXPIRY_HOURS)
    pending = db.get_pending_subscription_orders("ton", max_age_hours=SUBSCRIPTION_TON_EXPIRY_HOURS)
    if not pending:
        return []
    try:
        transactions = ton_wallet.fetch_recent_transactions(TON_WALLET_ADDRESS)
    except Exception:
        return []

    confirmed = []
    for match in ton_wallet.match_transactions(transactions, pending):
        order = db.confirm_ton_subscription_order(match["memo"], match["tx_hash"], time.time())
        if order is not None:
            apply_subscription(order["chat_id"], order["plan"], order["months"])
            confirmed.append(order)
    return confirmed


# ==================== 💳 کارت‌به‌کارت (دستی) ====================

def create_card_order(chat_id: int, user_id: int, plan: str, months: int = 1) -> Optional[dict]:
    if not card_enabled() or plan not in PURCHASABLE_PLANS:
        return None
    amount_toman = price_card_toman(plan) * months
    reference = f"NX{chat_id}{user_id}{int(time.time()) % 100000}"
    order_id = db.create_subscription_order(
        chat_id=chat_id, user_id=user_id, plan=plan, months=months,
        method="card", ts=time.time(), card_reference=reference,
    )
    return {
        "id": order_id,
        "reference": reference,
        "amount_toman": amount_toman,
        "card_number": SUBSCRIPTION_CARD_NUMBER,
        "card_holder": SUBSCRIPTION_CARD_HOLDER,
    }


def confirm_card_order(order_id: int, admin_id: int) -> Optional[dict]:
    """صدا زده می‌شه بعد از اینکه ادمین رسید کارت‌به‌کارت رو دستی چک کرد."""
    order = db.confirm_card_subscription_order(order_id, admin_id, time.time())
    if order is None:
        return None
    apply_subscription(order["chat_id"], order["plan"], order["months"])
    return order


def reject_card_order(order_id: int, admin_id: int) -> bool:
    return db.reject_subscription_order(order_id, admin_id)


def expire_stale_card_orders() -> int:
    return db.expire_stale_subscription_orders("card", SUBSCRIPTION_CARD_EXPIRY_HOURS)
