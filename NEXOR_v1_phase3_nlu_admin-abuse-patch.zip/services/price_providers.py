# -*- coding: utf-8 -*-
"""
services/price_providers.py

معماری Provider-Based برای قیمت‌ها. هر Provider فقط یک مسئولیت دارد: گرفتن
چند دارایی مشخص از یک API واقعی و برگرداندن دیکشنری {asset_code: PriceQuote}.
هیچ Providerای هیچ‌وقت مقدار ساختگی برنمی‌گرداند و هیچ‌وقت اجازه نمی‌دهد یک
خطای شبکه/HTTP/Parse به بیرون درز کند و ربات را Crash کند — services/price_service.py
(لایه‌ی بالاتر) این توابع را همیشه در try/except صدا می‌زند، ولی هر Provider
هم مستقل self-contained و safe است.

هیچ AI در مسیر قیمت‌ها استفاده نمی‌شود (طبق اسپک صریحاً ممنوع است).

Providerهای فعلی:
  - NavasanProvider: قیمت‌های بازار ایران (طلای ۱۸ عیار، دلار، یورو، تتر به
    تومان) از api.navasan.tech — نیازمند NAVASAN_API_KEY.
  - CoinGeckoProvider: قیمت جهانی ارزهای دیجیتال (TON، و اختیاری BTC/ETH) به
    دلار، از CoinGecko Public API — رایگان، بدون نیاز به کلید.
  - ManualStarsProvider: Telegram Stars هیچ API عمومی/بازار واقعی برای نرخ
    ندارد؛ فقط اگر ادمین/اپراتور صریحاً یک نرخ ثابت را با متغیر محیطی
    STARS_MANUAL_RATE_TOMAN تنظیم کرده باشد نمایش داده می‌شود (source="manual")
    — در غیر این صورت این دارایی کلاً از خروجی حذف می‌شود، نه این‌که با عدد
    ساختگی نمایش داده شود.

نکته درباره‌ی نگاشت فیلدهای Navasan: چون schema دقیق پاسخ ممکن است بین
اکانت‌ها/نسخه‌های API کمی فرق کند، نام فیلدها با متغیر محیطی قابل override
هستند (NAVASAN_FIELD_<ASSET>) تا بدون تغییر کد با API واقعی سازگار شود.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Optional

import requests

logger = logging.getLogger(__name__)

REQUEST_TIMEOUT_SECONDS = 10

NAVASAN_API_KEY = os.environ.get("NAVASAN_API_KEY", "").strip()
NAVASAN_BASE_URL = os.environ.get("NAVASAN_BASE_URL", "").strip() or "http://api.navasan.tech/latest/"

# نام پیش‌فرض فیلدها در پاسخ Navasan (طبق مستندات رایج این سرویس)؛ در صورت
# نیاز با env قابل override است بدون تغییر کد.
_NAVASAN_FIELD_DEFAULTS = {
    "gold18": "18ayar",
    "usd": "usd_sell",
    "eur": "eur_sell",
    "usdt": "usdt",
}

STARS_MANUAL_RATE_TOMAN = os.environ.get("STARS_MANUAL_RATE_TOMAN", "").strip()

COINGECKO_URL = "https://api.coingecko.com/api/v3/simple/price"
# نگاشت asset_code داخلی -> شناسه‌ی CoinGecko
_COINGECKO_IDS = {
    "ton": "the-open-network",
    "btc": "bitcoin",
    "eth": "ethereum",
}


@dataclass
class PriceQuote:
    asset: str          # کد داخلی دارایی، مثل "gold18", "usd", "ton"
    value: float
    unit: str            # واحد نمایشی، مثل "toman", "usd"
    source: str           # نام Provider/منبع، برای شفافیت به کاربر نهایی


def _navasan_field(asset: str) -> str:
    env_key = f"NAVASAN_FIELD_{asset.upper()}"
    return os.environ.get(env_key, _NAVASAN_FIELD_DEFAULTS.get(asset, asset)).strip()


def _to_float(value) -> Optional[float]:
    if value is None:
        return None
    try:
        # بعضی APIها عدد را با کاما جدا می‌کنند (مثلاً "1,234,000")
        if isinstance(value, str):
            value = value.replace(",", "").strip()
        return float(value)
    except (TypeError, ValueError):
        return None


class NavasanProvider:
    """قیمت‌های بازار آزاد ایران: طلای ۱۸ عیار، دلار، یورو، تتر (تومان)."""

    name = "Navasan"
    supported_assets = ("gold18", "usd", "eur", "usdt")

    def enabled(self) -> bool:
        return bool(NAVASAN_API_KEY)

    def fetch(self, assets: list[str]) -> dict[str, PriceQuote]:
        wanted = [a for a in assets if a in self.supported_assets]
        if not wanted or not self.enabled():
            return {}
        try:
            resp = requests.get(
                NAVASAN_BASE_URL,
                params={"api_key": NAVASAN_API_KEY},
                timeout=REQUEST_TIMEOUT_SECONDS,
            )
            resp.raise_for_status()
            data = resp.json()
        except Exception:
            logger.warning("NavasanProvider: request failed", exc_info=True)
            return {}
        if not isinstance(data, dict):
            logger.warning("NavasanProvider: unexpected response shape (not a dict)")
            return {}

        result: dict[str, PriceQuote] = {}
        for asset in wanted:
            field = _navasan_field(asset)
            raw = data.get(field)
            # بعضی نسخه‌های API مقدار را زیر یک آبجکت تو در تو ({"value": ...}) می‌دهند.
            if isinstance(raw, dict):
                raw = raw.get("value")
            value = _to_float(raw)
            if value is None or value <= 0:
                logger.info("NavasanProvider: no valid value for asset=%s (field=%s); skipping", asset, field)
                continue
            result[asset] = PriceQuote(asset=asset, value=value, unit="toman", source=self.name)
        return result


class CoinGeckoProvider:
    """قیمت جهانی ارزهای دیجیتال (دلار) — رایگان، بدون کلید."""

    name = "CoinGecko"
    supported_assets = tuple(_COINGECKO_IDS.keys())

    def enabled(self) -> bool:
        return True

    def fetch(self, assets: list[str]) -> dict[str, PriceQuote]:
        wanted = [a for a in assets if a in self.supported_assets]
        if not wanted:
            return {}
        ids = ",".join(_COINGECKO_IDS[a] for a in wanted)
        try:
            resp = requests.get(
                COINGECKO_URL,
                params={"ids": ids, "vs_currencies": "usd"},
                timeout=REQUEST_TIMEOUT_SECONDS,
            )
            resp.raise_for_status()
            data = resp.json()
        except Exception:
            logger.warning("CoinGeckoProvider: request failed", exc_info=True)
            return {}
        if not isinstance(data, dict):
            logger.warning("CoinGeckoProvider: unexpected response shape (not a dict)")
            return {}

        result: dict[str, PriceQuote] = {}
        for asset in wanted:
            cg_id = _COINGECKO_IDS[asset]
            value = _to_float((data.get(cg_id) or {}).get("usd"))
            if value is None or value <= 0:
                continue
            result[asset] = PriceQuote(asset=asset, value=value, unit="usd", source=self.name)
        return result


class ManualStarsProvider:
    """Telegram Stars بازار/API عمومی معتبری برای نرخ ندارد. فقط اگر اپراتور
    صریحاً یک نرخ ثابت تنظیم کرده باشد نمایش داده می‌شود، وگرنه حذف کامل."""

    name = "manual"
    supported_assets = ("stars",)

    def enabled(self) -> bool:
        return bool(STARS_MANUAL_RATE_TOMAN)

    def fetch(self, assets: list[str]) -> dict[str, PriceQuote]:
        if "stars" not in assets or not self.enabled():
            return {}
        value = _to_float(STARS_MANUAL_RATE_TOMAN)
        if value is None or value <= 0:
            return {}
        return {"stars": PriceQuote(asset="stars", value=value, unit="toman", source=self.name)}


# ترتیب Fallback: هر Provider فقط دارایی‌های خودش را پاسخ می‌دهد؛ اگر یکی
# Down باشد یا Asset را نداشته باشد، بقیه‌ی Providerها و بقیه‌ی Assetها
# متاثر نمی‌شوند (Isolation کامل بین Providerها).
ALL_PROVIDERS = [NavasanProvider(), CoinGeckoProvider(), ManualStarsProvider()]

# لیست کامل دارایی‌های پشتیبانی‌شده (برای منوی تنظیمات ادمین) به ترتیب نمایش.
SUPPORTED_ASSETS = ["gold18", "usd", "eur", "usdt", "ton", "stars", "btc", "eth"]
DEFAULT_ENABLED_ASSETS = ["gold18", "usd", "eur", "usdt", "ton", "stars"]
