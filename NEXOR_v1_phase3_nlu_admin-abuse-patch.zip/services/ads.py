# -*- coding: utf-8 -*-
"""
services/ads.py

سیستم تبلیغات NEXOR — الهام‌گرفته از advertisement_service.py در nationbot،
اما ساده‌سازی‌شده برای یک ربات مدیریت گروه (بدون Gold/کلیک/ضدتقلب که آنجا
مخصوص بازی بود). دو محل نمایش:

1) زیر پیام‌های کمک NEXOR Copilot (handlers/ai_copilot.py) — یک خط کوتاه،
   فقط برای گروه‌هایی که پلن‌شون free است (ai_copilot/plans.get_chat_plan).
2) پست روزانه‌ی مستقل (با بنر) داخل تمام گروه‌های متصل به ربات که پلن‌شون
   free است — با ad_delivery_job که در core/bootstrap.py چندبار در روز
   (به تعداد AD_SLOT_HOURS) اجرا می‌شود.

قیمت‌گذاری/پرداخت از همون الگوی services/payments.py استفاده می‌کنه (⭐ Stars
و 💎 TON)؛ تایید نهایی همیشه یک صف بررسی ادمین (pending_review) داره — دقیقاً
شبیه همون approval queue که در ADS_IMPLEMENTATION_FA.md/nationbot توضیح داده
شده — تا محتوای تبلیغ قبل از رفتن به گروه‌های واقعی چک بشه.
"""
from __future__ import annotations

import datetime
import time
from typing import Optional

from repositories import store as db
from services import ton_wallet
from ai_copilot import plans as ai_plans
from config import (
    AI_PLAN_FREE, AD_VISIBLE_PLANS,
    AD_MIN_TIMES_PER_DAY, AD_MAX_TIMES_PER_DAY, AD_DEFAULT_TIMES_PER_DAY,
    AD_SLOT_HOURS, AD_DURATION_CHOICES_DAYS, AD_DEFAULT_DURATION_DAYS,
    AD_BASE_PRICE_STARS_PER_DAY, AD_BASE_PRICE_TON_PER_DAY,
    TON_WALLET_ADDRESS, SUBSCRIPTION_TON_EXPIRY_HOURS,
)

KIND_FREE = "free"
KIND_PAID = "paid"


def chat_should_see_ads(chat_id: int) -> bool:
    """فقط گروه‌های پلن free تبلیغ می‌بینن — Pro/Premium همیشه بدون تبلیغ."""
    return ai_plans.get_chat_plan(chat_id) in AD_VISIBLE_PLANS


def _today_str(ts: float = None) -> str:
    ts = ts if ts is not None else time.time()
    return datetime.datetime.utcfromtimestamp(ts).strftime("%Y-%m-%d")


# ==================== قیمت‌گذاری ====================

def price_stars(times_per_day: int, duration_days: int) -> int:
    return AD_BASE_PRICE_STARS_PER_DAY * times_per_day * duration_days


def price_ton(times_per_day: int, duration_days: int) -> float:
    return round(AD_BASE_PRICE_TON_PER_DAY * times_per_day * duration_days, 4)


def ton_enabled() -> bool:
    return bool(TON_WALLET_ADDRESS)


def clamp_times_per_day(value: int) -> int:
    return max(AD_MIN_TIMES_PER_DAY, min(AD_MAX_TIMES_PER_DAY, value))


# ==================== ثبت سفارش (رایگان/خریداری‌شده) ====================

def create_draft(owner_chat_id: int, user_id: int, kind: str, banner_file_id: Optional[str],
                  text: str, times_per_day: int, duration_days: int) -> int:
    if kind == KIND_FREE:
        times_per_day = AD_DEFAULT_TIMES_PER_DAY  # رایگان همیشه فقط ۱ بار در روز
        duration_days = AD_DEFAULT_DURATION_DAYS
    else:
        times_per_day = clamp_times_per_day(times_per_day)
        if duration_days not in AD_DURATION_CHOICES_DAYS:
            duration_days = AD_DEFAULT_DURATION_DAYS
    return db.create_ad_draft(
        owner_chat_id=owner_chat_id, user_id=user_id, kind=kind,
        banner_file_id=banner_file_id, text=text,
        times_per_day=times_per_day, duration_days=duration_days, ts=time.time(),
    )


def submit_free_ad(ad_id: int) -> None:
    """آگهی رایگان مستقیم می‌ره صف بررسی ادمین (بدون پرداخت)."""
    db.submit_free_ad_for_review(ad_id)


def build_stars_invoice_payload(ad_id: int) -> str:
    return f"nexor_ad_{ad_id}"


def start_stars_payment(ad_id: int) -> Optional[dict]:
    order = db.get_ad_order(ad_id)
    if order is None or order["kind"] != KIND_PAID:
        return None
    amount = price_stars(order["times_per_day"], order["duration_days"])
    if amount <= 0:
        return None
    payload = build_stars_invoice_payload(ad_id)
    db.set_ad_payment_pending(ad_id, method="stars", amount_stars=amount, stars_invoice_payload=payload)
    return {"amount_stars": amount, "payload": payload}


def confirm_stars_payment(invoice_payload: str, charge_id: str) -> Optional[dict]:
    return db.confirm_ad_stars_payment(invoice_payload, charge_id, time.time())


def start_ton_payment(ad_id: int, owner_chat_id: int, user_id: int) -> Optional[dict]:
    if not ton_enabled():
        return None
    order = db.get_ad_order(ad_id)
    if order is None or order["kind"] != KIND_PAID:
        return None
    amount_ton = price_ton(order["times_per_day"], order["duration_days"])
    if amount_ton <= 0:
        return None
    memo = ton_wallet.generate_memo(owner_chat_id, user_id)
    amount_nano = ton_wallet.ton_to_nano(amount_ton)
    db.set_ad_payment_pending(ad_id, method="ton", amount_ton_nano=amount_nano, ton_memo=memo)
    return {
        "memo": memo,
        "amount_ton": amount_ton,
        "amount_nano": amount_nano,
        "address": TON_WALLET_ADDRESS,
        "transfer_link": ton_wallet.build_ton_transfer_link(TON_WALLET_ADDRESS, amount_ton, memo),
    }


def check_ton_payments_once() -> list:
    """معادل services/payments.py:check_ton_payments_once ولی برای سفارش‌های تبلیغ:
    تایید TON فقط سفارش رو می‌بره pending_review (نه فعال) — چون محتوای تبلیغ هنوز
    باید توسط ادمین چک بشه، برخلاف ارتقای پلن که نیازی به تایید محتوایی نداره."""
    if not ton_enabled():
        return []
    db.expire_stale_ad_orders("ton", SUBSCRIPTION_TON_EXPIRY_HOURS)
    pending = db.get_pending_ad_orders("ton", max_age_hours=SUBSCRIPTION_TON_EXPIRY_HOURS)
    if not pending:
        return []
    try:
        transactions = ton_wallet.fetch_recent_transactions(TON_WALLET_ADDRESS)
    except Exception:
        return []
    confirmed = []
    for match in ton_wallet.match_transactions(transactions, pending):
        order = db.confirm_ad_ton_payment(match["memo"], match["tx_hash"], time.time())
        if order is not None:
            confirmed.append(order)
    return confirmed


# ==================== بررسی ادمین ====================

def list_pending() -> list:
    return db.list_pending_review_ads()


def approve(ad_id: int, admin_id: int) -> Optional[dict]:
    order = db.get_ad_order(ad_id)
    duration = order["duration_days"] if order else AD_DEFAULT_DURATION_DAYS
    return db.approve_ad(ad_id, admin_id, time.time(), duration)


def reject(ad_id: int, admin_id: int, reason: str | None = None) -> bool:
    return db.reject_ad(ad_id, admin_id, reason)


def my_ads(owner_chat_id: int) -> list:
    return db.list_my_ads(owner_chat_id)


def ad_stats(ad_id: int, requester_chat_id: int, requester_user_id: int) -> Optional[dict]:
    """آمار نمایش برای *صاحب* آگهی — چک مالکیت روی owner_chat_id (همون گروهی
    که /ads توش زده شده) یا user_id (اگه توی پی‌وی خودش پیگیری کنه)."""
    order = db.get_ad_order(ad_id)
    if order is None:
        return None
    if order["owner_chat_id"] != requester_chat_id and order["user_id"] != requester_user_id:
        return None
    stats = db.get_ad_delivery_stats(ad_id)
    today = _today_str()
    stats["order"] = order
    stats["today_count"] = next((d["count"] for d in stats["per_day"] if d["day"] == today), 0)
    stats["daily_quota"] = order["times_per_day"]
    return stats


# ==================== انتخاب/چرخش تبلیغ برای نمایش ====================

def _eligible_pool(now_ts: float, slot: int) -> list:
    """تبلیغ‌های فعالی که برای این Slot واجد شرایطن: رایگان فقط Slot ۱،
    خریداری‌شده هر Slotی که times_per_day پوششش بده (Slotهای پایین‌شماره‌تر
    اول پر می‌شن، طبق ترتیب AD_SLOT_HOURS)."""
    active = db.list_active_ads(now_ts)
    pool = []
    for ad in active:
        if ad["kind"] == KIND_FREE:
            if slot == 0:
                pool.append(ad)
        else:
            if slot < max(AD_MIN_TIMES_PER_DAY, ad["times_per_day"]):
                pool.append(ad)
    return pool


def pick_ad_for_slot(slot: int) -> Optional[dict]:
    """یک تبلیغ برای این Slot با چرخش round-robin (بین همه‌ی تبلیغ‌های واجد
    شرایط، مستقل از گروه) انتخاب می‌کنه — پخش نمایش‌ها بین تبلیغ‌دهنده‌ها را
    عادلانه نگه می‌داره، دقیقاً هدف weighted/priority selection در
    advertisement_service.py نسخه‌ی nationbot، اما بدون بودجه/Gold."""
    now_ts = time.time()
    db.expire_stale_ads(now_ts)
    pool = _eligible_pool(now_ts, slot)
    if not pool:
        return None
    idx = db.next_rotation_index(bucket=f"slot_{slot}", pool_size=len(pool))
    return pool[idx]


def pick_ad_for_footer(chat_id: int) -> Optional[dict]:
    """برای خط تبلیغاتی زیر پیام‌های Copilot — از کل استخر تبلیغ‌های فعال
    (بدون مصرف سهمیه‌ی Slot روزانه؛ این محل جدا از پست روزانه‌ست)."""
    now_ts = time.time()
    active = db.list_active_ads(now_ts)
    if not active:
        return None
    idx = db.next_rotation_index(bucket=f"footer_{chat_id}", pool_size=len(active))
    return active[idx]


def ad_short_line(ad: dict) -> str:
    text = (ad.get("text") or "").strip().splitlines()[0] if ad.get("text") else ""
    if len(text) > 90:
        text = text[:87] + "…"
    return f"📢 {text}"


# ==================== پست روزانه/چند-باره داخل گروه‌های متصل ====================

async def run_delivery_slot(context) -> None:
    """صدا زده می‌شه توسط core/bootstrap.py برای هر Slot در AD_SLOT_HOURS.
    فقط گروه‌های پلن free که ربات هنوز توشون عضوه پیام می‌گیرن.

    شماره‌ی Slot باید از طریق job.data (وقتی با job_queue.run_daily ثبت می‌شه)
    صریح پاس داده بشه — نه از ساعت لحظه‌ای سرور مشتق بشه؛ چون اگه Job چند
    دقیقه دیر/زود اجرا بشه یا صدازننده دستی باشه، مشتق‌کردن از ساعت می‌تونه
    Slot اشتباه رو انتخاب کنه یا اصلاً هیچ Slotی مچ نشه."""
    now_ts = time.time()
    day = _today_str(now_ts)
    slot = getattr(getattr(context, "job", None), "data", None)
    if slot is None:
        slot_hour = datetime.datetime.utcfromtimestamp(now_ts).hour
        slot = AD_SLOT_HOURS.index(min(AD_SLOT_HOURS, key=lambda h: abs(h - slot_hour)))

    groups = db.list_active_group_chats()
    if not groups:
        return

    import logging
    logger = logging.getLogger(__name__)

    for chat_id in groups:
        if db.chat_already_served_slot(chat_id, slot, day):
            continue
        if not chat_should_see_ads(chat_id):
            continue
        ad = pick_ad_for_slot(slot)
        if ad is None:
            continue
        if not db.record_ad_delivery(ad["id"], chat_id, slot, day, now_ts):
            continue  # یکی دیگه همزمان همین Slot رو برای این گروه ثبت کرده
        try:
            if ad.get("banner_file_id"):
                await context.bot.send_photo(chat_id=chat_id, photo=ad["banner_file_id"], caption=ad["text"])
            else:
                await context.bot.send_message(chat_id=chat_id, text=ad["text"])
        except Exception:
            logger.exception("ارسال تبلیغ روزانه به گروه %s شکست خورد", chat_id)
