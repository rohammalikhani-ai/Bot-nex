"""Business/service layer for NEXOR_v1.

Handlers should call services for cross-cutting business rules instead of
implementing policy in multiple Telegram entry points.
"""
