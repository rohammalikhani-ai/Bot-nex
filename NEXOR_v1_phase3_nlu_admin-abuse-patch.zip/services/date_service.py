# -*- coding: utf-8 -*-
"""
services/date_service.py

بخشی از معماری «DailyMessageBuilder → DateService + OccasionService +
PriceService + NewsService» برای سیستم اطلاع‌رسانی روزانه.

مسئولیت این ماژول فقط «امروز، به وقت و تقویم خود گروه، چیه؟» است:
- ساعت/تاریخ بر اساس Timezone خود Group (نه UTC سرور).
- برای فارسی: تقویم شمسی (Jalali) + نام روز/ماه فارسی.
- برای بقیه‌ی زبان‌ها: تقویم میلادی + نام روز/ماه به همون زبان.

هیچ متنی این‌جا Hardcode نمی‌شود؛ تمام نام روزها/ماه‌ها از i18n (locales/*.py)
خوانده می‌شوند — اضافه‌کردن زبان جدید فقط نیاز به افزودن کلیدهای day_*/month_*
در فایل زبان جدید دارد، هیچ‌جای این ماژول نیازی به تغییر ندارد.

تبدیل میلادی→شمسی با یک الگوریتم خالص ریاضی (بدون هیچ کتابخانه‌ی خارجی)
انجام می‌شود تا هیچ وابستگی جدیدی به requirements.txt اضافه نشود.
"""
from __future__ import annotations

import datetime
import logging
from dataclasses import dataclass
from typing import Optional
try:
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError  # Python 3.9+ stdlib
except ImportError:  # Python 3.8: نیاز به پکیج backports.zoneinfo (در requirements.txt اضافه شد)
    from backports.zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from i18n import tc

logger = logging.getLogger(__name__)

DEFAULT_TIMEZONE = "UTC"
# اگر زبان گروه فارسی است و ادمین هنوز Timezone را صریحاً تنظیم نکرده،
# پیش‌فرض معقول‌تر «Asia/Tehran» است (چون خود پروژه با فارسی شروع شده).
LANG_DEFAULT_TIMEZONE = {
    "fa": "Asia/Tehran",
}

# نقاط شکستِ چرخه‌ی نامنظم کبیسه‌های تقویم رسمی ایران (نه یک چرخه‌ی ساده‌ی
# هر-۴-سال). این آرایه بخشی از الگوریتم نجومی استاندارد و منتشرشده‌ی
# Kazimierz Borkowski است (همان‌که کتابخانه‌های معتبر مثل jalaali-js از آن
# استفاده می‌کنند) و تنها راهیست که موارد کبیسه‌ی ۵ ساله‌ی واقعی (مثلاً
# گذار ۱۳۹۹ → ۱۴۰۸، به‌جای ۱۳۹۹ → ۱۴۰۳) را درست تشخیص می‌دهد؛ یک چرخه‌ی
# ساده‌ی هر-۴-سال سال ۱۴۰۳ را (اشتباهاً) کبیسه حساب می‌کند.
_JALALI_BREAKS = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210,
                  1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178]

# ترتیب کلید روزهای هفته مطابق Python: Monday=0 ... Sunday=6
_WEEKDAY_KEYS = ["day_mon", "day_tue", "day_wed", "day_thu", "day_fri", "day_sat", "day_sun"]
_GREGORIAN_MONTH_KEYS = [f"month_g_{i}" for i in range(1, 13)]
_JALALI_MONTH_KEYS = [f"month_j_{i}" for i in range(1, 13)]


@dataclass
class ResolvedDate:
    lang: str
    timezone: str
    now: datetime.datetime          # aware datetime، به وقت محلی گروه
    weekday_name: str
    day: int
    month: int
    year: int
    month_name: str
    calendar: str                   # "jalali" یا "gregorian"
    date_str: str                   # رشته‌ی نمایشی نهایی تاریخ (بدون برچسب/ایموجی)


def _jalali_year_info(jy: int) -> tuple[int, int]:
    """برای یک سال شمسی مشخص، (leap, march) را برمی‌گرداند:
      leap  = چند سال از آخرین سال کبیسه گذشته (۰ یعنی خودِ jy کبیسه است).
      march = فروردینِ ۱ همین سال، چندمِ مارسِ میلادیِ همان بازه‌ی گرگوری است.
    پیاده‌سازی مستقیمِ الگوریتم منتشرشده‌ی Borkowski (همان‌که jalaali-js/
    persian-tools استفاده می‌کنند) — تنها الگوریتمی که کبیسه‌های نامنظم
    (گاه ۵ ساله به‌جای ۴ ساله) تقویم رسمی ایران را درست پوشش می‌دهد."""
    bl = len(_JALALI_BREAKS)
    jp = _JALALI_BREAKS[0]
    leap_j = -14
    jump = 0
    for i in range(1, bl):
        jm_break = _JALALI_BREAKS[i]
        jump = jm_break - jp
        if jy < jm_break:
            break
        leap_j += (jump // 33) * 8 + (jump % 33) // 4
        jp = jm_break
    n = jy - jp
    leap_j += (n // 33) * 8 + ((n % 33) + 3) // 4
    if jump % 33 == 4 and jump - n == 4:
        leap_j += 1
    gy = jy + 621
    leap_g = (gy // 4) - ((gy // 100 + 1) * 3 // 4) - 150
    march = 20 + leap_j - leap_g
    if jump - n < 6:
        n = n - jump + ((jump + 4) // 33) * 33
    leap = (((n + 1) % 33) - 1) % 4
    if leap == -1:
        leap = 4
    return leap, march


def gregorian_to_jalali(gy: int, gm: int, gd: int) -> tuple[int, int, int]:
    """تبدیل میلادی -> شمسی، بدون هیچ وابستگی خارجی (فقط datetime استاندارد
    برای شمارش دقیق روز بین دو تاریخ، که خودش کاملاً قابل‌اعتماد و
    بدون‌باگ است). سال شمسیِ حدسی با _jalali_year_info دقیق تنظیم می‌شود تا
    نزدیکِ مرز فروردین (اسفند/فروردین) هم درست باشد."""
    target = datetime.date(gy, gm, gd)

    jy = gy - 621 if (gm, gd) >= (3, 20) else gy - 622
    for _ in range(4):
        leap, march = _jalali_year_info(jy)
        anchor = datetime.date(jy + 621, 3, march)
        delta = (target - anchor).days
        if delta < 0:
            jy -= 1
            continue
        year_len = 366 if leap == 0 else 365
        if delta >= year_len:
            jy += 1
            continue
        break
    else:
        raise ValueError(f"gregorian_to_jalali: failed to converge for {gy}-{gm:02d}-{gd:02d}")

    if delta < 186:  # ۶ ماه اول، هرکدام ۳۱ روزه
        jm = delta // 31 + 1
        jd = delta % 31 + 1
    else:  # ۶ ماه بعدی (مهر..اسفند)، هرکدام ۳۰ روزه (اسفند در سال عادی ۲۹ روزه)
        k = delta - 186
        jm = k // 30 + 7
        jd = k % 30 + 1

    return jy, jm, jd


def resolve_timezone(tz_name: Optional[str], lang: str) -> ZoneInfo:
    """Timezone معتبر خود گروه را resolve می‌کند؛ در صورت نامعتبر بودن (که
    نباید معمولاً پیش بیاید چون /setdailytz خودش validate می‌کند) به‌جای
    Crash کردن، به UTC یا پیش‌فرض زبان fallback می‌کند."""
    candidates = []
    if tz_name:
        candidates.append(tz_name)
    candidates.append(LANG_DEFAULT_TIMEZONE.get(lang, DEFAULT_TIMEZONE))
    candidates.append(DEFAULT_TIMEZONE)
    for name in candidates:
        try:
            return ZoneInfo(name)
        except (ZoneInfoNotFoundError, ValueError, KeyError):
            continue
    return ZoneInfo(DEFAULT_TIMEZONE)


def is_valid_timezone(tz_name: str) -> bool:
    try:
        ZoneInfo(tz_name)
        return True
    except (ZoneInfoNotFoundError, ValueError, KeyError):
        return False


def resolve_today(chat_id: int, lang: str, tz_name: Optional[str]) -> ResolvedDate:
    """تاریخ «امروز» را برای یک گروه مشخص، به وقت و تقویم خودش برمی‌گرداند.
    هرگز Exception بیرون نمی‌اندازد — بدترین حالت fallback به UTC/میلادی است.
    """
    try:
        tz = resolve_timezone(tz_name, lang)
        now = datetime.datetime.now(tz)
        weekday_name = tc(chat_id, _WEEKDAY_KEYS[now.weekday()])

        if lang == "fa":
            jy, jm, jd = gregorian_to_jalali(now.year, now.month, now.day)
            month_name = tc(chat_id, _JALALI_MONTH_KEYS[jm - 1])
            date_str = tc(chat_id, "date_format_jalali", weekday=weekday_name,
                          day=jd, month=month_name, year=jy)
            return ResolvedDate(lang, str(tz), now, weekday_name, jd, jm, jy,
                                 month_name, "jalali", date_str)

        month_name = tc(chat_id, _GREGORIAN_MONTH_KEYS[now.month - 1])
        date_str = tc(chat_id, "date_format_gregorian", weekday=weekday_name,
                      day=now.day, month=month_name, year=now.year)
        return ResolvedDate(lang, str(tz), now, weekday_name, now.day, now.month,
                             now.year, month_name, "gregorian", date_str)
    except Exception:
        logger.exception("DateService failed to resolve today's date for chat %s; falling back to UTC", chat_id)
        now = datetime.datetime.now(datetime.timezone.utc)
        weekday_name = _WEEKDAY_KEYS[now.weekday()]
        month_name = _GREGORIAN_MONTH_KEYS[now.month - 1]
        return ResolvedDate(lang, "UTC", now, weekday_name, now.day, now.month,
                             now.year, month_name, "gregorian",
                             f"{now.year}-{now.month:02d}-{now.day:02d}")


def day_key_str(resolved: ResolvedDate) -> str:
    """کلید یکتای «روز» برای جلوگیری از ارسال دوباره‌ی پیام در یک روز
    (مستقل از تقویم نمایشی، همیشه بر اساس تاریخ محلی میلادیِ همون Timezone)."""
    return resolved.now.strftime("%Y-%m-%d")
