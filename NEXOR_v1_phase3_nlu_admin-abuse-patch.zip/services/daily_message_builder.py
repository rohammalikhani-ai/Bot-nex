# -*- coding: utf-8 -*-
"""
services/daily_message_builder.py

معماری مرکزی سیستم اطلاع‌رسانی روزانه، طبق اسپک:

    DailyMessageBuilder -> DateService + OccasionService + PriceService + NewsService

این ماژول تنها جایی است که منطق «ترکیب» (کدوم بخش فعاله، هدر تاریخ/مناسبت
کجا بره، چه چیزی از i18n خونده بشه) پیاده می‌شود؛ Handlerها (handlers/daily_notify.py)
فقط این توابع را صدا می‌زنند و پیام را می‌فرستند — هیچ منطقی در خود Handler
تکرار نمی‌شود.

هر دو تابع اصلی (build_price_message / build_news_message) هرگز Exception
بیرون نمی‌اندازند: در بدترین حالت None برمی‌گردانند (یعنی «چیزی برای ارسال
نیست»)، که Handler آن را به‌عنوان «این دور رد شو» تفسیر می‌کند، نه Crash.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

from i18n import tc, get_lang
from services import date_service, occasion_service, price_service, news_service
from services.price_providers import SUPPORTED_ASSETS, DEFAULT_ENABLED_ASSETS
from config import (
    DAILY_NOTIFY_DEFAULT_PRICE_HOUR, DAILY_NOTIFY_DEFAULT_PRICE_MINUTE,
    DAILY_NOTIFY_DEFAULT_NEWS_HOUR, DAILY_NOTIFY_DEFAULT_NEWS_MINUTE,
    DAILY_NOTIFY_MAX_SEEN_NEWS,
)
from repositories import store as db

logger = logging.getLogger(__name__)

# واحدهایی که PriceQuote.unit می‌تونه داشته باشه -> کلید i18n برچسب واحد.
_UNIT_LABEL_KEYS = {
    "toman": "unit_toman",
    "usd": "unit_usd",
}

_ASSET_LABEL_KEYS = {
    "gold18": "asset_gold18",
    "usd": "asset_usd",
    "eur": "asset_eur",
    "usdt": "asset_usdt",
    "ton": "asset_ton",
    "stars": "asset_stars",
    "btc": "asset_btc",
    "eth": "asset_eth",
}


def asset_label_key(asset: str) -> str:
    """کلید i18n برچسب نمایشی یک asset_code — برای استفاده در Handlerها هم
    (منوی تنظیمات) بدون دسترسی مستقیم به دیکشنری داخلی این ماژول."""
    return _ASSET_LABEL_KEYS.get(asset, asset)


def default_config() -> dict:
    return {
        "prices_enabled": False,
        "news_enabled": False,
        "assets": list(DEFAULT_ENABLED_ASSETS),
        "price_hour": DAILY_NOTIFY_DEFAULT_PRICE_HOUR,
        "price_minute": DAILY_NOTIFY_DEFAULT_PRICE_MINUTE,
        "news_hour": DAILY_NOTIFY_DEFAULT_NEWS_HOUR,
        "news_minute": DAILY_NOTIFY_DEFAULT_NEWS_MINUTE,
        "timezone": None,  # None => DateService از پیش‌فرض زبان استفاده می‌کنه
        "date_before_price": True,
        "occasion_before_price": True,
        "date_before_news": True,
        "occasion_before_news": True,
        "last_price_sent_day": None,
        "last_news_sent_day": None,
        "seen_news_fingerprints": [],
    }


def get_config(chat_id: int) -> dict:
    """تنظیمات فعلی گروه را با پیش‌فرض‌ها merge می‌کند (کلیدهای جدیدی که در
    یک نسخه‌ی بعدی اضافه بشن، برای گروه‌های قدیمی هم مقدار پیش‌فرض دارن)."""
    stored = db.get_daily_notify_config(chat_id)
    cfg = default_config()
    cfg.update(stored or {})
    # همیشه فقط asset های شناخته‌شده رو نگه دار (اگه یک asset از رده خارج شد).
    cfg["assets"] = [a for a in cfg.get("assets", []) if a in SUPPORTED_ASSETS]
    return cfg


def save_config(chat_id: int, cfg: dict) -> None:
    db.set_daily_notify_config(chat_id, cfg)


@dataclass
class BuildResult:
    text: Optional[str] = None
    day_key: Optional[str] = None
    new_fingerprints: list = field(default_factory=list)


def _occasion_header_lines(chat_id: int, lang: str, resolved, cfg: dict, prefix: str) -> list[str]:
    lines = []
    if cfg.get(f"date_before_{prefix}", True):
        lines.append(tc(chat_id, "daily_date_line", date=resolved.date_str))
    if cfg.get(f"occasion_before_{prefix}", True):
        try:
            occ = occasion_service.get_today_occasion(
                lang, resolved.now.year, resolved.now.month, resolved.now.day,
            )
        except Exception:
            logger.exception("DailyMessageBuilder: occasion lookup failed for chat %s", chat_id)
            occ = None
        if occ:
            lines.append(tc(chat_id, "daily_occasion_line", occasion=occ.name))
    return lines


def build_price_message(chat_id: int, force: bool = False) -> BuildResult:
    """force=True برای «ارسال آزمایشی» است: بدون توجه به فعال/غیرفعال بودن
    قیمت‌ها، پیام را می‌سازد (ولی وضعیتی در دیتابیس ثبت نمی‌کند)."""
    lang = get_lang(chat_id)
    cfg = get_config(chat_id)
    if not force and not cfg.get("prices_enabled"):
        return BuildResult()

    resolved = date_service.resolve_today(chat_id, lang, cfg.get("timezone"))
    assets = cfg.get("assets") or []
    quotes = []
    if assets:
        try:
            quotes = price_service.get_prices(assets)
        except Exception:
            logger.exception("DailyMessageBuilder: price_service failed for chat %s", chat_id)
            quotes = []

    if not quotes:
        # هیچ قیمت معتبری از هیچ Provider نیومد -> به‌جای پیام گمراه‌کننده،
        # اصلاً چیزی ارسال نمی‌شه.
        return BuildResult(day_key=date_service.day_key_str(resolved))

    lines = [tc(chat_id, "daily_price_header")]
    lines.extend(_occasion_header_lines(chat_id, lang, resolved, cfg, "price"))
    lines.append("")
    for quote in quotes:
        asset_label = tc(chat_id, _ASSET_LABEL_KEYS.get(quote.asset, quote.asset))
        unit_label = tc(chat_id, _UNIT_LABEL_KEYS.get(quote.unit, quote.unit))
        formatted_value = f"{quote.value:,.0f}" if quote.value >= 100 else f"{quote.value:,.2f}"
        lines.append(tc(chat_id, "daily_price_line", asset=asset_label, value=formatted_value, unit=unit_label))
    lines.append("")
    sources = sorted({q.source for q in quotes})
    lines.append(tc(chat_id, "daily_price_footer", sources=", ".join(sources)))

    return BuildResult(text="\n".join(lines), day_key=date_service.day_key_str(resolved))


def build_news_message(chat_id: int, force: bool = False) -> BuildResult:
    """force=True برای «ارسال آزمایشی» است: بدون توجه به فعال/غیرفعال بودن
    اخبار، پیام را می‌سازد (ولی fingerprintها را به‌عنوان دیده‌شده ثبت
    نمی‌کند تا ارسال واقعی بعدی همان خبر را حذف‌شده نبیند)."""
    lang = get_lang(chat_id)
    cfg = get_config(chat_id)
    if not force and not cfg.get("news_enabled"):
        return BuildResult()

    resolved = date_service.resolve_today(chat_id, lang, cfg.get("timezone"))
    already_seen = set(cfg.get("seen_news_fingerprints") or [])
    try:
        items = news_service.get_daily_news(lang, already_seen)
    except Exception:
        logger.exception("DailyMessageBuilder: news_service failed for chat %s", chat_id)
        items = []

    if not items:
        return BuildResult(day_key=date_service.day_key_str(resolved))

    lines = [tc(chat_id, "daily_news_header")]
    lines.extend(_occasion_header_lines(chat_id, lang, resolved, cfg, "news"))
    lines.append("")
    for idx, item in enumerate(items, start=1):
        title = news_service.summarize_if_needed(item.title, lang)
        summary = news_service.summarize_if_needed(item.summary, lang)
        lines.append(tc(chat_id, "daily_news_item", n=idx, title=title))
        if summary:
            lines.append(tc(chat_id, "daily_news_summary", summary=summary))
        lines.append(tc(chat_id, "daily_news_source", source=item.source))
        lines.append("")

    return BuildResult(
        text="\n".join(lines).rstrip(),
        day_key=date_service.day_key_str(resolved),
        new_fingerprints=[item.fingerprint for item in items],
    )


def record_price_sent(chat_id: int, day_key: str) -> None:
    cfg = get_config(chat_id)
    cfg["last_price_sent_day"] = day_key
    save_config(chat_id, cfg)


def record_news_sent(chat_id: int, day_key: str, new_fingerprints: list[str]) -> None:
    cfg = get_config(chat_id)
    cfg["last_news_sent_day"] = day_key
    seen = list(cfg.get("seen_news_fingerprints") or [])
    for fp in new_fingerprints:
        if fp not in seen:
            seen.append(fp)
    if len(seen) > DAILY_NOTIFY_MAX_SEEN_NEWS:
        seen = seen[-DAILY_NOTIFY_MAX_SEEN_NEWS:]
    cfg["seen_news_fingerprints"] = seen
    save_config(chat_id, cfg)
