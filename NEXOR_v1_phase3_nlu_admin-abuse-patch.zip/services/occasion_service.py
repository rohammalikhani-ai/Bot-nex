# -*- coding: utf-8 -*-
"""
services/occasion_service.py

بخشی از معماری DailyMessageBuilder. مسئولیت: «آیا امروز مناسبت شناخته‌شده‌ای
از یک منبع معتبر ثبت شده یا نه؟»

منبع: Nager.Date (https://date.nager.at) — یک API عمومی، رایگان، بدون نیاز
به API Key، برای تعطیلات/مناسبت‌های رسمی بیش از ۱۰۰ کشور. کشور بر اساس زبان
گروه map می‌شود (COUNTRY_BY_LANG). این یک تصمیم ساده و قابل‌گسترش است: اگر
بعداً بخواهید کشور دقیق‌تری برای یک گروه خاص تنظیم کنید، همین‌جا (یا با یک
تنظیم Per-Group جدید) قابل افزودن است.

قانون طلایی طبق اسپک: «مناسبت فقط از منبع معتبر؛ اگر چیزی وجود ندارد نمایش
داده نشود.» یعنی هر خطا (شبکه/Timeout/عدم تطبیق تاریخ) => None، هرگز مقدار
ساختگی یا حدسی.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Optional

import requests

logger = logging.getLogger(__name__)

NAGER_BASE_URL = "https://date.nager.at/api/v3/publicholidays"
REQUEST_TIMEOUT_SECONDS = 8

# نگاشت زبان گروه -> کد کشور ISO-3166 برای Nager.Date. این یک پیش‌فرض معقول
# است (هر زبان اصلی‌ترین کشور مرتبط)؛ اگر یک گروه مشخص کشور متفاوتی بخواهد،
# نقطه‌ی گسترش طبیعی این است که بعداً یک تنظیم Per-Group "country" اضافه شود.
COUNTRY_BY_LANG = {
    "fa": "IR",
    "en": "US",
    "ar": "SA",
    "tr": "TR",
    "ru": "RU",
    "es": "ES",
}

# کش بسیار ساده‌ی در-حافظه به ازای (کشور، سال) تا اسکجول روزانه‌ی هر گروه
# مجبور نباشد برای هر گروه/هر بار یک Request جدا بزند (بسیاری از گروه‌ها
# زبان/کشور مشترک دارند). عمداً پیچیده (TTL/LRU) نشده — طول عمر پردازش کافیست
# چون هر روز حداکثر یک بار در ابتدای کار برای هر کشور واکشی می‌شود.
_cache: dict[tuple[str, int], tuple[float, Optional[dict]]] = {}
_CACHE_TTL_SECONDS = 6 * 3600


@dataclass
class Occasion:
    name: str
    source: str = "Nager.Date"


def _fetch_year_holidays(country_code: str, year: int) -> Optional[list[dict]]:
    cache_key = (country_code, year)
    cached = _cache.get(cache_key)
    now = time.time()
    if cached and (now - cached[0]) < _CACHE_TTL_SECONDS:
        return cached[1]

    try:
        resp = requests.get(f"{NAGER_BASE_URL}/{year}/{country_code}", timeout=REQUEST_TIMEOUT_SECONDS)
        resp.raise_for_status()
        data = resp.json()
        if not isinstance(data, list):
            raise ValueError("unexpected Nager.Date response shape")
        _cache[cache_key] = (now, data)
        return data
    except Exception:
        logger.warning("OccasionService: Nager.Date fetch failed for %s/%s", country_code, year, exc_info=True)
        _cache[cache_key] = (now, None)
        return None


def get_today_occasion(lang: str, year: int, month: int, day: int) -> Optional[Occasion]:
    """مناسبت امروز (تاریخ میلادی، چون Nager.Date روی تقویم میلادی کار
    می‌کند) را برای زبان/کشور مرتبط برمی‌گرداند؛ اگر چیزی پیدا نشود یا
    Provider در دسترس نباشد، None (هرگز مقدار جعلی)."""
    country_code = COUNTRY_BY_LANG.get(lang)
    if not country_code:
        return None

    holidays = _fetch_year_holidays(country_code, year)
    if not holidays:
        return None

    target = f"{year:04d}-{month:02d}-{day:02d}"
    for item in holidays:
        try:
            if item.get("date") != target:
                continue
            name = (item.get("localName") or item.get("name") or "").strip()
            if not name:
                continue
            return Occasion(name=name)
        except (AttributeError, TypeError):
            continue
    return None
