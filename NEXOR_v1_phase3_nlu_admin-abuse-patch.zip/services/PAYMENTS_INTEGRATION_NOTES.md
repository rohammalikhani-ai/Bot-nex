# یادداشت داخلی توسعه‌دهنده — زیرساخت پرداخت (⭐ Stars / 💎 TON / 💳 کارت)

این فایل فقط برای توسعه‌دهنده است، در ربات به کاربر نمایش داده نمی‌شود.

## وضعیت فعلی

زیرساخت کامل خرید اشتراک (ارتقای پلن AI Copilot به `pro`/`premium`) با سه
روش پرداخت پیاده‌سازی شده، اما **عمداً به هیچ دستور/دکمه/منویی وصل نیست**:

- `db.py` → جدول `subscription_orders` + توابع CRUD خام.
- `repositories/store.py` → همون توابع را export می‌کند.
- `services/payments.py` → قیمت‌گذاری، ساخت سفارش، اعمال پلن بعد از تایید.
- `services/ton_wallet.py` → تطبیق تراکنش‌های TON (مثل nationbot).
- `handlers/payments.py` → توابع Telegram (send_invoice، pre_checkout،
  successful_payment، پیام‌های راهنمای TON/کارت، تایید/رد ادمین برای کارت).

هیچ‌کدام از این‌ها در `handlers/registry.py`، `core/menus.py` یا
`core/bootstrap.py` رجیستر نشده‌اند، پس فعلاً از هیچ کجای ربات قابل‌دسترسی
نیستند.

## برای فعال‌سازی (وقتی آماده بودید)

1. **متغیرهای محیطی** را در `.env` تنظیم کنید (هرکدام خالی بمونه، همون روش
   غیرفعال می‌مونه):
   - `TON_WALLET_ADDRESS`, `TONCENTER_API_KEY` (اختیاری)
   - `NEXOR_CARD_NUMBER`, `NEXOR_CARD_HOLDER`
   - `NEXOR_PRICE_STARS_PRO`, `NEXOR_PRICE_STARS_PREMIUM`
   - `NEXOR_PRICE_TON_PRO`, `NEXOR_PRICE_TON_PREMIUM`
   - `NEXOR_PRICE_CARD_PRO`, `NEXOR_PRICE_CARD_PREMIUM`

2. **دستور خرید** — یک `CommandHandler` جدید (مثلاً `/buyplan`) در
   `handlers/registry.py` اضافه کنید که کیبورد انتخاب پلن/روش پرداخت را نشان
   دهد و بر اساس انتخاب کاربر یکی از این‌ها را صدا بزند:
   - `handlers.payments.send_plan_invoice_stars(...)`
   - `handlers.payments.start_ton_purchase(...)`
   - `handlers.payments.start_card_purchase(...)`
   حتماً `"buyplan"` را به `RESERVED_COMMAND_NAMES` در `config.py` هم اضافه
   کنید (مثل بقیه‌ی دستورهای اصلی).

3. **Stars**: در `register_message_pipelines` (یا مستقیم در
   `register_all`)، دو هندلر ثبت کنید:
   ```python
   app.add_handler(PreCheckoutQueryHandler(payments.stars_precheckout_callback))
   app.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, payments.stars_successful_payment_callback))
   ```

4. **TON**: در `core/bootstrap.py`، یک Job دوره‌ای اضافه کنید (هم‌الگو با
   `errors.healthcheck_job`):
   ```python
   if app.job_queue:
       app.job_queue.run_repeating(payments.ton_check_job, interval=120, first=60)
   ```

5. **کارت‌به‌کارت**: چون تایید نهایی همیشه دستی است، یک دستور ادمین (مثلاً
   `/cardorders`, `/confirmcard <id>`, `/rejectcard <id>`) اضافه کنید که به
   `handlers.payments.admin_list_pending_card_orders` /
   `admin_confirm_card_order` / `admin_reject_card_order` وصل شود.

6. اگر خواستید قیمت از پنل ادمین هم قابل‌تغییر باشد (مثل `shop.py` در
   nationbot)، یک لایه‌ی نازک روی `db.get_setting`/`set_setting` جلوی
   `services.payments.price_stars/price_ton/price_card_toman` اضافه کنید؛
   ساختار جدول از الان آماده‌ی این افزونه است، چیزی در schema عوض نمی‌شود.

7. `requirements.txt` از قبل `requests` را برای `services/ton_wallet.py`
   اضافه دارد.

## نکته تست

`services/payments.py` و `services/ton_wallet.py` هیچ وابستگی مستقیم به
`telegram` ندارند (فقط `handlers/payments.py` دارد) — پس منطق قیمت‌گذاری/
تطبیق/idempotency را می‌شود بدون نیاز به python-telegram-bot تست کرد، دقیقاً
مثل الگوی تست‌شده در nationbot (`match_transactions` بدون نیاز به شبکه).
