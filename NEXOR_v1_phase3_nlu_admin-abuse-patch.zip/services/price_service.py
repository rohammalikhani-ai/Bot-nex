# -*- coding: utf-8 -*-
"""
services/price_service.py

لایه‌ی هماهنگ‌کننده‌ی Providerها (بخش 💰 قیمت‌ها). قوانین اسپک:
  - فقط از API/Provider معتبر؛ هیچ مقدار جعلی.
  - معماری Provider-Based با Fallback و Error Handling.
  - هیچ‌وقت از AI برای قیمت‌ها استفاده نمی‌شود.

`get_prices` هرگز Exception بیرون نمی‌اندازد؛ اگر همه‌ی Providerها Down
باشند، فقط لیست خالی برمی‌گرداند (و DailyMessageBuilder در آن صورت پیام
قیمت را اصلاً ارسال نمی‌کند — به‌جای فرستادن پیام گمراه‌کننده).
"""
from __future__ import annotations

import logging

from services.price_providers import ALL_PROVIDERS, PriceQuote

logger = logging.getLogger(__name__)


def get_prices(assets: list[str]) -> list[PriceQuote]:
    """برای لیست asset_codeهای درخواستی، هر Provider را (مستقل و ایزوله) صدا
    می‌زند و نتایج را ترکیب می‌کند. اگر چند Provider بتوانند یک Asset را
    پاسخ دهند، اولین Providerِ موفق در ALL_PROVIDERS برنده است (Fallback)."""
    if not assets:
        return []

    remaining = list(dict.fromkeys(assets))  # حفظ ترتیب، حذف تکراری
    collected: dict[str, PriceQuote] = {}

    for provider in ALL_PROVIDERS:
        if not remaining:
            break
        try:
            if not provider.enabled():
                continue
            quotes = provider.fetch(remaining)
        except Exception:
            # یک Provider خراب هرگز نباید بقیه را متوقف کند یا ربات را Crash کند.
            logger.exception("PriceService: provider %s raised unexpectedly", getattr(provider, "name", provider))
            continue
        for asset, quote in (quotes or {}).items():
            if asset in remaining:
                collected[asset] = quote
                remaining.remove(asset)

    # ترتیب خروجی را مطابق ترتیب درخواستی اصلی نگه می‌داریم (برای نمایش پایدار)
    # ولی خودِ خروجی هم باید مثل ورودیِ dedupe‌شده یکتا باشد (هر Asset فقط یک‌بار).
    return [collected[a] for a in dict.fromkeys(assets) if a in collected]
