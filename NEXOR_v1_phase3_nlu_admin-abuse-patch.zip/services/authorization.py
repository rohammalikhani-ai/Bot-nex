"""Pure business authorization facade used by Telegram handlers."""
from __future__ import annotations  # keep set[str]/int | None hints working on Python < 3.9/3.10

from security_policy import can_target, effective_rank, has_required_capability

__all__ = ["authorize", "can_target", "effective_rank", "has_required_capability"]


def authorize(actual_rank: int, target_rank: int | None, capabilities: set[str],
              capability: str, minimum_rank: int, delegated_rank: int = 1) -> bool:
    """Check capability and, when supplied, target hierarchy."""
    if not has_required_capability(actual_rank, capabilities, capability, minimum_rank):
        return False
    if target_rank is None:
        return True
    effective = effective_rank(actual_rank, capabilities, capability, minimum_rank, delegated_rank)
    return can_target(effective, target_rank)
