# -*- coding: utf-8 -*-
"""
services/news_service.py

بخش 📰 اخبار سیستم اطلاع‌رسانی روزانه.

منبع: RSS رسمی BBC برای هر زبان (BBC برای هر ۶ زبان پشتیبانی‌شده‌ی NEXOR
نسخه‌ی زبانی معتبر و شناخته‌شده دارد؛ یعنی نیازی به ترجمه‌ی ماشینی نیست —
خبر همان زبان از منبع اصلی گرفته می‌شود). RSS با کتابخانه‌ی استاندارد پایتون
(xml.etree) پارس می‌شود تا هیچ وابستگی جدیدی (مثل feedparser) به
requirements.txt اضافه نشود.

قوانین اسپک:
  - روزانه حدود ۵ خبر مهم و جدید.
  - حذف اخبار تکراری (هم داخل یک دسته، هم نسبت به آنچه قبلاً برای همان گروه
    فرستاده شده).
  - نمایش عنوان، خلاصه، منبع.
  - AI فقط در صورت نیاز (خلاصه‌سازی/ترجمه/رتبه‌بندی) — این پیاده‌سازی برای
    هر ۶ زبان منبع زبانی مستقیم دارد، پس در حالت پیش‌فرض اصلاً به AI نیاز
    نیست؛ نقطه‌ی گسترش summarize_if_needed برای آینده (وقتی یک زبان منبع
    مستقیم نداشته باشد) نگه داشته شده، ولی فعلاً هیچ‌جا صدا زده نمی‌شود.
"""
from __future__ import annotations

import hashlib
import logging
import xml.etree.ElementTree as ET
from dataclasses import dataclass

import requests

logger = logging.getLogger(__name__)

REQUEST_TIMEOUT_SECONDS = 10
DEFAULT_NEWS_COUNT = 5
MAX_SUMMARY_CHARS = 280

# فیدهای رسمی RSS بی‌بی‌سی به ازای هر زبان پشتیبانی‌شده‌ی NEXOR.
FEEDS_BY_LANG = {
    "fa": ["https://feeds.bbci.co.uk/persian/rss.xml"],
    "en": ["https://feeds.bbci.co.uk/news/world/rss.xml"],
    "ar": ["https://feeds.bbci.co.uk/arabic/rss.xml"],
    "tr": ["https://feeds.bbci.co.uk/turkce/rss.xml"],
    "ru": ["https://feeds.bbci.co.uk/russian/rss.xml"],
    "es": ["https://feeds.bbci.co.uk/mundo/rss.xml"],
}


@dataclass
class NewsItem:
    title: str
    summary: str
    source: str
    link: str
    fingerprint: str  # برای dedupe بین‌روزی


def _clean_text(text: str) -> str:
    text = (text or "").strip()
    # بعضی فیدها HTML ساده داخل description می‌گذارند؛ برای امنیت/خوانایی
    # پیام تلگرام، تگ‌های ساده حذف می‌شوند (بدون نیاز به کتابخانه‌ی جدید).
    out = []
    inside_tag = False
    for ch in text:
        if ch == "<":
            inside_tag = True
            continue
        if ch == ">":
            inside_tag = False
            continue
        if not inside_tag:
            out.append(ch)
    cleaned = "".join(out).strip()
    if len(cleaned) > MAX_SUMMARY_CHARS:
        cleaned = cleaned[:MAX_SUMMARY_CHARS].rstrip() + "…"
    return cleaned


def _fingerprint(title: str, link: str) -> str:
    basis = (link or title or "").strip().lower()
    return hashlib.sha1(basis.encode("utf-8", errors="ignore")).hexdigest()


def _full_text(elem) -> str:
    """متن کامل یک Element را برمی‌گرداند، حتی اگر داخلش تگ HTML تودرتو
    باشد (مثلاً «Some <b>bold</b> text.»). elem.text/.findtext تنها متنِ
    قبل از اولین تگ فرزند را می‌دهند و باقیِ متن را بی‌صدا حذف می‌کنند؛
    itertext() تمام تکه‌های متنی (قبل/بین/بعد از تگ‌ها) را به‌ترتیب می‌دهد."""
    if elem is None:
        return ""
    return "".join(elem.itertext())


def _source_label(url: str) -> str:
    # همه‌ی فیدهای فعلی از BBC هستند؛ اگر بعداً منبع دیگری اضافه شود این
    # تابع همان‌جا باید نگاشت مربوطه را برگرداند.
    return "BBC"


def _parse_rss(xml_text: str, feed_url: str) -> list[NewsItem]:
    items: list[NewsItem] = []
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        logger.warning("NewsService: failed to parse RSS XML from %s", feed_url, exc_info=True)
        return items

    channel = root.find("channel")
    if channel is None:
        return items

    source_label = _source_label(feed_url)
    for item in channel.findall("item"):
        title = _clean_text(_full_text(item.find("title")))
        link = (item.findtext("link") or "").strip()
        summary = _clean_text(_full_text(item.find("description")))
        if not title:
            continue
        items.append(NewsItem(
            title=title, summary=summary, source=source_label, link=link,
            fingerprint=_fingerprint(title, link),
        ))
    return items


def _fetch_feed(url: str) -> list[NewsItem]:
    try:
        resp = requests.get(url, timeout=REQUEST_TIMEOUT_SECONDS, headers={"User-Agent": "NEXORBot/1.0"})
        resp.raise_for_status()
    except Exception:
        logger.warning("NewsService: request failed for feed %s", url, exc_info=True)
        return []
    return _parse_rss(resp.text, url)


def get_daily_news(lang: str, already_seen_fingerprints: set[str], limit: int = DEFAULT_NEWS_COUNT) -> list[NewsItem]:
    """حدود `limit` خبر جدید (که قبلاً برای این گروه فرستاده نشده) برمی‌گرداند.
    هرگز Exception بیرون نمی‌اندازد — در بدترین حالت لیست خالی (یعنی
    DailyMessageBuilder آن روز پیام خبر نمی‌فرستد به‌جای پیام گمراه‌کننده)."""
    feeds = FEEDS_BY_LANG.get(lang) or FEEDS_BY_LANG["en"]

    all_items: list[NewsItem] = []
    for feed_url in feeds:
        try:
            all_items.extend(_fetch_feed(feed_url))
        except Exception:
            logger.exception("NewsService: unexpected error fetching feed %s", feed_url)
            continue

    result: list[NewsItem] = []
    seen_this_batch: set[str] = set()
    for item in all_items:
        if item.fingerprint in seen_this_batch:
            continue  # تکراری داخل همین دسته
        if item.fingerprint in already_seen_fingerprints:
            continue  # قبلاً برای این گروه فرستاده شده
        seen_this_batch.add(item.fingerprint)
        result.append(item)
        if len(result) >= limit:
            break
    return result


def summarize_if_needed(text: str, lang: str) -> str:
    """نقطه‌ی گسترش برای خلاصه‌سازی/ترجمه با AI در آینده (وقتی یک زبان منبع
    مستقیم نداشته باشد). فعلاً چون هر ۶ زبان فید مستقیم دارند، هیچ AI صدا
    زده نمی‌شود — فقط متن (که خودش قبلاً کوتاه‌سازی شده) را برمی‌گرداند."""
    return text
