# -*- coding: utf-8 -*-
"""
services/ton_wallet.py

پرداخت با کیف‌پول TON برای خرید اشتراک pro/premium.

بر خلاف Telegram Stars، تاییدِ پرداخت TON از خودِ تلگرام نمی‌آد: کاربر باید
مبلغ مشخصی TON با یک memo (کامنت) یکتا به آدرس کیف‌پول پروژه واریز کنه؛ یک
Job دوره‌ای (periodic_ton_check، در handlers/payments.py صدا زده می‌شه، نه
اینجا) هر چند دقیقه تراکنش‌های تازه‌ی آدرس رو از toncenter می‌گیره، memo/مبلغ
رو با سفارش‌های pending تطبیق می‌ده و در صورت تطابق services.payments رو صدا
می‌زنه تا پلن رو فعال کنه.

منطق تطبیق (match_transactions) عمداً از فراخوانی شبکه جدا شده تا بدون نیاز
به اتصال اینترنت هم قابل تست باشه — دقیقاً هم‌الگو با nationbot/ton_wallet_service.py.

نکته: این ماژول فعلاً به هیچ Job/Handlerِ ثبت‌شده‌ای وصل نیست (نگاه کن به
services/PAYMENTS_INTEGRATION_NOTES.md).
"""
from __future__ import annotations

import logging
import secrets
from typing import List, Optional, Set, Tuple
from urllib.parse import quote

import requests

from config import (
    TON_WALLET_ADDRESS, TONCENTER_API_KEY, TONCENTER_BASE_URL,
    SUBSCRIPTION_TON_TOLERANCE_RATIO,
)

logger = logging.getLogger(__name__)

NANOTONS_PER_TON = 1_000_000_000


def ton_to_nano(amount_ton: float) -> int:
    return int(round(amount_ton * NANOTONS_PER_TON))


def nano_to_ton(amount_nano: int) -> float:
    return amount_nano / NANOTONS_PER_TON


def generate_memo(chat_id: int, user_id: int) -> str:
    """memo یکتا و کوتاه که کاربر باید دقیقاً همینو در فیلد کامنت واریزش بذاره.
    شامل chat_id/user_id هست تا حتی بدون دیتابیس هم قابل ردیابیه، به‌علاوه‌ی
    یک بخش تصادفی برای یکتایی بین چند سفارش."""
    return f"NX-{chat_id}-{user_id}-{secrets.token_hex(3)}"


def build_ton_transfer_link(address: str, amount_ton: float, memo: str) -> str:
    """لینک ton:// که اکثر کیف‌پول‌ها (Tonkeeper و…) مبلغ و کامنت رو خودکار پر می‌کنن."""
    amount_nano = ton_to_nano(amount_ton)
    return f"ton://transfer/{address}?amount={amount_nano}&text={quote(memo)}"


def fetch_recent_transactions(address: str, limit: int = 50) -> List[dict]:
    """آخرین تراکنش‌های ورودی آدرس کیف‌پول پروژه رو از toncenter می‌گیره.
    شبکه واقعاً اینجا صدا زده می‌شه؛ برای تست، match_transactions رو مستقیم
    با داده‌ی ساختگی صدا بزن، نه این تابع رو."""
    params = {"address": address, "limit": limit, "archival": "false"}
    headers = {}
    if TONCENTER_API_KEY:
        headers["X-API-Key"] = TONCENTER_API_KEY
    resp = requests.get(f"{TONCENTER_BASE_URL}/getTransactions", params=params, headers=headers, timeout=15)
    resp.raise_for_status()
    data = resp.json()
    if not data.get("ok"):
        raise RuntimeError(f"پاسخ نامعتبر از toncenter: {data}")
    return data.get("result", [])


def _extract_incoming(tx: dict) -> Optional[Tuple[str, int, str]]:
    """از یک آبجکت تراکنش toncenter (memo, مبلغ به نانوتون, هش تراکنش) رو
    استخراج می‌کنه. اگه تراکنش ورودی/قابل‌فهم نباشه None برمی‌گردونه."""
    in_msg = tx.get("in_msg") or {}
    value_raw = in_msg.get("value")
    if value_raw is None:
        return None
    try:
        value_nano = int(value_raw)
    except (TypeError, ValueError):
        return None
    if value_nano <= 0:
        return None
    memo = (in_msg.get("message") or "").strip()
    if not memo:
        return None
    tx_hash = (
        tx.get("transaction_id", {}).get("hash")
        or tx.get("hash")
        or f"{memo}:{value_nano}"  # نباید عملاً اتفاق بیفته؛ فقط محافظ در برابر KeyError
    )
    return memo, value_nano, tx_hash


def match_transactions(transactions: List[dict], pending_orders: List[dict]) -> List[dict]:
    """منطق اصلی تطبیق -- بدون شبکه، کاملاً قابل‌تست.

    transactions: خروجی خام toncenter (یا معادلش در تست).
    pending_orders: ردیف‌های subscription_orders با method='ton' و status='pending'
        (باید کلیدهای ton_memo, amount_ton_nano, id, chat_id, user_id, plan, months داشته باشن).

    خروجی: لیستی از dict با کلیدهای memo, tx_hash, order_id, chat_id, user_id,
    plan, months برای هر سفارشی که تطبیق پیدا کرد -- صدازننده باید برای هرکدوم
    db.confirm_ton_subscription_order رو صدا بزنه (که خودش idempotency رو تضمین می‌کنه).
    """
    pending_by_memo = {p["ton_memo"]: p for p in pending_orders if p.get("ton_memo")}
    matches: List[dict] = []
    seen_memos: Set[str] = set()
    for tx in transactions:
        extracted = _extract_incoming(tx)
        if not extracted:
            continue
        memo, value_nano, tx_hash = extracted
        if memo in seen_memos:
            continue  # از تطبیق دوباره‌ی همون memo با چند تراکنش جلوگیری می‌کنه
        order = pending_by_memo.get(memo)
        if not order:
            continue
        required = int(order["amount_ton_nano"])
        if value_nano < required * (1 - SUBSCRIPTION_TON_TOLERANCE_RATIO):
            logger.warning(
                "مبلغ ناکافی برای memo %s: دریافتی=%s نانوتون، موردنیاز=%s نانوتون",
                memo, value_nano, required,
            )
            continue
        seen_memos.add(memo)
        matches.append({
            "memo": memo,
            "tx_hash": tx_hash,
            "order_id": order["id"],
            "chat_id": order["chat_id"],
            "user_id": order["user_id"],
            "plan": order["plan"],
            "months": order["months"],
        })
    return matches
