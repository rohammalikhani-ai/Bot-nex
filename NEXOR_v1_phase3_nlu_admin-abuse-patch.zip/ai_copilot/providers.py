# -*- coding: utf-8 -*-
"""
Providerهای واقعی — یک پیاده‌سازی HTTP عمومی (فرمت رایج و سازگار با اکثر
APIهای رایگان/متن‌باز فعلی: چیزی شبیه OpenAI Chat Completions:
POST {base_url}/chat/completions  با بدنه‌ی {model, messages, max_tokens})
که سه بار جدا، یک‌بار به ازای هر پلن، با Configuration خودش نمونه‌سازی می‌شود.

جایگزینی بعدی API رایگان هر پلن با یک API پولی:
    فقط کافیه یک کلاس Provider جدید (یا همین GenericChatCompletionProvider با
    Base URL/Header متفاوت) بسازی و در _build_provider همون پلن رو صداش
    بزنی — service.py و هیچ Handler‌ای دست نمی‌خوره.

هیچ API Key‌ای در کد hardcode نشده؛ همه از Environment Variable خونده می‌شن:
    NEXOR_AI_FREE_API_KEY / NEXOR_AI_FREE_API_URL / NEXOR_AI_FREE_MODEL
    NEXOR_AI_PRO_API_KEY / NEXOR_AI_PRO_API_URL / NEXOR_AI_PRO_MODEL
    NEXOR_AI_PREMIUM_API_KEY / NEXOR_AI_PREMIUM_API_URL / NEXOR_AI_PREMIUM_MODEL
"""
from __future__ import annotations

import logging
import os

from config import AI_PLAN_FREE, AI_PLAN_PRO, AI_PLAN_PREMIUM, AI_PROVIDER_TIMEOUT_SECONDS
from ai_copilot.provider import AIProvider, AIProviderConfigError, AIProviderError

logger = logging.getLogger(__name__)

_ENV_PREFIX = {
    AI_PLAN_FREE: "NEXOR_AI_FREE",
    AI_PLAN_PRO: "NEXOR_AI_PRO",
    AI_PLAN_PREMIUM: "NEXOR_AI_PREMIUM",
}


class GenericChatCompletionProvider(AIProvider):
    """
    Provider عمومی برای هر API سازگار با فرمت رایج Chat Completions.
    Base URL/Key/Model کاملاً از بیرون (Environment) داده می‌شود؛ این کلاس
    هیچ فرضی درباره‌ی این‌که "کدوم" سرویسه نمی‌کند — دقیقاً همون Provider
    Interface مستقلی که برای جایگزینی بعدی با API پولی لازم است.
    """

    def __init__(self, name: str, base_url: str, api_key: str, model: str):
        self.name = name
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model

    async def complete(self, system_prompt: str, user_prompt: str, *, max_tokens: int = 700) -> str:
        try:
            import httpx  # وابستگی transitive از python-telegram-bot[job-queue]==21.4
        except ImportError as exc:  # pragma: no cover - محیط استاندارد پروژه httpx را همراه دارد
            raise AIProviderConfigError("httpx در دسترس نیست") from exc

        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "max_tokens": max_tokens,
            "temperature": 0.2,
        }
        url = f"{self.base_url}/chat/completions"
        try:
            async with httpx.AsyncClient(timeout=AI_PROVIDER_TIMEOUT_SECONDS) as client:
                resp = await client.post(url, headers=headers, json=payload)
        except httpx.TimeoutException as exc:
            raise AIProviderError(f"{self.name}: timeout") from exc
        except httpx.HTTPError as exc:
            raise AIProviderError(f"{self.name}: network error") from exc

        if resp.status_code >= 400:
            logger.warning("AI provider %s returned HTTP %s", self.name, resp.status_code)
            raise AIProviderError(f"{self.name}: HTTP {resp.status_code}")

        try:
            data = resp.json()
            return data["choices"][0]["message"]["content"]
        except (ValueError, KeyError, IndexError, TypeError) as exc:
            raise AIProviderError(f"{self.name}: unexpected response shape") from exc


_provider_cache: dict = {}


def _build_provider(plan: str) -> AIProvider:
    prefix = _ENV_PREFIX.get(plan)
    if prefix is None:
        raise AIProviderConfigError(f"unknown plan: {plan}")

    api_key = os.environ.get(f"{prefix}_API_KEY", "").strip()
    base_url = os.environ.get(f"{prefix}_API_URL", "").strip()
    model = os.environ.get(f"{prefix}_MODEL", "").strip()

    if not api_key or not base_url or not model:
        raise AIProviderConfigError(
            f"AI provider for plan '{plan}' is not configured "
            f"(set {prefix}_API_KEY, {prefix}_API_URL, {prefix}_MODEL in .env)"
        )
    return GenericChatCompletionProvider(name=plan, base_url=base_url, api_key=api_key, model=model)


def get_provider(plan: str) -> AIProvider:
    """
    Provider مربوط به یک پلن را برمی‌گرداند (Cache می‌شود). اگر Configure نشده
    باشد AIProviderConfigError می‌دهد — caller (service.py) این را می‌گیرد و
    پیام مناسب «فعلاً AI برای این گروه در دسترس نیست» را نشان می‌دهد، نه کرش.
    """
    if plan not in _provider_cache:
        _provider_cache[plan] = _build_provider(plan)
    return _provider_cache[plan]


def reset_provider_cache():
    """برای تست‌ها: بعد از تغییر Environment Variableها، Cache را خالی می‌کند."""
    _provider_cache.clear()
