# -*- coding: utf-8 -*-
"""
Provider Interface — قرارداد مستقل از هر API خاص.

هدف: بعداً بتوان API رایگان هر پلن را فقط با نوشتن/عوض‌کردن یک Provider جدید
(بدون تغییر ai_copilot/service.py یا هیچ Handler‌ای) با یک API پولی جایگزین
کرد. هر Provider باید فقط این یک متد را پیاده کند.
"""
from __future__ import annotations

from abc import ABC, abstractmethod


class AIProviderError(Exception):
    """خطای عمومی Provider (شبکه، Timeout، پاسخ نامعتبر، ...). Non-fatal برای ربات."""


class AIProviderConfigError(AIProviderError):
    """Provider این پلن اصلاً Configure نشده (API Key/URL در .env تنظیم نشده)."""


class AIProvider(ABC):
    """قرارداد یکسان برای Free/Pro/Premium Provider — و هر Provider پولی آینده."""

    name: str = "base"

    @abstractmethod
    async def complete(self, system_prompt: str, user_prompt: str, *, max_tokens: int = 700) -> str:
        """
        یک درخواست completion به مدل می‌فرستد و متن خام پاسخ را برمی‌گرداند.

        پیاده‌سازی‌ها باید:
        - در صورت نبود Configuration، AIProviderConfigError بدهند (نه crash).
        - در صورت خطای شبکه/Timeout/HTTP، AIProviderError بدهند.
        - هرگز Exception خام (ValueError/KeyError/...) به بیرون درز نکنند.
        """
        raise NotImplementedError
