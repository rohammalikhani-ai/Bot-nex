# -*- coding: utf-8 -*-
"""
NEXOR Copilot — ماژول مستقل AI برای کمک به ادمین/مدیران گروه.

این پکیج عمداً از بقیه‌ی پروژه جدا نگه داشته شده (طبق ARCHITECTURE.md):
    handlers/ai_copilot.py  →  ai_copilot.service  →  ai_copilot.providers  →  API خارجی

نکات معماری مهم:
- هیچ Handler‌ای مستقیماً به ai_copilot.providers وابسته نیست؛ همه از
  ai_copilot.service (که خودش Rate Limit، Plan، Provider و Logging را
  یک‌جا هماهنگ می‌کند) استفاده می‌کنند.
- این ماژول هرگز مستقیماً روی گروه Ban/Mute/Delete انجام نمی‌دهد و به
  services.authorization/security_policy دسترسی نداره؛ فقط یک
  Recommendation ساختاریافته برمی‌گرداند. اجرای واقعی همیشه از همون مسیر
  استاندارد authorize_action در handlers/common.py رد می‌شود.
- خطای Provider (Timeout/شبکه/پاسخ نامعتبر) هیچ‌وقت نباید به بیرون از
  ai_copilot.service درز کند؛ همیشه به یک نتیجه‌ی ساختاریافته با
  ok=False تبدیل می‌شود تا کرش ربات یا اختلال بقیه‌ی Featureها رخ ندهد.
"""
