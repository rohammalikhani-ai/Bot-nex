# -*- coding: utf-8 -*-
"""تبدیل خروجی ساختاریافته‌ی AI (dict) به متن نمایشی چندزبانه (i18n) برای تلگرام."""
from __future__ import annotations

from i18n import tc

_RISK_KEY = {"low": "ai_risk_low", "medium": "ai_risk_medium", "high": "ai_risk_high"}
_PRIORITY_KEY = {
    "high": "ai_priority_high", "suspicious": "ai_priority_suspicious",
    "low": "ai_priority_low", "false_report": "ai_priority_false",
}
_ACTION_KEY = {
    "none": "ai_action_none", "delete": "ai_action_delete", "warn": "ai_action_warn",
    "delete_warn": "ai_action_delete_warn", "mute": "ai_action_mute", "ban": "ai_action_ban",
}
_TREND_KEY = {"up": "ai_trend_up", "down": "ai_trend_down", "stable": "ai_trend_stable"}


def format_analyze_message(chat_id: int, result: dict) -> str:
    risk_label = tc(chat_id, _RISK_KEY.get(result.get("risk"), "ai_risk_medium"))
    action_label = tc(chat_id, _ACTION_KEY.get(
        (result.get("recommendation") or {}).get("action"), "ai_action_none"))
    reason = (result.get("recommendation") or {}).get("reason") or ""
    return tc(
        chat_id, "ai_analyze_message_result",
        risk=risk_label,
        spam=result.get("spam_pct", 0), ad=result.get("advertisement_pct", 0),
        suspicious=result.get("suspicious_pct", 0), toxic=result.get("toxic_pct", 0),
        summary=result.get("summary", ""), action=action_label, reason=reason,
    )


def format_explain_action(chat_id: int, result: dict) -> str:
    factors = result.get("key_factors") or []
    factors_text = "\n".join(f"• {f}" for f in factors) if factors else tc(chat_id, "none")
    return tc(chat_id, "ai_explain_result", explanation=result.get("explanation", ""), factors=factors_text)


def format_analyze_reports(chat_id: int, result: dict) -> str:
    items = result.get("items") or []
    lines = [tc(chat_id, "ai_reports_header")]
    for item in items:
        priority_label = tc(chat_id, _PRIORITY_KEY.get(item.get("priority"), "ai_priority_low"))
        lines.append(tc(chat_id, "ai_reports_item", id=item.get("id"), priority=priority_label,
                         reason=item.get("reason", "")))
    lines.append("")
    lines.append(tc(chat_id, "ai_reports_summary", summary=result.get("summary", "")))
    return "\n".join(lines)


def format_group_health(chat_id: int, result: dict) -> str:
    spam_label = tc(chat_id, _RISK_KEY.get(result.get("spam_level"), "ai_risk_low"))
    trend_label = tc(chat_id, _TREND_KEY.get(result.get("trend"), "ai_trend_stable"))
    risks = result.get("risks") or []
    risks_text = "\n".join(f"• {r}" for r in risks) if risks else tc(chat_id, "none")
    return tc(
        chat_id, "ai_health_result",
        spam_level=spam_label, trend=trend_label, risks=risks_text,
        recommendation=result.get("recommendation", ""),
    )


def format_rule_advisor(chat_id: int, result: dict) -> str:
    action_value = result.get("action_value") or ""
    action_text = f"{result.get('action_type')}:{action_value}" if action_value else result.get("action_type")
    return tc(
        chat_id, "ai_rule_advisor_result",
        trigger=f"{result.get('condition_type')}:{result.get('condition_value')}",
        action=action_text, scope=result.get("scope", ""), reason=result.get("reason", ""),
        confidence=result.get("confidence", 0),
    )


def format_rule_optimization(chat_id: int, result: dict) -> str:
    def _fmt_pairs(pairs):
        return ", ".join(f"#{a}↔#{b}" for a, b in pairs) if pairs else tc(chat_id, "none")

    def _fmt_ids(ids):
        return ", ".join(f"#{i}" for i in ids) if ids else tc(chat_id, "none")

    suggestions = result.get("suggestions") or []
    suggestions_text = "\n".join(f"• {s}" for s in suggestions) if suggestions else tc(chat_id, "none")
    return tc(
        chat_id, "ai_optimize_result",
        duplicates=_fmt_pairs(result.get("duplicates") or []),
        conflicts=_fmt_pairs(result.get("conflicts") or []),
        too_frequent=_fmt_ids(result.get("too_frequent") or []),
        dangerous=_fmt_ids(result.get("dangerous") or []),
        suggestions=suggestions_text,
    )


def format_incident_analysis(chat_id: int, result: dict) -> str:
    severity_label = tc(chat_id, _RISK_KEY.get(result.get("severity"), "ai_risk_medium"))
    timeline = result.get("timeline") or []
    timeline_text = "\n".join(f"• {t}" for t in timeline) if timeline else tc(chat_id, "none")
    return tc(
        chat_id, "ai_incident_result",
        summary=result.get("summary", ""), severity=severity_label,
        timeline=timeline_text, recommendation=result.get("recommendation", ""),
    )
