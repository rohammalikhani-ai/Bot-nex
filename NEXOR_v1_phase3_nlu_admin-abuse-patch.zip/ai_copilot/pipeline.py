# -*- coding: utf-8 -*-
"""
پیش‌فیلتر محلی و رایگان — طبق نکته‌ی هزینه در بریف پروژه:

    Telegram Message → Local/Rule-based checks → مشکوک یا درخواست ادمین؟
    → (بله) → AI API → Analysis

NEXOR Copilot با دستور صریح ادمین صدا زده می‌شود (نه خودکار روی هر پیام)،
پس اصل «AI فقط وقتی لازم است» به‌طور ساختاری رعایت می‌شود. این ماژول یک
لایه‌ی اضافه‌ی رایگان است: حتی وقتی ادمین صریحاً "Analyze Message" می‌زند،
اگر پیام آشکارا بی‌خطر باشد (خیلی کوتاه، بدون لینک/فوروارد، فقط متن ساده)
می‌توان بدون هزینه‌ی فراخوانی API یک نتیجه‌ی low-risk محلی داد؛ در غیر این
صورت باید حتماً از AI Provider استفاده شود.
"""
from __future__ import annotations

import re

from config import AI_PREFILTER_MIN_CHARS

_LINK_RE = re.compile(r"(https?://\S+|t\.me/\S+|www\.\S+|@\w{4,})", re.IGNORECASE)
_CAPS_RE = re.compile(r"[A-Z]{6,}")


def local_prefilter(*, text: str | None, is_forward: bool, is_new_member: bool) -> dict:
    """
    خروجی: {"needs_ai": bool, "local_risk": "low"|"unknown", "signals": [...]}

    "needs_ai" فقط یک پیشنهاد صرفه‌جویی است؛ handler همیشه اگر ادمین صریحاً
    خواسته باشد، صرف‌نظر از این پیشنهاد به سراغ AI می‌رود (این تابع هرگز یک
    درخواست صریح ادمین را رد نمی‌کند، فقط برچسب می‌زند).
    """
    text = (text or "").strip()
    signals = []

    if is_forward:
        signals.append("forward")
    if _LINK_RE.search(text):
        signals.append("link")
    if is_new_member:
        signals.append("new_member")
    if _CAPS_RE.search(text):
        signals.append("all_caps")
    if len(text) > 500:
        signals.append("long_text")

    if not signals and len(text) < AI_PREFILTER_MIN_CHARS:
        return {"needs_ai": False, "local_risk": "low", "signals": []}

    return {"needs_ai": True, "local_risk": "unknown", "signals": signals}
