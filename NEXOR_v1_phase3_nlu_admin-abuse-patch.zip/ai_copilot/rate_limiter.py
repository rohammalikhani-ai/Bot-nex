# -*- coding: utf-8 -*-
"""
Rate Limit روزانه به ازای (چت، کاربر)، متناسب با پلن گروه. مصرف در جدول
ai_usage_daily (db.py) نگه‌داری می‌شود؛ افزایش شمارنده اتمیک است (همون
الگوی cursor() با قفل threading.Lock که بقیه‌ی db.py استفاده می‌کند)، پس
دو درخواست هم‌زمان نمی‌تونن سقف رو دور بزنن.
"""
from __future__ import annotations

import time
from datetime import datetime, timezone

from repositories import store as db
from ai_copilot.plans import daily_limit_for


def _today() -> str:
    return datetime.fromtimestamp(time.time(), tz=timezone.utc).strftime("%Y-%m-%d")


def check_and_consume(chat_id: int, user_id: int, plan: str) -> tuple:
    """
    اگر هنوز زیر سقف روزانه بود، مصرف را یکی زیاد می‌کند و (True, remaining)
    برمی‌گرداند. اگر سقف پر شده بود، شمارنده را زیاد نمی‌کند و (False, 0)
    برمی‌گرداند.
    """
    limit = daily_limit_for(plan)
    if limit <= 0:
        return False, 0
    day = _today()
    current = db.ai_get_usage(chat_id, user_id, day)
    if current >= limit:
        return False, 0
    new_count = db.ai_increment_usage(chat_id, user_id, day)
    return True, max(0, limit - new_count)


def remaining_today(chat_id: int, user_id: int, plan: str) -> int:
    limit = daily_limit_for(plan)
    used = db.ai_get_usage(chat_id, user_id, _today())
    return max(0, limit - used)
