# -*- coding: utf-8 -*-
"""
تفکیک Free/Pro/Premium — AI در هر سه پلن فعال است (Free بدون AI نیست)؛ فقط
عمق/تعداد Featureها و سقف روزانه فرق می‌کند. پلن هر گروه در همون جدول settings
موجود ذخیره می‌شود (کلید "ai_plan") — چیز جدیدی به معماری Storage اضافه نمی‌شود.
"""
from __future__ import annotations

from repositories import store as db
from config import (
    AI_PLANS, DEFAULT_AI_PLAN, AI_PLAN_FEATURES, AI_DAILY_LIMITS,
)


def get_chat_plan(chat_id: int) -> str:
    plan = db.get_setting(chat_id, "ai_plan", DEFAULT_AI_PLAN)
    return plan if plan in AI_PLANS else DEFAULT_AI_PLAN


def set_chat_plan(chat_id: int, plan: str) -> bool:
    """
    فقط برای مدیریت دستی/تست است — اتصال واقعی به سیستم Subscription/Billing
    خارج از این پروژه انجام می‌شود؛ اینجا صرفاً یک مقدار Config است.
    """
    if plan not in AI_PLANS:
        return False
    db.set_setting(chat_id, "ai_plan", plan)
    return True


def plan_allows(plan: str, feature: str) -> bool:
    return feature in AI_PLAN_FEATURES.get(plan, set())


def daily_limit_for(plan: str) -> int:
    return AI_DAILY_LIMITS.get(plan, AI_DAILY_LIMITS[DEFAULT_AI_PLAN])


def features_for(plan: str) -> set:
    return set(AI_PLAN_FEATURES.get(plan, set()))
