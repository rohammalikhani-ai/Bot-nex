# -*- coding: utf-8 -*-
"""
Service Layer — تنها نقطه‌ای که Handlerها با آن کار دارند (طبق نکته‌ی معماری
«وابستگی مستقیم Handlerها به Providerهای AI ایجاد نکن»). هر Feature همین
مسیر مشترک را طی می‌کند:

    Plan اجازه می‌ده؟ → Rate Limit رد شده؟ → (پیش‌فیلتر محلی) → Provider →
    Parse JSON → Log → نتیجه‌ی ساختاریافته (هرگز Exception به بیرون درز نمی‌کند)

خروجی همیشه یک AIResult است؛ handlers/ai_copilot.py بر اساس result.ok و
result.error_code تصمیم می‌گیرد چه متنی (از i18n) نشان دهد.
"""
from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass
from typing import Any, Callable, Optional

from config import (
    AI_MAX_INPUT_CHARS, AI_FEATURE_ANALYZE_MESSAGE, AI_FEATURE_EXPLAIN_ACTION,
    AI_FEATURE_ANALYZE_REPORTS, AI_FEATURE_GROUP_HEALTH, AI_FEATURE_RULE_ADVISOR,
    AI_FEATURE_RULE_OPTIMIZATION, AI_FEATURE_INCIDENT_ANALYSIS, AI_FEATURE_INTERPRET_REQUEST,
    AUTO_ACTION_CONDITION_TYPES, AUTO_ACTION_MESSAGE_TYPES, AUTO_ACTION_USER_ROLES,
    AUTO_ACTION_TYPES,
)
from repositories import store as db
from i18n import get_lang, tc
from ai_copilot import providers, prompts, plans, rate_limiter, pipeline
from ai_copilot.provider import AIProviderConfigError, AIProviderError

logger = logging.getLogger(__name__)

_JSON_BLOCK_RE = re.compile(r"\{.*\}", re.DOTALL)


@dataclass
class AIResult:
    ok: bool
    data: Optional[dict] = None
    error_code: Optional[str] = None
    used_ai: bool = True
    remaining_today: Optional[int] = None


def _truncate(text: str) -> str:
    text = text or ""
    return text[:AI_MAX_INPUT_CHARS]


def _parse_json(raw: str) -> dict:
    match = _JSON_BLOCK_RE.search(raw or "")
    if not match:
        raise ValueError("no JSON object found in model output")
    return json.loads(match.group(0))


def _clamp_pct(value) -> int:
    try:
        v = int(value)
    except (TypeError, ValueError):
        return 0
    return max(0, min(100, v))


async def _run(chat_id: int, actor_id: int, feature: str, system_prompt: str, user_prompt: str,
                parse_fn: Callable[[dict], dict]) -> AIResult:
    plan = plans.get_chat_plan(chat_id)
    now = time.time()

    if not plans.plan_allows(plan, feature):
        db.ai_log_request(chat_id, actor_id, feature, plan, False, False, "plan_not_allowed", now)
        return AIResult(ok=False, error_code="plan_not_allowed")

    allowed, remaining = rate_limiter.check_and_consume(chat_id, actor_id, plan)
    if not allowed:
        db.ai_log_request(chat_id, actor_id, feature, plan, False, False, "rate_limited", now)
        return AIResult(ok=False, error_code="rate_limited", remaining_today=0)

    try:
        provider = providers.get_provider(plan)
    except AIProviderConfigError:
        db.ai_log_request(chat_id, actor_id, feature, plan, False, False, "not_configured", now)
        return AIResult(ok=False, error_code="not_configured", remaining_today=remaining)

    try:
        raw = await provider.complete(system_prompt, user_prompt)
        data = _parse_json(raw)
        parsed = parse_fn(data)
    except AIProviderError as exc:
        logger.warning("AI provider error for chat %s feature %s: %s", chat_id, feature, exc)
        db.ai_log_request(chat_id, actor_id, feature, plan, False, True, "provider_error", now)
        return AIResult(ok=False, error_code="provider_error", remaining_today=remaining)
    except (ValueError, TypeError, KeyError) as exc:
        logger.warning("AI response parse error for chat %s feature %s: %s", chat_id, feature, exc)
        db.ai_log_request(chat_id, actor_id, feature, plan, False, True, "bad_response", now)
        return AIResult(ok=False, error_code="bad_response", remaining_today=remaining)
    except Exception:  # noqa: BLE001 - safety net: an AI call must never crash the bot
        logger.exception("unexpected AI Copilot failure for chat %s feature %s", chat_id, feature)
        db.ai_log_request(chat_id, actor_id, feature, plan, False, True, "unknown_error", now)
        return AIResult(ok=False, error_code="unknown_error", remaining_today=remaining)

    db.ai_log_request(chat_id, actor_id, feature, plan, True, True, "", now)
    return AIResult(ok=True, data=parsed, remaining_today=remaining)


# ---------------- Feature 1: Analyze Message ----------------

def _parse_analyze_message(data: dict) -> dict:
    rec = data.get("recommendation") or {}
    return {
        "risk": data.get("risk") if data.get("risk") in ("low", "medium", "high") else "medium",
        "spam_pct": _clamp_pct(data.get("spam_pct")),
        "advertisement_pct": _clamp_pct(data.get("advertisement_pct")),
        "suspicious_pct": _clamp_pct(data.get("suspicious_pct")),
        "toxic_pct": _clamp_pct(data.get("toxic_pct")),
        "summary": str(data.get("summary", ""))[:500],
        "recommendation": {
            "action": rec.get("action") if rec.get("action") in
            ("none", "delete", "warn", "delete_warn", "mute", "ban") else "none",
            "reason": str(rec.get("reason", ""))[:300],
        },
    }


async def analyze_message(chat_id: int, actor_id: int, *, message_text: str, is_forward: bool,
                           has_link: bool, sender_warn_count: int, sender_is_new: bool) -> AIResult:
    local = pipeline.local_prefilter(text=message_text, is_forward=is_forward, is_new_member=sender_is_new)
    if not local["needs_ai"]:
        result = {
            "risk": "low", "spam_pct": 0, "advertisement_pct": 0, "suspicious_pct": 0, "toxic_pct": 0,
            "summary": tc(chat_id, "ai_local_summary_safe"),
            "recommendation": {"action": "none", "reason": tc(chat_id, "ai_local_reason_no_ai_needed")},
        }
        db.ai_log_request(chat_id, actor_id, AI_FEATURE_ANALYZE_MESSAGE, plans.get_chat_plan(chat_id),
                           True, False, "", time.time())
        return AIResult(ok=True, data=result, used_ai=False)

    lang = get_lang(chat_id)
    system, user = prompts.analyze_message_prompt(
        message_text=_truncate(message_text), is_forward=is_forward, has_link=has_link,
        sender_warn_count=sender_warn_count, sender_is_new=sender_is_new, lang=lang,
    )
    return await _run(chat_id, actor_id, AI_FEATURE_ANALYZE_MESSAGE, system, user, _parse_analyze_message)


# ---------------- Feature 2: Explain Moderation Action ----------------

def _parse_explain_action(data: dict) -> dict:
    factors = data.get("key_factors") or []
    if not isinstance(factors, list):
        factors = []
    return {
        "explanation": str(data.get("explanation", ""))[:800],
        "key_factors": [str(f)[:150] for f in factors[:8]],
    }


async def explain_action(chat_id: int, actor_id: int, *, target_name: str, warn_count: int,
                          recent_actions: list, active_rule: Optional[str], question: str) -> AIResult:
    system, user = prompts.explain_action_prompt(
        target_name=target_name, warn_count=warn_count, recent_actions=recent_actions,
        active_rule=active_rule, question=_truncate(question), lang=get_lang(chat_id),
    )
    return await _run(chat_id, actor_id, AI_FEATURE_EXPLAIN_ACTION, system, user, _parse_explain_action)


# ---------------- Feature 3: Analyze Reports ----------------

def _parse_analyze_reports(data: dict) -> dict:
    items = data.get("items") or []
    clean = []
    for item in items[:50]:
        if not isinstance(item, dict):
            continue
        priority = item.get("priority")
        if priority not in ("high", "suspicious", "low", "false_report"):
            priority = "low"
        clean.append({"id": item.get("id"), "priority": priority, "reason": str(item.get("reason", ""))[:200]})
    return {"items": clean, "summary": str(data.get("summary", ""))[:400]}


async def analyze_reports(chat_id: int, actor_id: int, *, reports: list) -> AIResult:
    system, user = prompts.analyze_reports_prompt(reports=reports[:20], lang=get_lang(chat_id))
    return await _run(chat_id, actor_id, AI_FEATURE_ANALYZE_REPORTS, system, user, _parse_analyze_reports)


# ---------------- Feature 4: Group Health ----------------

def _parse_group_health(data: dict) -> dict:
    risks = data.get("risks") or []
    if not isinstance(risks, list):
        risks = []
    return {
        "spam_level": data.get("spam_level") if data.get("spam_level") in ("low", "medium", "high") else "low",
        "trend": data.get("trend") if data.get("trend") in ("up", "down", "stable") else "stable",
        "risks": [str(r)[:150] for r in risks[:6]],
        "recommendation": str(data.get("recommendation", ""))[:400],
    }


async def group_health(chat_id: int, actor_id: int, *, stats: dict) -> AIResult:
    system, user = prompts.group_health_prompt(stats=stats, lang=get_lang(chat_id))
    return await _run(chat_id, actor_id, AI_FEATURE_GROUP_HEALTH, system, user, _parse_group_health)


# ---------------- Feature 5: Rule Advisor ----------------

def _parse_rule_advisor(data: dict) -> dict:
    ctype = data.get("condition_type")
    atype = data.get("action_type")
    return {
        "condition_type": ctype if ctype in AUTO_ACTION_CONDITION_TYPES else None,
        "condition_value": str(data.get("condition_value", ""))[:100],
        "action_type": atype if atype in AUTO_ACTION_TYPES else None,
        "action_value": str(data.get("action_value", ""))[:100],
        "scope": str(data.get("scope", ""))[:300],
        "reason": str(data.get("reason", ""))[:400],
        "confidence": _clamp_pct(data.get("confidence")),
    }


async def suggest_rule(chat_id: int, actor_id: int, *, admin_description: str) -> AIResult:
    system, user = prompts.rule_advisor_prompt(
        admin_description=_truncate(admin_description),
        condition_types=sorted(AUTO_ACTION_CONDITION_TYPES),
        action_types=sorted(AUTO_ACTION_TYPES),
        lang=get_lang(chat_id),
    )
    result = await _run(chat_id, actor_id, AI_FEATURE_RULE_ADVISOR, system, user, _parse_rule_advisor)
    if result.ok and result.data:
        ctype, cvalue = result.data["condition_type"], result.data["condition_value"]
        valid = ctype is not None and result.data["action_type"] is not None
        if valid and ctype == "message_type" and cvalue not in AUTO_ACTION_MESSAGE_TYPES:
            valid = False
        if valid and ctype == "user_role" and cvalue not in AUTO_ACTION_USER_ROLES:
            valid = False
        if valid and ctype == "warns_gte" and not cvalue.isdigit():
            valid = False
        result.data["is_valid"] = valid
    return result


# ---------------- Feature 6: Rule Optimization ----------------

def _parse_rule_optimization(data: dict) -> dict:
    def _pairs(raw):
        out = []
        for p in (raw or [])[:20]:
            if isinstance(p, (list, tuple)) and len(p) == 2:
                out.append((p[0], p[1]))
        return out

    def _ids(raw):
        return [i for i in (raw or [])[:20]]

    suggestions = data.get("suggestions") or []
    return {
        "duplicates": _pairs(data.get("duplicates")),
        "conflicts": _pairs(data.get("conflicts")),
        "too_frequent": _ids(data.get("too_frequent")),
        "dangerous": _ids(data.get("dangerous")),
        "suggestions": [str(s)[:200] for s in suggestions[:6]] if isinstance(suggestions, list) else [],
    }


async def optimize_rules(chat_id: int, actor_id: int, *, rules: list) -> AIResult:
    system, user = prompts.rule_optimization_prompt(rules=rules[:100], lang=get_lang(chat_id))
    return await _run(chat_id, actor_id, AI_FEATURE_RULE_OPTIMIZATION, system, user, _parse_rule_optimization)


# ---------------- Feature 7: Incident Analysis ----------------

def _parse_incident_analysis(data: dict) -> dict:
    timeline = data.get("timeline") or []
    return {
        "summary": str(data.get("summary", ""))[:800],
        "timeline": [str(t)[:200] for t in timeline[:15]] if isinstance(timeline, list) else [],
        "severity": data.get("severity") if data.get("severity") in ("low", "medium", "high") else "medium",
        "recommendation": str(data.get("recommendation", ""))[:400],
    }


async def analyze_incident(chat_id: int, actor_id: int, *, audit_lines: list, alert_lines: list) -> AIResult:
    system, user = prompts.incident_analysis_prompt(
        audit_lines=audit_lines, alert_lines=alert_lines, lang=get_lang(chat_id),
    )
    return await _run(chat_id, actor_id, AI_FEATURE_INCIDENT_ANALYSIS, system, user, _parse_incident_analysis)


# ---------------- Feature 8: Interpret Request (لایه‌ی سوم Smart Router) ----------------

def _parse_interpret_request(data: dict) -> dict:
    intent = data.get("intent")
    if not isinstance(intent, str) or not intent.strip():
        intent = None
    else:
        intent = intent.strip()
    return {"intent": intent, "confidence": _clamp_pct(data.get("confidence"))}


async def interpret_request(chat_id: int, actor_id: int, *, text: str, lang: str) -> AIResult:
    """فقط طبقه‌بندی می‌کند (کدوم intent از پیش‌موجود)، هیچ اکشنی اجرا نمی‌کند
    و entity استخراج نمی‌کند — اجرای واقعی همیشه از مسیر قطعی/تست‌شده‌ی
    handlers/natural_language.py رد می‌شود (بخش 23)."""
    from nlu.intent_parser import KNOWN_INTENTS  # import محلی: جلوگیری از وابستگی سطح-ماژول ai_copilot<->nlu
    system, user = prompts.interpret_request_prompt(
        text=_truncate(text), known_intents=list(KNOWN_INTENTS), lang=lang,
    )
    return await _run(chat_id, actor_id, AI_FEATURE_INTERPRET_REQUEST, system, user, _parse_interpret_request)
