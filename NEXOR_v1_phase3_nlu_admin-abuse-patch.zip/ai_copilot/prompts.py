# -*- coding: utf-8 -*-
"""
قالب‌های Prompt هر Feature. همه یک قانون مشترک دارند: مدل باید *فقط* یک
JSON معتبر با ساختار مشخص برگرداند (بدون توضیح اضافه، بدون Markdown) تا
ai_copilot/service.py بتواند آن را قابل‌اعتماد Parse کند. اگر مدل قالب را
رعایت نکند، service.py با خطای قابل‌کنترل fallback می‌کند (کرش نمی‌کند).

فقط داده‌ی لازم برای هر Feature ساخته و ارسال می‌شود (نه کل دیتابیس گروه)،
طبق الزام امنیتی «اطلاعات غیرضروری گروه به API ارسال نشود».

چندزبانگی: هر گروه یک زبان انتخابی دارد (i18n.get_lang). این ماژول همان
کد زبان (fa/en/ar/tr/ru/es) را می‌گیرد و به مدل دستور می‌دهد که تمام
فیلدهای متنی آزاد JSON (خلاصه/توضیح/دلیل/پیشنهاد/ریسک‌ها و...) را دقیقاً
به همان زبان بنویسد؛ ساختار خودِ JSON (کلیدها و enumها) همیشه ثابت و
انگلیسی می‌ماند تا service.py بتواند آن را Parse کند.
"""
from __future__ import annotations

# نام هر زبان به‌صورتی که مدل به‌وضوح آن را می‌شناسد (انگلیسی + نام بومی).
_LANG_NAMES = {
    "fa": "Persian/Farsi (فارسی)",
    "en": "English",
    "ar": "Arabic (العربية)",
    "tr": "Turkish (Türkçe)",
    "ru": "Russian (Русский)",
    "es": "Spanish (Español)",
}


def _lang_name(lang: str) -> str:
    return _LANG_NAMES.get(lang, _LANG_NAMES["fa"])


def _base_system(lang: str = "fa") -> str:
    return (
        "تو NEXOR Copilot هستی: دستیار هوش مصنوعی ادمین‌های یک گروه تلگرام. "
        "تو هیچ‌وقت مستقیماً کسی را بن/میوت/حذف نمی‌کنی؛ فقط تحلیل و پیشنهاد "
        "می‌دهی و تصمیم نهایی همیشه با خود ادمین است. "
        f"زبان انتخابی این گروه {_lang_name(lang)} است: تمام مقادیر متنی آزاد "
        "داخل JSON (خلاصه، توضیح، دلیل، پیشنهاد، ریسک‌ها و مشابه آن) را دقیقاً "
        f"به زبان {_lang_name(lang)} بنویس؛ ولی کلیدهای JSON و مقادیر enum "
        "(مثل risk/action/priority) را همیشه دقیقاً به همان شکل انگلیسیِ "
        "خواسته‌شده نگه‌دار. "
        "همیشه فقط یک شیء JSON معتبر و دقیقاً با ساختار خواسته‌شده برگردان؛ "
        "هیچ متن، توضیح یا ```markdown``` قبل یا بعد از JSON اضافه نکن."
    )


def analyze_message_prompt(*, message_text: str, is_forward: bool, has_link: bool,
                            sender_warn_count: int, sender_is_new: bool, lang: str = "fa") -> tuple:
    user = (
        "این پیام یک عضو گروه را از نظر Spam/تبلیغات/لینک مشکوک/محتوای "
        "توهین‌آمیز یا اسکم تحلیل کن.\n"
        f"متن پیام: {message_text!r}\n"
        f"فوروارد شده: {is_forward}\n"
        f"دارای لینک: {has_link}\n"
        f"تعداد اخطار قبلی فرستنده: {sender_warn_count}\n"
        f"عضو جدید (اخیراً پیوسته): {sender_is_new}\n\n"
        "دقیقاً با این ساختار JSON پاسخ بده:\n"
        "{\n"
        '  "risk": "low" | "medium" | "high",\n'
        '  "spam_pct": <0-100>,\n'
        '  "advertisement_pct": <0-100>,\n'
        '  "suspicious_pct": <0-100>,\n'
        '  "toxic_pct": <0-100>,\n'
        '  "summary": "<یک جمله کوتاه>",\n'
        '  "recommendation": {"action": "none" | "delete" | "warn" | "delete_warn" | "mute" | "ban", '
        '"reason": "<کوتاه>"}\n'
        "}"
    )
    return _base_system(lang), user


def explain_action_prompt(*, target_name: str, warn_count: int, recent_actions: list,
                           active_rule: str | None, question: str, lang: str = "fa") -> tuple:
    actions_text = "; ".join(recent_actions) if recent_actions else "موردی ثبت نشده"
    user = (
        "یک ادمین درباره‌ی یک اکشن مدیریتی که روی یک کاربر انجام شده سؤال کرده. "
        "فقط بر اساس داده‌های واقعی زیر (نه حدس) توضیح بده که چرا این اتفاق افتاده.\n"
        f"سؤال ادمین: {question!r}\n"
        f"نام کاربر هدف: {target_name}\n"
        f"تعداد اخطار فعلی: {warn_count}\n"
        f"آخرین اقدامات ثبت‌شده روی این کاربر: {actions_text}\n"
        f"قانون خودکار (Auto Action) فعال مرتبط: {active_rule or 'ندارد'}\n\n"
        "دقیقاً با این ساختار JSON پاسخ بده:\n"
        "{\n"
        '  "explanation": "<توضیح، ۲ تا ۴ جمله>",\n'
        '  "key_factors": ["<عامل ۱>", "<عامل ۲>"]\n'
        "}"
    )
    return _base_system(lang), user


def analyze_reports_prompt(*, reports: list, lang: str = "fa") -> tuple:
    lines = [
        f'- id={r["id"]}, reporter={r["reporter"]!r}, target={r["target"]!r}, reason={r["reason"]!r}'
        for r in reports
    ]
    user = (
        "این لیست گزارش‌های باز گروه است. هرکدام را دسته‌بندی کن.\n"
        + "\n".join(lines)
        + "\n\nدقیقاً با این ساختار JSON پاسخ بده:\n"
        "{\n"
        '  "items": [{"id": <int>, "priority": "high" | "suspicious" | "low" | "false_report", '
        '"reason": "<کوتاه>"}],\n'
        '  "summary": "<یک جمله کلی درباره‌ی مهم‌ترین موارد>"\n'
        "}"
    )
    return _base_system(lang), user


def group_health_prompt(*, stats: dict, lang: str = "fa") -> tuple:
    user = (
        "این آمار اخیر گروه است. وضعیت کلی سلامت گروه را ارزیابی کن.\n"
        f"پیام‌های حذف‌شده (اخیر): {stats.get('deleted', 0)}\n"
        f"اخطارها (اخیر): {stats.get('warns', 0)}\n"
        f"بن/میوت‌ها (اخیر): {stats.get('bans', 0)}\n"
        f"گزارش‌های باز: {stats.get('open_reports', 0)}\n"
        f"Alertهای امنیتی اخیر: {stats.get('security_alerts', 0)}\n"
        f"روند نسبت به بازه‌ی قبلی (تغییر تخلفات): {stats.get('trend_pct', 0)}%\n\n"
        "دقیقاً با این ساختار JSON پاسخ بده:\n"
        "{\n"
        '  "spam_level": "low" | "medium" | "high",\n'
        '  "trend": "up" | "down" | "stable",\n'
        '  "risks": ["<ریسک ۱>", "<ریسک ۲ (اختیاری)>"],\n'
        '  "recommendation": "<یک پیشنهاد عملی کوتاه>"\n'
        "}"
    )
    return _base_system(lang), user


def rule_advisor_prompt(*, admin_description: str, condition_types: list, action_types: list,
                         lang: str = "fa") -> tuple:
    user = (
        "یک ادمین این مشکل را توصیف کرده و می‌خواهد یک قانون خودکار (Auto Action Rule) "
        "پیشنهاد بگیرد. قانون باید فقط از نوع‌های زیر باشد (چون این‌ها تنها انواعی هستند "
        "که موتور Rule فعلی NEXOR پشتیبانی می‌کند):\n"
        f"condition_type مجاز: {condition_types}\n"
        f"action_type مجاز: {action_types}\n"
        f"توضیح ادمین: {admin_description!r}\n\n"
        "اگر مشکل توصیف‌شده اصلاً با این نوع‌ها قابل پوشش نیست، confidence را پایین بگذار "
        "و در reason توضیح بده که چرا. دقیقاً با این ساختار JSON پاسخ بده:\n"
        "{\n"
        '  "condition_type": "<یکی از condition_type مجاز>",\n'
        '  "condition_value": "<مقدار>",\n'
        '  "action_type": "<یکی از action_type مجاز>",\n'
        '  "action_value": "<مقدار یا رشته خالی>",\n'
        '  "scope": "<توضیح کوتاه دامنه‌ی اعمال>",\n'
        '  "reason": "<چرا این قانون پیشنهاد شد>",\n'
        '  "confidence": <0-100>\n'
        "}"
    )
    return _base_system(lang), user


def rule_optimization_prompt(*, rules: list, lang: str = "fa") -> tuple:
    lines = [
        f'- id={r["id"]}, condition={r["condition_type"]}:{r["condition_value"]}, '
        f'action={r["action_type"]}:{r["action_value"]}, fired_recently={r["fired_recently"]}'
        for r in rules
    ]
    user = (
        "این‌ها قوانین خودکار فعلی گروه هستند. مشکلات (تکراری، متناقض، بیش‌ازحد "
        "فعال، پیکربندی خطرناک) را پیدا کن.\n" + "\n".join(lines) + "\n\n"
        "دقیقاً با این ساختار JSON پاسخ بده:\n"
        "{\n"
        '  "duplicates": [[<id>, <id>]],\n'
        '  "conflicts": [[<id>, <id>]],\n'
        '  "too_frequent": [<id>],\n'
        '  "dangerous": [<id>],\n'
        '  "suggestions": ["<پیشنهاد کوتاه ۱>", "<پیشنهاد کوتاه ۲>"]\n'
        "}"
    )
    return _base_system(lang), user


def incident_analysis_prompt(*, audit_lines: list, alert_lines: list, lang: str = "fa") -> tuple:
    user = (
        "این رخدادهای اخیر گروه است (لاگ اقدامات مدیریتی + Alertهای امنیتی). "
        "یک خلاصه‌ی Incident بساز.\n"
        "لاگ اقدامات:\n" + "\n".join(audit_lines[:50])
        + "\n\nAlertها:\n" + "\n".join(alert_lines[:20])
        + "\n\nدقیقاً با این ساختار JSON پاسخ بده:\n"
        "{\n"
        '  "summary": "<خلاصه، ۲ تا ۴ جمله>",\n'
        '  "timeline": ["<رخداد ۱ با زمان تقریبی>", "<رخداد ۲>"],\n'
        '  "severity": "low" | "medium" | "high",\n'
        '  "recommendation": "<اقدام پیشنهادی بعدی>"\n'
        "}"
    )
    return _base_system(lang), user


def interpret_request_prompt(*, text: str, known_intents: list, lang: str = "fa") -> tuple:
    """لایه‌ی سوم Smart Router (بخش 6/7 پرامپت): وقتی لایه‌ی سریع/قطعی
    (nlu/intent_parser.py) یک پیام گروه را نشناخت، این prompt از AI فقط
    می‌خواهد پیام را به یکی از intentهای *از پیش موجود* map کند — نه اینکه
    خودش اکشنی انجام دهد یا capability جدیدی بسازد (بخش 23). AI فقط
    classifier است؛ اجرای واقعی، permission check، و confirmation همه در
    handlers/natural_language.py و با همان مسیر تست‌شده‌ی موجود انجام می‌شود.
    """
    intents_list = "\n".join(f"- {name}" for name in known_intents)
    user = (
        "این پیام یک عضو/ادمین گروه تلگرام است. فقط تشخیص بده منظورش کدام‌یک "
        "از این intentهای از پیش تعریف‌شده است (اگر هیچ‌کدام نبود، null بده؛ "
        "هیچ‌وقت حدس اجباری نزن):\n" + intents_list + "\n\n"
        f"متن پیام: {text!r}\n\n"
        "دقیقاً با این ساختار JSON پاسخ بده:\n"
        "{\n"
        '  "intent": "<یکی از نام‌های بالا>" | null,\n'
        '  "confidence": <0-100>\n'
        "}\n"
        "نکته: entities (مثل مدت‌زمان یا کلیدواژه) را استخراج نکن — فقط نام "
        "intent را مشخص کن؛ استخراج entity جای دیگری (با منطق قطعی) انجام می‌شود."
    )
    return _base_system(lang), user
