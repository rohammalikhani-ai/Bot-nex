# -*- coding: utf-8 -*-
import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.environ.get("BOT_TOKEN", "PUT_YOUR_TOKEN_HERE")

DB_PATH = os.environ.get("BOT_DB_PATH", "bot_data.sqlite3")

# آنتی‌فلاد
FLOOD_LIMIT = 5
FLOOD_WINDOW_SECONDS = 8
FLOOD_MUTE_MINUTES = 10

# اخطارها
MAX_WARNS = 3
# اکشن پیش‌فرض بعد از رسیدن به سقف اخطار: "mute" یا "ban" (قابل تنظیم per-group با /setwarnaction)
DEFAULT_WARN_ACTION = "ban"
DEFAULT_WARN_MUTE_MINUTES = 60

# ==================== Anti-Admin Abuse (Priority 7) ====================
# اگر یک actor (ادمین واقعی تلگرام یا Moderator داخلی) در یک بازه‌ی زمانی کوتاه
# تعداد غیرعادی اکشن مخرب (ban/mute/kick/warn) بزنه، به‌جای اینکه فقط منتظر
# بررسی دستی /logs بمونیم، بلافاصله یک Alert صادر می‌شه (از همون زیرساخت
# handlers/alerts.py) تا Owner فوراً بفهمه — چه اکانت ادمین هک شده باشه، چه
# سوءاستفاده‌ی عمدی. این هیچ‌وقت جلوی اکشن رو نمی‌گیره (چون از نظر Hierarchy
# مجازه)، فقط دیدِ فوری می‌ده. هر دو مقدار per-group هم قابل بازنویسی‌ان
# (با db.get_setting("admin_abuse_threshold"/"admin_abuse_window_minutes")).
ADMIN_ABUSE_ACTIONS = {"ban", "mute", "kick", "warn", "warn_escalate_mute", "warn_escalate_ban"}
ADMIN_ABUSE_WINDOW_MINUTES = 10
ADMIN_ABUSE_THRESHOLD = 6

# نقش‌های ربات (Hierarchy) — عدد بزرگ‌تر = دسترسی بیشتر
RANK_USER = 0
RANK_MODERATOR = 1
RANK_ADMIN = 2
RANK_OWNER = 3
RANK_LABELS = {RANK_USER: "کاربر", RANK_MODERATOR: "مدیر (Moderator)", RANK_ADMIN: "ادمین", RANK_OWNER: "مالک"}

# CAPTCHA
CAPTCHA_TIMEOUT_SECONDS = 180  # مهلت تایید عضو جدید (۳ دقیقه)

WELCOME_MESSAGE = "سلام {mention} عزیز، به {chat_title} خوش اومدی! 🌹\nبرای شروع، لطفاً روی دکمه زیر بزن تا تایید بشی."
GOODBYE_MESSAGE = "{name} از گروه خارج شد. 👋"

VALID_LOCKS = {
    "link", "invitelink", "channellink", "photo", "video", "sticker", "voice", "forward",
    # Priority 3 — Media Locks تکمیلی
    "gif", "video_note", "document", "poll",
}

# Forward Protection: قوانین انتخابی Allow/Block روی Source خاص (کانال/کاربر خاص)
# این مستقل از قفل کلی "forward" عمل می‌کند: یک Source بلاک‌شده همیشه حذف می‌شود
# حتی اگر قفل forward خاموش باشد، و یک Source مجازشده همیشه رد می‌شود حتی اگر قفل روشن باشد.
DEFAULT_FORWARD_ACTION = "delete"

# Mention Protection
DEFAULT_MENTION_LIMIT = 5              # چند @mention/text_mention در یک پیام = سوءاستفاده
DEFAULT_MENTION_ACTION = "delete"

# Anti-Spam: تشخیص پیام تکراری بین چند کاربر مختلف (Copy/Paste Raid)
SPAM_CROSS_USER_THRESHOLD = 3          # چند کاربر مختلف عین همون متن رو بفرستن
SPAM_CROSS_USER_WINDOW_SECONDS = 45    # در چه بازه‌ای
DEFAULT_DUPLICATE_CROSS_ACTION = "delete"

# اکشن‌های قابل تنظیم برای سیستم‌های امنیتی (delete/warn/mute/ban)
DEFAULT_SPAM_ACTION = "delete"
DEFAULT_FILTER_ACTION = "delete"
DEFAULT_FLOOD_ACTION = "mute"
AUTO_ACTION_MUTE_MINUTES = 30  # مدت سکوت پیش‌فرض وقتی اکشن خودکار "mute" باشه

# Anti-Spam: تشخیص پیام تکراری
SPAM_DUPLICATE_THRESHOLD = 3          # چند بار تکرار عین همون پیام
SPAM_DUPLICATE_WINDOW_SECONDS = 60    # در چه بازه‌ای
SPAM_NEWMEMBER_LINK_MINUTES = 10      # اگه عضو کمتر از این مدت قبل جوین شده و لینک بفرسته، مشکوکه

# Anti-Raid
DEFAULT_RAID_THRESHOLD = 8        # چند Join در بازه زیر = رید
DEFAULT_RAID_WINDOW_SECONDS = 30
DEFAULT_RAID_LOCKDOWN_MINUTES = 15

# شناسه عددی چت شما (owner) — خطاهای بحرانی ربات به این چت گزارش می‌شود.
# برای گرفتن شناسه خودتون، به @userinfobot تو تلگرام پیام بدید.
OWNER_ID = int(os.environ.get("OWNER_ID", "0"))

# Rate limiting برای ارسال پیام/پست (جلوگیری از خطای Too Many Requests تلگرام)
SEND_RETRY_MAX = 5          # حداکثر تعداد تلاش مجدد بعد از خطای flood
SEND_MIN_INTERVAL = 0.05    # حداقل فاصله بین دو ارسال پشت‌سرهم (ثانیه)

# Priority 4 — Custom Commands: نام‌های رزرو شده (نباید توسط ادمین بازنویسی بشن،
# چون قبلاً به‌عنوان دستور واقعی ربات ثبت شدن)
RESERVED_COMMAND_NAMES = {
    "start", "help", "settings",
    "warn", "unwarn", "warns", "setwarnaction", "setmaxwarns",
    "mute", "unmute", "ban", "unban", "kick", "del", "purge",
    "promote", "demote", "roles", "logs", "setlang",
    "lock", "unlock", "locks", "filter", "stopfilter", "filters",
    "setfilteraction", "allowword", "disallowword",
    "blockdomain", "unblockdomain", "allowdomain", "unallowdomain", "domains",
    "allowforward", "blockforward", "unruleforward", "forwardrules",
    "mentionprotection", "setmentionlimit", "setmentionaction",
    "antispam", "setspamaction", "dupcross", "setdupcross",
    "setflood", "setfloodaction",
    "antiraid", "setraidthreshold", "lockdown", "unlockchat",
    "captcha", "save", "get", "notes", "clear",
    "setchannel", "post", "schedulepost", "editpost", "delpost", "channelstats",
    "setlogchannel", "fnew", "fjoin", "fleave", "finfo", "fban", "funban",
    # Priority 4 خودش
    "setwelcomedelete", "setgoodbye", "resetgoodbye", "goodbye",
    "rules", "setrules", "clearrules",
    "addkeyword", "delkeyword", "keywords",
    "addcmd", "delcmd", "cmds",
    "schedulerecurring", "recurringposts", "delrecurring",
    "addautoaction", "delautoaction", "autoactions", "autoactiontoggle",
    # Priority 5
    "createprofile", "delprofile", "profiles", "assignprofile", "unassignprofile", "myperms",
    "report", "reports",
    "setalertchannel", "alerts",
    "exportsettings", "importsettings",
    # NEXOR Copilot (AI Module)
    "copilot", "aicheck", "aiexplain", "aireports", "aihealth",
    "airule", "aioptimize", "aiincident", "aiplan",
    # Payments
    "buyplan",
}

# Priority 4 — Scheduled Messages (Recurring): نگاشت نام روز هفته به عدد weekday
# پایتون‌تلگرام‌بات: Monday=0 ... Sunday=6 (مطابق JobQueue.run_daily days=)
WEEKDAY_NAMES = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}

# Priority 4 — Auto Actions Rule Engine
AUTO_ACTION_CONDITION_TYPES = {"message_type", "user_role", "warns_gte"}
AUTO_ACTION_MESSAGE_TYPES = {
    "photo", "video", "sticker", "voice", "gif", "video_note", "document", "poll", "forward", "link", "text",
}
AUTO_ACTION_USER_ROLES = {"user", "moderator", "admin"}
AUTO_ACTION_TYPES = {"delete", "warn", "mute", "ban", "kick"}

# ==================== Priority 5 — Professional Admin Tools ====================

# Item 25 — Permission Profiles: مجموعه‌ی قابلیت‌های قابل واگذاری به یک Profile
# سفارشی (مستقل از Hierarchy اصلی). این‌ها اکشن‌های حساسی هستند که Owner می‌تونه
# به یک کاربر (بدون ارتقای کامل به Moderator/Admin) واگذار کنه.
# نکته امنیتی: واگذاری این قابلیت‌ها هیچ‌وقت جایگزین چک Hierarchy نمی‌شه —
# can_act_on (actor باید rank بالاتر از target داشته باشه) همیشه علاوه بر این
# چک می‌شود؛ Permission Profile فقط "کدوم قابلیت‌ها" رو مشخص می‌کنه، نه اینکه
# Hierarchy رو دور بزنه.
CAPABILITIES = {
    "warn", "mute", "unmute", "ban", "unban", "kick",
    "delete", "purge", "lock", "filter", "reports", "notes", "broadcast",
}

# Item 26 — Reports
REPORT_COOLDOWN_SECONDS = 60  # یک کاربر روی یک پیام مشخص فقط هر این‌قدر یک‌بار می‌تونه Report بزنه

# Item 27 — Admin Alerts: انواع Alert (علاوه بر Raid که از قبل وجود داشت)
ALERT_TYPE_MULTI_REPORTS = "multiple_reports"
ALERT_TYPE_SUSPICIOUS = "suspicious_activity"
ALERT_TYPE_SECURITY = "security_event"
ALERT_TYPE_ABNORMAL = "abnormal_behavior"
MULTI_REPORT_THRESHOLD = 3            # چند Report مجزا روی یک کاربر در بازه‌ی زیر = Alert
MULTI_REPORT_WINDOW_SECONDS = 3600

# Item 28 — Import / Export Settings
SETTINGS_EXPORT_VERSION = 1

# ==================== NEXOR Copilot (AI Module) ====================
# نکته مهم: AI Copilot جایگزین Permission/Policy Engine فعلی نیست — فقط
# Recommendation تولید می‌کند؛ اجرای واقعی همیشه از همون authorize_action
# و مسیر تأیید صریح ادمین رد می‌شود (services/authorization.py، handlers/common.py).
#
# قابلیتی که با Permission Profile هم قابل واگذاریه (مثل "reports")، تا یک
# کاربر بدون ارتقای کامل به Moderator هم بتونه به Copilot دسترسی داشته باشه.
CAPABILITIES.add("ai_copilot")

# سه پلن مستقل، هرکدوم با API/Provider جدا (ai_copilot/providers.py).
AI_PLAN_FREE = "free"
AI_PLAN_PRO = "pro"
AI_PLAN_PREMIUM = "premium"
AI_PLANS = (AI_PLAN_FREE, AI_PLAN_PRO, AI_PLAN_PREMIUM)
DEFAULT_AI_PLAN = AI_PLAN_FREE

# قابلیت‌های هر بخش از NEXOR Copilot — با مقدار پیش‌فرض کد؛ اما کاملاً
# Configurable با متغیر محیطی هم هست (نگاه کن به ai_copilot/plans.py).
AI_FEATURE_ANALYZE_MESSAGE = "analyze_message"
AI_FEATURE_EXPLAIN_ACTION = "explain_action"
AI_FEATURE_ANALYZE_REPORTS = "analyze_reports"
AI_FEATURE_GROUP_HEALTH = "group_health"
AI_FEATURE_RULE_ADVISOR = "rule_advisor"
AI_FEATURE_RULE_OPTIMIZATION = "rule_optimization"
AI_FEATURE_INCIDENT_ANALYSIS = "incident_analysis"
AI_FEATURE_INTERPRET_REQUEST = "interpret_request"  # لایه‌ی سوم Smart Router (بخش 6/7) — nlu/

AI_PLAN_FEATURES = {
    AI_PLAN_FREE: {
        AI_FEATURE_ANALYZE_MESSAGE, AI_FEATURE_EXPLAIN_ACTION, AI_FEATURE_ANALYZE_REPORTS,
        AI_FEATURE_INTERPRET_REQUEST,
    },
    AI_PLAN_PRO: {
        AI_FEATURE_ANALYZE_MESSAGE, AI_FEATURE_EXPLAIN_ACTION, AI_FEATURE_ANALYZE_REPORTS,
        AI_FEATURE_GROUP_HEALTH, AI_FEATURE_RULE_OPTIMIZATION, AI_FEATURE_INCIDENT_ANALYSIS,
        AI_FEATURE_RULE_ADVISOR, AI_FEATURE_INTERPRET_REQUEST,
    },
    AI_PLAN_PREMIUM: {
        AI_FEATURE_ANALYZE_MESSAGE, AI_FEATURE_EXPLAIN_ACTION, AI_FEATURE_ANALYZE_REPORTS,
        AI_FEATURE_GROUP_HEALTH, AI_FEATURE_RULE_OPTIMIZATION, AI_FEATURE_INCIDENT_ANALYSIS,
        AI_FEATURE_RULE_ADVISOR, AI_FEATURE_INTERPRET_REQUEST,
    },
}

# محدودیت روزانه‌ی درخواست AI به ازای هر (چت، کاربر) — Configurable با env.
AI_DAILY_LIMIT_FREE = int(os.environ.get("NEXOR_AI_DAILY_LIMIT_FREE", "15"))
AI_DAILY_LIMIT_PRO = int(os.environ.get("NEXOR_AI_DAILY_LIMIT_PRO", "100"))
AI_DAILY_LIMIT_PREMIUM = int(os.environ.get("NEXOR_AI_DAILY_LIMIT_PREMIUM", "500"))
AI_DAILY_LIMITS = {
    AI_PLAN_FREE: AI_DAILY_LIMIT_FREE,
    AI_PLAN_PRO: AI_DAILY_LIMIT_PRO,
    AI_PLAN_PREMIUM: AI_DAILY_LIMIT_PREMIUM,
}

# سقف طول متنی که به AI Provider ارسال می‌شود (کنترل هزینه/امنیت — پیام‌های
# خیلی بلند بریده می‌شوند، هیچ‌وقت کامل داده‌ی غیرضروری گروه ارسال نمی‌شود).
AI_MAX_INPUT_CHARS = int(os.environ.get("NEXOR_AI_MAX_INPUT_CHARS", "2000"))
AI_MAX_ITEMS_PER_REQUEST = 20  # مثلاً حداکثر چند گزارش/چند سطر لاگ در یک درخواست تحلیل

# Timeout هر فراخوانی Provider (ثانیه) — تا یک API کند/بی‌پاسخ ربات را قفل نکند.
AI_PROVIDER_TIMEOUT_SECONDS = float(os.environ.get("NEXOR_AI_TIMEOUT_SECONDS", "20"))

# پیش از فراخوانی واقعی API، یک پیش‌فیلتر محلی (رایگان) تصمیم می‌گیرد که آیا
# اصلاً لازم است این پیام به AI ارسال شود یا می‌توان محلی جواب داد (کنترل هزینه).
AI_PREFILTER_MIN_CHARS = 8  # پیام‌های خیلی کوتاه‌تر از این، محلی low-risk اعلام می‌شن

# ==================== Payments / Subscriptions ====================
# زیرساخت پرداخت برای ارتقای پلن AI Copilot (pro/premium) با سه روش: Telegram
# Stars، کیف‌پول TON، و کارت‌به‌کارت دستی. عمداً هنوز به هیچ دستور/دکمه/منویی
# در ربات وصل نشده (نه در handlers/registry.py و نه در core/menus.py) — فقط
# زیرساخت (services/payments.py, services/ton_wallet.py, handlers/payments.py)
# آماده است تا در قدمی بعدی، آگاهانه، به رابط کاربری وصل بشه.

# قیمت پیش‌فرض هر پلن به ازای ۱ ماه (ادمین می‌تونه بعداً از تنظیمات override کنه،
# همون الگوی bot_settings که در nationbot/shop.py استفاده شده).
# ۱۵۰ استارز ≈ ۳ دلار (نرخ خرید Stars داخل اپ ≈ ۰.۰۲ دلار به ازای هر استارز).
SUBSCRIPTION_PRICE_STARS = {
    AI_PLAN_PRO: int(os.environ.get("NEXOR_PRICE_STARS_PRO", "150")),
    AI_PLAN_PREMIUM: int(os.environ.get("NEXOR_PRICE_STARS_PREMIUM", "350")),
}
# نرخ‌های زیر بر اساس قیمت TON در حدود شهریور ۱۴۰۵ (~$1.37) تنظیم شدن تا Pro
# تقریباً معادل همون ۳ دلاری بشه که پلن Stars هم داره (۱۵۰ استارز ≈ ۳ دلار).
# ⚠️ TON نوسان قیمتی زیادی داره؛ این عدد ثابت (بر خلاف Stars که دلاریه) هر
# چند وقت باید دستی بازبینی و آپدیت بشه، وگرنه با گذشت زمان قیمت واقعی دلاری
# سفارش‌ها می‌ره بالا/پایین.
SUBSCRIPTION_PRICE_TON = {
    AI_PLAN_PRO: float(os.environ.get("NEXOR_PRICE_TON_PRO", "2.2")),
    AI_PLAN_PREMIUM: float(os.environ.get("NEXOR_PRICE_TON_PREMIUM", "5.0")),
}
# مبلغ به تومان فقط برای نمایش در دستورالعمل کارت‌به‌کارت (تایید نهایی همیشه
# دستی و توسط ادمین است؛ این ربات خودش درگاه بانکی ندارد).
SUBSCRIPTION_PRICE_CARD_TOMAN = {
    AI_PLAN_PRO: int(os.environ.get("NEXOR_PRICE_CARD_PRO", "0")),
    AI_PLAN_PREMIUM: int(os.environ.get("NEXOR_PRICE_CARD_PREMIUM", "0")),
}

# کیف‌پول TON پروژه — اگه خالی بمونه، مسیر پرداخت TON غیرفعال می‌مونه.
TON_WALLET_ADDRESS = os.environ.get("TON_WALLET_ADDRESS", "").strip()
TONCENTER_API_KEY = os.environ.get("TONCENTER_API_KEY", "").strip()
TONCENTER_BASE_URL = os.environ.get("TONCENTER_BASE_URL", "https://toncenter.com/api/v2").rstrip("/")
# چون تلگرام برای TON تاییدی نمی‌فرسته، سفارش‌های واریزنشده بعد از این مدت expire می‌شن.
SUBSCRIPTION_TON_EXPIRY_HOURS = int(os.environ.get("NEXOR_TON_EXPIRY_HOURS", "6"))
SUBSCRIPTION_TON_TOLERANCE_RATIO = 0.02

# کارت‌به‌کارت دستی — اگه خالی بمونه، مسیر پرداخت با کارت غیرفعال می‌مونه.
SUBSCRIPTION_CARD_NUMBER = os.environ.get("NEXOR_CARD_NUMBER", "").strip()
SUBSCRIPTION_CARD_HOLDER = os.environ.get("NEXOR_CARD_HOLDER", "").strip()
# سفارش‌های کارتی که ادمین مدت‌ها تاییدشون نکنه، بعد از این مدت expire می‌شن.
SUBSCRIPTION_CARD_EXPIRY_HOURS = int(os.environ.get("NEXOR_CARD_EXPIRY_HOURS", "48"))

# ==================== Ads (سیستم تبلیغات) ====================
# فقط گروه‌هایی که پلن‌شون AI_PLAN_FREE است تبلیغ می‌بینند (زیر پیام‌های
# Copilot و در پست روزانه‌ای که داخل گروه‌های متصل به ربات ارسال می‌شود).
# پلن‌های Pro/Premium هیچ‌وقت تبلیغ نمی‌بینند — این همان مزیت "بدون تبلیغات"ـه
# که با ارتقای پلن به‌دست میاد (services/payments.py و همین قیمت‌گذاری بالا).
AD_VISIBLE_PLANS = {AI_PLAN_FREE}

# تبلیغ رایگان همیشه فقط روزی یک‌بار ارسال می‌شود (slot شماره ۱). تبلیغ خریداری‌شده
# می‌تواند بین ۱ تا ۵ بار در روز انتخاب شود؛ هرچه بیشتر، گران‌تر.
AD_MIN_TIMES_PER_DAY = 1
AD_MAX_TIMES_PER_DAY = 5
AD_DEFAULT_TIMES_PER_DAY = 1
# ساعت‌های ارسال هر Slot در روز (UTC ساعت سرور) — Slot اول همیشه همونیه که
# تبلیغ رایگان هم توش قرار می‌گیره.
AD_SLOT_HOURS = [7, 10, 13, 16, 19]

AD_DURATION_CHOICES_DAYS = [1, 3, 7]
AD_DEFAULT_DURATION_DAYS = 1

# قیمت پایه‌ی هر (روز × یک بار ارسال در روز) — قیمت نهایی = پایه × تعداد دفعات × مدت.
AD_BASE_PRICE_STARS_PER_DAY = int(os.environ.get("NEXOR_AD_PRICE_STARS_PER_DAY", "30"))
AD_BASE_PRICE_TON_PER_DAY = float(os.environ.get("NEXOR_AD_PRICE_TON_PER_DAY", "0.45"))

RESERVED_COMMAND_NAMES.update({
    "ads", "myads", "adadmin", "adstats",
})
CAPABILITIES.add("ads_admin")

# ==================== Daily Notify (سیستم اطلاع‌رسانی روزانه) ====================
# 💰 قیمت‌ها + 📰 اخبار + 📅 تاریخ/مناسبت، قابل‌تنظیم به ازای هر گروه.
# پیاده‌سازی: services/date_service.py + services/occasion_service.py +
# services/price_service.py + services/news_service.py، ترکیب‌شده در
# services/daily_message_builder.py و متصل به JobQueue موجود در
# handlers/daily_notify.py (هیچ Scheduler موازی جدیدی ساخته نشده).
DAILY_NOTIFY_DEFAULT_PRICE_HOUR = 9
DAILY_NOTIFY_DEFAULT_PRICE_MINUTE = 0
DAILY_NOTIFY_DEFAULT_NEWS_HOUR = 18
DAILY_NOTIFY_DEFAULT_NEWS_MINUTE = 0
DAILY_NOTIFY_MAX_SEEN_NEWS = 300  # حداکثر تعداد fingerprint خبر که به ازای هر گروه نگه داشته می‌شه (جلوگیری از رشد بی‌نهایت)

RESERVED_COMMAND_NAMES.update({
    "dailynotify", "setpricetime", "setnewstime", "setdailytz",
    "testdailyprice", "testdailynews", "dailyassets",
})

RESERVED_COMMAND_NAMES.update({"adminabuseprotection"})
